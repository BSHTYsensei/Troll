// RootHelper.swift
// Swift consolidation of TrollStore's root helper pipeline.
// The standalone RootHelper target must link libarchive and the existing fastPathSign/ChOma C implementation.
// EMBEDDED_ROOT_HELPER excludes those install-only backends for the persistence-helper target.

import Foundation
import Darwin
import ObjectiveC.runtime

// MARK: - Linked C dependencies

#if !EMBEDDED_ROOT_HELPER
@_silgen_name("archive_read_new") private func ts_archive_read_new() -> OpaquePointer?
@_silgen_name("archive_read_support_filter_all") private func ts_archive_read_support_filter_all(_ archive: OpaquePointer?) -> Int32
@_silgen_name("archive_read_support_format_all") private func ts_archive_read_support_format_all(_ archive: OpaquePointer?) -> Int32
@_silgen_name("archive_read_open_filename") private func ts_archive_read_open_filename(_ archive: OpaquePointer?, _ filename: UnsafePointer<CChar>?, _ blockSize: Int) -> Int32
@_silgen_name("archive_read_next_header") private func ts_archive_read_next_header(_ archive: OpaquePointer?, _ entry: UnsafeMutablePointer<OpaquePointer?>) -> Int32
@_silgen_name("archive_read_data") private func ts_archive_read_data(_ archive: OpaquePointer?, _ buffer: UnsafeMutableRawPointer?, _ length: Int) -> Int
@_silgen_name("archive_read_data_skip") private func ts_archive_read_data_skip(_ archive: OpaquePointer?) -> Int32
@_silgen_name("archive_read_free") private func ts_archive_read_free(_ archive: OpaquePointer?) -> Int32
@_silgen_name("archive_entry_pathname") private func ts_archive_entry_pathname(_ entry: OpaquePointer?) -> UnsafePointer<CChar>?
@_silgen_name("archive_entry_filetype") private func ts_archive_entry_filetype(_ entry: OpaquePointer?) -> UInt32
@_silgen_name("archive_entry_perm") private func ts_archive_entry_perm(_ entry: OpaquePointer?) -> UInt32
@_silgen_name("archive_entry_symlink") private func ts_archive_entry_symlink(_ entry: OpaquePointer?) -> UnsafePointer<CChar>?
@_silgen_name("archive_error_string") private func ts_archive_error_string(_ archive: OpaquePointer?) -> UnsafePointer<CChar>?

// This symbol is supplied by the original TrollStore fastPathSign / ChOma sources.
// It is the CoreTrust-bypass backend; ldid alone cannot replace this operation.
@_silgen_name("apply_coretrust_bypass") private func ts_apply_coretrust_bypass(_ path: UnsafePointer<CChar>) -> Int32

private let tsArchiveOK: Int32 = 0
private let tsArchiveEOF: Int32 = 1
private let tsFileTypeMask: UInt32 = 0o170000
private let tsFileTypeRegular: UInt32 = 0o100000
private let tsFileTypeDirectory: UInt32 = 0o040000
private let tsFileTypeSymlink: UInt32 = 0o120000
#endif

private let tsActiveMarker = "_TrollStore"
private let tsInactiveMarker = "_TrollStoreLite"
private let tsProtectedBundleID = "com.opa334.TrollStore"
private let tsSignatureVersion = 132352

@inline(__always) private func tsChmod(_ path: String, _ mode: mode_t) -> Int32 {
    path.withCString { chmod($0, mode) }
}
@inline(__always) private func tsChown(_ path: String, _ owner: uid_t, _ group: gid_t) -> Int32 {
    path.withCString { chown($0, owner, group) }
}
@inline(__always) private func tsRename(_ oldPath: String, _ newPath: String) -> Int32 {
    oldPath.withCString { oldCString in newPath.withCString { newCString in rename(oldCString, newCString) } }
}
@inline(__always) private func tsSymlink(_ target: String, _ path: String) -> Int32 {
    target.withCString { targetCString in path.withCString { pathCString in symlink(targetCString, pathCString) } }
}
@inline(__always) private func tsOpen(_ path: String, _ flags: Int32, _ mode: mode_t) -> Int32 {
    path.withCString { open($0, flags, mode) }
}

// MARK: - Process runner

public struct TSProcessResult {
    public let status: Int32
    public let output: String
}

public enum TSProcessRunner {
    /// Captures stdout and stderr through one pipe so a verbose child cannot deadlock
    /// by filling a second pipe while the parent waits.
    public static func run(_ executable: String, _ arguments: [String], outputLimit: Int = 2 * 1024 * 1024) -> TSProcessResult {
        guard FileManager.default.isExecutableFile(atPath: executable) else {
            return TSProcessResult(status: 127, output: "Executable not found or not executable: \(executable)")
        }

        var pipeFDs: [Int32] = [0, 0]
        guard pipe(&pipeFDs) == 0 else {
            return TSProcessResult(status: errno, output: "pipe() failed: \(String(cString: strerror(errno)))")
        }

        var actions = posix_spawn_file_actions_t()
        posix_spawn_file_actions_init(&actions)
        posix_spawn_file_actions_adddup2(&actions, pipeFDs[1], STDOUT_FILENO)
        posix_spawn_file_actions_adddup2(&actions, pipeFDs[1], STDERR_FILENO)
        posix_spawn_file_actions_addclose(&actions, pipeFDs[0])
        posix_spawn_file_actions_addclose(&actions, pipeFDs[1])

        let argvStrings = [executable] + arguments
        // posix_spawn requires a NULL-terminated argv array; omitting the sentinel can
        // make the child read past the Swift array and receive corrupted arguments.
        let argv: [UnsafeMutablePointer<CChar>?] = argvStrings.map { strdup($0) } + [nil]
        defer {
            for ptr in argv { if let ptr { free(ptr) } }
            posix_spawn_file_actions_destroy(&actions)
        }

        var pid = pid_t(0)
        let spawnStatus: Int32 = argv.withUnsafeMutableBufferPointer { buffer in
            guard let base = buffer.baseAddress else { return EINVAL }
            return executable.withCString { cExecutable in
                posix_spawn(&pid, cExecutable, &actions, nil, base, environ)
            }
        }
        close(pipeFDs[1])

        guard spawnStatus == 0 else {
            close(pipeFDs[0])
            return TSProcessResult(status: spawnStatus, output: "posix_spawn failed: \(String(cString: strerror(spawnStatus)))")
        }

        var captured = Data()
        let chunkSize = 64 * 1024
        let chunk = UnsafeMutableRawPointer.allocate(byteCount: chunkSize, alignment: 16)
        defer { chunk.deallocate() }
        while true {
            let readCount = read(pipeFDs[0], chunk, chunkSize)
            if readCount == 0 { break }
            if readCount < 0 {
                if errno == EINTR { continue }
                break
            }
            if captured.count < outputLimit {
                captured.append(chunk.assumingMemoryBound(to: UInt8.self), count: min(readCount, outputLimit - captured.count))
            }
            // Continue draining even after the capture limit is reached.
        }
        close(pipeFDs[0])

        var waitStatus: Int32 = 0
        while waitpid(pid, &waitStatus, 0) == -1 {
            if errno == EINTR { continue }
            return TSProcessResult(status: errno, output: String(data: captured, encoding: .utf8) ?? "")
        }
        let exitCode: Int32
        if (waitStatus & 0x7f) == 0 {
            exitCode = (waitStatus >> 8) & 0xff
        } else {
            exitCode = 128 + (waitStatus & 0x7f)
        }
        return TSProcessResult(status: exitCode, output: String(data: captured, encoding: .utf8) ?? "")
    }
}

// MARK: - Bounded parallel work

/// Parallelizes independent ldid processes without allowing unbounded process or I/O fan-out.
/// Each job must exclusively own the files it mutates. Bundle sealing is scheduled by depth so
/// sibling bundles may run concurrently while parent CodeResources waits for child cdhashes.
private final class TSConcurrentJobBox<Input, Output>: @unchecked Sendable {
    private let items: [Input]
    private let transform: (Input) -> Output
    private let lock = NSLock()
    private var storage: [Output?]

    init(items: [Input], transform: @escaping (Input) -> Output) {
        self.items = items
        self.transform = transform
        self.storage = Array<Output?>(repeating: nil, count: items.count)
    }

    func execute(index: Int) {
        let value = transform(items[index])
        lock.lock()
        storage[index] = value
        lock.unlock()
    }

    func results() -> [Output] {
        lock.lock()
        defer { lock.unlock() }
        return storage.map { $0! }
    }
}

private enum TSConcurrency {
    static let workerLimit: Int = {
        let cpuLimit = max(1, min(4, ProcessInfo.processInfo.activeProcessorCount))
        // Tune this down to 1 if a custom ldid binary already parallelizes internally.
        if let raw = ProcessInfo.processInfo.environment["TROLLSTORE_SIGN_JOBS"],
           let requested = Int(raw), requested > 0 {
            return max(1, min(cpuLimit, requested))
        }
        return cpuLimit
    }()

    static func map<Input, Output>(
        _ items: [Input],
        maxConcurrent: Int = TSConcurrency.workerLimit,
        _ transform: @escaping (Input) -> Output
    ) -> [Output] {
        guard !items.isEmpty else { return [] }
        if items.count == 1 { return [transform(items[0])] }

        let queue = OperationQueue()
        queue.name = "com.trollstore.signing"
        queue.qualityOfService = .userInitiated
        queue.maxConcurrentOperationCount = max(1, min(maxConcurrent, items.count))
        let job = TSConcurrentJobBox(items: items, transform: transform)
        for index in items.indices {
            queue.addOperation { job.execute(index: index) }
        }
        queue.waitUntilAllOperationsAreFinished()
        return job.results()
    }
}

// MARK: - ldid integration

private final class TSEntitlementCache: @unchecked Sendable {
    private let lock = NSLock()
    private var values: [String: [String: Any]] = [:]

    func clear() {
        lock.lock()
        values.removeAll(keepingCapacity: true)
        lock.unlock()
    }

    func set(_ entitlements: [String: Any], for bundleID: String) {
        lock.lock()
        values[bundleID] = entitlements
        lock.unlock()
    }

    func get(_ bundleID: String) -> [String: Any]? {
        lock.lock()
        defer { lock.unlock() }
        return values[bundleID]
    }
}

public enum TSLdid {
    private static let entitlementCache = TSEntitlementCache()

    public static func clearEntitlementCache() { entitlementCache.clear() }

    public static func cacheEntitlements(_ entitlements: [String: Any], bundleID: String) {
        entitlementCache.set(entitlements, for: bundleID)
    }

    public static func cachedEntitlements(bundleID: String) -> [String: Any]? {
        entitlementCache.get(bundleID)
    }
    public static func executablePath() -> String? {
        let executableDirectory = URL(fileURLWithPath: CommandLine.arguments.first ?? "/", isDirectory: false).deletingLastPathComponent()
        let bundleDirectory = Bundle.main.bundleURL
        let candidates = [
            ProcessInfo.processInfo.environment["TROLLSTORE_LDID_PATH"],
            executableDirectory.appendingPathComponent("ldid").path,
            bundleDirectory.appendingPathComponent("ldid").path,
            "/var/containers/Bundle/TrollStore/TrollStore.app/ldid",
            "/usr/bin/ldid",
            "/var/jb/usr/bin/ldid"
        ].compactMap { $0 }
        return candidates.first(where: { FileManager.default.isExecutableFile(atPath: $0) })
    }

    public static func run(_ arguments: [String]) -> TSProcessResult {
        guard let path = executablePath() else {
            return TSProcessResult(status: 173, output: "ldid not found. Bundle the compiled custom ldid binary beside trollstorehelper.")
        }
        return TSProcessRunner.run(path, arguments)
    }

    public static func dumpEntitlements(_ executablePath: String) -> [String: Any] {
        let result = run(["-e", executablePath])
        guard result.status == 0, let data = result.output.data(using: .utf8), !data.isEmpty,
              let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil),
              let dictionary = plist as? [String: Any] else {
            return [:]
        }
        return dictionary
    }

    public static func writeEntitlements(_ entitlements: [String: Any]) throws -> String {
        let data = try PropertyListSerialization.data(fromPropertyList: entitlements,
                                                     format: .xml,
                                                     options: 0)
        let path = "/tmp/TS-entitlements-\(UUID().uuidString).plist"
        try data.write(to: URL(fileURLWithPath: path), options: .atomic)
        return path
    }

    public static func sign(_ path: String, entitlements: [String: Any]? = nil) -> Int32 {
        if let entitlements {
            let plistPath: String
            do { plistPath = try writeEntitlements(entitlements) }
            catch { return 175 }
            defer { try? FileManager.default.removeItem(atPath: plistPath) }
            // -M performs the merge against the existing embedded Entitlements dictionary.
            let result = run(["-S\(plistPath)", "-M", path])
            if result.status != 0 { fputs("[ldid] \(result.output)\n", stderr) }
            return result.status == 0 ? 0 : 175
        }
        let result = run(["-S", "--deep", path])
        if result.status != 0 { fputs("[ldid] \(result.output)\n", stderr) }
        return result.status == 0 ? 0 : 175
    }

    /// Signs one bundle only. Unlike --deep, this refreshes this bundle's CodeResources and
    /// main executable without recursively re-signing all nested bundles again.
    public static func signBundleSeal(at path: String) -> Int32 {
        // Use -s, not bare -S: this CLI treats a following non-option argument as -S's
        // optional entitlement plist path, which would otherwise consume the bundle path.
        let result = run(["-s", path])
        if result.status != 0 { fputs("[ldid] bundle seal failed for \(path): \(result.output)\n", stderr) }
        return result.status == 0 ? 0 : 175
    }
}

#if !EMBEDDED_ROOT_HELPER
// MARK: - Safe, streaming IPA extraction

private enum TSArchiveExtractor {
    static func extractPayload(from ipaPath: String, to destination: String) -> Bool {
        guard let archive = ts_archive_read_new() else { return false }
        defer { _ = ts_archive_read_free(archive) }
        _ = ts_archive_read_support_filter_all(archive)
        _ = ts_archive_read_support_format_all(archive)

        let openStatus = ipaPath.withCString { ts_archive_read_open_filename(archive, $0, 1024 * 1024) }
        guard openStatus == tsArchiveOK else {
            if let message = ts_archive_error_string(archive) { fputs("[archive] \(String(cString: message))\n", stderr) }
            return false
        }

        do { try FileManager.default.createDirectory(atPath: destination, withIntermediateDirectories: true) }
        catch { return false }

        var entry: OpaquePointer?
        let chunkSize = 1024 * 1024
        let chunk = UnsafeMutableRawPointer.allocate(byteCount: chunkSize, alignment: 16)
        defer { chunk.deallocate() }

        while true {
            let status = ts_archive_read_next_header(archive, &entry)
            if status == tsArchiveEOF { break }
            guard status == tsArchiveOK, let entry else {
                if let message = ts_archive_error_string(archive) { fputs("[archive] \(String(cString: message))\n", stderr) }
                return false
            }

            guard let rawName = ts_archive_entry_pathname(entry) else {
                _ = ts_archive_read_data_skip(archive)
                continue
            }
            var name = String(cString: rawName).replacingOccurrences(of: "\\", with: "/")
            while name.hasPrefix("./") { name.removeFirst(2) }
            guard !name.isEmpty, !name.hasPrefix("/"), !name.contains("\0") else {
                _ = ts_archive_read_data_skip(archive)
                continue
            }
            let components = name.split(separator: "/", omittingEmptySubsequences: true)
            guard !components.isEmpty, components.first == "Payload",
                  !components.contains(".."), !components.contains(".") else {
                _ = ts_archive_read_data_skip(archive)
                continue
            }

            let outputURL = URL(fileURLWithPath: destination, isDirectory: true).appendingPathComponent(name).standardizedFileURL
            let rootPath = URL(fileURLWithPath: destination, isDirectory: true).standardizedFileURL.path
            guard outputURL.path == rootPath || outputURL.path.hasPrefix(rootPath + "/") else {
                _ = ts_archive_read_data_skip(archive)
                continue
            }

            let kind = ts_archive_entry_filetype(entry) & tsFileTypeMask
            let permissions = ts_archive_entry_perm(entry) & 0o777

            if kind == tsFileTypeDirectory {
                do { try FileManager.default.createDirectory(at: outputURL, withIntermediateDirectories: true) }
                catch { return false }
                // Directory permissions are normalized in one pass after install.
                _ = ts_archive_read_data_skip(archive)
                continue
            }

            do { try FileManager.default.createDirectory(at: outputURL.deletingLastPathComponent(), withIntermediateDirectories: true) }
            catch { return false }

            if kind == tsFileTypeSymlink {
                guard let rawTarget = ts_archive_entry_symlink(entry) else { _ = ts_archive_read_data_skip(archive); continue }
                let target = String(cString: rawTarget)
                guard !target.hasPrefix("/") else { _ = ts_archive_read_data_skip(archive); continue }
                let resolvedTarget = outputURL.deletingLastPathComponent().appendingPathComponent(target).standardizedFileURL.path
                guard resolvedTarget.hasPrefix(rootPath + "/") else { _ = ts_archive_read_data_skip(archive); continue }
                try? FileManager.default.removeItem(at: outputURL)
                if tsSymlink(target, outputURL.path) != 0 {
                    fputs("[archive] failed creating symlink \(outputURL.path): \(String(cString: strerror(errno)))\n", stderr)
                    return false
                }
                _ = ts_archive_read_data_skip(archive)
                continue
            }

            guard kind == tsFileTypeRegular || kind == 0 else {
                _ = ts_archive_read_data_skip(archive)
                continue
            }
            let fd = tsOpen(outputURL.path, O_CREAT | O_WRONLY | O_TRUNC | O_CLOEXEC, mode_t(permissions == 0 ? 0o644 : permissions))
            guard fd >= 0 else { return false }
            var fileError = false
            while true {
                let count = ts_archive_read_data(archive, chunk, chunkSize)
                if count == 0 { break }
                if count < 0 { fileError = true; break }
                var written = 0
                while written < count {
                    let amount = write(fd, chunk.advanced(by: written), count - written)
                    if amount < 0 {
                        if errno == EINTR { continue }
                        fileError = true
                        break
                    }
                    if amount == 0 { fileError = true; break }
                    written += amount
                }
                if fileError { break }
            }
            _ = close(fd)
            // Avoid one chmod syscall per extracted file; repairPermissions applies final modes later.
            if fileError { return false }
        }
        return true
    }
}

#endif // !EMBEDDED_ROOT_HELPER

// MARK: - Private LaunchServices / MobileContainerManager bridge

private enum TSPrivateServices {
    private static func classObject(_ name: String) -> AnyClass? { NSClassFromString(name) }

    static func defaultWorkspace() -> NSObject? {
        guard let cls = classObject("LSApplicationWorkspace") else { return nil }
        let selector = NSSelectorFromString("defaultWorkspace")
        guard let method = class_getClassMethod(cls, selector) else { return nil }
        typealias Function = @convention(c) (AnyClass, Selector) -> Unmanaged<AnyObject>?
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        return function(cls, selector)?.takeUnretainedValue() as? NSObject
    }

    static func appProxy(bundleID: String) -> NSObject? {
        guard let cls = classObject("LSApplicationProxy") else { return nil }
        let selector = NSSelectorFromString("applicationProxyForIdentifier:")
        guard let method = class_getClassMethod(cls, selector) else { return nil }
        typealias Function = @convention(c) (AnyClass, Selector, NSString) -> Unmanaged<AnyObject>?
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        return function(cls, selector, bundleID as NSString)?.takeUnretainedValue() as? NSObject
    }

    static func appContainer(bundleID: String, create: Bool) -> NSObject? {
        return container(className: "MCMAppContainer", identifier: bundleID, create: create)
    }

    static func dataContainer(identifier: String, create: Bool) -> NSObject? {
        return container(className: "MCMAppDataContainer", identifier: identifier, create: create)
    }

    static func groupContainer(className: String, identifier: String, create: Bool) -> NSObject? {
        return container(className: className, identifier: identifier, create: create)
    }

    private static func container(className: String, identifier: String, create: Bool) -> NSObject? {
        guard let cls = classObject(className) else { return nil }
        let selector = NSSelectorFromString("containerWithIdentifier:createIfNecessary:existed:error:")
        guard let method = class_getClassMethod(cls, selector) else { return nil }
        typealias Function = @convention(c) (AnyClass, Selector, NSString, Bool, UnsafeMutablePointer<ObjCBool>?, UnsafeMutableRawPointer?) -> Unmanaged<AnyObject>?
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        return function(cls, selector, identifier as NSString, create, nil, nil)?.takeUnretainedValue() as? NSObject
    }

    static func register(dictionary: [String: Any]) -> Bool {
        guard let workspace = defaultWorkspace() else { return false }
        let selector = NSSelectorFromString("registerApplicationDictionary:")
        guard let method = class_getInstanceMethod(type(of: workspace), selector) else { return false }
        typealias Function = @convention(c) (AnyObject, Selector, NSDictionary) -> Bool
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        return function(workspace, selector, dictionary as NSDictionary)
    }

    static func open(bundleID: String) -> Bool {
        guard let workspace = defaultWorkspace() else { return false }
        let selector = NSSelectorFromString("openApplicationWithBundleID:")
        guard let method = class_getInstanceMethod(type(of: workspace), selector) else { return false }
        typealias Function = @convention(c) (AnyObject, Selector, NSString) -> Bool
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        return function(workspace, selector, bundleID as NSString)
    }

    static func uninstall(bundleID: String) -> Bool {
        guard let workspace = defaultWorkspace() else { return false }
        let selector = NSSelectorFromString("uninstallApplication:withOptions:")
        guard let method = class_getInstanceMethod(type(of: workspace), selector) else { return false }
        typealias Function = @convention(c) (AnyObject, Selector, NSString, NSDictionary?) -> Bool
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        return function(workspace, selector, bundleID as NSString, nil)
    }

    static func rebuildDatabases() {
        guard let workspace = defaultWorkspace() else { return }
        let selector = NSSelectorFromString("_LSPrivateRebuildApplicationDatabasesForSystemApps:internal:user:")
        guard let method = class_getInstanceMethod(type(of: workspace), selector) else { return }
        typealias Function = @convention(c) (AnyObject, Selector, Bool, Bool, Bool) -> Bool
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        _ = function(workspace, selector, true, true, true)
    }
}

// MARK: - Bundle and Mach-O utilities

private struct TSBundleInfo {
    let path: String
    let bundleID: String
    let executablePath: String
    let packageType: String
}

private enum TSBundleUtils {
    static func info(at path: String) -> TSBundleInfo? {
        let bundleURL = URL(fileURLWithPath: path, isDirectory: true).standardizedFileURL
        let infoPath = bundleURL.appendingPathComponent("Info.plist").path
        guard let info = NSDictionary(contentsOfFile: infoPath) as? [String: Any],
              let bundleID = info["CFBundleIdentifier"] as? String, !bundleID.isEmpty,
              !bundleID.contains("/"), !bundleID.contains("\\"), !bundleID.contains("\0"),
              let executable = info["CFBundleExecutable"] as? String, !executable.isEmpty,
              executable != ".", executable != "..", !executable.contains("/"), !executable.contains("\0") else { return nil }
        // Info.plist comes from an untrusted IPA. Never allow its executable name to escape
        // the bundle; the helper runs as root and ldid/CoreTrust operate on the resulting path.
        let executableURL = bundleURL.appendingPathComponent(executable).standardizedFileURL
        guard executableURL.path.hasPrefix(bundleURL.path + "/") else { return nil }
        let packageType = (info["CFBundlePackageType"] as? String) ?? "APPL"
        return TSBundleInfo(path: bundleURL.path, bundleID: bundleID, executablePath: executableURL.path, packageType: packageType)
    }

    static func mainApp(in payloadPath: String) -> String? {
        let urls = (try? FileManager.default.contentsOfDirectory(at: URL(fileURLWithPath: payloadPath),
                                                                includingPropertiesForKeys: [.isDirectoryKey],
                                                                options: [.skipsHiddenFiles])) ?? []
        return urls.first(where: { $0.pathExtension.lowercased() == "app" && (try? $0.resourceValues(forKeys: [.isDirectoryKey]).isDirectory) == true })?.path
    }

    static func executableTargets(in appPath: String) -> [TSBundleInfo] {
        let root = URL(fileURLWithPath: appPath, isDirectory: true)
        guard let enumerator = FileManager.default.enumerator(at: root,
                                                              includingPropertiesForKeys: [.isDirectoryKey],
                                                              options: [.skipsHiddenFiles],
                                                              errorHandler: { _, _ in true }) else {
            return TSBundleUtils.info(at: appPath).map { [$0] } ?? []
        }
        var paths = [appPath]
        for case let url as URL in enumerator where url.lastPathComponent == "Info.plist" {
            let parent = url.deletingLastPathComponent()
            let ext = parent.pathExtension.lowercased()
            if ["app", "appex", "xpc", "framework"].contains(ext) { paths.append(parent.path) }
        }
        let unique = Set(paths)
        return unique.compactMap { info(at: $0) }.sorted { $0.path.components(separatedBy: "/").count > $1.path.components(separatedBy: "/").count }
    }

    /// Includes the root and every ldid-supported nested bundle. Parent bundles are sealed only
    /// after children have their final signatures, so CodeResources records the final child cdhash.
    static func signableBundles(in appPath: String) -> [String] {
        let supported = Set(["app", "framework", "xpc", "appex", "kext", "plugin", "bundle"])
        var paths = [appPath]
        if let enumerator = FileManager.default.enumerator(atPath: appPath) {
            for case let relative as String in enumerator {
                let candidate = URL(fileURLWithPath: appPath, isDirectory: true).appendingPathComponent(relative).path
                guard supported.contains(URL(fileURLWithPath: candidate).pathExtension.lowercased()),
                      !isSymbolicLink(candidate) else { continue }
                var isDirectory: ObjCBool = false
                if FileManager.default.fileExists(atPath: candidate, isDirectory: &isDirectory), isDirectory.boolValue {
                    paths.append(candidate)
                }
            }
        }
        return Array(Set(paths))
    }

    static func patchInfoPlist(_ appPath: String) {
        let path = URL(fileURLWithPath: appPath).appendingPathComponent("Info.plist").path
        guard var info = NSDictionary(contentsOfFile: path) as? [String: Any] else { return }
        info["SBAppUsesLocalNotifications"] = 1
        if let data = try? PropertyListSerialization.data(fromPropertyList: info, format: .xml, options: 0) {
            try? data.write(to: URL(fileURLWithPath: path), options: .atomic)
        }
    }

    static func isSymbolicLink(_ path: String) -> Bool {
        (try? FileManager.default.destinationOfSymbolicLink(atPath: path)) != nil
    }

    static func isMachO(_ path: String) -> Bool {
        guard let handle = try? FileHandle(forReadingFrom: URL(fileURLWithPath: path)) else { return false }
        defer { try? handle.close() }
        let bytes = (try? handle.read(upToCount: 4)) ?? nil
        guard let b = bytes, b.count == 4 else { return false }
        let magic = [UInt8](b)
        return magic == [0xfe, 0xed, 0xfa, 0xce] || magic == [0xce, 0xfa, 0xed, 0xfe] ||
               magic == [0xfe, 0xed, 0xfa, 0xcf] || magic == [0xcf, 0xfa, 0xed, 0xfe] ||
               magic == [0xca, 0xfe, 0xba, 0xbe] || magic == [0xbe, 0xba, 0xfe, 0xca] ||
               magic == [0xca, 0xfe, 0xba, 0xbf] || magic == [0xbf, 0xba, 0xfe, 0xca]
    }

    static func repairPermissions(_ appPath: String) {
        // One walk only. lstat avoids a second stat through FileManager, and chmod is skipped
        // when the mode is already correct. Existing executable bits are the cheap Mach-O hint;
        // magic probing is only needed for an unexpectedly non-executable regular file.
        func repair(_ path: String) {
            var metadata = stat()
            let result = path.withCString { lstat($0, &metadata) }
            guard result == 0 else { return }
            let kind = metadata.st_mode & mode_t(S_IFMT)
            if kind == mode_t(S_IFLNK) { return }
            let isDirectory = kind == mode_t(S_IFDIR)
            let isRegular = kind == mode_t(S_IFREG)
            let hasExecuteBit = (metadata.st_mode & mode_t(0o111)) != 0
            let isMachOFile = isRegular && !hasExecuteBit && isMachO(path)
            let desiredMode: mode_t = (isDirectory || hasExecuteBit || isMachOFile) ? 0o755 : 0o644

            if metadata.st_uid != uid_t(33) || metadata.st_gid != gid_t(33) {
                _ = tsChown(path, 33, 33)
            }
            if (metadata.st_mode & mode_t(0o777)) != desiredMode {
                _ = tsChmod(path, desiredMode)
            }
        }
        repair(appPath)
        guard let enumerator = FileManager.default.enumerator(atPath: appPath) else { return }
        for case let relative as String in enumerator {
            repair(URL(fileURLWithPath: appPath).appendingPathComponent(relative).path)
        }
    }
}

#if !EMBEDDED_ROOT_HELPER
// MARK: - CoreTrust slice handling

private enum TSMachO {
    private struct Slice {
        let offset: UInt64
        let size: UInt64
        let cpuType: UInt32
        let cpuSubtype: UInt32
    }

    private static func u32(_ bytes: [UInt8], _ offset: Int, bigEndian: Bool) -> UInt32? {
        guard offset >= 0, offset + 4 <= bytes.count else { return nil }
        if bigEndian {
            return (UInt32(bytes[offset]) << 24) | (UInt32(bytes[offset + 1]) << 16) |
                   (UInt32(bytes[offset + 2]) << 8) | UInt32(bytes[offset + 3])
        }
        return UInt32(bytes[offset]) | (UInt32(bytes[offset + 1]) << 8) |
               (UInt32(bytes[offset + 2]) << 16) | (UInt32(bytes[offset + 3]) << 24)
    }

    private static func u64(_ bytes: [UInt8], _ offset: Int, bigEndian: Bool) -> UInt64? {
        guard offset >= 0, offset + 8 <= bytes.count else { return nil }
        if bigEndian {
            var value: UInt64 = 0
            for index in 0..<8 { value = (value << 8) | UInt64(bytes[offset + index]) }
            return value
        }
        var value: UInt64 = 0
        for index in stride(from: 7, through: 0, by: -1) { value = (value << 8) | UInt64(bytes[offset + index]) }
        return value
    }

    private static func preferredSlice(path: String) -> Slice? {
        guard let handle = try? FileHandle(forReadingFrom: URL(fileURLWithPath: path)) else { return nil }
        defer { try? handle.close() }
        guard let headerData = try? handle.read(upToCount: 8), headerData.count >= 4 else { return nil }
        let header = [UInt8](headerData)
        let magic = Array(header.prefix(4))
        let isFat32 = magic == [0xca, 0xfe, 0xba, 0xbe] || magic == [0xbe, 0xba, 0xfe, 0xca]
        let isFat64 = magic == [0xca, 0xfe, 0xba, 0xbf] || magic == [0xbf, 0xba, 0xfe, 0xca]
        guard isFat32 || isFat64 else {
            guard TSBundleUtils.isMachO(path) else { return nil }
            let attributes = try? FileManager.default.attributesOfItem(atPath: path)
            let fileSize = (attributes?[.size] as? NSNumber)?.uint64Value ?? 0
            return Slice(offset: 0, size: fileSize, cpuType: 0x0100000c, cpuSubtype: 0)
        }
        let bigEndian = magic[0] == 0xca
        guard let count = u32(header, 4, bigEndian: bigEndian), count > 0, count < 4096 else { return nil }
        let entrySize = isFat64 ? 32 : 20
        guard let allHeaders = try? handle.read(upToCount: Int(count) * entrySize), allHeaders.count == Int(count) * entrySize else { return nil }
        let bytes = [UInt8](allHeaders)
        var slices = [Slice]()
        for i in 0..<Int(count) {
            let base = i * entrySize
            guard let cpu = u32(bytes, base, bigEndian: bigEndian),
                  let sub = u32(bytes, base + 4, bigEndian: bigEndian) else { continue }
            let offset: UInt64
            let size: UInt64
            if isFat64 {
                guard let o = u64(bytes, base + 8, bigEndian: bigEndian),
                      let s = u64(bytes, base + 16, bigEndian: bigEndian) else { continue }
                offset = o; size = s
            } else {
                guard let o = u32(bytes, base + 8, bigEndian: bigEndian),
                      let s = u32(bytes, base + 12, bigEndian: bigEndian) else { continue }
                offset = UInt64(o); size = UInt64(s)
            }
            if cpu == 0x0100000c && size > 0 { slices.append(Slice(offset: offset, size: size, cpuType: cpu, cpuSubtype: sub)) }
        }
        // Prefer arm64e on arm64e-capable devices, otherwise ordinary arm64.
        var arm64eCapable = false
        var hostSubtype: Int32 = 0
        var subtypeSize = MemoryLayout<Int32>.size
        if sysctlbyname("hw.cpusubtype", &hostSubtype, &subtypeSize, nil, 0) == 0 {
            arm64eCapable = (hostSubtype & 0x00ff_ffff) == 2
        }
        return slices.sorted { lhs, rhs in
            func rank(_ item: Slice) -> Int {
                let subtype = item.cpuSubtype & 0x00ff_ffff
                if subtype == 2 { return arm64eCapable ? 3 : 1 }
                if subtype == 0 { return 2 }
                return 0
            }
            return rank(lhs) > rank(rhs)
        }.first
    }

    static func extractPreferredSlice(from source: String, to destination: String) -> Bool {
        guard let slice = preferredSlice(path: source), slice.size > 0,
              let input = try? FileHandle(forReadingFrom: URL(fileURLWithPath: source)) else { return false }
        defer { try? input.close() }
        _ = FileManager.default.createFile(atPath: destination, contents: nil)
        guard let output = try? FileHandle(forWritingTo: URL(fileURLWithPath: destination)) else { return false }
        defer { try? output.close() }
        do {
            try input.seek(toOffset: slice.offset)
            var remaining = slice.size
            while remaining > 0 {
                let amount = Int(min(remaining, 1024 * 1024))
                guard let data = try input.read(upToCount: amount), !data.isEmpty else { return false }
                try output.write(contentsOf: data)
                remaining -= UInt64(data.count)
            }
            // This is a disposable temporary slice immediately consumed by the next operation;
            // forcing it to stable storage adds latency without improving install correctness.
            _ = tsChmod(destination, 0o755)
            return true
        } catch { return false }
    }
}

// MARK: - Performance diagnostics

private enum TSPerformanceLog {
    static func record(_ phase: String, startedAt: TimeInterval) {
        let elapsed = max(0, ProcessInfo.processInfo.systemUptime - startedAt)
        fputs(String(format: "[perf] %@: %.3fs\n", phase, elapsed), stderr)
    }
}

// MARK: - Signing pipeline

private enum TSSigner {
    static func signApp(at appPath: String, customEntitlements: [String: Any]) -> Int32 {
        guard let mainInfo = TSBundleUtils.info(at: appPath),
              FileManager.default.fileExists(atPath: mainInfo.executablePath) else { return 174 }
        guard TSLdid.executablePath() != nil else { return 173 }

        TSLdid.clearEntitlementCache()
        let allTargets = TSBundleUtils.executableTargets(in: appPath)
        let targets = allTargets.filter {
            (["APPL", "XPC!", "XPC"].contains($0.packageType) ||
             ["app", "appex", "xpc"].contains(URL(fileURLWithPath: $0.path).pathExtension.lowercased())) &&
            FileManager.default.fileExists(atPath: $0.executablePath) && TSBundleUtils.isMachO($0.executablePath)
        }

        // These executables are independent files. Spawn a bounded number of ldid processes so
        // entitlements inspection and signing overlap across app/appex/xpc targets.
        let executableSigningStarted = ProcessInfo.processInfo.systemUptime
        let signingResults = TSConcurrency.map(targets) { target -> (bundleID: String, path: String, status: Int32, requiresDeveloperMode: Bool) in
            var entitlements = TSLdid.dumpEntitlements(target.executablePath)
            if target.path == appPath && entitlements.isEmpty {
                entitlements = [
                    "application-identifier": "TROLLTROLL.*",
                    "com.apple.developer.team-identifier": "TROLLTROLL",
                    "get-task-allow": true,
                    "keychain-access-groups": ["TROLLTROLL.*", "com.apple.token"]
                ]
            }
            for (key, value) in customEntitlements { entitlements[key] = value }

            var needsDeveloperMode = false
            if #available(iOS 16.0, *) {
                let developerModeKeys = [
                    "get-task-allow",
                    "task_for_pid-allow",
                    "com.apple.system-task-ports",
                    "com.apple.system-task-ports.control",
                    "com.apple.system-task-ports.token.control",
                    "com.apple.private.cs.debugger"
                ]
                needsDeveloperMode = developerModeKeys.contains {
                    (entitlements[$0] as? NSNumber)?.boolValue == true
                }
            }

            let noContainer = (entitlements["com.apple.private.security.no-container"] as? NSNumber)?.boolValue ?? false
            let noSandbox = (entitlements["com.apple.private.security.no-sandbox"] as? NSNumber)?.boolValue ?? false
            if !noContainer && !noSandbox && entitlements["com.apple.private.security.container-required"] == nil {
                entitlements["com.apple.private.security.container-required"] = target.bundleID
            }

            let status = TSLdid.sign(target.executablePath, entitlements: entitlements)
            if status == 0 {
                // Registration runs later, after the app has moved to its final path. Cache by
                // bundle ID so LaunchServices registration doesn't spawn another `ldid -e`.
                TSLdid.cacheEntitlements(entitlements, bundleID: target.bundleID)
            }
            return (target.bundleID, target.executablePath, status, needsDeveloperMode)
        }
        TSPerformanceLog.record("parallel executable signing", startedAt: executableSigningStarted)
        if let failure = signingResults.first(where: { $0.status != 0 }) {
            fputs("[sign] executable signing failed: \(failure.path) (\(failure.status))\n", stderr)
            return failure.status
        }
        let requiresDeveloperMode = signingResults.contains(where: { $0.requiresDeveloperMode })

        // ldid's --deep path re-signs all nested binaries again. Instead, seal disjoint bundles
        // in parallel at each depth (deepest first), and seal the root app last. This preserves
        // child cdhash dependencies while avoiding a second full recursive signing pass.
        let bundleSealStarted = ProcessInfo.processInfo.systemUptime
        let bundlePaths = TSBundleUtils.signableBundles(in: appPath)
        let bundlesByDepth = Dictionary(grouping: bundlePaths) { $0.split(separator: "/").count }
        for depth in bundlesByDepth.keys.sorted(by: >) {
            let layer = bundlesByDepth[depth] ?? []
            let results = TSConcurrency.map(layer) { path -> (String, Int32) in
                (path, TSLdid.signBundleSeal(at: path))
            }
            if let failure = results.first(where: { $0.1 != 0 }) {
                fputs("[sign] CodeResources sealing failed: \(failure.0) (\(failure.1))\n", stderr)
                return failure.1
            }
        }
        TSPerformanceLog.record("dependency-ordered CodeResources sealing", startedAt: bundleSealStarted)

        let bypassStarted = ProcessInfo.processInfo.systemUptime
        let bypassStatus = applyCoreTrustBypass(appPath: appPath, mainExecutablePath: mainInfo.executablePath)
        TSPerformanceLog.record("CoreTrust bypass", startedAt: bypassStarted)
        guard bypassStatus == 0 || bypassStatus == 184 else { return bypassStatus }
        return requiresDeveloperMode ? 182 : bypassStatus
    }

    private static func applyCoreTrustBypass(appPath: String, mainExecutablePath: String) -> Int32 {
        guard let enumerator = FileManager.default.enumerator(atPath: appPath) else { return 185 }
        let files = enumerator.compactMap { $0 as? String }
            .map { URL(fileURLWithPath: appPath).appendingPathComponent($0).path }
            .filter { !TSBundleUtils.isSymbolicLink($0) && TSBundleUtils.isMachO($0) }
        var additionalEncrypted = false

        for path in files {
            let temporaryPath = "/tmp/TS-macho-\(UUID().uuidString)"
            defer { try? FileManager.default.removeItem(atPath: temporaryPath) }
            guard TSMachO.extractPreferredSlice(from: path, to: temporaryPath) else {
                if path == mainExecutablePath { return 185 }
                continue
            }
            let result = temporaryPath.withCString { ts_apply_coretrust_bypass($0) }
            switch result {
            case 0:
                // Replace only after a successful mutation; a failed bypass must never truncate the input.
                if tsRename(temporaryPath, path) != 0 {
                    // /tmp and an app container are normally on the same APFS volume. If not,
                    // stage the transformed binary beside the destination and then rename it.
                    let siblingStage = URL(fileURLWithPath: path).deletingLastPathComponent()
                        .appendingPathComponent(".TS-bypass-\(UUID().uuidString)").path
                    do {
                        try FileManager.default.copyItem(atPath: temporaryPath, toPath: siblingStage)
                    } catch {
                        fputs("[CoreTrust] copy stage failed for \(path): \(error)\n", stderr)
                        return 185
                    }
                    if tsRename(siblingStage, path) != 0 {
                        try? FileManager.default.removeItem(atPath: siblingStage)
                        fputs("[CoreTrust] replacement failed for \(path): \(String(cString: strerror(errno)))\n", stderr)
                        return 185
                    }
                }
                _ = tsChmod(path, 0o755)
            case 2:
                if path == mainExecutablePath { return 180 }
                additionalEncrypted = true
            case 3:
                // Unsupported/non-executable Mach-O type: not fatal, matching TrollStore behaviour.
                continue
            default:
                fputs("[CoreTrust] bypass failed for \(path) with code \(result)\n", stderr)
                return 185
            }
        }
        return additionalEncrypted ? 184 : 0
    }
}

#endif // !EMBEDDED_ROOT_HELPER

// MARK: - LaunchServices registration

private enum TSRegistration {
    private static func containerization(entitlements: [String: Any], defaultID: String) -> (Bool, String) {
        if (entitlements["com.apple.private.security.no-container"] as? NSNumber)?.boolValue == true { return (false, defaultID) }
        if let required = entitlements["com.apple.private.security.container-required"] as? NSNumber, !required.boolValue { return (false, defaultID) }
        if let required = entitlements["com.apple.private.security.container-required"] as? String, !required.isEmpty { return (true, required) }
        return (true, defaultID)
    }

    private static func environmentVariables(containerPath: String?, containerized: Bool) -> [String: String] {
        let home = containerized ? (containerPath ?? "/var/mobile") : "/var/mobile"
        let temporary = containerized ? URL(fileURLWithPath: home).appendingPathComponent("tmp").path : "/var/tmp"
        return ["CFFIXED_USER_HOME": home, "HOME": home, "TMPDIR": temporary]
    }

    private static func groupPaths(_ entitlementKey: String, className: String, entitlements: [String: Any]) -> [String: String] {
        guard let groups = entitlements[entitlementKey] as? [String] else { return [:] }
        var result = [String: String]()
        for group in groups {
            if let container = TSPrivateServices.groupContainer(className: className, identifier: group, create: true),
               let url = container.value(forKey: "url") as? URL {
                result[group] = url.path
            }
        }
        return result
    }

    static func registerApp(at appPath: String) -> Bool {
        guard let info = TSBundleUtils.info(at: appPath) else { return false }
        let entitlements = TSLdid.cachedEntitlements(bundleID: info.bundleID) ?? TSLdid.dumpEntitlements(info.executablePath)
        var customContainerID = info.bundleID
        let (isContainerized, resolvedID) = containerization(entitlements: entitlements, defaultID: customContainerID)
        customContainerID = resolvedID
        let appDataContainer = TSPrivateServices.dataContainer(identifier: customContainerID, create: true)
        let appDataPath = (appDataContainer?.value(forKey: "url") as? URL)?.path
        let inContainer = appPath.hasPrefix("/var/containers/") || appPath.hasPrefix("/private/var/containers/")
        let registerAsUser = inContainer && !FileManager.default.fileExists(atPath: "/System/Library/AppSignatures/\(info.bundleID)")

        var dictionary: [String: Any] = [
            "ApplicationType": registerAsUser ? "User" : "System",
            "CFBundleIdentifier": info.bundleID,
            "CodeInfoIdentifier": info.bundleID,
            "CompatibilityState": 0,
            "IsContainerized": isContainerized,
            "Path": URL(fileURLWithPath: appPath).resolvingSymlinksInPath().standardizedFileURL.path,
            "SignerOrganization": "Apple Inc.",
            "SignatureVersion": tsSignatureVersion,
            "SignerIdentity": "Apple iPhone OS Application Signing",
            "IsDeletable": info.bundleID != tsProtectedBundleID && ProcessInfo.processInfo.operatingSystemVersion.majorVersion >= 15,
            "IsAdHocSigned": true,
            "LSInstallType": 1,
            "HasMIDBasedSINF": 0,
            "MissingSINF": 0,
            "FamilyID": 0,
            "IsOnDemandInstallCapable": 0
        ]
        if !entitlements.isEmpty { dictionary["Entitlements"] = entitlements }
        if let appDataPath, isContainerized { dictionary["Container"] = appDataPath }
        dictionary["EnvironmentVariables"] = environmentVariables(containerPath: appDataPath, containerized: isContainerized)
        if let teamID = entitlements["com.apple.developer.team-identifier"] as? String { dictionary["TeamIdentifier"] = teamID }

        let appGroups = groupPaths("com.apple.security.application-groups", className: "MCMSharedDataContainer", entitlements: entitlements)
        let systemGroups = groupPaths("com.apple.security.system-groups", className: "MCMSystemDataContainer", entitlements: entitlements)
        var groups = appGroups
        groups.merge(systemGroups) { _, new in new }
        if !groups.isEmpty {
            dictionary["GroupContainers"] = groups
            dictionary["HasAppGroupContainers"] = !appGroups.isEmpty
            dictionary["HasSystemGroupContainers"] = !systemGroups.isEmpty
        }

        // Register PlugIns with the parent application so extensions appear in LaunchServices.
        var plugins = [String: [String: Any]]()
        let pluginsPath = URL(fileURLWithPath: appPath).appendingPathComponent("PlugIns").path
        if let items = try? FileManager.default.contentsOfDirectory(atPath: pluginsPath) {
            for item in items where item.hasSuffix(".appex") {
                let pluginPath = URL(fileURLWithPath: pluginsPath).appendingPathComponent(item).path
                guard let pluginInfo = TSBundleUtils.info(at: pluginPath) else { continue }
                let pluginEntitlements = TSLdid.cachedEntitlements(bundleID: pluginInfo.bundleID) ?? TSLdid.dumpEntitlements(pluginInfo.executablePath)
                var pluginContainerID = pluginInfo.bundleID
                let (pluginIsContainerized, resolvedPluginID) = containerization(entitlements: pluginEntitlements, defaultID: pluginContainerID)
                pluginContainerID = resolvedPluginID
                let pluginContainer = TSPrivateServices.groupContainer(className: "MCMPluginKitPluginDataContainer", identifier: pluginContainerID, create: true)
                let pluginDataPath = (pluginContainer?.value(forKey: "url") as? URL)?.path
                var plugin: [String: Any] = [
                    "ApplicationType": "PluginKitPlugin",
                    "CFBundleIdentifier": pluginInfo.bundleID,
                    "CodeInfoIdentifier": pluginInfo.bundleID,
                    "CompatibilityState": 0,
                    "IsContainerized": pluginIsContainerized,
                    "Path": pluginPath,
                    "PluginOwnerBundleID": info.bundleID,
                    "SignerOrganization": "Apple Inc.",
                    "SignatureVersion": tsSignatureVersion,
                    "SignerIdentity": "Apple iPhone OS Application Signing"
                ]
                if !pluginEntitlements.isEmpty { plugin["Entitlements"] = pluginEntitlements }
                if let pluginDataPath, pluginIsContainerized { plugin["Container"] = pluginDataPath }
                plugin["EnvironmentVariables"] = environmentVariables(containerPath: pluginDataPath, containerized: pluginIsContainerized)
                if let team = pluginEntitlements["com.apple.developer.team-identifier"] as? String { plugin["TeamIdentifier"] = team }
                plugins[pluginInfo.bundleID] = plugin
            }
        }
        dictionary["_LSBundlePlugins"] = plugins
        return TSPrivateServices.register(dictionary: dictionary)
    }

    static func refreshManagedApps() -> Bool {
        TSPrivateServices.rebuildDatabases()
        var allOK = true

        // TrollStore itself lives outside the ordinary per-app UUID containers. Register it
        // explicitly so a database/icon-cache rebuild cannot make TrollStore disappear.
        let trollStorePaths = [
            "/var/containers/Bundle/TrollStore/TrollStore.app",
            "/var/containers/Bundle/TrollStore/TrollStoreLite.app",
            "/Applications/TrollStore.app",
            "/Applications/TrollStoreLite.app"
        ]
        for path in trollStorePaths where FileManager.default.fileExists(atPath: path) {
            if !registerApp(at: path) { allOK = false }
        }

        let root = "/var/containers/Bundle/Application"
        guard let ids = try? FileManager.default.contentsOfDirectory(atPath: root) else { return false }
        for id in ids {
            let containerPath = URL(fileURLWithPath: root).appendingPathComponent(id).path
            let active = FileManager.default.fileExists(atPath: URL(fileURLWithPath: containerPath).appendingPathComponent(tsActiveMarker).path)
            let lite = FileManager.default.fileExists(atPath: URL(fileURLWithPath: containerPath).appendingPathComponent(tsInactiveMarker).path)
            guard active || lite else { continue }
            guard let entries = try? FileManager.default.contentsOfDirectory(atPath: containerPath) else { continue }
            for entry in entries where entry.hasSuffix(".app") && entry != "TrollStore.app" && entry != "TrollStoreLite.app" {
                let path = URL(fileURLWithPath: containerPath).appendingPathComponent(entry).path
                if !registerApp(at: path) { allOK = false }
            }
        }
        return allOK
    }
}

// MARK: - Installation and app management

public enum TrollStoreRootHelper {
    @discardableResult
    public static func run(_ arguments: [String]) -> Int32 {
        guard !arguments.isEmpty else { return -1 }
        guard geteuid() == 0 else {
            fputs("trollstorehelper must run as root.\n", stderr)
            return 1
        }

        let command = arguments[0]
        switch command {
        case "install":
            #if EMBEDDED_ROOT_HELPER
            // The persistence helper only re-registers apps; install/signing backends are excluded.
            return 2
            #else
            guard let ipa = arguments.last, ipa != "install", FileManager.default.fileExists(atPath: ipa) else { return 166 }
            let force = arguments.contains("force")
            let entitlementPath: String? = {
                guard let index = arguments.firstIndex(of: "--entitlements"), index + 1 < arguments.count else { return nil }
                return arguments[index + 1]
            }()
            var custom = [String: Any]()
            if let entitlementPath {
                guard let data = try? Data(contentsOf: URL(fileURLWithPath: entitlementPath)),
                      let plist = (try? PropertyListSerialization.propertyList(from: data, options: [], format: nil)) as? [String: Any] else { return 186 }
                custom = plist
            }
            let result = installIPA(ipa, force: force, customEntitlements: custom)
            print("TrollStore install result: \(result)")
            return result
            #endif
        case "uninstall":
            guard let bundleID = arguments.last else { return 1 }
            return uninstall(bundleID: bundleID)
        case "refresh", "refresh-all":
            return TSRegistration.refreshManagedApps() ? 0 : 181
        case "open":
            guard let bundleID = arguments.last else { return 1 }
            return TSPrivateServices.open(bundleID: bundleID) ? 0 : 1
        case "install-ldid":
            guard arguments.count >= 2 else { return 1 }
            return installLdid(from: arguments[1])
        case "verify-ldid":
            guard let path = TSLdid.executablePath() else { return 173 }
            let result = TSLdid.run(["--version"])
            print("ldid: \(path)\n\(result.output)")
            return result.status
        default:
            fputs("Unsupported helper command: \(command)\n", stderr)
            return 2
        }
    }

    private static func installLdid(from sourcePath: String) -> Int32 {
        let destination = URL(fileURLWithPath: CommandLine.arguments.first ?? "/trollstorehelper").deletingLastPathComponent().appendingPathComponent("ldid").path
        do {
            if FileManager.default.fileExists(atPath: destination) { try FileManager.default.removeItem(atPath: destination) }
            try FileManager.default.copyItem(atPath: sourcePath, toPath: destination)
            _ = tsChmod(destination, 0o755)
            return 0
        } catch {
            fputs("Failed installing bundled ldid: \(error)\n", stderr)
            return 1
        }
    }

    #if !EMBEDDED_ROOT_HELPER
    private static func makeInstallStagingRoot() -> String? {
        // Stage on the same APFS volume as installed apps so the final move is a rename, not a
        // multi-gigabyte copy. The hidden temporary directory is removed before returning.
        let fileManager = FileManager.default
        let candidates = ["/var/containers/Bundle/Application", "/var/containers/Bundle/TrollStore", NSTemporaryDirectory()]
        for base in candidates {
            var isDirectory: ObjCBool = false
            guard fileManager.fileExists(atPath: base, isDirectory: &isDirectory), isDirectory.boolValue else { continue }
            let stage = URL(fileURLWithPath: base, isDirectory: true)
                .appendingPathComponent(".TrollStore-Install-\(UUID().uuidString)", isDirectory: true).path
            do {
                try fileManager.createDirectory(atPath: stage, withIntermediateDirectories: false)
                return stage
            } catch {
                continue
            }
        }
        return nil
    }

    private static func installIPA(_ ipaPath: String, force: Bool, customEntitlements: [String: Any]) -> Int32 {
        guard FileManager.default.fileExists(atPath: ipaPath) else { return 166 }
        guard TSLdid.executablePath() != nil else { return 173 }

        guard let temporaryRoot = makeInstallStagingRoot() else { return 1 }
        defer { try? FileManager.default.removeItem(atPath: temporaryRoot) }

        fputs("[install] extracting Payload\n", stderr)
        let extractionStarted = ProcessInfo.processInfo.systemUptime
        guard TSArchiveExtractor.extractPayload(from: ipaPath, to: temporaryRoot) else { return 168 }
        TSPerformanceLog.record("IPA extraction", startedAt: extractionStarted)
        let payloadPath = URL(fileURLWithPath: temporaryRoot).appendingPathComponent("Payload").path
        guard let appPath = TSBundleUtils.mainApp(in: payloadPath) else { return 167 }
        guard let appInfo = TSBundleUtils.info(at: appPath) else { return 172 }
        guard FileManager.default.fileExists(atPath: appInfo.executablePath) else { return 174 }
        if appInfo.bundleID.caseInsensitiveCompare(tsProtectedBundleID) == .orderedSame { return 179 }
        if FileManager.default.fileExists(atPath: "/System/Library/AppSignatures/\(appInfo.bundleID)") { return 179 }

        TSBundleUtils.patchInfoPlist(appPath)
        fputs("[install] signing \(appInfo.bundleID)\n", stderr)
        let overallSigningStarted = ProcessInfo.processInfo.systemUptime
        let signResult = TSSigner.signApp(at: appPath, customEntitlements: customEntitlements)
        TSPerformanceLog.record("total signing pipeline", startedAt: overallSigningStarted)
        if signResult != 0 && signResult != 182 && signResult != 184 { return signResult }
        let requiresDeveloperMode = signResult == 182
        let hasAdditionalEncryptedBinaries = signResult == 184

        let existingProxy = TSPrivateServices.appProxy(bundleID: appInfo.bundleID)
        let existingURL = (existingProxy?.value(forKey: "bundleURL") as? URL)?.standardizedFileURL
        let existingBundlePath = existingURL?.path
        var targetContainerPath: String?

        if let existingBundlePath, FileManager.default.fileExists(atPath: existingBundlePath) {
            let parent = URL(fileURLWithPath: existingBundlePath).deletingLastPathComponent().path
            let isManaged = FileManager.default.fileExists(atPath: URL(fileURLWithPath: parent).appendingPathComponent(tsActiveMarker).path) ||
                            FileManager.default.fileExists(atPath: URL(fileURLWithPath: parent).appendingPathComponent(tsInactiveMarker).path)
            if !isManaged && !force { return 171 }
            targetContainerPath = parent
        } else if let container = TSPrivateServices.appContainer(bundleID: appInfo.bundleID, create: true),
                  let url = container.value(forKey: "url") as? URL {
            targetContainerPath = url.path
        } else {
            return 170
        }

        guard let containerPath = targetContainerPath else { return 170 }
        let installMoveStarted = ProcessInfo.processInfo.systemUptime
        let targetBundlePath = URL(fileURLWithPath: containerPath).appendingPathComponent(URL(fileURLWithPath: appPath).lastPathComponent).path
        var stagedBackups: [(original: String, backup: String)] = []
        var pathsToStage: [String] = []
        if let existingBundlePath, FileManager.default.fileExists(atPath: existingBundlePath) {
            pathsToStage.append(existingBundlePath)
        }
        if FileManager.default.fileExists(atPath: targetBundlePath), !pathsToStage.contains(targetBundlePath) {
            pathsToStage.append(targetBundlePath)
        }

        // Existing installs can have a different `.app` directory name than the IPA being installed.
        // Stage both paths when needed so a successful update cannot leave a second stale app behind.
        for oldPath in pathsToStage {
            let backupPath = URL(fileURLWithPath: containerPath)
                .appendingPathComponent(".TrollStore-backup-\(UUID().uuidString)").path
            do {
                try FileManager.default.moveItem(atPath: oldPath, toPath: backupPath)
                stagedBackups.append((oldPath, backupPath))
            } catch {
                for item in stagedBackups.reversed() { try? FileManager.default.moveItem(atPath: item.backup, toPath: item.original) }
                fputs("[install] could not stage existing app at \(oldPath): \(error)\n", stderr)
                return 178
            }
        }

        func rollbackInstall() {
            try? FileManager.default.removeItem(atPath: targetBundlePath)
            for item in stagedBackups.reversed() {
                try? FileManager.default.moveItem(atPath: item.backup, toPath: item.original)
            }
        }

        do {
            // A same-volume move is a rename and avoids writing large app resources twice.
            try FileManager.default.moveItem(atPath: appPath, toPath: targetBundlePath)
        } catch {
            do {
                try FileManager.default.copyItem(atPath: appPath, toPath: targetBundlePath)
                try? FileManager.default.removeItem(atPath: appPath)
            } catch {
                rollbackInstall()
                fputs("[install] app copy failed: \(error)\n", stderr)
                return 178
            }
        }

        TSPerformanceLog.record("same-volume install move and backup staging", startedAt: installMoveStarted)
        let markerPath = URL(fileURLWithPath: containerPath).appendingPathComponent(tsActiveMarker).path
        let markerExisted = FileManager.default.fileExists(atPath: markerPath)
        if !markerExisted {
            guard FileManager.default.createFile(atPath: markerPath, contents: Data()) else {
                rollbackInstall()
                return 177
            }
        }

        let permissionsStarted = ProcessInfo.processInfo.systemUptime
        TSBundleUtils.repairPermissions(targetBundlePath)
        TSPerformanceLog.record("permission repair", startedAt: permissionsStarted)
        fputs("[install] registering \(appInfo.bundleID)\n", stderr)
        let registrationStarted = ProcessInfo.processInfo.systemUptime
        guard TSRegistration.registerApp(at: targetBundlePath) else {
            rollbackInstall()
            if !markerExisted { try? FileManager.default.removeItem(atPath: markerPath) }
            return 181
        }

        for item in stagedBackups { try? FileManager.default.removeItem(atPath: item.backup) }
        try? FileManager.default.removeItem(atPath: URL(fileURLWithPath: containerPath).appendingPathComponent(tsInactiveMarker).path)
        TSPrivateServices.rebuildDatabases()
        TSPerformanceLog.record("LaunchServices registration and refresh", startedAt: registrationStarted)
        if requiresDeveloperMode { return 182 }
        return hasAdditionalEncryptedBinaries ? 184 : 0
    }
    #endif // !EMBEDDED_ROOT_HELPER

    private static func uninstall(bundleID: String) -> Int32 {
        guard let proxy = TSPrivateServices.appProxy(bundleID: bundleID),
              let url = proxy.value(forKey: "bundleURL") as? URL else { return 1 }
        let appPath = url.path
        let parent = url.deletingLastPathComponent().path
        let managed = FileManager.default.fileExists(atPath: URL(fileURLWithPath: parent).appendingPathComponent(tsActiveMarker).path) ||
                      FileManager.default.fileExists(atPath: URL(fileURLWithPath: parent).appendingPathComponent(tsInactiveMarker).path)
        guard managed else { return 171 }

        _ = TSPrivateServices.uninstall(bundleID: bundleID)
        do {
            try FileManager.default.removeItem(atPath: parent)
            TSPrivateServices.rebuildDatabases()
            return 0
        } catch {
            fputs("[uninstall] \(error)\n", stderr)
            return FileManager.default.fileExists(atPath: appPath) ? 1 : 0
        }
    }
}

#if !EMBEDDED_ROOT_HELPER
@main
private enum RootHelperCommandLine {
    static func main() {
        let status = TrollStoreRootHelper.run(Array(CommandLine.arguments.dropFirst()))
        exit(status)
    }
}
#endif
