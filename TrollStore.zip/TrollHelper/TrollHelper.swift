// TrollHelper.swift
// Minimal Swift persistence-helper UI. When embedded and started with helper
// arguments as root, it dispatches to the shared TrollStoreRootHelper implementation.

import UIKit
import Foundation
import Darwin
import ObjectiveC.runtime

// Match the original helper's privileged spawn semantics.
@_silgen_name("posix_spawnattr_set_persona_np")
private func tshSpawnSetPersona(_ attributes: UnsafePointer<posix_spawnattr_t>?, _ persona: uid_t, _ flags: UInt32) -> Int32
@_silgen_name("posix_spawnattr_set_persona_uid_np")
private func tshSpawnSetPersonaUID(_ attributes: UnsafePointer<posix_spawnattr_t>?, _ uid: uid_t) -> Int32
@_silgen_name("posix_spawnattr_set_persona_gid_np")
private func tshSpawnSetPersonaGID(_ attributes: UnsafePointer<posix_spawnattr_t>?, _ gid: gid_t) -> Int32
private let tshPersonaOverrideFlags: UInt32 = 1

@objc(TSHAppDelegateNoScene)
final class TrollHelperAppDelegate: UIResponder, UIApplicationDelegate {
    var window: UIWindow?

    func application(_ application: UIApplication,
                    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        let window = UIWindow(frame: UIScreen.main.bounds)
        let root = TrollHelperRootViewController()
        window.rootViewController = UINavigationController(rootViewController: root)
        self.window = window
        window.makeKeyAndVisible()
        return true
    }
}

final class TrollHelperRootViewController: UIViewController {
    private let statusLabel = UILabel()
    private let refreshButton = UIButton(type: .system)
    private let openButton = UIButton(type: .system)

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "TrollStore Helper"
        view.backgroundColor = .systemGroupedBackground

        let icon = UIImageView(image: UIImage(systemName: "checkmark.shield.fill"))
        icon.tintColor = .systemGreen
        icon.contentMode = .scaleAspectFit
        icon.preferredSymbolConfiguration = UIImage.SymbolConfiguration(pointSize: 48, weight: .regular)

        let heading = UILabel()
        heading.text = "TrollStore Persistence Helper"
        heading.font = .preferredFont(forTextStyle: .title2)
        heading.textAlignment = .center
        heading.numberOfLines = 0

        statusLabel.text = "Use this helper to refresh TrollStore app registrations if icons disappear or apps cannot launch after an icon-cache rebuild."
        statusLabel.font = .preferredFont(forTextStyle: .body)
        statusLabel.textColor = .secondaryLabel
        statusLabel.textAlignment = .center
        statusLabel.numberOfLines = 0

        refreshButton.setTitle("Refresh App Registrations", for: .normal)
        refreshButton.titleLabel?.font = .preferredFont(forTextStyle: .headline)
        refreshButton.addTarget(self, action: #selector(refreshPressed), for: .touchUpInside)
        refreshButton.backgroundColor = .secondarySystemGroupedBackground
        refreshButton.layer.cornerRadius = 12
        refreshButton.contentEdgeInsets = UIEdgeInsets(top: 14, left: 18, bottom: 14, right: 18)

        openButton.setTitle("Open TrollStore", for: .normal)
        openButton.titleLabel?.font = .preferredFont(forTextStyle: .headline)
        openButton.addTarget(self, action: #selector(openPressed), for: .touchUpInside)
        openButton.backgroundColor = .secondarySystemGroupedBackground
        openButton.layer.cornerRadius = 12
        openButton.contentEdgeInsets = UIEdgeInsets(top: 14, left: 18, bottom: 14, right: 18)

        let stack = UIStackView(arrangedSubviews: [icon, heading, statusLabel, refreshButton, openButton])
        stack.axis = .vertical
        stack.spacing = 20
        stack.alignment = .fill
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -24),
            stack.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            icon.heightAnchor.constraint(equalToConstant: 64)
        ])
    }

    @objc private func refreshPressed() {
        setBusy(true, message: "Refreshing LaunchServices registrations…")
        DispatchQueue.global(qos: .userInitiated).async {
            let result = TrollHelperProcess.run(["refresh-all"])
            DispatchQueue.main.async {
                self.setBusy(false, message: result.status == 0
                              ? "Registrations refreshed. Return to the Home Screen and check your TrollStore apps."
                              : "Refresh failed (\(result.status)). \(result.output)")
                self.showAlert(title: result.status == 0 ? "Completed" : "Refresh failed",
                               message: self.statusLabel.text ?? result.output)
            }
        }
    }

    @objc private func openPressed() {
        guard let workspaceClass = NSClassFromString("LSApplicationWorkspace"),
              let factory = class_getClassMethod(workspaceClass, NSSelectorFromString("defaultWorkspace")) else {
            showAlert(title: "Unavailable", message: "LaunchServices is not available in this process.")
            return
        }
        typealias Factory = @convention(c) (AnyClass, Selector) -> Unmanaged<AnyObject>?
        let workspace = unsafeBitCast(method_getImplementation(factory), to: Factory.self)(workspaceClass, NSSelectorFromString("defaultWorkspace"))?.takeUnretainedValue()
        guard let workspace,
              let method = class_getInstanceMethod(type(of: workspace), NSSelectorFromString("openApplicationWithBundleID:")) else {
            showAlert(title: "Unavailable", message: "Could not resolve the LaunchServices open API.")
            return
        }
        typealias Open = @convention(c) (AnyObject, Selector, NSString) -> Bool
        let function = unsafeBitCast(method_getImplementation(method), to: Open.self)
        let opened = function(workspace, NSSelectorFromString("openApplicationWithBundleID:"), "com.opa334.TrollStore" as NSString)
        if !opened { showAlert(title: "Could not open TrollStore", message: "Make sure TrollStore is installed and registered.") }
    }

    private func setBusy(_ busy: Bool, message: String) {
        refreshButton.isEnabled = !busy
        openButton.isEnabled = !busy
        statusLabel.text = message
    }

    private func showAlert(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

private struct TrollHelperProcessResult {
    let status: Int32
    let output: String
}

private enum TrollHelperProcess {
    static func run(_ arguments: [String]) -> TrollHelperProcessResult {
        #if EMBEDDED_ROOT_HELPER
        let helper = CommandLine.arguments.first ?? ""
        #else
        let helper = Bundle.main.bundleURL.appendingPathComponent("trollstorehelper").path
        #endif
        guard !helper.isEmpty, FileManager.default.isExecutableFile(atPath: helper) else {
            return TrollHelperProcessResult(status: 127, output: "Missing embedded trollstorehelper at \(helper).")
        }
        var fds: [Int32] = [0, 0]
        guard pipe(&fds) == 0 else { return TrollHelperProcessResult(status: errno, output: "pipe() failed") }
        var actions = posix_spawn_file_actions_t()
        posix_spawn_file_actions_init(&actions)
        var attributes = posix_spawnattr_t()
        posix_spawnattr_init(&attributes)
        _ = tshSpawnSetPersona(&attributes, 99, tshPersonaOverrideFlags)
        _ = tshSpawnSetPersonaUID(&attributes, 0)
        _ = tshSpawnSetPersonaGID(&attributes, 0)
        posix_spawn_file_actions_adddup2(&actions, fds[1], STDOUT_FILENO)
        posix_spawn_file_actions_adddup2(&actions, fds[1], STDERR_FILENO)
        posix_spawn_file_actions_addclose(&actions, fds[0])
        posix_spawn_file_actions_addclose(&actions, fds[1])
        // The argv pointer passed to posix_spawn must be NULL-terminated.
        let argv: [UnsafeMutablePointer<CChar>?] = ([helper] + arguments).map { strdup($0) } + [nil]
        defer {
            for pointer in argv { if let pointer { free(pointer) } }
            posix_spawn_file_actions_destroy(&actions)
            posix_spawnattr_destroy(&attributes)
        }
        var pid = pid_t(0)
        let spawnStatus: Int32 = argv.withUnsafeMutableBufferPointer { buffer in
            guard let base = buffer.baseAddress else { return EINVAL }
            return helper.withCString { cHelper in
                posix_spawn(&pid, cHelper, &actions, &attributes, base, environ)
            }
        }
        close(fds[1])
        guard spawnStatus == 0 else {
            close(fds[0])
            return TrollHelperProcessResult(status: spawnStatus, output: "posix_spawn failed")
        }
        var output = Data()
        let chunk = UnsafeMutableRawPointer.allocate(byteCount: 16 * 1024, alignment: 16)
        defer { chunk.deallocate() }
        while true {
            let count = read(fds[0], chunk, 16 * 1024)
            if count == 0 { break }
            if count < 0 {
                if errno == EINTR { continue }
                break
            }
            if output.count < 512 * 1024 {
                output.append(chunk.assumingMemoryBound(to: UInt8.self), count: min(count, 512 * 1024 - output.count))
            }
        }
        close(fds[0])
        var status: Int32 = 0
        while waitpid(pid, &status, 0) == -1 {
            if errno == EINTR { continue }
            return TrollHelperProcessResult(status: errno, output: String(data: output, encoding: .utf8) ?? "")
        }
        let code: Int32 = (status & 0x7f) == 0 ? ((status >> 8) & 0xff) : (128 + (status & 0x7f))
        return TrollHelperProcessResult(status: code, output: String(data: output, encoding: .utf8) ?? "")
    }
}

@main
private enum TrollHelperEntry {
    static func main() {
        let arguments = Array(CommandLine.arguments.dropFirst())
        #if EMBEDDED_ROOT_HELPER
        if geteuid() == 0 && !arguments.isEmpty {
            exit(TrollStoreRootHelper.run(arguments))
        }
        #endif
        UIApplicationMain(CommandLine.argc, CommandLine.unsafeArgv, nil, NSStringFromClass(TrollHelperAppDelegate.self))
    }
}
