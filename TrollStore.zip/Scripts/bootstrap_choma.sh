#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CHOMA_DIR="${ROOT}/ChOma"
CHOMA_URL="${CHOMA_URL:-https://github.com/opa334/ChOma.git}"
CHOMA_COMMIT="${CHOMA_COMMIT:-964023ddac2286ef8e843f90df64d44ac6a673df}"
MARKER="${CHOMA_DIR}/.trollstore-choma-commit"
ARCHIVE_URL="https://codeload.github.com/opa334/ChOma/tar.gz/${CHOMA_COMMIT}"

has_required_files() {
    [[ -f "${CHOMA_DIR}/src/FAT.h" && \
       -f "${CHOMA_DIR}/src/MachOLoadCommand.h" && \
       -f "${CHOMA_DIR}/src/CodeDirectory.h" && \
       -f "${CHOMA_DIR}/src/CSBlob.h" && \
       -f "${CHOMA_DIR}/external/ios/libcrypto.a" ]]
}

current_revision() {
    local revision=""
    if git -C "$CHOMA_DIR" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
        revision="$(git -C "$CHOMA_DIR" rev-parse HEAD 2>/dev/null || true)"
    elif [[ -f "$MARKER" ]]; then
        revision="$(cat "$MARKER" 2>/dev/null || true)"
    fi
    printf '%s' "$revision"
}

fetch_archive() {
    local archive
    archive="$(mktemp "${TMPDIR:-/tmp}/choma-${CHOMA_COMMIT}.XXXXXX.tar.gz")"
    trap 'rm -f "${archive:-}"' EXIT
    echo "[deps] downloading ChOma source archive pinned to ${CHOMA_COMMIT}"
    curl --fail --silent --show-error --location --retry 3 "$ARCHIVE_URL" -o "$archive"
    tar -tzf "$archive" >/dev/null

    # Deliberately discard any cached Git checkout with a different commit.
    # Switching an old shallow checkout with `git fetch <sha>` can fail or leave
    # FETCH_HEAD/HEAD state ambiguous; an immutable commit archive is deterministic.
    rm -rf "$CHOMA_DIR"
    mkdir -p "$CHOMA_DIR"
    tar -xzf "$archive" --strip-components=1 -C "$CHOMA_DIR"
    printf '%s\n' "$CHOMA_COMMIT" > "$MARKER"
    rm -f "$archive"
    trap - EXIT
}

revision="$(current_revision)"
if [[ "$revision" != "$CHOMA_COMMIT" ]] || ! has_required_files; then
    echo "[deps] replacing ChOma source (found ${revision:-unmarked source}; expected ${CHOMA_COMMIT})"
    fetch_archive
else
    # A cached source tree is only trusted if its API and required files still match.
    if python3 "${ROOT}/Scripts/validate_choma_api.py" "$CHOMA_DIR" --expected-commit "$CHOMA_COMMIT"; then
        exit 0
    fi
    echo "[deps] cached ChOma source failed validation; re-fetching pinned commit"
    fetch_archive
fi

python3 "${ROOT}/Scripts/validate_choma_api.py" "$CHOMA_DIR" --expected-commit "$CHOMA_COMMIT"
