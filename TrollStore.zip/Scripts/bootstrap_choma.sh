#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
CHOMA_DIR="${ROOT}/ChOma"
CHOMA_URL="${CHOMA_URL:-https://github.com/opa334/ChOma.git}"
CHOMA_COMMIT="${CHOMA_COMMIT:-964023ddac2286ef8e843f90df64d44ac6a673df}"
MARKER="${CHOMA_DIR}/.trollstore-choma-commit"
ARCHIVE_URL="https://codeload.github.com/opa334/ChOma/tar.gz/${CHOMA_COMMIT}"

fetch_archive() {
    local archive
    archive="$(mktemp "${TMPDIR:-/tmp}/choma-${CHOMA_COMMIT}.XXXXXX.tar.gz")"
    echo "[deps] downloading ChOma pinned to ${CHOMA_COMMIT}"
    curl --fail --silent --show-error --location --retry 3 "$ARCHIVE_URL" -o "$archive"
    rm -rf "$CHOMA_DIR"
    mkdir -p "$CHOMA_DIR"
    tar -xzf "$archive" --strip-components=1 -C "$CHOMA_DIR"
    rm -f "$archive"
    printf '%s\n' "$CHOMA_COMMIT" > "$MARKER"
}

# If the outer workflow already cloned the moving default branch, update that
# checkout to the exact submodule commit rather than accepting an API mismatch.
if git -C "$CHOMA_DIR" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    current="$(git -C "$CHOMA_DIR" rev-parse HEAD 2>/dev/null || true)"
    if [[ "$current" != "$CHOMA_COMMIT" ]]; then
        echo "[deps] ChOma revision mismatch: ${current:-unknown}; expected ${CHOMA_COMMIT}"
        if ! git -C "$CHOMA_DIR" remote get-url origin >/dev/null 2>&1; then
            git -C "$CHOMA_DIR" remote add origin "$CHOMA_URL"
        else
            git -C "$CHOMA_DIR" remote set-url origin "$CHOMA_URL"
        fi
        if git -C "$CHOMA_DIR" fetch --depth 1 origin "$CHOMA_COMMIT"; then
            git -C "$CHOMA_DIR" checkout --force --detach FETCH_HEAD
        else
            echo "[deps] direct commit fetch unavailable; falling back to pinned source archive"
            fetch_archive
        fi
    fi
fi

# ZIP exports have no .git directory. Trust only the matching marker; otherwise
# fetch the same pinned source archive. Also recover from an incomplete cache.
if git -C "$CHOMA_DIR" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    current="$(git -C "$CHOMA_DIR" rev-parse HEAD 2>/dev/null || true)"
    if [[ "$current" != "$CHOMA_COMMIT" ]]; then
        echo "error: failed to resolve ChOma commit ${CHOMA_COMMIT}" >&2
        exit 2
    fi
    printf '%s\n' "$CHOMA_COMMIT" > "$MARKER"
else
    marker="$(cat "$MARKER" 2>/dev/null || true)"
    if [[ "$marker" != "$CHOMA_COMMIT" || ! -f "$CHOMA_DIR/src/FAT.h" || ! -f "$CHOMA_DIR/external/ios/libcrypto.a" ]]; then
        fetch_archive
    fi
fi

python3 "${ROOT}/Scripts/validate_choma_api.py" "$CHOMA_DIR" --expected-commit "$CHOMA_COMMIT"
