#!/usr/bin/env python3
"""Fail-fast static checks for the three-file Swift TrollStore port."""
from pathlib import Path
import plistlib
import sys

ROOT = Path(__file__).resolve().parent.parent
REQUIRED = [
    "Makefile",
    "CHOMA-COMMIT.txt",
    ".github/workflows/build.yml",
    "TrollStore/Makefile",
    "TrollStore/TrollStore.swift",
    "TrollStore/Resources/Info.plist",
    "TrollStore/entitlements.plist",
    "TrollStore/Resources/Base.lproj/LaunchScreen.storyboardc/Info.plist",
    "RootHelper/Makefile",
    "RootHelper/RootHelper.swift",
    "RootHelper/entitlements.plist",
    "TrollHelper/Makefile",
    "TrollHelper/TrollHelper.swift",
    "TrollHelper/Resources/Info.plist",
    "TrollHelper/entitlements.plist",
    "bin/ldid",
    "Exploits/fastPathSign/Makefile",
    "Exploits/fastPathSign/src/coretrust_bug.c",
    "Exploits/fastPathSign/src/codesign.m",
    "Scripts/validate_macho.py",
    "Scripts/bootstrap_choma.sh",
    "Scripts/validate_choma_api.py",
]
missing = [item for item in REQUIRED if not (ROOT / item).is_file()]
if missing:
    print("error: missing required project files:", ", ".join(missing), file=sys.stderr)
    raise SystemExit(1)

swift_sources = sorted(
    str(path.relative_to(ROOT))
    for folder in (ROOT / "TrollStore", ROOT / "RootHelper", ROOT / "TrollHelper")
    for path in folder.rglob("*.swift")
)
expected_swift = [
    "RootHelper/RootHelper.swift",
    "TrollHelper/TrollHelper.swift",
    "TrollStore/TrollStore.swift",
]
if swift_sources != expected_swift:
    print(f"error: expected exactly the three consolidated Swift files, found {swift_sources}", file=sys.stderr)
    raise SystemExit(1)

root_makefile = (ROOT / "Makefile").read_text(encoding="utf-8")
workflow_text = (ROOT / ".github/workflows/build.yml").read_text(encoding="utf-8")
pinned_choma = "964023ddac2286ef8e843f90df64d44ac6a673df"
if pinned_choma not in root_makefile or pinned_choma not in workflow_text:
    raise SystemExit("error: ChOma must be pinned to TrollStore's compatible submodule revision")
if "git clone --depth 1 https://github.com/opa334/ChOma.git ChOma" in workflow_text:
    raise SystemExit("error: workflow must not clone ChOma's moving default branch")
if "bootstrap-swift-support:" not in root_makefile or "$(MAKE) bootstrap-swift-support" not in root_makefile:
    raise SystemExit("error: Swift support must be bootstrapped serially before parallel target builds")

if any(path.name == ".Assets" for path in ROOT.rglob("*")):
    print("error: unexpected .Assets directory or file", file=sys.stderr)
    raise SystemExit(1)
if any("Donate" in path.name or "donat" in path.name.lower() for path in ROOT.rglob("*")):
    print("error: donation feature file remains in the project", file=sys.stderr)
    raise SystemExit(1)

plist_files = sorted(ROOT.rglob("*.plist"))
for path in plist_files:
    try:
        with path.open("rb") as stream:
            plistlib.load(stream)
    except Exception as exc:
        print(f"error: invalid plist {path.relative_to(ROOT)}: {exc}", file=sys.stderr)
        raise SystemExit(1)

with (ROOT / "TrollStore/Resources/Info.plist").open("rb") as stream:
    app_info = plistlib.load(stream)
with (ROOT / "TrollHelper/Resources/Info.plist").open("rb") as stream:
    helper_info = plistlib.load(stream)
if app_info.get("CFBundleExecutable") != "TrollStore":
    raise SystemExit("error: TrollStore Info.plist executable does not match the target")
if app_info.get("CFBundleIdentifier") != "com.opa334.TrollStore":
    raise SystemExit("error: unexpected TrollStore bundle identifier")
if not {"trollstorehelper", "ldid"}.issubset(set(app_info.get("TSRootBinaries", []))):
    raise SystemExit("error: TSRootBinaries must include trollstorehelper and ldid")
if any("public.tar-archive" in (entry.get("LSItemContentTypes") or []) for entry in app_info.get("CFBundleDocumentTypes", [])):
    raise SystemExit("error: unsupported .tar update document type must not be advertised")
if helper_info.get("CFBundleExecutable") != "TrollStorePersistenceHelper":
    raise SystemExit("error: persistence helper Info.plist executable does not match the target")
root_helper_source = (ROOT / "RootHelper/RootHelper.swift").read_text(encoding="utf-8")
if 'executableURL.path.hasPrefix(bundleURL.path + "/")' not in root_helper_source:
    raise SystemExit("error: bundle executable path-containment check is missing")
if "/var/containers/Bundle/TrollStore/TrollStore.app" not in root_helper_source:
    raise SystemExit("error: persistence refresh must re-register TrollStore itself")

ldid = ROOT / "bin/ldid"
if ldid.stat().st_size < 1024 * 1024:
    raise SystemExit("error: bin/ldid is unexpectedly small; expected a precompiled device executable")

print(f"[audit] {len(REQUIRED)} required files present")
print(f"[audit] exactly {len(swift_sources)} consolidated Swift source files")
print(f"[audit] {len(plist_files)} plist files parse successfully")
print("[audit] bundle IDs, target executables, resources, and bundled ldid metadata verified")
