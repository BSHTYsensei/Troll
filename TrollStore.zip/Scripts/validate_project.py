#!/usr/bin/env python3
"""Static integrity checks for the restored original TrollStore UI + zh-Hans build."""
from pathlib import Path
import hashlib
import json
import plistlib
import re
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
PINNED_CHOMA = "964023ddac2286ef8e843f90df64d44ac6a673df"
REQUIRED = [
    "Makefile", "CHOMA-COMMIT.txt", ".gitmodules", "README.md",
    "TrollStore/Makefile", "TrollStore/main.m", "TrollStore/TSRootViewController.m",
    "TrollStore/TSAppTableViewController.m", "TrollStore/TSAppInfo.m",
    "TrollStore/TSApplicationsManager.m", "TrollStore/TSInstallationController.m",
    "TrollStore/TSSettingsListController.m", "TrollStore/TSSettingsAdvancedListController.m",
    "TrollStore/TSEntitlementsEditorViewController.swift", "TrollStore/entitlements.plist",
    "TrollStore/Resources/Info.plist", "TrollStore/Resources/ldid",
    "TrollStore/Resources/zh-Hans.lproj/Localizable.strings",
    "TrollStore/Resources/zh-Hans.lproj/InfoPlist.strings",
    "RootHelper/Makefile", "RootHelper/main.m", "RootHelper/entitlements.plist",
    "TrollHelper/Makefile", "TrollHelper/main.m", "TrollHelper/TSHRootViewController.m",
    "TrollHelper/Resources/Info.plist", "TrollHelper/entitlements.plist",
    "TrollHelper/Resources/zh-Hans.lproj/Localizable.strings",
    "TrollHelper/Resources/zh-Hans.lproj/InfoPlist.strings",
    "Shared/TSUtil.h", "Shared/TSUtil.m", "Shared/TSListControllerShared.m",
    "Shared/TSPresentationDelegate.m", "Exploits/fastPathSign/Makefile",
    "Exploits/fastPathSign/src/coretrust_bug.c", "Exploits/fastPathSign/src/codesign.m",
    "Scripts/bootstrap_choma.sh", "Scripts/validate_choma_api.py", "Scripts/validate_macho.py",
    "Scripts/validate_project.py", "bin/ldid",
]
missing = [item for item in REQUIRED if not (ROOT / item).is_file()]
if missing:
    raise SystemExit("error: missing required project files: " + ", ".join(missing))

# The original ObjC controllers should remain; only the new settings sub-page is Swift.
swift_sources = sorted(
    str(p.relative_to(ROOT))
    for top in (ROOT / "TrollStore", ROOT / "RootHelper", ROOT / "TrollHelper", ROOT / "Shared")
    for p in top.rglob("*.swift")
)
if swift_sources != ["TrollStore/TSEntitlementsEditorViewController.swift"]:
    raise SystemExit(f"error: expected only the supplementary Entitlements Swift controller, found {swift_sources}")

for rel in ("Makefile", "CHOMA-COMMIT.txt", "Scripts/bootstrap_choma.sh", "Scripts/validate_choma_api.py"):
    if PINNED_CHOMA not in (ROOT / rel).read_text(encoding="utf-8"):
        raise SystemExit(f"error: {rel} does not pin compatible ChOma revision {PINNED_CHOMA}")
root_make = (ROOT / "Makefile").read_text(encoding="utf-8")
app_make = (ROOT / "TrollStore/Makefile").read_text(encoding="utf-8")
if "bootstrap-swift-support:" not in root_make or "build-targets: build-fastpaths" not in root_make:
    raise SystemExit("error: dependency bootstrap / compile order is incomplete")
if "TrollStore_SWIFT_FILES = TSEntitlementsEditorViewController.swift" not in app_make:
    raise SystemExit("error: Swift Entitlements editor is not included in the TrollStore app target")
if "TrollStore_SWIFT_VERSION = 5" not in app_make:
    raise SystemExit("error: Swift language version must be pinned")

if any(p.name == ".Assets" for p in ROOT.rglob("*")):
    raise SystemExit("error: a .Assets path is not allowed")
if any("Donate" in p.name or "donat" in p.name.lower() for p in ROOT.rglob("*")):
    raise SystemExit("error: donation feature source remains in the project")
if (ROOT / "TrollStore/TSDonateListController.m").exists() or (ROOT / "TrollStore/TSDonateListController.h").exists():
    raise SystemExit("error: original donation controller was not removed")

plists = sorted(ROOT.rglob("*.plist"))
for path in plists:
    try:
        with path.open("rb") as stream:
            plistlib.load(stream)
    except Exception as exc:
        raise SystemExit(f"error: invalid plist {path.relative_to(ROOT)}: {exc}")

app_info = plistlib.loads((ROOT / "TrollStore/Resources/Info.plist").read_bytes())
helper_info = plistlib.loads((ROOT / "TrollHelper/Resources/Info.plist").read_bytes())
if app_info.get("CFBundleExecutable") != "TrollStore" or app_info.get("CFBundleIdentifier") != "com.opa334.TrollStore":
    raise SystemExit("error: main app bundle identity has changed")
if not {"trollstorehelper", "ldid"}.issubset(set(app_info.get("TSRootBinaries", []))):
    raise SystemExit("error: TSRootBinaries must include trollstorehelper and ldid")
if not any("public.tar-archive" in entry.get("LSItemContentTypes", []) for entry in app_info.get("CFBundleDocumentTypes", [])):
    raise SystemExit("error: original .tar self-update document association has been lost")
if helper_info.get("CFBundleExecutable") != "TrollStorePersistenceHelper":
    raise SystemExit("error: persistence helper bundle identity has changed")
for label, info in (("TrollStore", app_info), ("TrollHelper", helper_info)):
    if info.get("CFBundleDevelopmentRegion") != "zh-Hans":
        raise SystemExit(f"error: {label} must use zh-Hans as its default/fallback language")
    if info.get("CFBundleLocalizations") != ["zh-Hans"]:
        raise SystemExit(f"error: {label} must advertise zh-Hans as the only bundled localization so Chinese is visible on English devices too")

# Ensure the bundled device binary is the same one supplied at bin/ldid.
def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()
ldid = ROOT / "bin/ldid"
embedded_ldid = ROOT / "TrollStore/Resources/ldid"
if ldid.stat().st_size < 1024 * 1024 or not (ldid.stat().st_mode & 0o111):
    raise SystemExit("error: bin/ldid must be an executable precompiled device binary")
if sha(ldid) != sha(embedded_ldid):
    raise SystemExit("error: bin/ldid and TrollStore/Resources/ldid differ")

# Validate OpenStep .strings syntax using plutil and make sure every source key is present.
strings_files = [
    ROOT / "TrollStore/Resources/zh-Hans.lproj/Localizable.strings",
    ROOT / "TrollHelper/Resources/zh-Hans.lproj/Localizable.strings",
    ROOT / "TrollStore/Resources/zh-Hans.lproj/InfoPlist.strings",
    ROOT / "TrollHelper/Resources/zh-Hans.lproj/InfoPlist.strings",
]
for path in strings_files:
    result = subprocess.run(["plutil", "-lint", "--", str(path)], text=True, capture_output=True)
    if result.returncode:
        raise SystemExit(f"error: invalid strings resource {path.relative_to(ROOT)}: {result.stderr.strip() or result.stdout.strip()}")

def decode_quoted(value):
    try:
        return json.loads('"' + value + '"')
    except Exception:
        return value

def catalog_entries(path):
    entries = {}
    pattern = re.compile(r'\s*"((?:\\.|[^"\\])*)"\s*=\s*"((?:\\.|[^"\\])*)"\s*;')
    for line in path.read_text(encoding="utf-8").splitlines():
        m = pattern.match(line)
        if m:
            entries[decode_quoted(m.group(1))] = decode_quoted(m.group(2))
    return entries

def catalog_keys(path):
    return set(catalog_entries(path))

source_keys = set()
source_extensions = {".m", ".h", ".swift"}
for path in ROOT.rglob("*"):
    if path.is_file() and path.suffix in source_extensions and any(part in {"TrollStore", "TrollHelper", "Shared"} for part in path.parts):
        text = path.read_text(encoding="utf-8", errors="replace")
        for match in re.finditer(r'NSLocalizedString\(@"((?:\\.|[^"\\])*)"\s*,', text):
            source_keys.add(decode_quoted(match.group(1)))
app_entries = catalog_entries(strings_files[0])
helper_entries = catalog_entries(strings_files[1])
app_keys = set(app_entries)
helper_keys = set(helper_entries)
chinese_values = [value for value in app_entries.values() if any("\u4e00" <= char <= "\u9fff" for char in value)]
if len(chinese_values) < 100:
    raise SystemExit(f"error: zh-Hans catalog appears untranslated; found only {len(chinese_values)} values containing Chinese characters")
missing_app = sorted(source_keys - app_keys)
missing_helper = sorted(source_keys - helper_keys)
if missing_app or missing_helper:
    missing = sorted(set(missing_app + missing_helper))
    raise SystemExit("error: zh-Hans catalog lacks source keys: " + repr(missing[:12]))
if app_keys != helper_keys:
    raise SystemExit("error: app and persistence-helper localization catalogs diverge")

# Ensure the custom Entitlements control is wired from Settings through install into root helper.
settings = (ROOT / "TrollStore/TSSettingsListController.m").read_text(encoding="utf-8")
manager = (ROOT / "TrollStore/TSApplicationsManager.m").read_text(encoding="utf-8")
root_helper = (ROOT / "RootHelper/main.m").read_text(encoding="utf-8")
editor = (ROOT / "TrollStore/TSEntitlementsEditorViewController.swift").read_text(encoding="utf-8")
if settings.count('NSLocalizedString(@"Custom Entitlements", nil)') != 1 or 'NSClassFromString(@"TSEntitlementsEditorViewController")' not in settings:
    raise SystemExit("error: Custom Entitlements must be linked once in the original Signing Settings section")
signing_pos = settings.find('signingGroupSpecifier.name = NSLocalizedString(@"Signing", nil)')
custom_pos = settings.find('NSLocalizedString(@"Custom Entitlements", nil)')
persistence_pos = settings.find('persistenceGroupSpecifier.name = NSLocalizedString(@"Persistence", nil)')
if not (0 <= signing_pos < custom_pos < persistence_pos):
    raise SystemExit("error: Custom Entitlements should appear inside the original Signing section")
for token, source in (("TSCustomEntitlementsOverrideEnabled", manager), ("--entitlements", manager), ("gCustomEntitlementsOverride", root_helper), ("TSCustomEntitlements.plist", editor)):
    if token not in source:
        raise SystemExit(f"error: custom Entitlements path is incomplete; missing {token}")
if "TSDonateListController" in settings or "donat" in settings.lower():
    raise SystemExit("error: donation UI reference remains in Settings")

print(f"[audit] {len(REQUIRED)} required files present")
print("[audit] original TrollStore Objective-C UI/controllers retained; only donation controller removed")
print(f"[audit] {len(plists)} plists and {len(strings_files)} strings resources validated")
print(f"[audit] {len(app_keys)} matching zh-Hans localization keys validated; {len(chinese_values)} translated values contain Chinese characters")
print("[audit] ChOma pin, embedded ldid, custom Entitlements path, and self-update association validated")
