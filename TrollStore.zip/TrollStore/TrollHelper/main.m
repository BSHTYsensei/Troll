#import <Foundation/Foundation.h>
#import "TSHAppDelegateNoScene.h"
#import "TSHAppDelegateWithScene.h"
#import "TSHSceneDelegate.h"
#import <TSUtil.h>

BOOL sceneDelegateFix(void)
{
    // The replaced system app's Info.plist may name a delegate class that is
    // already registered by a loaded framework. Dynamically allocating the old
    // class name can return NULL; objc_registerClassPair(NULL) then crashes the
    // persistence helper at launch. TSHAppDelegateWithScene explicitly selects
    // our own delegate class instead, so only detect whether a scene is present.
    NSDictionary *manifest = [NSBundle.mainBundle objectForInfoDictionaryKey:@"UIApplicationSceneManifest"];
    if (![manifest isKindOfClass:NSDictionary.class]) return NO;
    NSDictionary *configurations = manifest[@"UISceneConfigurations"];
    if (![configurations isKindOfClass:NSDictionary.class]) return NO;
    NSArray *applicationScenes = configurations[@"UIWindowSceneSessionRoleApplication"];
    if (![applicationScenes isKindOfClass:NSArray.class] || applicationScenes.count == 0) return NO;
    for (id scene in applicationScenes) {
        if (![scene isKindOfClass:NSDictionary.class]) continue;
        NSString *name = scene[@"UISceneConfigurationName"];
        if (!name || [name isKindOfClass:NSString.class]) return YES;
    }
    return NO;
}

int main(int argc, char *argv[], char *envp[]) {
	@autoreleasepool {
		#ifdef EMBEDDED_ROOT_HELPER
		extern int rootHelperMain(int argc, char *argv[], char *envp[]);
		if(getuid() == 0)
		{
			// I got this idea while taking a dump
			// Don't judge
			return rootHelperMain(argc, argv, envp);
		}
		#endif

		chineseWifiFixup();
		if(sceneDelegateFix())
		{
			return UIApplicationMain(argc, argv, nil, NSStringFromClass(TSHAppDelegateWithScene.class));
		}
		else
		{
			return UIApplicationMain(argc, argv, nil, NSStringFromClass(TSHAppDelegateNoScene.class));
		}
	}
}
