#import "TSHAppDelegateWithScene.h"
#import "TSHSceneDelegate.h"

@implementation TSHAppDelegateWithScene

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
	return YES;
}

- (UISceneConfiguration *)application:(UIApplication *)application configurationForConnectingSceneSession:(UISceneSession *)connectingSceneSession options:(UISceneConnectionOptions *)options {
    NSDictionary *manifest = [NSBundle.mainBundle objectForInfoDictionaryKey:@"UIApplicationSceneManifest"];
    NSDictionary *configurations = [manifest isKindOfClass:NSDictionary.class] ? manifest[@"UISceneConfigurations"] : nil;
    NSArray *applicationScenes = [configurations isKindOfClass:NSDictionary.class] ? configurations[@"UIWindowSceneSessionRoleApplication"] : nil;
    NSString *configurationName = @"Default Configuration";
    if ([applicationScenes isKindOfClass:NSArray.class]) {
        for (id scene in applicationScenes) {
            if (![scene isKindOfClass:NSDictionary.class]) continue;
            NSString *candidate = scene[@"UISceneConfigurationName"];
            if ([candidate isKindOfClass:NSString.class] && candidate.length) {
                configurationName = candidate;
                if ([candidate isEqualToString:@"Default Configuration"]) break;
            }
        }
    }
    UISceneConfiguration *configuration = [[UISceneConfiguration alloc] initWithName:configurationName sessionRole:connectingSceneSession.role];
    configuration.delegateClass = TSHSceneDelegate.class;
    return configuration;
}


- (void)application:(UIApplication *)application didDiscardSceneSessions:(NSSet<UISceneSession *> *)sceneSessions {
    // Called when the user discards a scene session.
    // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
    // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
}

@end