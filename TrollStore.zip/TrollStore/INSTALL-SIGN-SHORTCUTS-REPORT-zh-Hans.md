# TrollStore 安装、签名、刷新快捷指令与 Framework 优化报告

**修改日期：2026-11-01**  
**基线：Library 中保存的 `TrollStore-VideoUI-LocalPlugins-InstallInject-CIFix-2026-10-31(1).zip`**  
**目标：保留原有功能，在现有代码上缩短签名/安装链路，加入仅刷新 App 注册的系统快捷指令，并补齐模板说明和导入操作。**

## 1. 快捷指令：刷新 App 注册

### 实现位置

- `TrollStore/TSRefreshAppRegistrationsIntent.swift`：由主 TrollStore App 声明 `Refresh Apps` App Intent / App Shortcut。
- `TrollStore/TSRefreshShortcutAction.m`：快捷指令的 Objective-C 桥接，只调用 `rootHelperPath()` 对应 RootHelper 的 `refresh` 命令。
- `TrollStore/TSRefreshShortcutController.{h,m}`：设置页的快捷指令介绍页、Apple `ShortcutsUIButton` 和 Done/退出入口。
- `TrollStore/TSSettingsListController.m`：仅检测到已安装/注入的 Persistence Helper 时，才显示“添加刷新快捷指令”。
- `Scripts/extract_app_intents_metadata.py` 与根 `Makefile`：在最终 App 组装阶段调用 Apple `appintentsmetadataprocessor`，把 App Intents 元数据放进 App 包。

### 用户操作

1. 打开 TrollStore → Settings → Persistence Helper。
2. 已安装/注入持久化助手时，点击“添加刷新快捷指令”。
3. 系统会跳转到 Apple Shortcuts 中 TrollStore 自己的页面；在 Shortcuts 页面里确认添加 `Refresh Apps`。
4. 在 Shortcuts → Automation 中创建个人自动化，例如按时间、到达/离开地点或其他系统触发条件运行该快捷指令。

“添加”按钮不能越过 Apple 的系统确认，静默地把快捷指令写进用户的 Shortcuts 库，也不能代替用户创建个人自动化。这是 Apple 控制的系统界面行为。

### 运行行为与隐私边界

- 快捷指令属于**主 TrollStore App**，不是注入到被注入的系统 App，也不注入 Shortcuts.app。
- Intent 设置 `openAppWhenRun = false`，用于兼容 iOS 16 的后台偏好；快捷指令执行时不会主动呈现持久化助手的 UI。
- 动作只运行 `refresh`（调用 `refreshAppRegistrations`），不会运行 `refresh-all`，也不会删除图标缓存、重建整套 SpringBoard 数据库、终止 `backboardd`、respring 或重启设备。
- 系统仍保留决定 Intent 执行上下文的权力。可以要求后台运行，但不能保证每种 iOS 版本、自动化来源及系统状态下绝对零前台活动；本实现不会主动打开被注入的 Persistence Helper 界面。
- 如果 RootHelper 返回非零状态，快捷指令会报告错误，不会伪装成功。

## 2. 安装与签名链路

### 普通真实证书签名

当选择真实 CMS 身份、没有显式编辑主应用 Entitlements 时，保留一次递归 ldid Bundle 签名：`--deep --super-deep`。这样不重复启动 ldid 签名每个嵌套文件；ldid 使用模板配置的 `jobs` 对独立 Mach-O/FAT 工作并行处理。

### 需要逐文件处理的路径

当使用 TrollStore/ad-hoc 模式，或用户启用了安装前完整 Entitlements 文档编辑时：

1. 先扫描 Bundle，建立 `Info.plist`、嵌套代码 Bundle 和候选 Mach-O 索引，避免对普通资源文件重复解析。
2. 在封装资源前，并发签署彼此独立的主程序、扩展程序、Framework 二进制和辅助 Mach-O。
3. 外层并发队列最多 4 个 worker，并受模板 `jobs` 和 CPU 核数约束。
4. 外层并发时，每个 ldid 子进程固定 `--jobs 1`，防止“文件并发数 × 每个 ldid 内部并发数”造成线程过量。
5. Mach-O 签名完成后，按嵌套 Bundle 从深到浅、最后主 App 的顺序生成资源封装。`CodeResources` 封装保持串行，避免并发写入或父 Bundle 封装过早。
6. 原有 Security.framework/native signer 路径仍保持串行；出现不兼容时继续走既有 ldid fallback。

这些优化只改变互相独立的 Mach-O 签名调度，不改变签名输入、主应用完整 Entitlements 文档的替换规则、Bundle 依赖顺序或安装后校验。它不能保证每个 IPA 都更快：只有包含多个独立可执行文件的包更容易从并发中获益；很小的 IPA、单个主 Mach-O 或 I/O 瓶颈不一定变快。

**完整 Entitlements 替换的模板隔离：** 用户编辑主应用 Entitlements 时，不能直接沿用常规模板的 `preserveEntitlements=true` / `mergeDeep=true` / `mergeOnly` 策略，否则原始签名里的键可能被重新合并回来。RootHelper 会复制当前 ldid JSON 配置的 `defaults` 和选中 `profile`，只将 Entitlements preserve/merge 相关字段关闭、移除 `mergeEntitlements`，其余证书、私钥引用、团队 ID、hash 和 jobs 保留；临时配置以 0600 权限保存，当前二进制签名完成后立即删除。这样即使用户最后保存空字典，也会明确签入空的主应用 Entitlements，而不会保留旧字典。此方案使用现有 `--config/--profile` 参数，不修改或替换用户提供的预编译 `bin/ldid`。

### 模板并发上限

| 模板 | jobs 配置 | 说明 |
|---|---:|---|
| App Store | 8 | SHA-256；App Store 风格发布工作流说明模板，不会生成 Apple 分发资格 |
| App Store Connect | 8 | SHA-256；需要匹配的 Distribution 身份、App ID 与配置文件 |
| TestFlight | 4 | SHA-256；适合平衡吞吐量的 TestFlight 构建 |
| Apple Development | 4 | SHA-256；开发/调试配置，调试权限仍需证书、profile 和 entitlement 配合 |
| Developer Distribution | 8 | SHA-256；需要真实 Apple Distribution 私钥和匹配 profile |
| Ad Hoc | 2 | SHA-256；保守并发，profile 通常需包含目标设备 UDID |
| Enterprise / In-House | 4 | SHA-256；需要组织授权的企业身份和 profile |
| TrollStore Default | 4 | 日常推荐，兼顾速度、内存与响应性 |
| TrollStore Fast | 8 | 请求更高并发；实际被文件队列上限 4、CPU 和可并发 Mach-O 数约束 |
| TrollStore Compatibility | 1 | 单 worker，适合排查兼容性或降低资源峰值 |

这里的 `jobs` 是并发度配置，不是签名强度等级。模板名称不会生成证书、私钥、Provisioning Profile、Apple 开发者权限、App Store 审核结果、企业分发权限，也不代替证书链验证或公证。

## 3. 安装方式

- **Custom**：保留现有安装语义，尽量减少中间操作；准备/解包一次、插件处理在签名前完成、签名一次、注册后优先尝试同卷 rename，不能 rename 时再走复制回退。它通常比走 `installd` 的系统握手链路短，但不能承诺任何设备、存储布局和 IPA 条件下必然更快。
- **installd**：保留原有系统安装流程和 `installd` 负责的 placeholder / 安装数据库等系统 bookkeeping。它可能更符合系统安装记录/持久性需求，但并不等于在所有重建场景中绝对不会丢失；仍受系统和安装状态影响。
- `installd` 失败时不静默改走 Custom；先向用户报告并让用户决定是否切换，避免无提示地改变安装语义。
- 不删除现有安装方式，不把两种方式强行合并成一个不可选择的路径。

## 4. Tweak Framework 方案

- 内置 AppLock 与 BackgroundAssist 预设在构建时先生成并签名通用 Mach-O 动态库，再包装为 `TSAppLock.framework` / `TSBackgroundAssist.framework`，并写入 Framework `Info.plist`。
- Framework 内部可执行文件仍是 `MH_DYLIB`；Framework 是承载 dylib 二进制和元数据的 Bundle，不是把 Mach-O 类型改成可执行 App。
- 选择器优先支持 `.framework`，同时继续接受用户导入的 `.dylib`。不会强制用户把旧插件重做，也不删除第三方 dylib 兼容逻辑。
- Makefile 在构建结束时校验 arm64/arm64e Framework 二进制的 CodeDirectory。

## 5. 导入/页面操作检查

- IPA/插件导入结果提供 Done/关闭和“删除本次导入文件”；删除前有确认，并只删除本次导入记录/Packages 目录内的目标。
- 已导入的 IPA/TIPA/TAR/ZIP/DEB 包可从包列表删除；删除函数检查解析后的目标必须是 Packages 目录的直接子文件，并限定扩展名。
- Tweak 导入支持 `.framework` 和 `.dylib`；DEB/ZIP 解包后选择插件时提供 Cancel，取消会清除临时解包目录；导入确认页提供 Continue、Delete Imported Files、Cancel。
- 删除路径拒绝 Packages 根目录本身及其外部路径；不会递归删除任意用户路径。
- 快捷指令介绍页与签名模板详情页都有 Done/返回入口；模板详情页只有点击“Use This Template”才提交选择，关闭/返回不隐式更改模板。
- 删除已导入文件与取消导入是不同动作；Cancel 默认不等同于删除，界面会明确提供 Delete Imported Files。
- 已开始的 RootHelper 安装/注入等特权操作不是可随时安全中止的事务；当前可取消按钮适用于尚未提交的选择/确认步骤，不能把“取消”描述成可回滚已开始的系统级写入。

## 6. 静态验证结果

在当前 Linux 工作环境执行：

```text
python3 -m py_compile Scripts/*.py
python3 Scripts/validate_project.py
python3 Scripts/test_fastpath_sign_pipeline.py
python3 Scripts/validate_macho.py bin/ldid
```

通过结果：

- 99 个必需项目文件存在；原有 App UI / helper 结构、插件兼容、Entitlements 编辑、安装重试状态、自动初始化默认关闭、内置 ldid 来源等检查通过。
- 6 个 plist、4 个 strings 资源通过格式校验；638 个中英文键匹配，630 个中文翻译值包含中文字符。
- fastPathSign 的分 slice 签名、arm64/arm64e universal 重建和 Framework 包装回归测试通过。
- `bin/ldid` 识别为 arm64 iOS Mach-O，大小 8,448,488 bytes；SHA-256 与 `bin/ldid.sha256` 一致：

```text
d23eb53e6c5b07f5cae72f0e93ab1b87214aa68ed4a59bc32286f8b15cb8b769
```

**未完成的验证：** 当前执行容器不是 macOS，未安装 Xcode、iOS SDK 和 Theos；因此没有声称完成真实 Apple 编译、App Intents 元数据处理、签名后的完整 App 包装、设备上的安装/持久化 helper 注入测试、快捷指令后台自动化测试或真实耗时基准。项目 Makefile 会在 macOS 构建前强制检查 Xcode、`swiftc` 与 `appintentsmetadataprocessor`，并在最终 App 组装时生成/校验 App Intents metadata 和签名二进制。

## 7. 官方与开源资料

- Apple — [App Intents: `supportedModes`](https://developer.apple.com/documentation/appintents/appintent/supportedmodes)：说明 Intent 可选择 background、foreground 等运行模式。
- Apple — [`openAppWhenRun`](https://developer.apple.com/documentation/appintents/appintent/openappwhenrun)：旧式兼容属性；Apple 当前建议新 API 使用 `supportedModes`。本实现保留 iOS 16 部署兼容性。
- Apple — [`ShortcutsUIButton`](https://developer.apple.com/documentation/appintents/shortcutsuibutton)：打开当前 App 在 Shortcuts 中的页面。
- Apple — [App Shortcuts](https://developer.apple.com/documentation/appintents/app-shortcuts)：App Shortcut 由 `AppShortcutsProvider` 声明，安装后系统可自动发现。
- GitHub — [Chromium `extract_metadata.py`](https://github.com/chromium/chromium/blob/main/build/config/ios/extract_metadata.py)：参考 Apple `appintentsmetadataprocessor` 的参数和元数据产物检查方式。
- GitHub — [Theos Variables](https://github.com/theos/theos/blob/master/docs/Variables.html) 与 [Theos Swift Wiki](https://github.com/theos/theos/wiki/Swift)：核对 `*_SWIFT_FILES` 和 `*_SWIFT_BRIDGING_HEADER` 变量用法。
