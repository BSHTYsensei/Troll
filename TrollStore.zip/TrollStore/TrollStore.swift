// TrollStore.swift
// Main UIKit application: IPA picker/URL installer, installed-app list, and
// a settings-level XML plist editor for entitlement overrides applied by RootHelper.

import UIKit
import Foundation
import UniformTypeIdentifiers
import Darwin
import ObjectiveC.runtime

private let tsClientMarker = "_TrollStore"
private let tsClientLiteMarker = "_TrollStoreLite"
private let tsClientEntitlementToggleKey = "TSEntitlementsOverrideEnabled"
private let tsClientEntitlementFileName = "TSCustomEntitlements.plist"
private let tsClientInstallLogName = "TrollStoreInstall.log"


// TrollStore's app launches its privileged helper through the iOS persona override API.
// A plain posix_spawn would leave the helper running as the app user and all install
// operations would fail the helper's geteuid() == 0 check.
@_silgen_name("posix_spawnattr_set_persona_np")
private func tsClientSpawnSetPersona(_ attributes: UnsafePointer<posix_spawnattr_t>?, _ persona: uid_t, _ flags: UInt32) -> Int32
@_silgen_name("posix_spawnattr_set_persona_uid_np")
private func tsClientSpawnSetPersonaUID(_ attributes: UnsafePointer<posix_spawnattr_t>?, _ uid: uid_t) -> Int32
@_silgen_name("posix_spawnattr_set_persona_gid_np")
private func tsClientSpawnSetPersonaGID(_ attributes: UnsafePointer<posix_spawnattr_t>?, _ gid: gid_t) -> Int32
private let tsClientPersonaOverrideFlags: UInt32 = 1

// MARK: - Client-side process launch

private struct TSClientProcessResult {
    let status: Int32
    let output: String
}

private enum TSClientProcess {
    static func rootHelperPath() -> String {
        let candidate = Bundle.main.bundleURL.appendingPathComponent("trollstorehelper").path
        if FileManager.default.isExecutableFile(atPath: candidate) { return candidate }
        return "/var/containers/Bundle/TrollStore/TrollStore.app/trollstorehelper"
    }

    static func entitlementPath() -> String {
        let base = (try? FileManager.default.url(for: .applicationSupportDirectory,
                                                 in: .userDomainMask,
                                                 appropriateFor: nil,
                                                 create: true)) ?? URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/Application Support", isDirectory: true)
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        return base.appendingPathComponent(tsClientEntitlementFileName).path
    }

    static func installLogPath() -> String {
        let base = (try? FileManager.default.url(for: .applicationSupportDirectory,
                                                 in: .userDomainMask,
                                                 appropriateFor: nil,
                                                 create: true)) ?? URL(fileURLWithPath: NSHomeDirectory()).appendingPathComponent("Library/Application Support", isDirectory: true)
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        return base.appendingPathComponent(tsClientInstallLogName).path
    }

    static func runHelper(_ arguments: [String], outputLimit: Int = 2 * 1024 * 1024) -> TSClientProcessResult {
        let executable = rootHelperPath()
        guard FileManager.default.isExecutableFile(atPath: executable) else {
            return TSClientProcessResult(status: 127, output: "Missing root helper at \(executable). Rebuild and embed trollstorehelper in TrollStore.app.")
        }
        var pipeFDs: [Int32] = [0, 0]
        guard pipe(&pipeFDs) == 0 else { return TSClientProcessResult(status: errno, output: "pipe() failed") }
        var actions = posix_spawn_file_actions_t()
        posix_spawn_file_actions_init(&actions)
        var attributes = posix_spawnattr_t()
        posix_spawnattr_init(&attributes)
        _ = tsClientSpawnSetPersona(&attributes, 99, tsClientPersonaOverrideFlags)
        _ = tsClientSpawnSetPersonaUID(&attributes, 0)
        _ = tsClientSpawnSetPersonaGID(&attributes, 0)
        posix_spawn_file_actions_adddup2(&actions, pipeFDs[1], STDOUT_FILENO)
        posix_spawn_file_actions_adddup2(&actions, pipeFDs[1], STDERR_FILENO)
        posix_spawn_file_actions_addclose(&actions, pipeFDs[0])
        posix_spawn_file_actions_addclose(&actions, pipeFDs[1])
        let strings = [executable] + arguments
        // posix_spawn consumes a C argv vector, which must end with a NULL pointer.
        let argv: [UnsafeMutablePointer<CChar>?] = strings.map { strdup($0) } + [nil]
        defer {
            for value in argv { if let value { free(value) } }
            posix_spawn_file_actions_destroy(&actions)
            posix_spawnattr_destroy(&attributes)
        }
        var pid = pid_t(0)
        let spawnResult: Int32 = argv.withUnsafeMutableBufferPointer { buffer in
            guard let base = buffer.baseAddress else { return EINVAL }
            return executable.withCString { cExecutable in
                posix_spawn(&pid, cExecutable, &actions, &attributes, base, environ)
            }
        }
        close(pipeFDs[1])
        guard spawnResult == 0 else {
            close(pipeFDs[0])
            return TSClientProcessResult(status: spawnResult, output: "Unable to launch root helper: \(String(cString: strerror(spawnResult)))")
        }
        let raw = UnsafeMutableRawPointer.allocate(byteCount: 64 * 1024, alignment: 16)
        defer { raw.deallocate() }
        var data = Data()
        while true {
            let count = read(pipeFDs[0], raw, 64 * 1024)
            if count == 0 { break }
            if count < 0 {
                if errno == EINTR { continue }
                break
            }
            if data.count < outputLimit {
                data.append(raw.assumingMemoryBound(to: UInt8.self), count: min(count, outputLimit - data.count))
            }
        }
        close(pipeFDs[0])
        var status: Int32 = 0
        while waitpid(pid, &status, 0) == -1 {
            if errno == EINTR { continue }
            return TSClientProcessResult(status: errno, output: String(data: data, encoding: .utf8) ?? "")
        }
        let exitCode: Int32 = (status & 0x7f) == 0 ? ((status >> 8) & 0xff) : (128 + (status & 0x7f))
        return TSClientProcessResult(status: exitCode, output: String(data: data, encoding: .utf8) ?? "")
    }
}

// MARK: - Private LaunchServices bridge

private enum TSClientLaunchServices {
    static func workspace() -> NSObject? {
        guard let cls = NSClassFromString("LSApplicationWorkspace"),
              let method = class_getClassMethod(cls, NSSelectorFromString("defaultWorkspace")) else { return nil }
        typealias Function = @convention(c) (AnyClass, Selector) -> Unmanaged<AnyObject>?
        return unsafeBitCast(method_getImplementation(method), to: Function.self)(cls, NSSelectorFromString("defaultWorkspace"))?.takeUnretainedValue() as? NSObject
    }

    static func open(bundleID: String) -> Bool {
        guard let object = workspace(),
              let method = class_getInstanceMethod(type(of: object), NSSelectorFromString("openApplicationWithBundleID:")) else { return false }
        typealias Function = @convention(c) (AnyObject, Selector, NSString) -> Bool
        let function = unsafeBitCast(method_getImplementation(method), to: Function.self)
        return function(object, NSSelectorFromString("openApplicationWithBundleID:"), bundleID as NSString)
    }
}

private struct TSInstalledApplication {
    let name: String
    let bundleID: String
    let path: String
    let version: String
}

private enum TSClientApplications {
    static func installed() -> [TSInstalledApplication] {
        let root = "/var/containers/Bundle/Application"
        guard let identifiers = try? FileManager.default.contentsOfDirectory(atPath: root) else { return [] }
        var result = [TSInstalledApplication]()
        for identifier in identifiers {
            let container = URL(fileURLWithPath: root).appendingPathComponent(identifier)
            let active = FileManager.default.fileExists(atPath: container.appendingPathComponent(tsClientMarker).path)
            let lite = FileManager.default.fileExists(atPath: container.appendingPathComponent(tsClientLiteMarker).path)
            guard active || lite, let items = try? FileManager.default.contentsOfDirectory(atPath: container.path) else { continue }
            for item in items where item.hasSuffix(".app") && item != "TrollStore.app" && item != "TrollStoreLite.app" {
                let appURL = container.appendingPathComponent(item)
                guard let info = NSDictionary(contentsOf: appURL.appendingPathComponent("Info.plist")) as? [String: Any],
                      let bundleID = info["CFBundleIdentifier"] as? String else { continue }
                result.append(TSInstalledApplication(name: (info["CFBundleDisplayName"] as? String) ?? (info["CFBundleName"] as? String) ?? item,
                                                     bundleID: bundleID,
                                                     path: appURL.path,
                                                     version: (info["CFBundleShortVersionString"] as? String) ?? (info["CFBundleVersion"] as? String) ?? "—"))
            }
        }
        return result.sorted { $0.name.localizedStandardCompare($1.name) == .orderedAscending }
    }
}

private enum TSClientLinks {
    static var pendingIPAURL: URL?
}

// MARK: - Application entry and scenes

@UIApplicationMain
@objc(TSAppDelegate)
final class TrollStoreAppDelegate: UIResponder, UIApplicationDelegate {
    func application(_ application: UIApplication,
                    didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil) -> Bool {
        return true
    }

    func application(_ app: UIApplication,
                    open url: URL,
                    options: [UIApplication.OpenURLOptionsKey: Any] = [:]) -> Bool {
        TSClientLinks.pendingIPAURL = url
        NotificationCenter.default.post(name: .tsHandleIncomingURL, object: url)
        return true
    }
}

@objc(TSSceneDelegate)
final class TrollStoreSceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?

    func scene(_ scene: UIScene,
               willConnectTo session: UISceneSession,
               options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = scene as? UIWindowScene else { return }
        let window = UIWindow(windowScene: windowScene)
        let root = TrollStoreRootViewController(style: .insetGrouped)
        window.rootViewController = UINavigationController(rootViewController: root)
        self.window = window
        window.makeKeyAndVisible()

        if let context = connectionOptions.urlContexts.first {
            TSClientLinks.pendingIPAURL = context.url
        }
    }

    func scene(_ scene: UIScene, openURLContexts URLContexts: Set<UIOpenURLContext>) {
        guard let url = URLContexts.first?.url else { return }
        TSClientLinks.pendingIPAURL = url
        NotificationCenter.default.post(name: .tsHandleIncomingURL, object: url)
    }
}

private extension Notification.Name {
    static let tsHandleIncomingURL = Notification.Name("TrollStoreHandleIncomingURL")
    static let tsApplicationsChanged = Notification.Name("TrollStoreApplicationsChanged")
}

// MARK: - Main app list

final class TrollStoreRootViewController: UITableViewController, UIDocumentPickerDelegate {
    private var apps = [TSInstalledApplication]()
    private var installInProgress = false

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "TrollStore"
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "AppCell")
        tableView.tableFooterView = UIView(frame: .zero)
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(systemName: "gearshape"), style: .plain, target: self, action: #selector(openSettings))
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(showInstallOptions))
        refreshApplications()
        NotificationCenter.default.addObserver(self, selector: #selector(refreshApplications), name: .tsApplicationsChanged, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleIncomingURL(_:)), name: .tsHandleIncomingURL, object: nil)
    }

    deinit { NotificationCenter.default.removeObserver(self) }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let pending = TSClientLinks.pendingIPAURL {
            TSClientLinks.pendingIPAURL = nil
            handleURL(pending)
        }
    }

    @objc private func refreshApplications() {
        DispatchQueue.global(qos: .userInitiated).async {
            let applications = TSClientApplications.installed()
            DispatchQueue.main.async {
                self.apps = applications
                self.tableView.reloadData()
            }
        }
    }

    @objc private func showInstallOptions() {
        let sheet = UIAlertController(title: "Install", message: nil, preferredStyle: .actionSheet)
        sheet.addAction(UIAlertAction(title: "Install IPA / TIPA", style: .default) { _ in self.pickIPA() })
        sheet.addAction(UIAlertAction(title: "Install from URL", style: .default) { _ in self.promptForURL() })
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        if let popover = sheet.popoverPresentationController { popover.barButtonItem = navigationItem.rightBarButtonItem }
        present(sheet, animated: true)
    }

    @objc private func openSettings() {
        navigationController?.pushViewController(TSEntitlementsEditorViewController(), animated: true)
    }

    private func pickIPA() {
        let picker = UIDocumentPickerViewController(documentTypes: ["com.apple.itunes.ipa", "com.opa334.trollstore.tipa", "public.data"], in: .import)
        picker.allowsMultipleSelection = false
        picker.delegate = self
        present(picker, animated: true)
    }

    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let url = urls.first else { return }
        installFromURLOrFile(url)
    }

    private func promptForURL() {
        let alert = UIAlertController(title: "Install from URL", message: "Enter a direct IPA/TIPA download URL.", preferredStyle: .alert)
        alert.addTextField { field in
            field.placeholder = "https://example.com/app.ipa"
            field.keyboardType = .URL
            field.autocapitalizationType = .none
            field.autocorrectionType = .no
        }
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Download & Install", style: .default) { _ in
            guard let raw = alert.textFields?.first?.text?.trimmingCharacters(in: .whitespacesAndNewlines),
                  let url = URL(string: raw), ["http", "https"].contains(url.scheme?.lowercased() ?? "") else {
                self.showMessage(title: "Invalid URL", message: "Use a valid http or https IPA URL.")
                return
            }
            self.downloadAndInstall(url)
        })
        present(alert, animated: true)
    }

    @objc private func handleIncomingURL(_ notification: Notification) {
        guard let url = notification.object as? URL else { return }
        handleURL(url)
    }

    private func handleURL(_ url: URL) {
        if url.scheme?.lowercased() == "apple-magnifier" {
            guard let components = URLComponents(url: url, resolvingAgainstBaseURL: false),
                  components.host == "install",
                  let value = components.queryItems?.first(where: { $0.name == "url" })?.value,
                  let remote = URL(string: value) else { return }
            downloadAndInstall(remote)
        } else if ["ipa", "tipa"].contains(url.pathExtension.lowercased()) {
            installFromURLOrFile(url)
        } else if url.isFileURL && url.pathExtension.lowercased() == "tar" {
            showMessage(title: "TrollStore update archive", message: "This three-file Swift port focuses on IPA installation and entitlement overrides. The original .tar self-update/persistence migration path is not included in this build.")
        }
    }

    private func installFromURLOrFile(_ url: URL, force: Bool = false) {
        if !url.isFileURL {
            downloadAndInstall(url, force: force)
            return
        }
        guard FileManager.default.fileExists(atPath: url.path) else {
            showMessage(title: "File unavailable", message: "The selected IPA could not be accessed.")
            return
        }
        let name = url.lastPathComponent
        let confirm = UIAlertController(title: "Install \(name)?", message: customEntitlementsSummary(), preferredStyle: .alert)
        confirm.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        confirm.addAction(UIAlertAction(title: "Install", style: .default) { _ in self.performInstall(ipaPath: url.path, force: force) })
        present(confirm, animated: true)
    }

    private func downloadAndInstall(_ remoteURL: URL, force: Bool = false) {
        guard !installInProgress else { return }
        let progress = makeProgressAlert(message: "Downloading \(remoteURL.lastPathComponent)…")
        present(progress, animated: true)
        let task = URLSession.shared.downloadTask(with: remoteURL) { location, response, error in
            DispatchQueue.main.async {
                progress.dismiss(animated: true) {
                    guard error == nil, let location else {
                        self.showMessage(title: "Download failed", message: error?.localizedDescription ?? "The server did not return a file.")
                        return
                    }
                    if let response = response as? HTTPURLResponse, !(200...299).contains(response.statusCode) {
                        self.showMessage(title: "Download failed", message: "HTTP status \(response.statusCode).")
                        return
                    }
                    let target = URL(fileURLWithPath: NSTemporaryDirectory()).appendingPathComponent("TrollStore-\(UUID().uuidString).ipa")
                    do {
                        try FileManager.default.moveItem(at: location, to: target)
                        self.performInstall(ipaPath: target.path, force: force, cleanupPath: target.path)
                    } catch {
                        self.showMessage(title: "Download failed", message: error.localizedDescription)
                    }
                }
            }
        }
        task.resume()
    }

    private func customEntitlementsSummary() -> String {
        let enabled = UserDefaults.standard.bool(forKey: tsClientEntitlementToggleKey)
        return enabled ? "Custom entitlements are enabled. Configured values override keys already present in each app/extension executable; other entitlements are preserved." : "Existing entitlements will be preserved and normalized by the bundled ldid."
    }

    private func performInstall(ipaPath: String, force: Bool = false, cleanupPath: String? = nil) {
        guard !installInProgress else { return }
        installInProgress = true
        let progress = makeProgressAlert(message: "Extracting, signing and registering…")
        present(progress, animated: true)

        DispatchQueue.global(qos: .userInitiated).async {
            var args = ["install", "custom"]
            if force { args.append("force") }
            if UserDefaults.standard.bool(forKey: tsClientEntitlementToggleKey) {
                args.append(contentsOf: ["--entitlements", TSClientProcess.entitlementPath()])
            }
            args.append(ipaPath)
            let result = TSClientProcess.runHelper(args)
            try? result.output.write(toFile: TSClientProcess.installLogPath(), atomically: true, encoding: .utf8)
            // Keep a downloaded IPA alive when the user is offered the one-time force-install retry.
            if let cleanupPath, result.status != 171 { try? FileManager.default.removeItem(atPath: cleanupPath) }

            DispatchQueue.main.async {
                self.installInProgress = false
                progress.dismiss(animated: true) {
                    if result.status == 0 || result.status == 184 || result.status == 182 {
                        let message: String
                        switch result.status {
                        case 184: message = "Installed, but one or more nested executables are encrypted. Some extensions or plugins may not work."
                        case 182: message = "Installed successfully. Enable Developer Mode and reboot if iOS asks for it."
                        default: message = "Installation completed."
                        }
                        self.showMessage(title: "Success", message: message)
                        self.refreshApplications()
                        NotificationCenter.default.post(name: .tsApplicationsChanged, object: nil)
                    } else if result.status == 171 && !force {
                        let alert = UIAlertController(title: "App already installed", message: "The existing app is not marked as managed by TrollStore. Force replacement may overwrite its installed bundle.", preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
                        alert.addAction(UIAlertAction(title: "Force Install", style: .destructive) { _ in self.performInstall(ipaPath: ipaPath, force: true, cleanupPath: cleanupPath) })
                        self.present(alert, animated: true)
                    } else {
                        let alert = UIAlertController(title: "Installation failed (\(result.status))", message: self.errorMessage(for: result.status), preferredStyle: .alert)
                        alert.addAction(UIAlertAction(title: "Close", style: .cancel))
                        alert.addAction(UIAlertAction(title: "Copy Log", style: .default) { _ in UIPasteboard.general.string = result.output })
                        self.present(alert, animated: true)
                    }
                }
            }
        }
    }

    private func makeProgressAlert(message: String) -> UIAlertController {
        let alert = UIAlertController(title: "TrollStore", message: "\n\(message)", preferredStyle: .alert)
        let spinner = UIActivityIndicatorView(style: .medium)
        spinner.translatesAutoresizingMaskIntoConstraints = false
        spinner.startAnimating()
        alert.view.addSubview(spinner)
        NSLayoutConstraint.activate([
            spinner.centerXAnchor.constraint(equalTo: alert.view.centerXAnchor),
            spinner.bottomAnchor.constraint(equalTo: alert.view.bottomAnchor, constant: -50)
        ])
        return alert
    }

    private func showMessage(title: String, message: String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }

    private func errorMessage(for code: Int32) -> String {
        switch code {
        case 166: return "The IPA does not exist or is not accessible."
        case 167: return "The IPA does not contain an app under Payload/."
        case 168: return "Failed to extract the IPA. The archive may be corrupt or unsupported."
        case 170: return "Failed to create or locate the app bundle container."
        case 171: return "A non-TrollStore app with the same bundle identifier is installed."
        case 172: return "The app's Info.plist is missing required values."
        case 173: return "The bundled custom ldid binary is missing or not executable."
        case 174: return "The app's main executable is missing."
        case 175: return "ldid failed. Check the copied installation log for details."
        case 177: return "Could not mark the app as managed by TrollStore."
        case 178: return "Could not move or copy the app bundle into its container."
        case 179: return "The bundle identifier is protected or belongs to an immutable system app."
        case 180: return "The main executable is FairPlay-encrypted. Install a decrypted IPA."
        case 181: return "LaunchServices registration failed. Check the helper log."
        case 185: return "The CoreTrust-bypass backend failed or is not linked into RootHelper."
        case 186: return "The custom entitlements plist is missing, invalid, or its root object is not a dictionary."
        case 127: return "RootHelper or the bundled ldid executable could not be launched."
        default: return "The helper returned error code \(code). Check the installation log for details."
        }
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int { apps.count }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "AppCell", for: indexPath)
        let app = apps[indexPath.row]
        var content = cell.defaultContentConfiguration()
        content.text = app.name
        content.secondaryText = "\(app.bundleID)  ·  \(app.version)"
        content.secondaryTextProperties.color = .secondaryLabel
        cell.contentConfiguration = content
        cell.accessoryType = .disclosureIndicator
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let app = apps[indexPath.row]
        let alert = UIAlertController(title: app.name, message: "\(app.bundleID)\nVersion \(app.version)", preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Open", style: .default) { _ in
            if !TSClientLaunchServices.open(bundleID: app.bundleID) {
                self.showMessage(title: "Could not open app", message: "LaunchServices did not open \(app.bundleID). Try Refresh App Registrations from the + menu.")
            }
        })
        alert.addAction(UIAlertAction(title: "Uninstall", style: .destructive) { _ in self.confirmUninstall(app) })
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        if let popover = alert.popoverPresentationController { popover.sourceView = tableView.cellForRow(at: indexPath); popover.sourceRect = tableView.cellForRow(at: indexPath)?.bounds ?? .zero }
        present(alert, animated: true)
    }

    private func confirmUninstall(_ app: TSInstalledApplication) {
        let alert = UIAlertController(title: "Uninstall \(app.name)?", message: "The app bundle and its TrollStore registration container will be removed. App data cleanup depends on the iOS version.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        alert.addAction(UIAlertAction(title: "Uninstall", style: .destructive) { _ in
            DispatchQueue.global(qos: .userInitiated).async {
                let result = TSClientProcess.runHelper(["uninstall", app.bundleID])
                DispatchQueue.main.async {
                    if result.status == 0 { self.refreshApplications() }
                    else { self.showMessage(title: "Uninstall failed", message: "Helper returned \(result.status).\n\(result.output)") }
                }
            }
        })
        present(alert, animated: true)
    }
}

// MARK: - Entitlements editor

final class TSEntitlementsEditorViewController: UIViewController {
    private let enabledSwitch = UISwitch()
    private let editor = UITextView()
    private let statusLabel = UILabel()

    private let defaultXML = """
    <?xml version="1.0" encoding="UTF-8"?>
    <!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
    <plist version="1.0">
    <dict>
    </dict>
    </plist>
    """

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Entitlements"
        view.backgroundColor = .systemBackground
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(saveEntitlements))

        let enabledLabel = UILabel()
        enabledLabel.text = "Apply custom entitlements during install"
        enabledLabel.font = .preferredFont(forTextStyle: .body)
        enabledLabel.numberOfLines = 0
        enabledSwitch.isOn = UserDefaults.standard.bool(forKey: tsClientEntitlementToggleKey)

        let description = UILabel()
        description.text = "Enter a property-list XML dictionary. Keys you add or change override the same keys in each app/extension's existing entitlements; all other existing keys are retained. Values may be strings, booleans, numbers, arrays, or nested dictionaries."
        description.font = .preferredFont(forTextStyle: .footnote)
        description.textColor = .secondaryLabel
        description.numberOfLines = 0

        editor.font = .monospacedSystemFont(ofSize: 12, weight: .regular)
        editor.autocapitalizationType = .none
        editor.autocorrectionType = .no
        editor.spellCheckingType = .no
        editor.keyboardDismissMode = .interactive
        editor.layer.borderColor = UIColor.separator.cgColor
        editor.layer.borderWidth = 1
        editor.layer.cornerRadius = 9
        editor.text = loadExistingXML()
        editor.translatesAutoresizingMaskIntoConstraints = false

        statusLabel.font = .preferredFont(forTextStyle: .footnote)
        statusLabel.textColor = .secondaryLabel
        statusLabel.numberOfLines = 0
        statusLabel.text = "Overrides are applied when you install or update an IPA. Already installed apps are not changed until reinstalled."

        let enabledRow = UIStackView(arrangedSubviews: [enabledLabel, enabledSwitch])
        enabledRow.axis = .horizontal
        enabledRow.alignment = .center
        enabledRow.spacing = 12

        let stack = UIStackView(arrangedSubviews: [enabledRow, description, editor, statusLabel])
        stack.axis = .vertical
        stack.spacing = 14
        stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)
        NSLayoutConstraint.activate([
            stack.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 16),
            stack.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -16),
            stack.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            stack.bottomAnchor.constraint(lessThanOrEqualTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -12),
            editor.heightAnchor.constraint(greaterThanOrEqualToConstant: 260),
            enabledLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 100)
        ])
    }

    private func loadExistingXML() -> String {
        guard let data = try? Data(contentsOf: URL(fileURLWithPath: TSClientProcess.entitlementPath())),
              let text = String(data: data, encoding: .utf8) else { return defaultXML }
        return text
    }

    @objc private func saveEntitlements() {
        guard let data = editor.text.data(using: .utf8) else {
            showError("The text could not be encoded as UTF-8.")
            return
        }
        do {
            let propertyList = try PropertyListSerialization.propertyList(from: data, options: [], format: nil)
            guard propertyList is [String: Any] else {
                showError("The root property-list object must be a dictionary (<dict>…</dict>).")
                return
            }
            try data.write(to: URL(fileURLWithPath: TSClientProcess.entitlementPath()), options: .atomic)
            UserDefaults.standard.set(enabledSwitch.isOn, forKey: tsClientEntitlementToggleKey)
            statusLabel.textColor = .systemGreen
            statusLabel.text = enabledSwitch.isOn ? "Saved. These overrides will be used for the next IPA install or update." : "Saved. Overrides are disabled; the XML is kept for later use."
            editor.resignFirstResponder()
        } catch {
            showError("Invalid plist or unable to save: \(error.localizedDescription)")
        }
    }

    private func showError(_ message: String) {
        let alert = UIAlertController(title: "Entitlements not saved", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}
