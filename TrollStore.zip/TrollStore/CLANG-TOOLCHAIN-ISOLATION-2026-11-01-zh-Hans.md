# TrollStore：Swift 5.8.1 与 Xcode Clang 编译器隔离修复

日期：2026-11-01

## 根因

GitHub Actions 在编译 `main.m`、`TSAppCollectionViewController.m` 等普通 Objective-C 文件时，实际 Clang builtin include 路径却来自 `swift-5.8.1-RELEASE.xctoolchain/usr/lib/swift/clang/include`。该 Swift.org toolchain 的 Clang 资源头文件集合不应被用于 Xcode/iPhoneOS SDK 的普通 C/Objective-C 编译，随后引发 `__stddef_max_align_t.h` 缺失以及 Darwin、Foundation、CoreFoundation、UIKit modules 连锁失败。

这不是 iPhoneOS 16.5 SDK 头文件缺失；不能通过复制内部头文件、修改 SDK 或关闭 module 检查处理。

## 修复

- 新增 `Scripts/xcode-clang.mk`，根据 `DEVELOPER_DIR` 或 `xcode-select -p` 找到 `XcodeDefault.xctoolchain/usr/bin/clang` 和 `clang++`。
- 使用 GNU Make `override TARGET_CC/TARGET_CXX`，即使环境变量或命令行中存在 Swift.org Clang 路径，也强制切换回 XcodeDefault。
- TrollStore、RootHelper、TrollHelper、AppLock Tweak、BackgroundAssist Tweak 都在 Theos `common.mk` 之前加载该片段。
- 根 Makefile 对每个递归 Theos 构建显式传递 Xcode Clang/Clang++。
- `fastPathSign` macOS 主机工具也显式使用 Xcode Clang，不再依赖 PATH 中第一个 `clang`。
- Swift 5.8.1 仍只通过绝对路径 `TARGET_SWIFTC` 编译 TrollStore Swift/AppIntents 源码；不把 Swift.org clang include 加入全局 CFLAGS/OBJCFLAGS。
- `check-build-tools` 在编译前检查并打印 XcodeDefault clang 路径。

## 回归验证

新增 `Scripts/test_xcode_clang_isolation.sh`，模拟 Swift.org toolchain 的 clang 被放在 PATH/环境优先级中的情况，验证 Theos `TARGET_CC/TARGET_CXX` 仍被 `override` 固定到 XcodeDefault。

最终运行 `make validate-project LDID_BIN=bin/ldid` 通过：

- Xcode Clang 隔离模拟测试通过。
- Theos Swift support 缓存损坏恢复测试通过。
- Swift.org package 签名解析：3 个可信状态接受、4 个不可信状态拒绝。
- 项目审计：108 个必需文件存在。
- 6 个 plist、4 个 strings 资源验证通过。
- 简体中文：638 个键匹配，630 个译值含中文。
- fastPathSign 分片签名、Universal 重建、Framework 包装回归通过。
- 预编译 `bin/ldid` arm64 完整性验证通过，未修改原始二进制。

## 验证边界

当前编辑环境不是 macOS/Xcode，无法运行真正的 XcodeDefault Clang + iPhoneOS 16.5 SDK + Swift 5.8.1 Theos 全量编译。本次验证覆盖了 Makefile 变量隔离和静态回归；仍需 GitHub macOS Runner 实际编译确认。

CI 日志预期：

- C/Objective-C：`.../XcodeDefault.xctoolchain/usr/bin/clang`
- C++：`.../XcodeDefault.xctoolchain/usr/bin/clang++`
- TrollStore Swift：`.../swift-5.8.1-RELEASE.xctoolchain/usr/bin/swiftc`

若 `.m` 编译仍然出现 `swift-5.8.1-RELEASE.xctoolchain/.../clang/include`，应检查完整 clang 命令行及 `.theosrc` / workflow 的更高优先级覆盖，不要复制系统头文件掩盖问题。
