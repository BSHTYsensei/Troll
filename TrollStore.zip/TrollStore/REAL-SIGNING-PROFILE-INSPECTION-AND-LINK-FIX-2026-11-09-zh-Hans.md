# RootHelper 链接修复与真签名描述文件检查改造

## RootHelper 链接配置

`RootHelper/Makefile` 将 `-L../ChOma/external/ios` 留在 `$(HELPER_NAME)_LDFLAGS`，把 `crypto` 作为 Theos `$(HELPER_NAME)_LIBRARIES` 项，与 `archive` 一起声明，不再把裸 `-lcrypto` 混在原始 linker flags 中。Theos 文档将 `XXX_LDFLAGS` 定义为链接器参数、将 `XXX_LIBRARIES` 定义为链接依赖库的标准变量。

**诊断边界：** 用户提供的 CI 日志只包含最终 `clang++: error: linker command failed` 汇总行，缺少前面的 `Undefined symbols`、`duplicate symbols` 或 library-not-found 详情。此改动修正项目中可见的 libcrypto 链接声明方式，但不能据此断言已经复现并确认 Runner 的唯一根因。若这次仍链接失败，需要补充 `clang++` 命令及其上方第一条具体 `ld:` 错误。

## 安装权限提示

- 普通高权限提示为 13pt 半粗体黄色。
- 高危/root/无限制能力提示为 13pt 粗体红色。
- 一般说明正文为 12pt。
- 深色模式使用系统黄色；浅色模式使用较深金黄色，避免白底上对比度过低。

## 真签名描述文件解析与展示

- 导入 `.mobileprovision` 时，检查 CMS `ContentInfo` / `SignedData` 结构，提取 encapsulated OCTET STRING，并将内部 XML/binary plist 解析为字典。
- 检查内容中存在 `Entitlements` 字典；拒绝空文件、非 CMS 封装文件、无签名者条目及损坏 plist。
- 使用项目内的 DER TLV 读取器解析 CMS 外壳，不调用 iOS SDK 不提供的 `CMSDecoder` API。
- 展示 Profile Name、UUID、Team、Application Identifier、平台、创建/过期时间、设备数量、全设备权限、`get-task-allow`、Xcode 管理标记和 CMS Signer 数量。
- 列出 `DeveloperCertificates` 中各证书的 Subject、Issuer、有效期、SHA-256 指纹和证书 OID。
- 将导入身份的 DER 证书与 Profile 中 `DeveloperCertificates` 精确比较，标记匹配项；PEM 身份保存独立 DER 路径，P12 身份保留导入时提取的 DER 文件。
- 展示 Profile 授权的完整 Entitlements 键和值；导入成功后直接打开详情页，也可从身份操作菜单重新打开。
- 真签名准备阶段拒绝明显过期或与当前身份不匹配的已关联描述文件。

**安全边界：** 当前代码解析 CMS 容器并统计 `SignerInfos` 条目，但没有执行 CMS 签名密码学验证或 Apple 根证书信任链评估。证书匹配只证明身份 DER 与 Profile 内 DeveloperCertificates 中某项字节一致，不代表证书链可信，也不代表每项 Entitlement 都能在目标设备/iOS 版本使用。最终安装与系统级授权仍由目标环境处理。

## 验证结果与限制

已通过项目源码验证器、plist/strings lint、本地化键一致性检查、Theos 构建配置测试脚本、fastPathSign 主机流水线测试和 Python 脚本语法检查。本执行环境不是 macOS + Theos + iPhoneOS SDK，无法在这里真正链接 `trollstorehelper` 或执行 iOS 设备真签名测试。当前链接修正仍须在你的 macOS CI 上复测。
