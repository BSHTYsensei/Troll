# TrollStore iOS 16+ / Theos ldid 构建错误修复（2026-10-31）

## 报错

GitHub Actions 在构建 `TweakPresets/AppLock` 时出现：

```text
/bin/bash: ldid: command not found
make: *** [.../makefiles/instance/library.mk:51: .../TSAppLock.dylib] Error 127
```

## 根因

- `TweakPresets/AppLock/Makefile` 与 `TweakPresets/BackgroundAssist/Makefile` 没有指定 `TARGET_CODESIGN`，Theos 因而回退到宿主环境默认的 `ldid` 命令。
- 包内 `bin/ldid` 是 **arm64 iOS 设备端 Mach-O**，`LC_BUILD_VERSION` 平台为 iOS、最低版本 iOS 16.0、SDK 16.4。它不是 macOS 主机程序，不能通过把它加入 macOS Runner 的 PATH 来解决问题。
- 工程原先的 TrollStore、RootHelper、TrollHelper 和两个 preset Makefile 仍将 iOS 14.0 写作最低部署版本，与产品只支持 iOS 16+ 的要求不一致。

## 修改

1. `TweakPresets/AppLock/Makefile` 和 `TweakPresets/BackgroundAssist/Makefile` 显式设置：

   ```make
   TARGET_CODESIGN = /usr/bin/codesign
   TARGET_CODESIGN_FLAGS = --force --sign -
   ```

   macOS Runner 使用系统 `codesign` 对构建产物执行 ad-hoc 签名，不需要证书，也不会调用设备端 `bin/ldid`。

2. 根 `Makefile` 的 `check-build-tools` 增加 `/usr/bin/codesign` 检查，让主机工具缺失时给出明确报错。

3. `TrollStore/Makefile`、`RootHelper/Makefile`、`TrollHelper/Makefile`、两个 preset Makefile 的最低部署版本全部调整为 iOS 16.0。

4. 更新安装错误提示、简体中文翻译、README 和实现报告，明确工程最低系统版本为 iOS 16.0+，并区分 macOS 构建工具与 iOS 设备端 ldid。

5. `bin/ldid` 保持逐字节不变；不下载替换、不重编译、不把它作为 macOS 主机工具。

## 已执行验证

- `python3 -m py_compile Scripts/validate_project.py Scripts/validate_macho.py Scripts/validate_choma_api.py`：通过。
- `python3 Scripts/validate_project.py`：通过；必需文件、plist、简体中文 strings、本地化键及已有项目约束均通过。
- `python3 Scripts/validate_macho.py bin/ldid`：通过；确认提供的文件仍是预期的 arm64 iOS 设备端 Mach-O。
- 对 `bin/ldid` 重新计算 SHA-256，与 `bin/ldid.sha256` 完全一致：`d23eb53e6c5b07f5cae72f0e93ab1b87214aa68ed4a59bc32286f8b15cb8b769`。
- 静态检查五个 iOS Theos Makefile 均设置最低版本 16.0；两个 preset 都显式选择 macOS `/usr/bin/codesign`。

## 尚未完成的验证

当前编辑环境没有 macOS、Xcode、iPhoneOS SDK 或 Theos 安装。因此没有执行 GitHub macOS Runner 上的 `make build-presets` / `make assemble_trollstore`，也没有进行真机安装与启动测试。该修复针对错误日志对应的 Theos 签名工具选择问题，最终仍需在 macOS CI 完整编译确认。


## 第二轮全工程 CI 编译修复：空值约定与 iOS 16 Collection Layout API

### 新报错

- `TSApplicationsManager.h` 中的 Objective-C 对象指针缺少 nullability 注解，启用 `-Wnullability-completeness -Werror` 后构建失败。
- `TSAppCollectionViewController.m` 调用了 iOS 16 已弃用的 `horizontalGroupWithLayoutSize:subitem:count:`，并被 `-Werror=deprecated-declarations` 提升为错误。

### 修改

1. `TSApplicationsManager.h` 使用 `NS_ASSUME_NONNULL_BEGIN/END` 建立完整默认非空上下文。
2. 对允许为空的双重输出参数明确使用 `NSString * _Nullable * _Nullable`；对可传入 nil 的卸载路径、应用标识和注册状态参数逐一标注 `_Nullable`。
3. `TSApplicationsManager.m` 中的实现声明同步更新，保持实现与公开头文件的可空契约一致。
4. 集合布局改用 `horizontalGroupWithLayoutSize:repeatingSubitem:count:`，保持两列布局行为。
5. `Scripts/validate_project.py` 增加 nullability 契约和非弃用布局 API 断言。
6. 根 Makefile 新增 `validate-project`，在进入 Apple 工具链前自动执行 Python 语法检查、工程完整性检查及内置 ldid Mach-O 检查。

### 本轮验证

- `clang -x objective-c -fsyntax-only -Wnullability-completeness -Werror`：使用轻量 Foundation 声明桩检查 `TSApplicationsManager.h`，通过。该检查只验证头文件语法与 nullability 诊断，不替代 iOS SDK 编译。
- `python3 -m py_compile Scripts/*.py`：通过。
- `python3 Scripts/validate_project.py`：通过，80 项必需文件、6 份 plist、4 份 strings、490 个简体中文键及全部已有功能断言通过。
- `python3 Scripts/validate_macho.py bin/ldid`：通过。
- 83 个 Objective-C/C 源文件和头文件的括号、注释词法扫描：通过。
- `bash -n Scripts/bootstrap_choma.sh`：通过。
- ZIP 完整性检查：通过。

### 工具链边界

当前环境为 Linux x86_64，没有 Xcode、iPhoneOS 16.5 SDK 或 Theos。未执行完整 `clang` iOS 编译、Theos 链接或真机运行测试。GitHub Actions 仍须提供固定提交的 ChOma 子模块和其构建依赖。

## 2026-10-31 iOS 16 UIKit / UniformTypeIdentifiers 修复（本轮）

- `TSAppearanceController` 的操作按钮已迁移到 iOS 15+ `UIButtonConfiguration`，通过 `contentInsets` 实现左右留白，并用 `UIBackgroundConfiguration` 设置背景色和圆角；不再使用已弃用的 `contentEdgeInsets`。
- `TSRootViewController` 浮动底栏按钮也迁移到 `UIButtonConfiguration`，通过 `imagePlacement` / `imagePadding` 排列图标和标题，不再使用已弃用的 `imageEdgeInsets`。
- `UTType.image`、`UTType.data`、`UTType.archive`、`UTType.package` 是 Swift 风格静态成员，不能作为 Objective-C `UTType` 类属性访问。项目中的文档选择器现统一使用 Objective-C `+[UTType typeWithIdentifier:]` 和 `+[UTType typeWithFilenameExtension:conformingToType:]`。
- 覆盖外观图片选择、IPA/TIPA/TAR/ZIP/DEB 包导入、Dylib/Framework/ZIP/DEB 注入、P12/PEM/Profile 文件导入等路径。
- 新增回归规则：全项目 Objective-C `.m/.h` 禁止重新引入 Swift-only `UTType` 类属性和 `contentEdgeInsets` / `imageEdgeInsets` / `titleEdgeInsets`。
- 为系统 UTI 注册表不可用的异常提示同步增加 TrollStore 与 TrollHelper 简体中文资源键。

验证：`Scripts/validate_project.py`、`Scripts/validate_macho.py bin/ldid`、三个 Python 脚本 `py_compile`、UTType 错误属性全项目搜索、UIButton 旧 inset API 全项目搜索、ZIP 完整性检查均通过。未在本环境执行 Xcode/Theos 真正的 iOS 16.5 编译。


## 第三轮 UIKit 编译修复：UIButtonConfiguration.imagePlacement 枚举类型

### 新报错

`TSRootViewController.m` 将 `UIButtonConfigurationImagePlacementLeading` 赋给 `UIButtonConfiguration.imagePlacement`，但该属性的实际类型是 `NSDirectionalRectEdge`。编译器因此报告未声明标识符，并进一步报告不同枚举类型转换错误。

### 修复

- 将 `configuration.imagePlacement` 改为 `NSDirectionalRectEdgeLeading`。
- 保留 `UIButtonConfiguration` 的 `image`、`title`、`imagePadding` 和 `contentInsets` 设置，浮动底栏仍为图标位于标题前方的布局。
- 在 `Scripts/validate_project.py` 增加回归检查：禁止使用不存在的 `UIButtonConfigurationImagePlacementLeading`，并要求浮动底栏使用 `NSDirectionalRectEdgeLeading`。

### 验证

- `make validate-project`：通过。
- `python3 -m py_compile Scripts/validate_project.py Scripts/validate_macho.py Scripts/validate_choma_api.py`：通过。
- `python3 Scripts/validate_macho.py bin/ldid`：通过。
- Objective-C 源码扫描：不存在错误的 `UIButtonConfigurationImagePlacementLeading`，唯一 `imagePlacement` 赋值使用 `NSDirectionalRectEdgeLeading`。
- Apple UIKit 文档确认 `UIButtonConfiguration.imagePlacement` 的类型为 `NSDirectionalRectEdge`，UIKit 枚举提供 `NSDirectionalRectEdgeLeading` 常量。

当前环境没有 Xcode/iPhoneOS 16.5 SDK/Theos，尚未执行真实 iOS 编译及链接。


## Signing settings Done button initializer correction

- Replaced the `UIBarButtonSystemItemDone` initializer with `initWithTitle:style:target:action:` using the existing localized `Done` key. This avoids the malformed/ambiguous enum token present in the stored source and keeps the same Done appearance and dismiss action.
- Added a validator assertion for the title initializer, selector, and zh-Hans `Done` key.
- Validation: `python3 -m py_compile Scripts/validate_project.py Scripts/validate_macho.py Scripts/validate_choma_api.py`, `python3 Scripts/validate_project.py`, and `python3 Scripts/validate_macho.py bin/ldid`.
- Not run: full Xcode/Theos compilation and device installation; the current editing environment does not contain the iOS SDK or Theos toolchain.
