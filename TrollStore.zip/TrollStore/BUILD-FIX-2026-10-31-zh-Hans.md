# TrollStore iOS 16+ / Theos ldid 构建错误修复（2026-10-31）

## 报错

GitHub Actions 在构建 `TweakPresets/AppLock` 时出现：

```text
/bin/bash: ldid: command not found
make: *** [.../makefiles/instance/library.mk:51: .../TSAppLock.dylib] Error 127
```

## 根因

- `TweakPresets/AppLock/Makefile` 与 `TweakPresets/BackgroundAssist/Makefile` 没有指定 `TARGET_CODESIGN`，Theos 因而回退到宿主环境默认的 `ldid` 命令。
- 包内 `bin/ldid` 是 **arm64 iOS 设备端 Mach-O**，`LC_BUILD_VERSION` 平台为 iOS、最低版本 iOS 16.0、SDK 16.4。它不是 macOS 主机程序，不能通过把它加入 macOS Runner 的 PATH 来解决问题。
- 工程原先的 TrollStore、RootHelper、TrollHelper 和两个 preset Makefile 仍将 iOS 14.0 写作最低部署版本，与产品只支持 iOS 16+ 的要求不一致。

## 修改

1. `TweakPresets/AppLock/Makefile` 和 `TweakPresets/BackgroundAssist/Makefile` 显式设置：

   ```make
   TARGET_CODESIGN = /usr/bin/codesign
   TARGET_CODESIGN_FLAGS = --force --sign -
   ```

   macOS Runner 使用系统 `codesign` 对构建产物执行 ad-hoc 签名，不需要证书，也不会调用设备端 `bin/ldid`。

2. 根 `Makefile` 的 `check-build-tools` 增加 `/usr/bin/codesign` 检查，让主机工具缺失时给出明确报错。

3. `TrollStore/Makefile`、`RootHelper/Makefile`、`TrollHelper/Makefile`、两个 preset Makefile 的最低部署版本全部调整为 iOS 16.0。

4. 更新安装错误提示、简体中文翻译、README 和实现报告，明确工程最低系统版本为 iOS 16.0+，并区分 macOS 构建工具与 iOS 设备端 ldid。

5. `bin/ldid` 保持逐字节不变；不下载替换、不重编译、不把它作为 macOS 主机工具。

## 已执行验证

- `python3 -m py_compile Scripts/validate_project.py Scripts/validate_macho.py Scripts/validate_choma_api.py`：通过。
- `python3 Scripts/validate_project.py`：通过；必需文件、plist、简体中文 strings、本地化键及已有项目约束均通过。
- `python3 Scripts/validate_macho.py bin/ldid`：通过；确认提供的文件仍是预期的 arm64 iOS 设备端 Mach-O。
- 对 `bin/ldid` 重新计算 SHA-256，与 `bin/ldid.sha256` 完全一致：`d23eb53e6c5b07f5cae72f0e93ab1b87214aa68ed4a59bc32286f8b15cb8b769`。
- 静态检查五个 iOS Theos Makefile 均设置最低版本 16.0；两个 preset 都显式选择 macOS `/usr/bin/codesign`。

## 尚未完成的验证

当前编辑环境没有 macOS、Xcode、iPhoneOS SDK 或 Theos 安装。因此没有执行 GitHub macOS Runner 上的 `make build-presets` / `make assemble_trollstore`，也没有进行真机安装与启动测试。该修复针对错误日志对应的 Theos 签名工具选择问题，最终仍需在 macOS CI 完整编译确认。
