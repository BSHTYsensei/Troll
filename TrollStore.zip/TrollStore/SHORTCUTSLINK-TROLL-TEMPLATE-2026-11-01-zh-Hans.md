> 已被 `SHORTCUTS-URL-SCHEME-IOS16.5-FALLBACK-2026-11-01-zh-Hans.md` 中的 iOS 16.5 SDK 兼容实现取代。原 ShortcutsLink/UIButton 方案在实际 SDK 编译中均不可用。

# TrollStore — ShortcutsLink 兼容修复与签名模板简化

日期：2026-11-01
基线：`TrollStore-Swift-PkgSignature-Fix-2026-11-01.zip`

## 1. ShortcutsLink 替换 ShortcutsUIButton

此前 CI 错误：

- `TSRefreshAppRegistrationsIntent.swift` 找不到 `ShortcutsUIButton`。
- 该类在当前 Theos / iOS 16.5 SDK 的编译上下文中不可用；把它放在 Swift 工厂中也不能解决 SDK 缺失符号的问题。

修改：

- 删除 `TSRefreshShortcutsButtonFactory` 和全部 `ShortcutsUIButton` 代码。
- 显式导入 `SwiftUI`。
- 新增 SwiftUI `TSRefreshShortcutsLinkView`，内部使用 Apple 原生 `ShortcutsLink()` 与 `.shortcutsLinkStyle(.automatic)`。
- 新增公开的 `TSRefreshShortcutsLinkFactory.makeViewController()`，返回 `UIHostingController`。
- Objective-C `TSRefreshShortcutController` 通过 `<TrollStore-Swift.h>` 获取该控制器，并以 child view controller 方式嵌入现有设置页。
- TrollStore target 显式链接 `SwiftUI` framework。
- Done / 退出入口、说明文字和旧系统 fallback 保留。

Apple WWDC22 “Implement App Shortcuts with App Intents” 展示了 `ShortcutsLink()` 的 SwiftUI 用法；Apple 文档说明该控件会打开当前 App 在 Shortcuts 中的 App Shortcuts 页面。`UIHostingController` 是 Apple 提供的 UIKit/SwiftUI 集成控制器。

## 2. TrollStore 签名模式取消模板选择器

源码确认 TrollStore 模式的实际配置是 `credentialFormat = adhoc`，ldid profile 的 `adhoc = true`，之后继续经过 TrollStore CoreTrust 处理。旧的 `TrollStore Default / Fast / Compatibility` 只改变 SHA-256 与 jobs 等参数，并不是不同签名身份。

修改：

- TrollStore 模式的设置页只显示签名方式，不创建模板 section。
- `templateDefinitionsForMode:@"troll"` 返回空数组。
- `selectedTemplateForMode:@"troll"` 不读取用户选择，固定返回内部标识 `trollstore-default`。
- 旧 `TSSigningTrollTemplate` preference 在切换或读取旧模式时清除，且设置 API 不再接受 TrollStore 模板写入。
- `prepareRootHelperSigningConfiguration` 在 TrollStore 模式直接建立内部配置：SHA-256、4 个 ldid jobs、ad-hoc；Real 模式仍按用户选择的模板解析。
- Real CMS Signing 继续保留 App Store、App Store Connect、TestFlight、Apple Development、Developer Distribution、Ad Hoc、Enterprise 等证书模板。模板不会伪造证书、描述文件或 Apple 分发权限。

## 3. Shortcuts / Persistence Helper 边界

没有将 Apple Shortcuts.app 加入 Persistence Helper 注入目标。UI 候选列表和 RootHelper 特权命令入口仍对 `com.apple.shortcuts` 执行拒绝。主 TrollStore 提供的 `Refresh Apps` App Intent 与 `AppShortcutsProvider` 保留；运行时继续只刷新应用注册，不 respring、不打开 Persistence Helper。

## 4. 验证

通过：

- `swiftc -frontend -parse TrollStore/TSRefreshAppRegistrationsIntent.swift`（只验证语法解析，不等于 iOS SDK 类型检查）。
- `make validate-project LDID_BIN=bin/ldid`。
- Theos Swift support 缓存损坏恢复回归。
- Swift toolchain pkg 签名状态解析测试：3 种可信状态接受、4 种无效/不可信情况拒绝。
- 项目资源与 plist/strings 校验。
- 简体中文本地化 App / Persistence Helper 目录一致性检查：635 个匹配键。
- fastPathSign per-slice signing、Universal 重建和 Framework 包装回归。
- 预编译 arm64 `bin/ldid` 完整性检查。
- ZIP 完整性检查。

未运行：真实 macOS Theos/Xcode iOS SDK 构建、App Intents Metadata Processor 实际提取、设备端 Shortcuts 页面打开与自动化执行。当前编辑环境没有 macOS/Xcode iOS SDK；GitHub Actions 的实际构建日志仍是最终验证依据。

## 5. 主要改动文件

- `TrollStore/TSRefreshAppRegistrationsIntent.swift`
- `TrollStore/TSRefreshShortcutController.m`
- `TrollStore/Makefile`
- `TrollStore/TSSigningManager.m`
- `TrollStore/TSSigningSettingsController.m`
- `TrollStore/Resources/zh-Hans.lproj/Localizable.strings`
- `TrollHelper/Resources/zh-Hans.lproj/Localizable.strings`
- `LOCALIZATION-KEYS-zh-Hans.txt`
- `Scripts/validate_project.py`
- `README.md` 与签名 / 快捷指令说明文档

预编译 `bin/ldid` 未修改。其他安装、Entitlements 编辑、防主屏幕删除、快捷指令刷新 Intent、Framework 组件、`.dylib` 兼容、签名与安装优化均保留。
