# 视频 UI、插件导航与逐 App 禁止升级实现记录

日期：2026-10-31

## 本轮实现

### 视频风格导航与应用分类

- 底部导航为四个入口：应用、安装包、插件、设置。
- 底部图标位于文字上方，选中状态采用蓝色，未选中状态采用系统灰色；保留原有淡入/缩放页面切换。
- 应用页改为四个分类：全部、用户、巨魔、系统。
- 旧版本 `TSAppSourceCategory` 从三分类迁移到 V2：旧 0（TrollStore）→ 新 2，旧 1（App Store）→ 新 1，旧 2（System）→ 新 3；没有保存过的用户默认进入全部。
- “全部”视图组合 TrollStore 管理路径、普通用户应用容器和 LaunchServices 系统应用；菜单按实际 bundle path 与 TrollStore marker 决定操作，不再依赖当前选中的分类猜测应用身份。
- 滑动卸载和注册状态切换只对带 TrollStore marker 的应用显示；禁止升级只对普通用户容器中的非 TrollStore 应用显示。

### 逐 App 禁止升级与恢复

- 在普通用户应用的操作菜单中增加“禁止应用升级 / 允许应用升级”。
- 设置页“已禁止应用升级”列出所有锁定的 Bundle ID；点选后可恢复原始元数据。
- RootHelper 验证 LaunchServices 已安装应用代理、Bundle ID、正常用户 App 容器、Info.plist 身份、TrollStore marker 和元数据文件必须是常规非符号链接文件。
- 禁止时重命名 `iTunesMetadata.plist` 为 `iTunesMetadata_blocked.plist`；恢复时反向重命名。
- 刷新 LaunchServices 数据库，观察 knowledge UUID/sequence token 稳定，再刷新 App Store 缓存。
- 如果刷新失败，尝试回滚元数据重命名；如果检测到重装后新旧两份文件共存，则清理旧的 blocked 标记，以新的正常元数据为准。
- 不影响 iOS 系统软件更新；不对 TrollStore 自身或 System Apps 执行此操作。

**重要限制：**此实现依赖私有 LaunchServices API 和 App Store 对 `iTunesMetadata.plist` 的当前处理方式，不是 Apple 公开承诺的管理接口。必须在目标 iOS 16.x 设备上用非关键应用测试禁止与恢复两条路径，不能仅凭 RootHelper 返回成功就推断未来所有 App Store 版本都绝对无法更新。

### 插件页面

- 实时读取 `iosdumpzzz/iosdump.repo` 的 `Packages` 索引；网络失败时使用本地索引缓存。
- 搜索名称、包 ID、说明、作者和架构；每个包/架构保留索引中的最新版本。
- 详情展示版本、架构、作者、描述、依赖；依赖 MobileSubstrate、ElleKit、libhooker、Substitute 或 RocketBootstrap 的包会明确标注为系统 tweak。
- 仅允许从固定 HTTPS 仓库下载安全的相对 `.deb` 路径；检查 SHA-256，索引提供 Size 时也检查大小；校验失败立即丢弃。
- 下载包保存到现有 Packages 页面。该页面已有 DEB 解包和动态库查找；应用页已有 Tweak Injector，能够将兼容的 dylib 注入指定 App。
- 不会通过 `dpkg` 把 DEB 系统文件写入 iOS 根文件系统。AppData、AirDrop 等包依赖 MobileSubstrate，普通 TrollStore 环境不能通过下载它们就激活系统 tweak。

## 验证范围

- `make validate-project`
- `python3 -m py_compile` 覆盖项目验证脚本、Mach-O 校验脚本和 fastPathSign universal 管线脚本
- `python3 Scripts/test_fastpath_sign_pipeline.py`
- `python3 Scripts/validate_macho.py bin/ldid`
- 简体中文主应用 / TrollHelper 字符串键集合一致性检查
- 原始预编译 `bin/ldid` SHA-256 与可执行权限核对
- ZIP 完整性与解压后路径核对

当前执行环境没有 macOS、Xcode、iPhoneOS SDK 或 Theos，故本报告不声称完成 Apple SDK 全量编译或真机验证。逐 App 更新锁定使用私有系统行为，目标设备实测仍是发布前必需步骤。
