#!/usr/bin/env bash
set -euo pipefail

THEOS_DIR="${THEOS:-$HOME/theos}"
SDK_VERSION="${SWIFT_TARGET_SDK_VERSION:-16.5}"
TOOLCHAIN_DIR="${SWIFT58_TOOLCHAIN_DIR:-$HOME/Library/Developer/Toolchains/swift-5.8.1-RELEASE.xctoolchain}"
SWIFTC="$TOOLCHAIN_DIR/usr/bin/swiftc"
PACKAGE_URL="${SWIFT58_TOOLCHAIN_PKG_URL:-https://download.swift.org/swift-5.8.1-release/xcode/swift-5.8.1-RELEASE/swift-5.8.1-RELEASE-osx.pkg}"
EXPECTED_SIGNER="Developer ID Installer: Swift Open Source (V9AUD2URP3)"
# This validates the compiler passed to Theos through the TARGET_SWIFTC override.

fail() { echo "error: $*" >&2; exit 1; }

[[ "$(uname -s)" == "Darwin" ]] || fail "Swift 5.8.1 target toolchain bootstrap must run on a macOS GitHub Actions runner"
[[ -d "$THEOS_DIR" ]] || fail "THEOS directory not found: $THEOS_DIR"
SDK_DIR="$THEOS_DIR/sdks/iPhoneOS${SDK_VERSION}.sdk"
[[ -d "$SDK_DIR" ]] || fail "expected patched iPhoneOS${SDK_VERSION}.sdk not found: $SDK_DIR"

# The patched 16.5 SDK exposes SwiftUI/AppIntents interfaces emitted by Swift 5.8.
# Match the compiler to that interface instead of changing or stripping the SDK.
SWIFTUI_INTERFACE="$(find "$SDK_DIR/System/Library/Frameworks/SwiftUI.framework/Modules/SwiftUI.swiftmodule" -type f -name '*.swiftinterface' -print -quit 2>/dev/null || true)"
[[ -n "$SWIFTUI_INTERFACE" && -f "$SWIFTUI_INTERFACE" ]] || fail "SwiftUI textual module interface is missing from iPhoneOS${SDK_VERSION}.sdk"
if ! grep -Eq 'swift-compiler-version:.*Swift version 5\.8([.[:space:]]|$)' "$SWIFTUI_INTERFACE"; then
    interface_version="$(grep -m1 'swift-compiler-version:' "$SWIFTUI_INTERFACE" || echo unknown)"
    fail "expected Swift 5.8 SDK interface, found: $interface_version"
fi

if [[ ! -x "$SWIFTC" ]]; then
    command -v curl >/dev/null 2>&1 || fail "curl is required to install the Swift 5.8.1 toolchain"
    command -v pkgutil >/dev/null 2>&1 || fail "pkgutil is required to verify the Swift toolchain package signature"
    command -v installer >/dev/null 2>&1 || fail "macOS installer is unavailable"
    temp_dir="$(mktemp -d "${TMPDIR:-/tmp}/trollstore-swift58.XXXXXX")"
    trap 'rm -rf "$temp_dir"' EXIT
    pkg="$temp_dir/swift-5.8.1-RELEASE-osx.pkg"
    echo "[swift] downloading the official Swift 5.8.1 toolchain package"
    curl --fail --location --retry 3 --retry-delay 2 "$PACKAGE_URL" --output "$pkg"
    signature="$(pkgutil --check-signature "$pkg" 2>&1)" || fail "Swift toolchain package signature verification failed: $signature"
    printf '%s\n' "$signature" | grep -Fq "$EXPECTED_SIGNER" || fail "Swift toolchain package is not signed by $EXPECTED_SIGNER"
    printf '%s\n' "$signature" | grep -Eqi 'Status: signed by a certificate trusted by Mac OS X' || fail "Swift toolchain package is not signed by a trusted certificate"
    echo "[swift] installing the verified Swift 5.8.1 target toolchain"
    installer -target CurrentUserHomeDirectory -pkg "$pkg"
fi

[[ -x "$SWIFTC" ]] || fail "Swift 5.8.1 compiler was not installed at $SWIFTC"
version_output="$("$SWIFTC" --version 2>&1)" || fail "could not execute target swiftc: $SWIFTC"
printf '%s\n' "$version_output" | grep -Eq '(Apple )?Swift version 5\.8\.1([[:space:]]|$)' || fail "TARGET_SWIFTC must be Swift 5.8.1; got: $version_output"

# Ensure the SDK being compiled is the same SDK family checked above.
echo "[swift] target compiler: $SWIFTC"
echo "[swift] target compiler version: $(printf '%s\n' "$version_output" | head -n 1)"
echo "[swift] target SDK: $SDK_DIR"
