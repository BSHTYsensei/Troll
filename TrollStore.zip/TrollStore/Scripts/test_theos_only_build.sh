#!/usr/bin/env bash
# The default release profile uses Theos Makefiles + standalone macOS CLT and
# the pinned iOS 16.5 SDK. It excludes Swift/App Intents and Xcode dependencies.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ROOT_MAKE="$ROOT/Makefile"
APP_MAKE="$ROOT/TrollStore/Makefile"
SETTINGS="$ROOT/TrollStore/TSSettingsListController.m"

for file in "$ROOT_MAKE" "$APP_MAKE" "$ROOT/RootHelper/Makefile" "$ROOT/TrollHelper/Makefile" \
    "$ROOT/TweakPresets/AppLock/Makefile" "$ROOT/TweakPresets/BackgroundAssist/Makefile" \
    "$ROOT/Exploits/fastPathSign/Makefile"; do
    if grep -Eq 'XcodeDefault\.xctoolchain|XCODE_DEFAULT_CLANG|XCODE_SWIFT_RUNTIME_DIR|prepare_swift_link_runtime\.sh|xcode-clang\.mk|xcrun --find swiftc' "$file"; then
        echo "error: Xcode-specific compiler/runtime path remains in active build file: $file" >&2
        exit 1
    fi
done

for file in "$ROOT/TrollStore/Makefile" "$ROOT/RootHelper/Makefile" "$ROOT/TrollHelper/Makefile" \
    "$ROOT/TweakPresets/AppLock/Makefile" "$ROOT/TweakPresets/BackgroundAssist/Makefile"; do
    grep -Eq '^TARGET[[:space:]]*:?=[[:space:]]*iphone:clang:16\.5:16\.0$' "$file" || {
        echo "error: target is not pinned to Theos iPhoneOS 16.5 SDK: $file" >&2
        exit 1
    }
done

grep -Fq 'override IOS_SDK_VERSION := 16.5' "$ROOT_MAKE"
grep -Fq 'APPLE_DEVELOPER_DIR ?= /Library/Developer/CommandLineTools' "$ROOT_MAKE"
grep -Fq 'APPLE_TOOLCHAIN_BIN ?= $(APPLE_DEVELOPER_DIR)/usr/bin' "$ROOT_MAKE"
if grep -Eq 'xcode-select|xcodebuild|/Applications/Xcode|XcodeDefault' "$ROOT_MAKE"; then
    echo 'error: root Makefile still depends on an Xcode installation or selector' >&2
    exit 1
fi
grep -Fq 'ENABLE_APP_INTENTS ?= 0' "$ROOT_MAKE"
grep -Fq 'ENABLE_APP_INTENTS ?= 0' "$APP_MAKE"
grep -Fq 'TrollStore_FILES = $(wildcard *.m) $(filter-out ../Shared/TSListControllerShared.m,$(wildcard ../Shared/*.m))' "$APP_MAKE"
grep -Fq 'TrollStore_FRAMEWORKS = UIKit CoreGraphics CoreServices CoreTelephony Security' "$APP_MAKE"
grep -Fq '$(HELPER_NAME)_LDFLAGS = -L../ChOma/external/ios -lcrypto' "$ROOT/RootHelper/Makefile"
grep -Fq '$(HELPER_NAME)_LIBRARIES = archive' "$ROOT/RootHelper/Makefile"
if grep -Fq '[TSThemeManager ' "$ROOT/Shared/TSListControllerShared.m"; then
    echo 'error: shared list controller has a static TSThemeManager dependency and cannot link into TrollHelper' >&2
    exit 1
fi
grep -Fq 'NSClassFromString(@"TSThemeManager")' "$ROOT/Shared/TSListControllerShared.m"
grep -Fq 'Cleaning TrollHelper objects' "$ROOT_MAKE"
grep -Fq 'ifeq ($(ENABLE_APP_INTENTS),1)' "$APP_MAKE"
grep -Fq 'TrollStore_SWIFT_FILES = TSRefreshAppRegistrationsIntent.swift' "$APP_MAKE"
grep -Fq 'TrollStore_FRAMEWORKS += AppIntents' "$APP_MAKE"
grep -Fq '#ifdef TS_ENABLE_APP_INTENTS' "$SETTINGS"

if grep -Fq 'TrollStore_SWIFT_FILES = TSRefreshAppRegistrationsIntent.swift' "$ROOT_MAKE"; then
    echo 'error: the root default build must not activate the Swift source' >&2
    exit 1
fi
if ! grep -Fq 'if [ "$(ENABLE_APP_INTENTS)" = "1" ]; then' "$ROOT_MAKE"; then
    echo 'error: App Intents metadata must be gated by ENABLE_APP_INTENTS' >&2
    exit 1
fi
if grep -Fq 'APP_INTENTS_METADATA_OPTIONAL=1' "$ROOT_MAKE"; then
    echo 'error: no-Xcode profile must not invoke the optional metadata processor path' >&2
    exit 1
fi

for marker in \
    'TARGET_CC="$(APPLE_CLANG)"' \
    'TARGET_CXX="$(APPLE_CLANGXX)"' \
    'TARGET_LIPO="$(APPLE_LIPO)"' \
    'TARGET_DSYMUTIL="$(APPLE_DSYMUTIL)"' \
    'override IOS_SDK_VERSION := 16.5'; do
    grep -Fq "$marker" "$ROOT_MAKE" || {
        echo "error: missing explicit Theos toolchain configuration: $marker" >&2
        exit 1
    }
done

for marker in \
    '-C ./RootHelper THEOS="$(THEOS)" $(THEOS_TARGET_TOOL_ARGS)' \
    '-C ./TrollStore THEOS="$(THEOS)" $(THEOS_TARGET_TOOL_ARGS)' \
    '-C ./TrollHelper THEOS="$(THEOS)" $(THEOS_TARGET_TOOL_ARGS)' \
    '-C ./TweakPresets/AppLock THEOS="$(THEOS)" $(THEOS_TARGET_TOOL_ARGS)' \
    '-C ./TweakPresets/BackgroundAssist THEOS="$(THEOS)" $(THEOS_TARGET_TOOL_ARGS)'; do
    grep -Fq -- "$marker" "$ROOT_MAKE" || {
        echo "error: subproject does not receive the shared Theos tool arguments: $marker" >&2
        exit 1
    }
done

grep -Fq '$(THEOS)/sdks/iPhoneOS$(IOS_SDK_VERSION).sdk' "$ROOT_MAKE"
grep -Fq 'HOST_MACOSX_SDKROOT' "$ROOT_MAKE"
grep -Fq 'HOST_MACOSX_SDKROOT ?= /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk' "$ROOT/Exploits/fastPathSign/Makefile"
grep -Fq 'Swift runtime is disabled' "$ROOT_MAKE"

# The fastPathSign signer preserves arm64/arm64e slices using a directly
# resolved lipo executable; no xcrun dependency is required.
if grep -Eq 'xcrun|xcodebuild|XcodeDefault' "$ROOT/Scripts/fastpath_sign_all_slices.py"; then
    echo 'error: signing wrapper still depends on Xcode/xcrun' >&2
    exit 1
fi

echo '[test] Theos + standalone CLT build profile is pinned to iPhoneOS 16.5 and excludes Xcode/Swift runtime dependencies'
