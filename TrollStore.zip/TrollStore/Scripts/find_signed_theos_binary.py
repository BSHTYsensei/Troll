#!/usr/bin/env python3
"""Assemble a signed universal Theos dylib from individually signed architecture slices."""
from __future__ import annotations

import argparse
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tempfile

from validate_macho_signature import has_valid_code_signature, macho_slices
import fastpath_sign_all_slices as sign_pipeline

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_WRAPPER = ROOT / "Scripts" / "fastpath_sign_all_slices.py"


def run(command: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, check=False, text=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("search_root", type=Path)
    parser.add_argument("filename")
    parser.add_argument("--expect-arch", action="append", default=None)
    parser.add_argument("--signer-wrapper", type=Path, default=DEFAULT_WRAPPER)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--lipo", default=sign_pipeline.LIPO)
    args = parser.parse_args()

    if not args.search_root.is_dir():
        print(f"error: Theos object directory does not exist: {args.search_root}", file=sys.stderr)
        return 1
    if not args.signer_wrapper.is_file():
        print(f"error: architecture-preserving fastPathSign wrapper is missing: {args.signer_wrapper}", file=sys.stderr)
        return 1

    sign_pipeline.LIPO = args.lipo
    expected_arches = args.expect_arch or ["arm64", "arm64e"]
    candidates = sorted(
        (p for p in args.search_root.rglob(args.filename)
         if p.is_file() and not any(part.endswith(".dSYM") or part == "DWARF" for part in p.parts)),
        key=lambda p: (p.stat().st_size, str(p)),
        reverse=True,
    )
    candidate_arches: dict[Path, list[str]] = {}
    for path in candidates:
        try:
            candidate_arches[path] = [arch for arch, _ in macho_slices(path)]
        except (OSError, ValueError, struct.error):
            candidate_arches[path] = []
    failures: list[str] = []
    args.output.parent.mkdir(parents=True, exist_ok=True)

    try:
        with tempfile.TemporaryDirectory(prefix=".theos-signed-universal-", dir=str(args.output.parent)) as temp_name:
            temp = Path(temp_name)
            signed_slices: list[Path] = []
            for index, arch in enumerate(expected_arches):
                eligible = [p for p in candidates if arch in candidate_arches[p]]
                # Prefer an architecture-specific object over a possibly thinned
                # top-level output; the wrapper will independently verify signing.
                eligible.sort(key=lambda p: (
                    0 if len(candidate_arches[p]) == 1 else 1,
                    0 if has_valid_code_signature(p, arch) else 1,
                    0 if p.parent.name == arch else 1,
                    -p.stat().st_size,
                    str(p),
                ))
                chosen: Path | None = None
                thin_path = temp / f"{index}-{arch}-{args.filename}"
                for source in eligible:
                    source_arches = candidate_arches[source]
                    if len(source_arches) == 1:
                        shutil.copy2(source, thin_path)
                    else:
                        result = run([args.lipo, "-thin", arch, str(source), "-output", str(thin_path)])
                        if result.returncode != 0:
                            failures.append(f"{source}: lipo could not extract {arch}")
                            continue
                    extracted = macho_slices(thin_path)
                    if len(extracted) != 1 or extracted[0][0] != arch:
                        failures.append(f"{source}: extraction did not produce a thin {arch} file")
                        continue
                    try:
                        sign_pipeline.sign_binary(thin_path)
                    except (OSError, RuntimeError, subprocess.SubprocessError, ValueError) as exc:
                        failures.append(f"{source} ({arch}): {exc}")
                        continue
                    if not has_valid_code_signature(thin_path, arch):
                        failures.append(f"{source} ({arch}): CodeDirectory verification failed after signing")
                        continue
                    chosen = thin_path
                    break
                if chosen is None:
                    listing = ", ".join(str(p) for p in eligible) if eligible else "no Mach-O candidate for this architecture"
                    raise RuntimeError(f"no signed {arch} slice could be produced for {args.filename}; candidates: {listing}; details: {' | '.join(failures)}")
                signed_slices.append(chosen)

            if len(signed_slices) == 1:
                final_path = signed_slices[0]
            else:
                final_path = temp / args.filename
                result = run([args.lipo, "-create", *map(str, signed_slices), "-output", str(final_path)])
                if result.returncode != 0:
                    raise RuntimeError(f"lipo failed to create universal {args.filename}")

            final_arches = [arch for arch, _ in macho_slices(final_path)]
            if set(final_arches) != set(expected_arches) or len(final_arches) != len(expected_arches):
                raise RuntimeError(f"final universal {args.filename} has wrong architecture set: expected {expected_arches}, got {final_arches}")
            for arch in expected_arches:
                if not has_valid_code_signature(final_path, arch):
                    raise RuntimeError(f"final universal {args.filename} failed {arch} CodeDirectory verification")

            shutil.copy2(final_path, args.output)
            args.output.chmod(0o644)

        print(f"[preset] assembled signed universal {args.output} ({', '.join(expected_arches)})")
        return 0
    except (OSError, RuntimeError, subprocess.SubprocessError, ValueError, struct.error) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
