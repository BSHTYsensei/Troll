#!/usr/bin/env python3
"""Find Theos' final universal Mach-O output by requiring signed arm64 + arm64e slices."""
from __future__ import annotations
import argparse
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
VALIDATOR = ROOT / "Scripts" / "validate_macho_signature.py"

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("search_root", type=Path)
    parser.add_argument("filename")
    parser.add_argument("--expect-arch", action="append", default=None)
    args = parser.parse_args()
    if not args.search_root.is_dir():
        print(f"error: Theos object directory does not exist: {args.search_root}", file=sys.stderr)
        return 1

    expected_arches = args.expect_arch or ["arm64", "arm64e"]
    candidates = sorted(
        (p for p in args.search_root.rglob(args.filename) if p.is_file()),
        key=lambda p: (p.stat().st_size, str(p)),
        reverse=True,
    )
    for candidate in candidates:
        command = [sys.executable, str(VALIDATOR), str(candidate)]
        for arch in expected_arches:
            command.extend(("--expect-arch", arch))
        result = subprocess.run(command, capture_output=True, text=True)
        if result.returncode == 0:
            print(candidate.resolve())
            return 0

    searched = ", ".join(str(p) for p in candidates) if candidates else "no matching files"
    print(
        f"error: no signed universal {args.filename} with architectures "
        f"{', '.join(expected_arches)} found under {args.search_root}; candidates: {searched}",
        file=sys.stderr,
    )
    return 1

if __name__ == "__main__":
    raise SystemExit(main())
