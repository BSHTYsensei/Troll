# This fragment MUST be included after $(THEOS)/makefiles/common.mk. Theos
# resolves the target platform/toolchain and loads ~/.theosrc inside common.mk;
# pinning the compiler before that point is not a reliable final override.
include $(dir $(lastword $(MAKEFILE_LIST)))clang-include-env.mk

XCODE_DEVELOPER_DIR ?= $(if $(DEVELOPER_DIR),$(DEVELOPER_DIR),$(shell xcode-select -p 2>/dev/null))
ifeq ($(strip $(XCODE_DEVELOPER_DIR)),)
$(error xcode-select could not locate the active Xcode Developer directory)
endif

XCODE_DEFAULT_TOOLCHAIN_BIN := $(XCODE_DEVELOPER_DIR)/Toolchains/XcodeDefault.xctoolchain/usr/bin
XCODE_DEFAULT_CLANG := $(XCODE_DEFAULT_TOOLCHAIN_BIN)/clang
XCODE_DEFAULT_CLANGXX := $(XCODE_DEFAULT_TOOLCHAIN_BIN)/clang++
XCODE_DEFAULT_CLANG_RESOURCE_DIR := $(shell unset CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH OBJC_INCLUDE_PATH OBJCPLUS_INCLUDE_PATH CCC_OVERRIDE_OPTIONS CLANG_CONFIG_FILE_USER_DIR CLANG_CONFIG_FILE_SYSTEM_DIR; "$(XCODE_DEFAULT_CLANG)" -print-resource-dir 2>/dev/null)
XCODE_DEFAULT_CLANG_VERSION := $(shell unset CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH OBJC_INCLUDE_PATH OBJCPLUS_INCLUDE_PATH CCC_OVERRIDE_OPTIONS CLANG_CONFIG_FILE_USER_DIR CLANG_CONFIG_FILE_SYSTEM_DIR; "$(XCODE_DEFAULT_CLANG)" --version 2>/dev/null | head -n 1 | shasum -a 256 | cut -c1-12)

ifeq ($(wildcard $(XCODE_DEFAULT_CLANG)),)
$(error Xcode default clang was not found at $(XCODE_DEFAULT_CLANG))
endif
ifeq ($(wildcard $(XCODE_DEFAULT_CLANGXX)),)
$(error Xcode default clang++ was not found at $(XCODE_DEFAULT_CLANGXX))
endif
ifeq ($(wildcard $(XCODE_DEFAULT_CLANG_RESOURCE_DIR)/include/stdatomic.h),)
$(error Xcode Clang stdatomic.h was not found under $(XCODE_DEFAULT_CLANG_RESOURCE_DIR)/include)
endif
ifeq ($(wildcard $(XCODE_DEFAULT_CLANG_RESOURCE_DIR)/include/__stddef_max_align_t.h),)
$(error Xcode Clang __stddef_max_align_t.h was not found under $(XCODE_DEFAULT_CLANG_RESOURCE_DIR)/include)
endif

XCODE_CLANG_WRAPPER := $(abspath $(dir $(lastword $(MAKEFILE_LIST)))xcode-clang-wrapper.sh)
XCODE_CLANGXX_WRAPPER := $(abspath $(dir $(lastword $(MAKEFILE_LIST)))xcode-clangxx-wrapper.sh)

# TARGET_CC/TARGET_CXX are executed directly by Theos' compile recipes. Some
# ZIP-based repository imports and CI checkout paths do not preserve the Git
# executable bit, even though the wrapper contents are valid shell scripts.
# Restore the required mode at Makefile-parse time, before Theos can launch the
# compiler. Do not rely on archive metadata or a manual chmod in CI YAML.
XCODE_CLANG_WRAPPER_PERMISSIONS := $(shell chmod 755 "$(XCODE_CLANG_WRAPPER)" "$(XCODE_CLANGXX_WRAPPER)" 2>/dev/null && printf 'ok')
ifneq ($(XCODE_CLANG_WRAPPER_PERMISSIONS),ok)
$(error Could not make the Xcode Clang wrappers executable: $(XCODE_CLANG_WRAPPER), $(XCODE_CLANGXX_WRAPPER))
endif

export TS_XCODE_CLANG := $(XCODE_DEFAULT_CLANG)
export TS_XCODE_CLANGXX := $(XCODE_DEFAULT_CLANGXX)
export TS_XCODE_CLANG_RESOURCE_DIR := $(XCODE_DEFAULT_CLANG_RESOURCE_DIR)

# Re-assign AFTER common.mk has loaded rc.mk and target-specific defaults. The
# wrapper also forces the matching resource directory and strips injected
# Swift.org clang/include search paths from final compiler argv.
override TARGET_CC := $(XCODE_CLANG_WRAPPER)
override TARGET_CXX := $(XCODE_CLANGXX_WRAPPER)
override TARGET_LD := $(XCODE_CLANGXX_WRAPPER)
export TARGET_CC TARGET_CXX TARGET_LD

# Avoid reusing PCM files produced by another Xcode/Clang toolchain from a CI
# cache. This is separate from SwiftPM's cache and does not disable modules.
override MODULESFLAGS += -fmodules-cache-path=$(THEOS_PROJECT_DIR)/.theos/module-cache/xcode-$(XCODE_DEFAULT_CLANG_VERSION)
