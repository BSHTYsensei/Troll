# Keep Theos C/Objective-C compilation on the active Xcode default toolchain.
# Swift.org toolchains are intentionally used only through TARGET_SWIFTC.
include $(dir $(lastword $(MAKEFILE_LIST)))clang-include-env.mk
XCODE_DEVELOPER_DIR ?= $(if $(DEVELOPER_DIR),$(DEVELOPER_DIR),$(shell xcode-select -p 2>/dev/null))
ifeq ($(strip $(XCODE_DEVELOPER_DIR)),)
$(error xcode-select could not locate the active Xcode Developer directory)
endif

XCODE_DEFAULT_TOOLCHAIN_BIN := $(XCODE_DEVELOPER_DIR)/Toolchains/XcodeDefault.xctoolchain/usr/bin
XCODE_DEFAULT_CLANG := $(XCODE_DEFAULT_TOOLCHAIN_BIN)/clang
XCODE_DEFAULT_CLANGXX := $(XCODE_DEFAULT_TOOLCHAIN_BIN)/clang++

ifeq ($(wildcard $(XCODE_DEFAULT_CLANG)),)
$(error Xcode default clang was not found at $(XCODE_DEFAULT_CLANG))
endif
ifeq ($(wildcard $(XCODE_DEFAULT_CLANGXX)),)
$(error Xcode default clang++ was not found at $(XCODE_DEFAULT_CLANGXX))
endif

# `override` prevents a PATH/toolchain environment override from injecting the
# Swift.org toolchain's bundled Clang into Objective-C and C compilation.
override TARGET_CC := $(XCODE_DEFAULT_CLANG)
override TARGET_CXX := $(XCODE_DEFAULT_CLANGXX)
export TARGET_CC TARGET_CXX
