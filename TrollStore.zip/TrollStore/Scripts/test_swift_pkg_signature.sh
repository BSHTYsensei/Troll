#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/swift_pkg_signature.sh"

signer='1. Developer ID Installer: Swift Open Source (V9AUD2URP3)'
make_output() {
    printf 'Package "swift.pkg":\nStatus: %s\nCertificate Chain:\n%s\n' "$1" "$2"
}
check_ok() {
    if ! verify_swift_pkg_signature_output "$1"; then
        printf '%s\n' "$1" >&2
        echo "expected valid pkg signature output" >&2
        exit 1
    fi
}
check_bad() {
    if verify_swift_pkg_signature_output "$1"; then
        printf '%s\n' "$1" >&2
        echo "unexpectedly accepted invalid pkg signature output" >&2
        exit 1
    fi
}

check_ok "$(make_output 'signed by a certificate trusted by Mac OS X' "$signer")"
check_ok "$(make_output 'signed by a developer certificate issued by Apple for distribution' "$signer")"
check_ok "$(make_output 'signed by a certificate trusted by macOS' "$signer")"
check_bad "$(make_output 'no signature' "$signer")"
check_bad "$(make_output 'revoked signature' "$signer")"
check_bad "$(make_output 'signed by a developer certificate issued by Apple for distribution' '1. Developer ID Installer: Someone Else (AAAAAAAAAA)')"
check_bad "$(make_output 'signed by a certificate that is not trusted' "$signer")"
echo "Swift package signature parser tests passed (3 accepted statuses, 4 rejected cases)."
