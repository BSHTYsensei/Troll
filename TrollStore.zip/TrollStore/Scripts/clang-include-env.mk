# Do not let another Clang distribution inject its private headers into this
# project's C, Objective-C, or C++ compiler invocations. Project-owned include
# directories must be expressed with the appropriate Theos *_CFLAGS (-I...),
# not process-global Clang environment variables.
#
# Swift.org's macOS toolchain contains a partial compatibility directory at
# usr/lib/swift/clang/include. Its stdatomic.h may shadow Xcode's builtin
# stdatomic.h and then fail to locate companion headers such as
# __stddef_max_align_t.h. Clang explicitly honors the five include variables;
# its driver also supports environment-based argument/config overrides.
unexport CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH OBJC_INCLUDE_PATH OBJCPLUS_INCLUDE_PATH
unexport CCC_OVERRIDE_OPTIONS CLANG_CONFIG_FILE_USER_DIR CLANG_CONFIG_FILE_SYSTEM_DIR
