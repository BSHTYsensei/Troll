#!/usr/bin/env bash
# Invoke the active Xcode Clang while rejecting leaked Swift.org Clang resources.
# The Swift 5.8.1 toolchain is used only by TARGET_SWIFTC, never by ObjC/C/C++.
set -euo pipefail

mode="${1:-cc}"
shift || true

case "$mode" in
    cc)
        compiler="${TS_XCODE_CLANG:-}"
        ;;
    cxx)
        compiler="${TS_XCODE_CLANGXX:-}"
        ;;
    *)
        echo "error: unknown Xcode Clang wrapper mode: $mode" >&2
        exit 64
        ;;
esac

if [[ -z "$compiler" ]]; then
    developer_dir="${DEVELOPER_DIR:-$(xcode-select -p 2>/dev/null || true)}"
    [[ -n "$developer_dir" ]] || {
        echo "error: cannot resolve the active Xcode Developer directory" >&2
        exit 69
    }
    case "$mode" in
        cc) compiler="$developer_dir/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang" ;;
        cxx) compiler="$developer_dir/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang++" ;;
    esac
fi

[[ -x "$compiler" ]] || {
    echo "error: Xcode Clang executable is missing or not executable: $compiler" >&2
    exit 69
}

# Clear environment overrides before asking the compiler to report its
# resource directory; these variables can affect driver behavior too.
unset CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH OBJC_INCLUDE_PATH OBJCPLUS_INCLUDE_PATH
unset CCC_OVERRIDE_OPTIONS CLANG_CONFIG_FILE_USER_DIR CLANG_CONFIG_FILE_SYSTEM_DIR

resource_dir="${TS_XCODE_CLANG_RESOURCE_DIR:-$([[ -x "$compiler" ]] && "$compiler" -print-resource-dir 2>/dev/null || true)}"
[[ -n "$resource_dir" && -f "$resource_dir/include/stdatomic.h" && -f "$resource_dir/include/__stddef_max_align_t.h" ]] || {
    echo "error: Xcode Clang builtin headers are incomplete under: ${resource_dir:-<unresolved>}" >&2
    exit 69
}

# Do not inherit global search paths or config overrides from a separately
# installed Swift.org toolchain. Project-owned include paths are passed by
# Theos as explicit -I flags and remain untouched unless they point into the
# Swift.org Clang resource tree.
is_swift_clang_resource() {
    # Clang may print/use the Swift toolchain resource path through the
    # executable-relative spelling `usr/bin/../lib/...` rather than the
    # normalized `usr/lib/...` spelling. Bash's `*` also matches `/`, so the
    # middle component intentionally accepts both spellings (and equivalent
    # relative layouts) without canonicalizing a possibly not-yet-existing
    # path.
    case "${1:-}" in
        *"/Toolchains/swift-"*".xctoolchain/"*"/lib/swift/clang"*)
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}

is_swift_clang_option() {
    local option="${1:-}" candidate=""
    case "$option" in
        -fmodule-map-file=*) candidate="${option#-fmodule-map-file=}" ;;
        -fmodule-file=*) candidate="${option#-fmodule-file=}" ;;
        -isystem*) candidate="${option#-isystem}" ;;
        -idirafter*) candidate="${option#-idirafter}" ;;
        -iquote*) candidate="${option#-iquote}" ;;
        -iframework*) candidate="${option#-iframework}" ;;
        -I?*) candidate="${option#-I}" ;;
        -F?*) candidate="${option#-F}" ;;
        *) ;;
    esac
    [[ -n "$candidate" ]] && is_swift_clang_resource "$candidate"
}

filtered=()
removed=0
while (($#)); do
    arg="$1"
    shift

    # Always discard caller-selected resource directories. The final explicit
    # -resource-dir below is taken from the selected Xcode Clang executable.
    if [[ "$arg" == "-resource-dir" ]]; then
        (($#)) && shift
        removed=$((removed + 1))
        continue
    elif [[ "$arg" == -resource-dir=* ]]; then
        removed=$((removed + 1))
        continue
    fi

    # These options take their path as the next argument.
    case "$arg" in
        -I|-isystem|-iquote|-idirafter|-F|-iframework|-fmodule-map-file|-include|-imacros)
            if (($#)); then
                next="$1"
                if is_swift_clang_resource "$next" || is_swift_clang_option "$next"; then
                    shift
                    removed=$((removed + 1))
                    continue
                fi
                filtered+=("$arg" "$next")
                shift
                continue
            fi
            filtered+=("$arg")
            continue
            ;;
        -Xclang)
            if (($#)); then
                next="$1"
                if [[ "$next" == "-resource-dir" ]]; then
                    shift
                    if [[ "${1:-}" == "-Xclang" ]]; then
                        shift
                    fi
                    (($#)) && shift
                    removed=$((removed + 1))
                    continue
                fi
                if is_swift_clang_resource "$next"; then
                    shift
                    removed=$((removed + 1))
                    continue
                fi
                filtered+=("$arg" "$next")
                shift
                continue
            fi
            filtered+=("$arg")
            continue
            ;;
    esac

    # Handle joined path options such as -I/path, -isystem/path and
    # -fmodule-map-file=/path/module.modulemap.
    candidate=""
    case "$arg" in
        -fmodule-map-file=*) candidate="${arg#-fmodule-map-file=}" ;;
        -isystem*) candidate="${arg#-isystem}" ;;
        -idirafter*) candidate="${arg#-idirafter}" ;;
        -iquote*) candidate="${arg#-iquote}" ;;
        -iframework*) candidate="${arg#-iframework}" ;;
        -I?*) candidate="${arg#-I}" ;;
        -F?*) candidate="${arg#-F}" ;;
        *) ;;
    esac
    if [[ -n "$candidate" ]] && is_swift_clang_resource "$candidate"; then
        removed=$((removed + 1))
        continue
    fi
    if is_swift_clang_resource "$arg"; then
        removed=$((removed + 1))
        continue
    fi
    filtered+=("$arg")
done

if [[ "${TS_CLANG_WRAPPER_DIAGNOSTICS:-0}" == "1" ]]; then
    printf '[toolchain] %s -> %s\n' "$mode" "$compiler" >&2
    printf '[toolchain] forced Clang resource directory: %s\n' "$resource_dir" >&2
    if ((removed)); then
        printf '[toolchain] removed %d Swift.org Clang resource argument(s)\n' "$removed" >&2
    fi
fi

# The final resource-dir wins over any earlier flag and ensures the builtin
# stdatomic/stddef headers come from the same compiler distribution.
exec "$compiler" "${filtered[@]}" -resource-dir "$resource_dir"
