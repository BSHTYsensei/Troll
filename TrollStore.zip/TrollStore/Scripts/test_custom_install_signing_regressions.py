#!/usr/bin/env python3
"""Source-level regression tests for the custom installer/signing fixes."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

def read(rel: str) -> str:
    path = ROOT / rel
    if not path.is_file():
        raise SystemExit(f"[FAIL] missing source: {rel}")
    return path.read_text(errors="replace")

def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(f"[FAIL] {message}")
    print(f"[OK] {message}")

root_helper = read("RootHelper/main.m")
signing = read("TrollStore/TSSigningManager.m")
picker = read("TrollStore/TSSigningSettingsController.m")
package_ui = read("TrollStore/TSIPAPackageStore.m")
error_map = read("TrollStore/TSApplicationsManager.m")
ldid = (ROOT.parent / "ldid" / "ldid" / "ldid.cpp")

require("![canonicalBundle isEqualToString:canonicalRoot]" in root_helper and
        "pathIsWithinDirectory(canonicalBundle, canonicalRoot)" in root_helper,
        "executable path validation accepts the top-level app bundle and nested bundles")
require("return 196;" in root_helper and
        "signingIdentityErrorCodeForLdidOutput" in root_helper and
        "return 197;" in root_helper and "return 198;" in root_helper and
        "case 196:" in error_map and "case 197:" in error_map and "case 198:" in error_map,
        "unsafe executable paths, mismatched identities, and encrypted-key passwords use distinct error codes")
require("canonicalExistingPath(candidate)" in root_helper and
        "pathIsWithinDirectory(resolved, canonicalRoot)" in root_helper and
        "stat(resolvedTarget, &targetStat) != 0 || !S_ISREG(targetStat.st_mode)" in root_helper and
        "!S_ISLNK(entryStat.st_mode) && !pathIsWithinDirectory(resolved, canonicalBundle)" in root_helper,
        "nested executable symlinks must resolve inside staged app while normal executables stay in their bundle")
require('appProxy.bundleURL.path' in root_helper and 'info[@"CFBundleExecutable"]' in root_helper and
        'appProxy.bundleType isEqualToString:@"System"' in root_helper,
        "persistence helper selects a verified system host using its own Info.plist")
require("moveItemAtPath:executablePath toPath:backupPath" in root_helper and
        "restoreError" in root_helper and "goto rollback" in root_helper,
        "persistence-helper replacement preserves a recoverable original executable")
require("TSPersistenceHostExecutableEntryPath(systemAppProxy, YES, &bundlePath)" in root_helper and
        "[uninstallPersistenceHelper] invalid host bundle/executable directory entry" in root_helper,
        "persistence-helper uninstall resolves and restores the original executable directory entry safely")
require("chown(stagedExecutable.fileSystemRepresentation, 33, 33)" in root_helper and
        "chown(stagedRootHelper.fileSystemRepresentation, 0, 0)" in root_helper and
        "chmod(stagedExecutable.fileSystemRepresentation, 0755)" in root_helper,
        "persistence helper and root helper receive their required ownership and executable modes")

require('SecPKCS12Import' in signing and 'errSecAuthFailed' in signing and
        'P12 password is incorrect' in signing,
        "P12 import distinguishes an incorrect password from damaged input")
require('TSDERFromPEM(certificateData)' in signing and 'TSPemFromDER(der)' in signing,
        "PEM import normalizes both PEM and DER X.509 certificates")
require('\\uFEFF' in signing and 'stringByReplacingOccurrencesOfString:@"\\r\\n"' in signing and
        'ENCRYPTED PRIVATE KEY' in signing and 'RSA PRIVATE KEY' in signing,
        "PEM parser accepts BOM/Windows line endings and common encrypted/traditional key labels")
require('public.item' in picker and 'public.data' in picker and
        'NSFileCoordinator' in picker and 'dataWithContentsOfURL:url' in picker,
        "document importer accepts generic File Provider UTTypes and has a bounded direct-read fallback")
require('TSSigningError(3' in signing and 'neither a valid X.509 PEM certificate nor a DER certificate' in signing,
        "malformed certificate and missing key blocks report a specific import error")

if ldid.is_file():
    ldid_text = ldid.read_text(errors="replace")
    require('PKCS12_parse' in ldid_text and 'PEM_read_bio_PrivateKey' in ldid_text and
            'X509_check_private_key' in ldid_text,
            "ldid parses P12/PEM identities and verifies certificate/private-key correspondence")
else:
    print("[INFO] separate ldid source is not bundled; runtime ldid checks remain in ldid.zip")

require('TSIPAPackageCell' in package_ui and 'numberOfLines = 2' in package_ui and
        'NSLineBreakByTruncatingMiddle' in package_ui and 'constraintEqualToAnchor:labels.trailingAnchor' not in package_ui,
        "package list uses a constrained custom two-line cell instead of clipped default labels")
print("[PASS] custom helper, signing import, file provider, and UI regression checks completed")
