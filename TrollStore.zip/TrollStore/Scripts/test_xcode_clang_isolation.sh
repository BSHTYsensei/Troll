#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/trollstore-xcode-clang-test.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT

DEVELOPER="$TMP/Developer"
BIN="$TMP/bin"
mkdir -p "$DEVELOPER/Toolchains/XcodeDefault.xctoolchain/usr/bin" "$BIN"
for tool in clang clang++; do
    cat > "$DEVELOPER/Toolchains/XcodeDefault.xctoolchain/usr/bin/$tool" <<'TOOL'
#!/usr/bin/env bash
exit 0
TOOL
    chmod +x "$DEVELOPER/Toolchains/XcodeDefault.xctoolchain/usr/bin/$tool"
done
cat > "$BIN/xcode-select" <<'XCODE_SELECT'
#!/usr/bin/env bash
[[ "${1:-}" == "-p" ]] || exit 2
printf '%s\n' "$MOCK_XCODE_DEVELOPER_DIR"
XCODE_SELECT
chmod +x "$BIN/xcode-select"

output="$(
    PATH="$BIN:$PATH" \
    MOCK_XCODE_DEVELOPER_DIR="$DEVELOPER" \
    TARGET_CC="/Users/runner/Library/Developer/Toolchains/swift-5.8.1-RELEASE.xctoolchain/usr/bin/clang" \
    TARGET_CXX="/Users/runner/Library/Developer/Toolchains/swift-5.8.1-RELEASE.xctoolchain/usr/bin/clang++" \
    make --no-print-directory -f "$ROOT/Scripts/xcode-clang.mk" -f - print-clang <<'MAKEFILE'
print-clang:
	@printf '%s\n%s\n' "$(TARGET_CC)" "$(TARGET_CXX)"
MAKEFILE
)"
expected_clang="$DEVELOPER/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang"
expected_clangxx="$DEVELOPER/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang++"
[[ "$output" == "$expected_clang"$'\n'"$expected_clangxx" ]] || {
    printf 'error: target clang was not isolated from Swift toolchain\nexpected:\n%s\nactual:\n%s\n' \
        "$expected_clang"$'\n'"$expected_clangxx" "$output" >&2
    exit 1
}
echo "[test] Theos TARGET_CC/TARGET_CXX override resolves to XcodeDefault, even when the Swift toolchain is first in the environment"
