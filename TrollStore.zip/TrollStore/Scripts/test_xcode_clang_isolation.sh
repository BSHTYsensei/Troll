#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/trollstore-xcode-clang-test.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT

DEVELOPER="$TMP/Developer"
BIN="$TMP/bin"
SWIFT_CLANG_INCLUDE="$TMP/swift-5.8.1-RELEASE.xctoolchain/usr/lib/swift/clang/include"
mkdir -p "$DEVELOPER/Toolchains/XcodeDefault.xctoolchain/usr/bin" "$BIN" "$SWIFT_CLANG_INCLUDE"
for tool in clang clang++; do
    cat > "$DEVELOPER/Toolchains/XcodeDefault.xctoolchain/usr/bin/$tool" <<'TOOL'
#!/usr/bin/env bash
exit 0
TOOL
    chmod +x "$DEVELOPER/Toolchains/XcodeDefault.xctoolchain/usr/bin/$tool"
done
cat > "$BIN/xcode-select" <<'XCODE_SELECT'
#!/usr/bin/env bash
[[ "${1:-}" == "-p" ]] || exit 2
printf '%s\n' "$MOCK_XCODE_DEVELOPER_DIR"
XCODE_SELECT
chmod +x "$BIN/xcode-select"

output="$(
    PATH="$BIN:$PATH" \
    MOCK_XCODE_DEVELOPER_DIR="$DEVELOPER" \
    TARGET_CC="/Users/runner/Library/Developer/Toolchains/swift-5.8.1-RELEASE.xctoolchain/usr/bin/clang" \
    TARGET_CXX="/Users/runner/Library/Developer/Toolchains/swift-5.8.1-RELEASE.xctoolchain/usr/bin/clang++" \
    CPATH="$SWIFT_CLANG_INCLUDE" \
    C_INCLUDE_PATH="$SWIFT_CLANG_INCLUDE" \
    CPLUS_INCLUDE_PATH="$SWIFT_CLANG_INCLUDE" \
    OBJC_INCLUDE_PATH="$SWIFT_CLANG_INCLUDE" \
    OBJCPLUS_INCLUDE_PATH="$SWIFT_CLANG_INCLUDE" \
    make --no-print-directory -f "$ROOT/Scripts/xcode-clang.mk" -f - print-clang <<'MAKEFILE'
print-clang:
	@printf '%s\n%s\n' "$(TARGET_CC)" "$(TARGET_CXX)"
	@for name in CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH OBJC_INCLUDE_PATH OBJCPLUS_INCLUDE_PATH; do \
	  if printenv "$$name" >/dev/null 2>&1; then echo "error: $$name leaked into compiler environment"; exit 1; fi; \
	done
MAKEFILE
)"
expected_clang="$DEVELOPER/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang"
expected_clangxx="$DEVELOPER/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang++"
[[ "$output" == "$expected_clang"$'\n'"$expected_clangxx" ]] || {
    printf 'error: target clang was not isolated from Swift toolchain\nexpected:\n%s\nactual:\n%s\n' \
        "$expected_clang"$'\n'"$expected_clangxx" "$output" >&2
    exit 1
}
echo "[test] Theos TARGET_CC/TARGET_CXX resolve to XcodeDefault and Swift.org Clang include environment variables do not leak into compiler recipes"
