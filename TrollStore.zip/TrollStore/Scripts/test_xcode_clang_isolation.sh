#!/usr/bin/env bash
# Regression test the final compiler executable and its real argument vector.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/trollstore-xcode-clang-test.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT

DEVELOPER="$TMP/Developer"
RESOURCE="$TMP/xcode-resource"
SWIFT_TOOLCHAIN="$TMP/Library/Developer/Toolchains/swift-5.8.1-RELEASE.xctoolchain"
# Reproduce the exact lexical spelling in the user's CI error:
# usr/bin/../lib/swift/clang/include/stdatomic.h
SWIFT_RESOURCE="$SWIFT_TOOLCHAIN/usr/bin/../lib/swift/clang"
GOOD_INCLUDE="$TMP/project-include"
BIN="$TMP/bin"
mkdir -p "$DEVELOPER/Toolchains/XcodeDefault.xctoolchain/usr/bin" \
    "$RESOURCE/include" "$SWIFT_TOOLCHAIN/usr/bin" \
    "$SWIFT_TOOLCHAIN/usr/lib/swift/clang/include" "$GOOD_INCLUDE" "$BIN"
touch "$RESOURCE/include/stdatomic.h" "$RESOURCE/include/__stddef_max_align_t.h"
touch "$SWIFT_RESOURCE/include/stdatomic.h" "$GOOD_INCLUDE/project-header.h"
printf 'module SwiftBad { header "stdatomic.h" }\n' > "$SWIFT_RESOURCE/include/module.modulemap"

cat > "$DEVELOPER/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang" <<'CLANG'
#!/usr/bin/env bash
set -euo pipefail
if [[ "${1:-}" == "-print-resource-dir" ]]; then
    printf '%s\n' "$MOCK_XCODE_RESOURCE"
    exit 0
fi
if [[ "${1:-}" == "--version" ]]; then
    echo 'Apple clang version 16.0.0 (mock regression test)'
    exit 0
fi
printf '%s\n' "$@" > "$MOCK_CLANG_ARGS"
env | sort > "$MOCK_CLANG_ENV"
printf 'cc\n' > "$MOCK_CLANG_USED"
CLANG
cat > "$DEVELOPER/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang++" <<'CLANGXX'
#!/usr/bin/env bash
set -euo pipefail
if [[ "${1:-}" == "-print-resource-dir" ]]; then
    printf '%s\n' "$MOCK_XCODE_RESOURCE"
    exit 0
fi
if [[ "${1:-}" == "--version" ]]; then
    echo 'Apple clang version 16.0.0 (mock regression test)'
    exit 0
fi
printf '%s\n' "$@" > "$MOCK_CLANGXX_ARGS"
env | sort > "$MOCK_CLANGXX_ENV"
printf 'cxx\n' > "$MOCK_CLANG_USED"
CLANGXX
chmod 755 "$DEVELOPER/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang" \
    "$DEVELOPER/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang++"

# Simulate a toolchain/rc.mk override being loaded by common.mk. The project
# fragment must be applied after common.mk to establish the final compiler.
cat > "$TMP/fake-common.mk" <<'MAKECOMMON'
override TARGET_CC := /injected/swift-5.8.1-RELEASE.xctoolchain/usr/bin/clang
override TARGET_CXX := /injected/swift-5.8.1-RELEASE.xctoolchain/usr/bin/clang++
override TARGET_LD := /injected/swift-5.8.1-RELEASE.xctoolchain/usr/bin/clang++
MAKECOMMON
cat > "$TMP/test.mk.in" <<'MAKEFILE'
include __TMP__/fake-common.mk
include __ROOT__/Scripts/xcode-clang.mk
GOOD_INCLUDE := __GOOD_INCLUDE__
SWIFT_RESOURCE := __SWIFT_RESOURCE__
.PHONY: test
test:
	@printf '%s\n%s\n%s\n' "$(TARGET_CC)" "$(TARGET_CXX)" "$(TARGET_LD)"
	@"$(TARGET_CC)" -fsyntax-only -I"$(GOOD_INCLUDE)" -I"$(SWIFT_RESOURCE)/include" -isystem "$(SWIFT_RESOURCE)/include" -resource-dir "$(SWIFT_RESOURCE)" -fmodule-map-file="$(SWIFT_RESOURCE)/include/module.modulemap" -Xclang "-fmodule-map-file=$(SWIFT_RESOURCE)/include/module.modulemap" mock.m
	@"$(TARGET_CXX)" -fsyntax-only -I"$(GOOD_INCLUDE)" -resource-dir "$(SWIFT_RESOURCE)" mock.cc
MAKEFILE
sed -e "s|__TMP__|$TMP|g" \
    -e "s|__ROOT__|$ROOT|g" \
    -e "s|__GOOD_INCLUDE__|$GOOD_INCLUDE|g" \
    -e "s|__SWIFT_RESOURCE__|$SWIFT_RESOURCE|g" \
    "$TMP/test.mk.in" > "$TMP/test.mk"

export DEVELOPER_DIR="$DEVELOPER"
export MOCK_XCODE_RESOURCE="$RESOURCE"
export MOCK_CLANG_ARGS="$TMP/clang.args"
export MOCK_CLANG_ENV="$TMP/clang.env"
export MOCK_CLANGXX_ARGS="$TMP/clangxx.args"
export MOCK_CLANGXX_ENV="$TMP/clangxx.env"
export MOCK_CLANG_USED="$TMP/compiler-used"
export CPATH="$SWIFT_RESOURCE/include"
export C_INCLUDE_PATH="$SWIFT_RESOURCE/include"
export CPLUS_INCLUDE_PATH="$SWIFT_RESOURCE/include"
export OBJC_INCLUDE_PATH="$SWIFT_RESOURCE/include"
export OBJCPLUS_INCLUDE_PATH="$SWIFT_RESOURCE/include"
export CCC_OVERRIDE_OPTIONS='^/resource-dir=/injected/swift/resource'
export CLANG_CONFIG_FILE_USER_DIR="$SWIFT_RESOURCE/config"
export CLANG_CONFIG_FILE_SYSTEM_DIR="$SWIFT_RESOURCE/system-config"

output="$(MOCK_XCODE_RESOURCE="$RESOURCE" make --no-print-directory -f "$TMP/test.mk" test)"
expected_cc="$ROOT/Scripts/xcode-clang-wrapper.sh"
expected_cxx="$ROOT/Scripts/xcode-clangxx-wrapper.sh"
expected_output="$expected_cc"$'\n'"$expected_cxx"$'\n'"$expected_cxx"
[[ "$output" == "$expected_output" ]] || {
    printf 'error: post-common.mk compiler pin failed\nexpected:\n%s\nactual:\n%s\n' "$expected_output" "$output" >&2
    exit 1
}
[[ "$(cat "$MOCK_CLANG_USED")" == cxx ]] || { echo 'error: C++ wrapper did not invoke Xcode clang++' >&2; exit 1; }

grep -Fx -- "-resource-dir" "$MOCK_CLANG_ARGS" >/dev/null || { echo 'error: Xcode resource-dir was not forced for C compile' >&2; exit 1; }
grep -Fx -- "$RESOURCE" "$MOCK_CLANG_ARGS" >/dev/null || { echo 'error: wrong resource-dir for C compile' >&2; exit 1; }
grep -Fx -- "-I$GOOD_INCLUDE" "$MOCK_CLANG_ARGS" >/dev/null || { echo 'error: valid project include path was dropped' >&2; exit 1; }
if grep -F "$SWIFT_RESOURCE" "$MOCK_CLANG_ARGS" "$MOCK_CLANGXX_ARGS"; then
    echo 'error: Swift.org Clang resource path leaked into compiler argv' >&2
    exit 1
fi
for env_file in "$MOCK_CLANG_ENV" "$MOCK_CLANGXX_ENV"; do
    for name in CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH OBJC_INCLUDE_PATH OBJCPLUS_INCLUDE_PATH; do
        if grep -q "^${name}=" "$env_file"; then
            echo "error: $name leaked into compiler environment" >&2
            exit 1
        fi
    done
    for name in CCC_OVERRIDE_OPTIONS CLANG_CONFIG_FILE_USER_DIR CLANG_CONFIG_FILE_SYSTEM_DIR; do
        if grep -q "^${name}=" "$env_file"; then
            echo "error: $name leaked into compiler environment" >&2
            exit 1
        fi
    done
done

echo '[test] final post-Theos compiler pin, resource-dir override, Swift include filtering, and compiler environment isolation passed'
