#!/usr/bin/env bash
# Signature parser for Swift.org macOS .pkg files.
# pkgutil changed its positive Status wording across macOS releases. Accept only
# known successful Apple trust states and the exact Swift Open Source signer.

SWIFT_EXPECTED_PKG_SIGNER="Developer ID Installer: Swift Open Source (V9AUD2URP3)"

verify_swift_pkg_signature_output() {
    local output="${1:-}"
    local status

    [[ -n "$output" ]] || return 1
    printf '%s\n' "$output" | grep -Fq "$SWIFT_EXPECTED_PKG_SIGNER" || return 1

    status="$(printf '%s\n' "$output" | awk -F: '/^[[:space:]]*Status:/ {sub(/^[[:space:]]*/, "", $2); print tolower($2); exit}')"
    case "$status" in
        "signed by a certificate trusted by mac os x"|\
        "signed by a certificate trusted by macos"|\
        "signed by a developer certificate issued by apple for distribution")
            return 0
            ;;
        *)
            return 1
            ;;
    esac
}
