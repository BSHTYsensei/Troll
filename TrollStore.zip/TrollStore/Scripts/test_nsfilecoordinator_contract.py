#!/usr/bin/env python3
"""Guard NSFileCoordinator's void-returning accessor API usage."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent.parent
SOURCES = {
    "package import": ROOT / "TrollStore/TSIPAPackageStore.m",
    "signing-file import": ROOT / "TrollStore/TSSigningSettingsController.m",
}

for label, path in SOURCES.items():
    if not path.is_file():
        raise SystemExit(f"error: missing {label} source: {path}")
    source = path.read_text(encoding="utf-8")
    calls = source.count("coordinateReadingItemAtURL:")
    if calls != 1:
        raise SystemExit(f"error: expected exactly one coordinated read in {path.name}, found {calls}")
    if re.search(r"\bBOOL\s+\w+\s*=\s*\[\s*coordinator\s+coordinateReadingItemAtURL:", source):
        raise SystemExit(f"error: {path.name} assigns the void coordination method to BOOL")
    if re.search(r"\bBOOL\s+coordinated\s*=|!\s*coordinated\b", source):
        raise SystemExit(f"error: {path.name} still relies on a nonexistent coordination return value")

package_source = SOURCES["package import"].read_text(encoding="utf-8")
if "if (!copied)" not in package_source or "error:&copyError byAccessor:" not in package_source:
    raise SystemExit("error: package import must report coordinator/copy failure using copyError and copied")

signing_source = SOURCES["signing-file import"].read_text(encoding="utf-8")
if "if (!data.length && url.isFileURL)" not in signing_source:
    raise SystemExit("error: signing import must use bounded direct-read fallback when coordinated read yields no data")
if "fileStat.st_size <= 64LL * 1024LL * 1024LL" not in signing_source:
    raise SystemExit("error: signing import direct-read fallback lost its 64 MiB file-size limit")
if "S_ISREG(fileStat.st_mode)" not in signing_source:
    raise SystemExit("error: signing import direct-read fallback must reject non-regular files")

print("NSFileCoordinator API contract checks passed")
