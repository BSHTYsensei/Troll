#!/usr/bin/env python3
"""Static integrity checks for the restored original TrollStore UI + zh-Hans build."""
from pathlib import Path
import hashlib
import json
import plistlib
import re
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
PINNED_CHOMA = "964023ddac2286ef8e843f90df64d44ac6a673df"
REQUIRED = [
    "Makefile", "CHOMA-COMMIT.txt", ".gitmodules", "README.md",
    "TrollStore/Makefile", "TrollStore/main.m", "TrollStore/TSRootViewController.m",
    "TrollStore/TSAppTableViewController.m", "TrollStore/TSAppInfo.m",
    "TrollStore/TSApplicationsManager.m", "TrollStore/TSInstallationController.m",
    "TrollStore/TSSettingsListController.m", "TrollStore/TSSettingsAdvancedListController.m",
    "TrollStore/TSEntitlementsEditorViewController.h", "TrollStore/TSEntitlementsEditorViewController.m", "TrollStore/entitlements.plist",
    "TrollStore/Resources/Info.plist",
    "TrollStore/Resources/zh-Hans.lproj/Localizable.strings",
    "TrollStore/Resources/zh-Hans.lproj/InfoPlist.strings",
    "RootHelper/Makefile", "RootHelper/main.m", "RootHelper/entitlements.plist",
    "TrollHelper/Makefile", "TrollHelper/main.m", "TrollHelper/TSHRootViewController.m",
    "TrollHelper/Resources/Info.plist", "TrollHelper/entitlements.plist",
    "TrollHelper/Resources/zh-Hans.lproj/Localizable.strings",
    "TrollHelper/Resources/zh-Hans.lproj/InfoPlist.strings",
    "Shared/TSUtil.h", "Shared/TSUtil.m", "Shared/TSListControllerShared.m",
    "Shared/TSPresentationDelegate.m", "Exploits/fastPathSign/Makefile",
    "Exploits/fastPathSign/src/coretrust_bug.c", "Exploits/fastPathSign/src/codesign.m",
    "Scripts/bootstrap_choma.sh", "Scripts/clang-include-env.mk", "Scripts/test_fastpath_host_sdk.sh", "Scripts/test_theos_only_build.sh", "Scripts/bootstrap_theos_swift_support.sh", "Scripts/test_swift_support_bootstrap.sh", "Scripts/bootstrap_swift_5_8_toolchain.sh", "Scripts/swift_pkg_signature.sh", "Scripts/test_swift_pkg_signature.sh", "Scripts/validate_choma_api.py", "Scripts/validate_macho.py",
    "Scripts/validate_project.py", "Scripts/test_nsfilecoordinator_contract.py", "Scripts/validate_macho_signature.py", "Scripts/find_signed_theos_binary.py", "Scripts/fastpath_sign_all_slices.py", "Scripts/test_fastpath_sign_pipeline.py", "bin/ldid", "bin/ldid.sha256",
    "TrollStore/TSAppRepackager.m", "TrollStore/TSArchiveExtractor.m",
    "TrollStore/TSIPAPackageStore.m", "TrollStore/TSAppDecryptor.m",
    "TrollStore/TSTweakInjector.m", "TrollStore/TSAppCollectionViewController.m",
    "TrollStore/TSThemeManager.m",
    "TrollStore/TSAppRepackager.h", "TrollStore/TSArchiveExtractor.h", "TrollStore/TSIPAPackageStore.h",
    "TrollStore/TSAppDecryptor.h", "TrollStore/TSTweakInjector.h", "TrollStore/TSAppCollectionViewController.h",
    "TrollStore/TSThemeManager.h",
    "TrollStore/TSChoiceListController.h", "TrollStore/TSChoiceListController.m",
    "TrollStore/TSSigningManager.h", "TrollStore/TSSigningManager.m",
    "TrollStore/TSSigningSettingsController.h", "TrollStore/TSSigningSettingsController.m",
    "TrollStore/Resources/SigningTemplates/apple-internal-profile-template.json",
    "APPLE-INTERNAL-DEVELOPMENT-TEMPLATE-2026-11-09-zh-Hans.md",
    "TrollStore/Resources/SigningTemplates/apple-internal-profile-template.json",
    "APPLE-INTERNAL-DEVELOPMENT-TEMPLATE-2026-11-09-zh-Hans.md",
    "CODEDIRECTORY-FLAGS-zh-Hans.md", "TrollStore/TSRefreshAppRegistrationsIntent.swift", "TrollStore/TrollStore-Bridging-Header.h",
    "TrollStore/TSRefreshShortcutAction.m", "TrollStore/TSRefreshShortcutController.h", "TrollStore/TSRefreshShortcutController.m",
    "Previews/TrollStore-UI-Video-Reference-Preview-2026-11-01.png",
    "Scripts/package_framework_preset.py", "Scripts/extract_app_intents_metadata.py",
    "RootHelper/TSAppMaintenance.h", "RootHelper/TSAppDecryptor.h",
    "TrollStore/TSAppUpdateManager.h", "TrollStore/TSAppUpdateManager.m",
    "TrollStore/TSBlockedUpdatesController.h", "TrollStore/TSBlockedUpdatesController.m",
    "TrollStore/TSPluginStoreController.h", "TrollStore/TSPluginStoreController.m",
    "RootHelper/TSAppUpdateControl.h", "RootHelper/TSAppUpdateControl.m",

    "RootHelper/TSAppMaintenance.m", "RootHelper/TSAppDecryptor.m",
    "TweakPresets/AppLock/Makefile", "TweakPresets/AppLock/Tweak.m",
    "TweakPresets/BackgroundAssist/Makefile", "TweakPresets/BackgroundAssist/Tweak.m",
    "TweakPresets/README.md",
    "BUILD-FIX-2026-10-31-zh-Hans.md",
    "VIDEO-UI-PLUGIN-UPDATE-LOCK-2026-10-31-zh-Hans.md",
    "CLANG-TOOLCHAIN-ISOLATION-2026-11-01-zh-Hans.md",
    "FASTPATHSIGN-MACOS-SDK-ROOT-FIX-2026-11-02-zh-Hans.md",
    "CLANG-TOOLCHAIN-ISOLATION-2026-11-04-zh-Hans.md",
    "CLANG-TOOLCHAIN-ISOLATION-2026-11-05-zh-Hans.md",
    "SWIFT-ARM64-RUNTIME-LINK-FIX-2026-11-06-zh-Hans.md",
]
missing = [item for item in REQUIRED if not (ROOT / item).is_file()]
if missing:
    raise SystemExit("error: missing required project files: " + ", ".join(missing))

# App Intents require one Swift declaration. Keep the Swift surface intentionally
# narrow so the rest of the app remains Objective-C/C and does not trigger a
# broad Swift migration.
swift_sources = sorted(str(p.relative_to(ROOT)) for p in ROOT.rglob("*.swift"))
if swift_sources != ["TrollStore/TSRefreshAppRegistrationsIntent.swift"]:
    raise SystemExit(f"error: unexpected Swift source set: {swift_sources}")

for rel in ("Makefile", "CHOMA-COMMIT.txt", "Scripts/bootstrap_choma.sh", "Scripts/validate_choma_api.py"):
    if PINNED_CHOMA not in (ROOT / rel).read_text(encoding="utf-8"):
        raise SystemExit(f"error: {rel} does not pin compatible ChOma revision {PINNED_CHOMA}")
root_make = (ROOT / "Makefile").read_text(encoding="utf-8")
helper_make = (ROOT / "TrollHelper/Makefile").read_text(encoding="utf-8")
if "TrollStorePersistenceHelper_FRAMEWORKS = UIKit CoreGraphics CoreServices CoreTelephony Security" not in helper_make:
    raise SystemExit("error: embedded TrollHelper must link Security.framework for RootHelper sources")
if "$(HELPER_NAME)_FRAMEWORKS = CoreTelephony CoreServices Security" not in (ROOT / "RootHelper/Makefile").read_text(encoding="utf-8"):
    raise SystemExit("error: standalone RootHelper must explicitly link CoreServices.framework for LaunchServices update control")
if "$(HELPER_NAME)_LIBRARIES = archive" not in (ROOT / "RootHelper/Makefile").read_text(encoding="utf-8") or "$(HELPER_NAME)_LDFLAGS = -L../ChOma/external/ios -lcrypto" not in (ROOT / "RootHelper/Makefile").read_text(encoding="utf-8"):
    raise SystemExit("error: RootHelper must link ChOma's iOS libcrypto archive using its explicit library search path and -lcrypto linker flag")
root_helper_make = (ROOT / "RootHelper/Makefile").read_text(encoding="utf-8")
root_helper_source_line = next((line for line in root_helper_make.splitlines() if "$(HELPER_NAME)_FILES =" in line), "")
if "../Shared/TSUtil.m" not in root_helper_source_line or "$(wildcard ../Shared/*.m)" in root_helper_source_line or "TSListControllerShared.m" in root_helper_source_line:
    raise SystemExit("error: RootHelper must compile TSUtil only from Shared; UI-only TSListControllerShared.m references TSThemeManager and must not be linked into the helper")
if '$(MAKE) -C ./RootHelper clean THEOS="$(THEOS)"' not in root_make or "Cleaning RootHelper objects" not in root_make:
    raise SystemExit("error: root build must clean RootHelper objects before linking to prevent stale UI-only objects")
shared_list_source = (ROOT / "Shared/TSListControllerShared.m").read_text(encoding="utf-8")
if '#import "../TrollStore/TSThemeManager.h"' in shared_list_source or "[TSThemeManager " in shared_list_source:
    raise SystemExit("error: Shared/TSListControllerShared.m must not statically link the app-only TSThemeManager class")
if 'NSClassFromString(@"TSThemeManager")' not in shared_list_source:
    raise SystemExit("error: shared list controller must dynamically resolve TSThemeManager and fall back in TrollHelper")
if '$(MAKE) -C ./TrollHelper clean THEOS="$(THEOS)"' not in root_make or "Cleaning TrollHelper objects" not in root_make:
    raise SystemExit("error: root build must clean TrollHelper objects before linking to prevent stale shared-controller objects")
app_make = (ROOT / "TrollStore/Makefile").read_text(encoding="utf-8")
if not all(token in root_make for token in (
    "APPLE_DEVELOPER_DIR ?= /Library/Developer/CommandLineTools",
    "APPLE_TOOLCHAIN_BIN ?= $(APPLE_DEVELOPER_DIR)/usr/bin",
    "APPLE_CLANG ?= $(APPLE_TOOLCHAIN_BIN)/clang",
    "APPLE_CLANGXX ?= $(APPLE_TOOLCHAIN_BIN)/clang++",
    "TARGET_CC=\"$(APPLE_CLANG)\"",
    "TARGET_CXX=\"$(APPLE_CLANGXX)\"",
    "override IOS_SDK_VERSION := 16.5",
    "iPhoneOS$(IOS_SDK_VERSION).sdk",
    "HOST_MACOSX_SDKROOT",
    "Swift runtime is disabled",
    "ENABLE_APP_INTENTS ?= 0",
)):
    raise SystemExit("error: root build must use Theos Makefiles, iOS 16.5 SDK and the no-Swift default profile")
if any(token in root_make for token in ("XCODE_DEFAULT_CLANG", "XCODE_SWIFT_RUNTIME_DIR", "xcrun --find swiftc", "xcodebuild", "XcodeDefault.xctoolchain", "xcode-select", "/Applications/Xcode")):
    raise SystemExit("error: active root build still depends on an Xcode Swift runtime or Xcode build command")
for rel in (
    "TrollStore/Makefile", "RootHelper/Makefile", "TrollHelper/Makefile",
    "TweakPresets/AppLock/Makefile", "TweakPresets/BackgroundAssist/Makefile",
):
    project_make = (ROOT / rel).read_text(encoding="utf-8")
    if "Scripts/xcode-clang.mk" in project_make or "XcodeDefault.xctoolchain" in project_make:
        raise SystemExit(f"error: {rel} must not hardcode an Xcode toolchain path")
    if "include $(THEOS)/makefiles/common.mk" not in project_make:
        raise SystemExit(f"error: {rel} must use Theos common.mk")
for marker in (
    '-C ./RootHelper THEOS="$(THEOS)" $(THEOS_TARGET_TOOL_ARGS)',
    '-C ./TrollStore THEOS="$(THEOS)" $(THEOS_TARGET_TOOL_ARGS)',
    '-C ./TrollHelper THEOS="$(THEOS)" $(THEOS_TARGET_TOOL_ARGS)',
    '-C ./TweakPresets/AppLock THEOS="$(THEOS)" $(THEOS_TARGET_TOOL_ARGS)',
    '-C ./TweakPresets/BackgroundAssist THEOS="$(THEOS)" $(THEOS_TARGET_TOOL_ARGS)',
):
    if marker not in root_make:
        raise SystemExit("error: all Theos target builds must receive the same Apple command-line compiler tools")
if 'CC="$(APPLE_CLANG)"' not in root_make or 'HOST_MACOSX_SDKROOT="$(HOST_MACOSX_SDKROOT)"' not in root_make:
    raise SystemExit("error: fastPathSign host build must use system Clang and an explicit macOS SDK root")
fastpath_make = (ROOT / "Exploits/fastPathSign/Makefile").read_text(encoding="utf-8")
if "xcode-select" in fastpath_make or "xcrun" in fastpath_make or "xcodebuild" in fastpath_make:
    raise SystemExit("error: fastPathSign host makefile must not query or invoke Xcode tools")
if "HOST_MACOSX_SDKROOT ?= /Library/Developer/CommandLineTools/SDKs/MacOSX.sdk" not in fastpath_make:
    raise SystemExit("error: fastPathSign host makefile must default to standalone Command Line Tools SDK")
if "clang-include-env.mk" not in fastpath_make or '-isysroot "$(HOST_MACOSX_SDKROOT)"' not in fastpath_make or 'System/Library/Frameworks/Foundation.framework/Headers/Foundation.h' not in fastpath_make or 'usr/include/stdlib.h' not in fastpath_make:
    raise SystemExit("error: fastPathSign must compile/link against the macOS host SDK, not the iPhoneOS SDK")
if "build-fastpaths: validate-project bootstrap-deps check-build-tools" not in root_make or "python3 ./Scripts/validate_project.py" not in root_make or "python3 ./Scripts/validate_macho.py \"$(LDID_BIN)\"" not in root_make:
    raise SystemExit("error: deterministic project and ldid validation must run before Theos compilation")
if "Objective-C/C/C++ target compilation below is performed by Theos" not in root_make:
    raise SystemExit("error: all iOS Objective-C/C/C++ compilation must remain inside Theos target rules")
if "build-targets: build-presets" not in root_make or "build-presets: build-fastpaths" not in root_make:
    raise SystemExit("error: dependency bootstrap / preset / compile order is incomplete")
for marker in (
    '[build] RootHelper', '[build] TrollStore', '[build] TrollHelper (embedded root helper)',
    '--jobs=$(BUILD_JOBS) -C ./RootHelper', '--jobs=$(BUILD_JOBS) -C ./TrollStore',
    '--jobs=$(BUILD_JOBS) -C ./TrollHelper',
):
    if marker not in root_make:
        raise SystemExit("error: build targets must run sequentially with per-target jobs and explicit diagnostics")
if '& p1=$$!' in root_make or 'wait $$p1' in root_make:
    raise SystemExit("error: backgrounded target builds hide subproject errors; build sequentially instead")
if "BUILD_JOBS ?= $(shell n=$$(sysctl -n hw.ncpu" not in root_make or "FINALPACKAGE=1 DEBUG=0" not in root_make:
    raise SystemExit("error: release orchestration must use detected bounded parallelism and disable debug builds")
if "TrollStore_FILES = $(wildcard *.m) $(filter-out ../Shared/TSListControllerShared.m,$(wildcard ../Shared/*.m))" not in app_make:
    raise SystemExit("error: the main app must exclude the legacy PSListController implementation")
if "TrollStore_PRIVATE_FRAMEWORKS = MobileIcons MobileContainerManager" not in app_make or "TrollStore_PRIVATE_FRAMEWORKS = Preferences" in app_make:
    raise SystemExit("error: the main app must not link the private Preferences framework")
app_objc_sources = list((ROOT / "TrollStore").glob("*.m")) + list((ROOT / "TrollStore").glob("*.h"))
for source_path in app_objc_sources:
    source_text = source_path.read_text(encoding="utf-8")
    if any(token in source_text for token in ("PSListController", "PSSpecifier", "TSListControllerShared")):
        raise SystemExit(f"error: main app source {source_path.name} still references the legacy Preferences list controller")
if not all(token in app_make for token in (
    "ENABLE_APP_INTENTS ?= 0", "ifeq ($(ENABLE_APP_INTENTS),1)",
    "TrollStore_SWIFT_FILES = TSRefreshAppRegistrationsIntent.swift",
    "TrollStore_SWIFT_BRIDGING_HEADER = TrollStore-Bridging-Header.h",
    "-emit-const-values-path", "TrollStore_FRAMEWORKS += AppIntents",
)):
    raise SystemExit("error: the optional App Intents target must remain isolated behind ENABLE_APP_INTENTS")
settings_source = (ROOT / "TrollStore/TSSettingsListController.m").read_text(encoding="utf-8")
settings_header = (ROOT / "TrollStore/TSSettingsListController.h").read_text(encoding="utf-8")
advanced_settings_source = (ROOT / "TrollStore/TSSettingsAdvancedListController.m").read_text(encoding="utf-8")
if "settingsReloadScheduled" not in settings_source or "dispatch_async(dispatch_get_main_queue()" not in settings_source or "requestSettingsReload" not in settings_source:
    raise SystemExit("error: native Settings table reloads must be deferred and coalesced on the main queue")
if "requestSettingsReloadRebuildingSpecifiers" in settings_source:
    raise SystemExit("error: native Settings must not call the removed Preferences/specifier reload selector")
if "- (void)requestSettingsReload;" not in settings_source or "- (void)requestSettingsReload {" not in settings_source:
    raise SystemExit("error: native Settings reload callback must be declared and implemented by TSSettingsListController")
if "if (!strongSelf.settingsVisible || !strongSelf.view.window) return;" not in settings_source:
    raise SystemExit("error: hidden Settings tab must not reload its native UIKit table")
if ": UITableViewController" not in settings_header or "self.tableView.dataSource = self" not in settings_source or "cellForRowAtIndexPath:" not in settings_source:
    raise SystemExit("error: main Settings screen must use a native UITableViewController data source")
if any(token in settings_source + settings_header + advanced_settings_source for token in ("PSListController", "PSSpecifier", "reloadSpecifiers", "PSListItemsController")):
    raise SystemExit("error: Settings UI must not depend on Apple's private Preferences list/specifier framework")
if ": UITableViewController" not in (ROOT / "TrollStore/TSSettingsAdvancedListController.h").read_text(encoding="utf-8") or "UISegmentedControl" not in advanced_settings_source:
    raise SystemExit("error: Advanced Settings must also use native UIKit controls")
if "accessibilityIdentifier =" not in settings_source or "removeTarget:self action:@selector(settingsSwitchChanged:)" not in settings_source:
    raise SystemExit("error: native Settings switches must use stable row identifiers and safely reset targets during cell reuse")
if "findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_ALL)" not in settings_source or "trollStoreInactiveInstalledAppBundlePaths().count" not in settings_source:
    raise SystemExit("error: Settings runtime metadata lookup must remain available for the background loader")
if "shadowPath =" not in (ROOT / "TrollStore/TSRootViewController.m").read_text(encoding="utf-8"):
    raise SystemExit("error: floating navigation dock must use a cached rounded shadow path to avoid dynamic shadow rasterization")
if "configurationWithPointSize:16.0 weight:UIImageSymbolWeightRegular" not in (ROOT / "TrollStore/TSRootViewController.m").read_text(encoding="utf-8"):
    raise SystemExit("error: custom bottom navigation icons must remain at normal 16pt regular weight")
if "configurationWithPointSize:16.0 weight:UIImageSymbolWeightRegular" not in (ROOT / "Shared/TSListControllerShared.m").read_text(encoding="utf-8"):
    raise SystemExit("error: Settings preference icons must remain at normal 16pt regular weight")
if (ROOT / "TrollStore/Resources/Base.lproj/LaunchScreen.storyboardc/UITabBarController-9el-pn-lH0.nib").exists():
    raise SystemExit("error: stale compiled UITabBarController launch UI must be removed")
if "UILaunchStoryboardName" in (ROOT / "TrollStore/Resources/Info.plist").read_text(encoding="utf-8"):
    raise SystemExit("error: app must not reference the stale legacy launch storyboard")
app_delegate_source = (ROOT / "TrollStore/TSAppDelegate.m").read_text(encoding="utf-8")
if "configuration.delegateClass = TSSceneDelegate.class;" not in app_delegate_source:
    raise SystemExit("error: app must explicitly select the custom scene delegate/root UI")
if settings_source.count("#ifdef TS_ENABLE_APP_INTENTS") < 2:
    raise SystemExit("error: App Shortcut settings import/UI/action must be hidden when the Swift feature is disabled")
shortcut_intent = (ROOT / "TrollStore/TSRefreshAppRegistrationsIntent.swift").read_text(encoding="utf-8")
shortcut_controller = (ROOT / "TrollStore/TSRefreshShortcutController.m").read_text(encoding="utf-8")
if "ShortcutsLink" in shortcut_intent or "ShortcutsUIButton" in shortcut_intent:
    raise SystemExit("error: ShortcutsLink/ShortcutsUIButton are not present in the selected iOS 16.5 SDK; use the supported Shortcuts URL scheme fallback")
if "shortcuts://" not in shortcut_controller or "openShortcutsPressed" not in shortcut_controller or "ShortcutsUIButton" in shortcut_controller:
    raise SystemExit("error: the settings shortcut button must use the SDK-compatible Shortcuts URL scheme")
shortcut_bridge = (ROOT / "TrollStore/TSRefreshShortcutAction.m").read_text(encoding="utf-8")
shortcut_ui = (ROOT / "TrollStore/TSRefreshShortcutController.m").read_text(encoding="utf-8")
if not all(token in shortcut_intent for token in ("AppIntent", "AppShortcutsProvider", "openAppWhenRun: Bool = false", "TSRunRefreshAppRegistrationsShortcut()", "Refresh Apps")):
    raise SystemExit("error: background Refresh Apps App Intent and discoverable App Shortcut source are incomplete")
if '@[@"refresh"]' not in shortcut_bridge or "refresh-all" in shortcut_bridge or "backboardd" in shortcut_bridge or "killall" in shortcut_bridge or "reboot" in shortcut_bridge:
    raise SystemExit("error: Shortcuts action must run only the narrow app-registration refresh, without cache rebuild or respring")
if "Open Shortcuts" not in shortcut_ui or "App Shortcuts" not in shortcut_ui or 'NSLocalizedString(@"Done", nil)' not in shortcut_ui:
    raise SystemExit("error: refresh shortcut UI must explain the App Shortcuts navigation and provide an exit control")
settings_intent_source = (ROOT / "TrollStore/TSSettingsListController.m").read_text(encoding="utf-8")
if 'findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_ALL)' not in settings_intent_source or 'addRefreshShortcutPressed' not in settings_intent_source:
    raise SystemExit("error: shortcut entry must be restricted to a device with an injected persistence helper")
if 'com.apple.shortcuts' not in settings_intent_source or 'TrollStore never injects the Persistence Helper into it' not in shortcut_controller:
    raise SystemExit("error: Apple Shortcuts must be explicitly excluded from Persistence Helper injection while retaining the standalone refresh action")
root_helper_source = (ROOT / "RootHelper/main.m").read_text(encoding="utf-8")
register_impl = root_helper_source.find("static int registerUserPersistenceHelper(NSString *userAppId)")
main_entry = root_helper_source.find("int MAIN_NAME(int argc, char *argv[], char *envp[])")
if register_impl < 0 or main_entry < 0 or register_impl > main_entry or "ret = registerUserPersistenceHelper(userAppId);" not in root_helper_source:
    raise SystemExit("error: registerUserPersistenceHelper must be implemented before RootHelper command dispatch")
if not all(token in root_helper_source for token in ("O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW", "fsync(fd)", "ret = registerUserPersistenceHelper(userAppId);")):
    raise SystemExit("error: user Persistence Helper registration must create and commit a safe, idempotent marker")
if not all(token in root_helper_source for token in ("createPrivateSiblingTemporaryDirectory(containerPath, @\"TrollStore-transfer\")", "rename(appBundlePath.fileSystemRepresentation, backupPath.fileSystemRepresentation)", "restoring previous bundle")):
    raise SystemExit("error: inactive-app transfer must stage and preserve the original bundle before replacement")
if "BOOL fixPermissionsOfAppBundle(NSString* appBundlePath)" not in root_helper_source or "success=%d" not in root_helper_source:
    raise SystemExit("error: installation must verify bundle permission normalization instead of silently continuing")
if not all(token in root_helper_source for token in ('[systemAppId isEqualToString:@"com.apple.shortcuts"]', 'ret = EPERM;', 'Refusing Persistence Helper installation into Apple Shortcuts')):
    raise SystemExit("error: RootHelper must reject direct Persistence Helper install requests targeting Apple Shortcuts")
if "Apple Shortcuts remains separate and never hosts the Persistence Helper" not in shortcut_intent:
    raise SystemExit("error: App Shortcut metadata must explicitly state that Shortcuts is not a Persistence Helper host")
if "ENABLE_APP_INTENTS=\"$(ENABLE_APP_INTENTS)\"" not in root_make or "if [ \"$(ENABLE_APP_INTENTS)\" = \"1\" ]; then" not in root_make:
    raise SystemExit("error: App Intents metadata processing must be gated and disabled by the default Theos profile")
if "test_theos_only_build.sh" not in root_make:
    raise SystemExit("error: no-Swift Theos build regression test must run as part of make validate-project")

# Every shipped iOS target is configured for iOS 14+, and every project-owned
# Mach-O output must pass through the same macOS fastPathSign host signer.
for rel in (
    "TrollStore/Makefile", "RootHelper/Makefile", "TrollHelper/Makefile",
    "TweakPresets/AppLock/Makefile", "TweakPresets/BackgroundAssist/Makefile",
):
    makefile = (ROOT / rel).read_text(encoding="utf-8")
    if not re.search(r"^TARGET\s*:?=\s*iphone:clang:[^:\s]+:14\.0\s*$", makefile, re.M):
        raise SystemExit(f"error: {rel} must target iOS 14.0 or later")
for rel in ("TrollStore/Makefile", "RootHelper/Makefile", "TrollHelper/Makefile"):
    makefile = (ROOT / rel).read_text(encoding="utf-8")
    if "TARGET_CODESIGN = ../Exploits/fastPathSign/fastPathSign" not in makefile:
        raise SystemExit(f"error: {rel} must use the shared fastPathSign host signer")
for rel in ("TweakPresets/AppLock/Makefile", "TweakPresets/BackgroundAssist/Makefile"):
    makefile = (ROOT / rel).read_text(encoding="utf-8")
    if "TARGET_CODESIGN = $(abspath ../../Scripts/fastpath_sign_all_slices.py)" not in makefile:
        raise SystemExit(f"error: {rel} must use the architecture-preserving fastPathSign wrapper")
    if "TARGET_CODESIGN = /usr/bin/codesign" in makefile or "TARGET_CODESIGN = ldid" in makefile:
        raise SystemExit(f"error: {rel} bypasses the shared fastPathSign signer")
fastpath_main = (ROOT / "Exploits/fastPathSign/src/main.m").read_text(encoding="utf-8")
if "ad-hoc signing failed" not in fastpath_main or "refusing to process an unsigned code object" not in fastpath_main:
    raise SystemExit("error: fastPathSign must stop immediately when the embedded signature cannot be created")
if "Continuing anyways" in fastpath_main:
    raise SystemExit("error: fastPathSign still contains the unsafe continue-after-signing-failure path")
background_tweak = (ROOT / "TweakPresets/BackgroundAssist/Tweak.m").read_text(encoding="utf-8")
if "static UIBackgroundTaskIdentifier TSBackgroundTask = UIBackgroundTaskInvalid;" in background_tweak:
    raise SystemExit("error: UIBackgroundTaskInvalid must not be used as a file-scope initializer")
if "static UIBackgroundTaskIdentifier TSBackgroundTask;" not in background_tweak or "static BOOL TSBackgroundTaskActive;" not in background_tweak:
    raise SystemExit("error: BackgroundAssist must use zero-initialized task storage and an explicit active flag")
if "if (!TSBackgroundTaskActive) return;" not in background_tweak or "TSBackgroundTaskActive = YES;" not in background_tweak:
    raise SystemExit("error: BackgroundAssist task lifecycle must be guarded by the active flag")
if "fastPathSign host signer was not produced" not in root_make or "validate_macho_signature.py" not in root_make:
    raise SystemExit("error: fastPathSign must be built and every shipped code object must be checked for an embedded CodeDirectory")
if "./Scripts/validate_macho_signature.py" not in root_make.split("validate-project:", 1)[1].split("build-fastpaths:", 1)[0] or "./Scripts/test_fastpath_sign_pipeline.py" not in root_make:
    raise SystemExit("error: validate-project must syntax-check the embedded-signature validator")
if "find_signed_theos_binary.py" not in root_make or "--signer-wrapper ./Scripts/fastpath_sign_all_slices.py" not in root_make or "--output" not in root_make:
    raise SystemExit("error: preset staging must independently sign and lipo-assemble the arm64 and arm64e Theos slices")
wrapper = (ROOT / "Scripts/fastpath_sign_all_slices.py").read_text(encoding="utf-8")
if '"-thin", arch' not in wrapper or '"-create"' not in wrapper or "fastPathSign failed" not in wrapper or "CodeDirectory" not in wrapper:
    raise SystemExit("error: architecture-preserving signer must split, sign, reassemble, and verify every Mach-O slice")
if 'part.endswith(".dSYM")' not in (ROOT / "Scripts/find_signed_theos_binary.py").read_text(encoding="utf-8"):
    raise SystemExit("error: Theos artifact discovery must exclude dSYM debug-symbol files")
preset_build_block = root_make.split("build-presets:", 1)[1].split("build-targets:", 1)[0]
if preset_build_block.count('-C ./TweakPresets/AppLock clean') != 1 or preset_build_block.count('-C ./TweakPresets/BackgroundAssist clean') != 1:
    raise SystemExit("error: preset outputs must be cleaned before building to prevent stale signed slices from being embedded")
chmod_wrapper = "chmod 755 ./Scripts/fastpath_sign_all_slices.py"
first_preset_build = "$(MAKE) -C ./TweakPresets/AppLock clean"
if chmod_wrapper not in preset_build_block or preset_build_block.index(chmod_wrapper) > preset_build_block.index(first_preset_build):
    raise SystemExit("error: universal fastPathSign wrapper must be made executable before Theos invokes TARGET_CODESIGN")
if "#!/usr/bin/env python3" not in wrapper:
    raise SystemExit("error: universal fastPathSign wrapper must have a Python 3 shebang for direct Theos execution")
if 'python3 ./Scripts/validate_macho_signature.py "$$APP_DIR/TweakPresets/TSBackgroundAssist.framework/TSBackgroundAssist"' not in root_make:
    raise SystemExit("error: final app assembly must validate the TSBackgroundAssist framework at NSBundle.resourcePath/TweakPresets")
if 'python3 ./Scripts/validate_macho_signature.py "$$APP_DIR/TweakPresets/TSAppLock.framework/TSAppLock"' not in root_make:
    raise SystemExit("error: final app assembly must validate the TSAppLock framework at NSBundle.resourcePath/TweakPresets")
if "@set -eu; \\" not in root_make:
    raise SystemExit("error: app assembly must stop immediately when a required signed component is missing or invalid")

# Theos RESOURCE_DIRS merges the contents of Resources into the app bundle root.
# The runtime resolver reads NSBundle.resourcePath/TweakPresets, so the final
# validation paths must not insert a second, non-existent Resources component.
app_make = (ROOT / "TrollStore/Makefile").read_text(encoding="utf-8")
injector = (ROOT / "TrollStore/TSTweakInjector.m").read_text(encoding="utf-8")
if "TrollStore_RESOURCE_DIRS = Resources" not in app_make or '[[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"TweakPresets"]' not in injector:
    raise SystemExit("error: built-in preset resource staging and runtime lookup must use the app bundle root")
advanced_ui = (ROOT / "TrollStore/TSSettingsAdvancedListController.m").read_text(encoding="utf-8")
settings_ui = (ROOT / "TrollStore/TSSettingsListController.m").read_text(encoding="utf-8")
if not all(token in advanced_ui for token in ("segmentedLayoutConstraints", "self.accessoryView = self.switchControl;", "heightForRowAtIndexPath", "return indexPath.section == 2 ? 88.0 : 108.0;")):
    raise SystemExit("error: Advanced settings must use stacked segmented rows and a native accessory switch to prevent clipping")
if "return [row[@\"detail\"] length] ? 84.0 : 72.0;" not in settings_ui:
    raise SystemExit("error: main settings cards must use the enlarged touch-target heights")
if "self.accessoryView = self.switchControl;" not in advanced_ui or "self.titleTrailingToMarginsConstraint.active = YES;" not in advanced_ui:
    raise SystemExit("error: Advanced special-install switch must use the native cell accessory layout")
root_helper_source = (ROOT / "RootHelper/main.m").read_text(encoding="utf-8")
if "dispatch_once(&gSystemApplicationMetadataOnce" not in root_helper_source or "gCachedImmutableAppBundleIdentifiers" not in root_helper_source:
    raise SystemExit("error: installation must reuse LaunchServices system-app metadata within a RootHelper operation")
if "fstatat(dirfd(directory), entry->d_name, &itemStat, AT_SYMLINK_NOFOLLOW)" not in root_helper_source or "openat(dirfd(directory), entry->d_name" not in root_helper_source or "fchmod(itemFD, desiredMode)" not in root_helper_source:
    raise SystemExit("error: permission repair must use no-follow descriptor traversal")
archive_ui_source = (ROOT / "TrollStore/TSArchiveExtractor.m").read_text(encoding="utf-8")
if "if (S_ISLNK(st.st_mode)) [enumerator skipDescendants];" not in archive_ui_source or "if (S_ISLNK(st.st_mode)) { [enumerator skipDescendants]; continue; }" not in archive_ui_source:
    raise SystemExit("error: archive repacking and dynamic-library discovery must not recurse through symlinks")
if "archive_read_support_format_zip(reader);" not in archive_ui_source or "archive_read_support_format_tar(reader);" not in archive_ui_source or "archive_read_support_format_ar(reader);" not in archive_ui_source or "archiveName.pathExtension" in archive_ui_source:
    raise SystemExit("error: archive extraction must identify IPA/ZIP/TAR/DEB formats from headers without RAW fallback")
if "if (S_ISLNK(candidateStat.st_mode)) { [enumerator skipDescendants]; continue; }" not in root_helper_source:
    raise SystemExit("error: signing inventory must not recurse through app-bundle symlinks")
archive_source = (ROOT / "RootHelper/unarchive.m").read_text(encoding="utf-8")
if "archive_read_support_format_zip(reader)" not in archive_source or "1048576" not in archive_source or "isSafeRelativeArchivePath" not in archive_source or 'isEqualToString:@\"..\"' not in archive_source:
    raise SystemExit("error: IPA extraction must use ZIP-specific reading, a larger buffer and traversal protection")
if "ARCHIVE_EXTRACT_SECURE_SYMLINKS" not in archive_source or "ARCHIVE_EXTRACT_SECURE_NODOTDOT" not in archive_source:
    raise SystemExit("error: IPA extraction must prevent symlink and dot-dot traversal")
if "[install-perf] stage=extract" not in root_helper_source or "[install-perf] stage=sign" not in root_helper_source or "[install-perf] stage=permissions" not in root_helper_source or "[install-perf] stage=registration" not in root_helper_source:
    raise SystemExit("error: install pipeline must report phase timings for performance diagnosis")

if "package_framework_preset.py" not in root_make or "TSAppLock.framework" not in root_make:
    raise SystemExit("error: signed built-in tweak dylibs must be wrapped as framework bundles")
if "extract_app_intents_metadata.py" not in root_make or 'if [ "$(ENABLE_APP_INTENTS)" = "1" ]; then' not in root_make:
    raise SystemExit("error: App Intents metadata generation must be gated behind the optional Swift build")
if './Exploits/fastPathSign/fastPathSign "$$APP_DIR/ldid-bootstrap/ldid"' not in root_make:
    raise SystemExit("error: the staged ldid copy must be signed with fastPathSign without mutating bin/ldid")
if 'python3 ./Scripts/validate_macho_signature.py "$$APP_DIR/ldid-bootstrap/ldid"' not in root_make:
    raise SystemExit("error: final app assembly must validate the staged ldid signature")

if any(p.name == ".Assets" for p in ROOT.rglob("*")):
    raise SystemExit("error: a .Assets path is not allowed")
if any("Donate" in p.name or "donat" in p.name.lower() for p in ROOT.rglob("*")):
    raise SystemExit("error: donation feature source remains in the project")
if (ROOT / "TrollStore/TSDonateListController.m").exists() or (ROOT / "TrollStore/TSDonateListController.h").exists():
    raise SystemExit("error: original donation controller was not removed")

plists = sorted(ROOT.rglob("*.plist"))
for path in plists:
    try:
        with path.open("rb") as stream:
            plistlib.load(stream)
    except Exception as exc:
        raise SystemExit(f"error: invalid plist {path.relative_to(ROOT)}: {exc}")

app_info = plistlib.loads((ROOT / "TrollStore/Resources/Info.plist").read_bytes())
helper_info = plistlib.loads((ROOT / "TrollHelper/Resources/Info.plist").read_bytes())
if app_info.get("CFBundleExecutable") != "TrollStore" or app_info.get("CFBundleIdentifier") != "com.opa334.TrollStore":
    raise SystemExit("error: main app bundle identity has changed")
if not {"trollstorehelper", "ldid"}.issubset(set(app_info.get("TSRootBinaries", []))):
    raise SystemExit("error: TSRootBinaries must include trollstorehelper and ldid")
if not any("public.tar-archive" in entry.get("LSItemContentTypes", []) for entry in app_info.get("CFBundleDocumentTypes", [])):
    raise SystemExit("error: original .tar self-update document association has been lost")
if helper_info.get("CFBundleExecutable") != "TrollStorePersistenceHelper":
    raise SystemExit("error: persistence helper bundle identity has changed")
for label, info in (("TrollStore", app_info), ("TrollHelper", helper_info)):
    if info.get("CFBundleDevelopmentRegion") != "zh-Hans":
        raise SystemExit(f"error: {label} must use zh-Hans as its default/fallback language")
    if info.get("CFBundleLocalizations") != ["zh-Hans"]:
        raise SystemExit(f"error: {label} must advertise zh-Hans as the only bundled localization so Chinese is visible on English devices too")

# The provided binary is the sole ldid source. Build assembly packages it dormant,
# and only the explicit/default-off initialization flow places it at the active path.
ldid = ROOT / "bin/ldid"
if ldid.stat().st_size < 1024 * 1024 or not (ldid.stat().st_mode & 0o111):
    raise SystemExit("error: bin/ldid must be an executable precompiled device binary")
expected_ldid_sha256 = (ROOT / "bin/ldid.sha256").read_text(encoding="utf-8").split()[0]
ldid_bytes = ldid.read_bytes()
actual_ldid_sha256 = hashlib.sha256(ldid_bytes).hexdigest()
if len(ldid_bytes) < 32 or struct.unpack_from("<I", ldid_bytes, 0)[0] != 0xFEEDFACF:
    raise SystemExit("error: supplied ldid must be a thin little-endian arm64 Mach-O")
ldid_ncmds = struct.unpack_from("<I", ldid_bytes, 16)[0]
ldid_offset = 32
ldid_minimum = None
for _ in range(ldid_ncmds):
    command, command_size = struct.unpack_from("<II", ldid_bytes, ldid_offset)
    if command_size < 8 or ldid_offset + command_size > len(ldid_bytes):
        raise SystemExit("error: supplied ldid contains an invalid Mach-O load command")
    if command == 0x32 and command_size >= 24:
        platform, ldid_minimum, _sdk, _tools = struct.unpack_from("<IIII", ldid_bytes, ldid_offset + 8)
        if platform != 2 or ldid_minimum > 0x00100000:
            raise SystemExit("error: supplied ldid must declare iOS 16.0 or earlier as its minimum runtime")
        break
    ldid_offset += command_size
if ldid_minimum is None:
    raise SystemExit("error: supplied ldid has no LC_BUILD_VERSION command")
if (ROOT / "ldid.cpp").exists() or (ROOT / "ldid.hpp").exists():
    raise SystemExit("error: obsolete in-tree ldid source files must be removed; the supplied prebuilt binary is authoritative")
if actual_ldid_sha256 != expected_ldid_sha256:
    raise SystemExit(f"error: supplied ldid checksum mismatch: {actual_ldid_sha256}")
ldid_bin_entries = {path.name for path in (ROOT / "bin").iterdir()}
if ldid_bin_entries != {"ldid", "ldid.sha256"}:
    raise SystemExit(f"error: TrollStore/bin must contain exactly ldid and ldid.sha256; found {sorted(ldid_bin_entries)}")
for forbidden_name in ("ldid.cpp", "ldid.hpp", "der_engine.hpp", "cms_attribute_engine.hpp"):
    matches = [path.relative_to(ROOT).as_posix() for path in ROOT.rglob(forbidden_name) if path.is_file()]
    if matches:
        raise SystemExit(f"error: ldid source {forbidden_name} must exist only in the separate ldid.zip, not TrollStore: {matches}")
if any(path.name == "ldid-reference" for path in ROOT.rglob("ldid-reference")):
    raise SystemExit("error: stale ldid-reference directory remains inside TrollStore")
root_make = (ROOT / "Makefile").read_text(encoding="utf-8")
helper_make = (ROOT / "TrollHelper/Makefile").read_text(encoding="utf-8")
if "TrollStorePersistenceHelper_FRAMEWORKS = UIKit CoreGraphics CoreServices CoreTelephony Security" not in helper_make:
    raise SystemExit("error: embedded TrollHelper must link Security.framework for RootHelper sources")
if "$(HELPER_NAME)_FRAMEWORKS = CoreTelephony CoreServices Security" not in (ROOT / "RootHelper/Makefile").read_text(encoding="utf-8"):
    raise SystemExit("error: standalone RootHelper must explicitly link CoreServices.framework for LaunchServices update control")
if 'cp "$(LDID_BIN)" "$$APP_DIR/ldid-bootstrap/ldid"' not in root_make:
    raise SystemExit("error: Makefile must stage the supplied ldid in ldid-bootstrap/ldid")
if 'cp "$(LDID_BIN)" "$$APP_DIR/ldid"' in root_make:
    raise SystemExit("error: the supplied ldid must not be active by default")

# Validate OpenStep .strings syntax using plutil and make sure every source key is present.
strings_files = [
    ROOT / "TrollStore/Resources/zh-Hans.lproj/Localizable.strings",
    ROOT / "TrollHelper/Resources/zh-Hans.lproj/Localizable.strings",
    ROOT / "TrollStore/Resources/zh-Hans.lproj/InfoPlist.strings",
    ROOT / "TrollHelper/Resources/zh-Hans.lproj/InfoPlist.strings",
]
for path in strings_files:
    result = subprocess.run(["plutil", "-lint", "--", str(path)], text=True, capture_output=True)
    if result.returncode:
        raise SystemExit(f"error: invalid strings resource {path.relative_to(ROOT)}: {result.stderr.strip() or result.stdout.strip()}")

def decode_quoted(value):
    try:
        return json.loads('"' + value + '"')
    except Exception:
        return value

def catalog_entries(path):
    entries = {}
    pattern = re.compile(r'\s*"((?:\\.|[^"\\])*)"\s*=\s*"((?:\\.|[^"\\])*)"\s*;')
    for line in path.read_text(encoding="utf-8").splitlines():
        m = pattern.match(line)
        if m:
            entries[decode_quoted(m.group(1))] = decode_quoted(m.group(2))
    return entries

def catalog_keys(path):
    return set(catalog_entries(path))

source_keys = set()
source_extensions = {".m", ".h"}
for path in ROOT.rglob("*"):
    if path.is_file() and path.suffix in source_extensions and any(part in {"TrollStore", "TrollHelper", "Shared"} for part in path.parts):
        text = path.read_text(encoding="utf-8", errors="replace")
        for match in re.finditer(r'NSLocalizedString\(@"((?:\\.|[^"\\])*)"\s*,', text):
            source_keys.add(decode_quoted(match.group(1)))
app_entries = catalog_entries(strings_files[0])
helper_entries = catalog_entries(strings_files[1])
app_keys = set(app_entries)
helper_keys = set(helper_entries)
chinese_values = [value for value in app_entries.values() if any("\u4e00" <= char <= "\u9fff" for char in value)]
if len(chinese_values) < 100:
    raise SystemExit(f"error: zh-Hans catalog appears untranslated; found only {len(chinese_values)} values containing Chinese characters")
missing_app = sorted(source_keys - app_keys)
missing_helper = sorted(source_keys - helper_keys)
if missing_app or missing_helper:
    missing = sorted(set(missing_app + missing_helper))
    raise SystemExit("error: zh-Hans catalog lacks source keys: " + repr(missing[:12]))
if app_keys != helper_keys:
    raise SystemExit("error: app and persistence-helper localization catalogs diverge")

# Verify the settings-gated, per-install complete Entitlements editing flow.
settings = (ROOT / "TrollStore/TSSettingsListController.m").read_text(encoding="utf-8")
advanced = (ROOT / "TrollStore/TSSettingsAdvancedListController.m").read_text(encoding="utf-8")
injector = (ROOT / "TrollStore/TSTweakInjector.m").read_text(encoding="utf-8")
installation = (ROOT / "TrollStore/TSInstallationController.m").read_text(encoding="utf-8")
scene = (ROOT / "TrollStore/TSSceneDelegate.m").read_text(encoding="utf-8")
app_table = (ROOT / "TrollStore/TSAppTableViewController.m").read_text(encoding="utf-8")
manager = (ROOT / "TrollStore/TSApplicationsManager.m").read_text(encoding="utf-8")
root_helper = (ROOT / "RootHelper/main.m").read_text(encoding="utf-8")
uicache = (ROOT / "RootHelper/uicache.m").read_text(encoding="utf-8")
editor = (ROOT / "TrollStore/TSEntitlementsEditorViewController.m").read_text(encoding="utf-8")
editor_header = (ROOT / "TrollStore/TSEntitlementsEditorViewController.h").read_text(encoding="utf-8")
codesign = (ROOT / "Exploits/fastPathSign/src/codesign.m").read_text(encoding="utf-8")
if 'TSEditEntitlementsBeforeInstallEnabled' not in settings or 'Edit Entitlements Before Install' not in settings:
    raise SystemExit("error: Settings must expose the pre-install Entitlements editor switch")
if 'TSEditEntitlementsBeforeInstallEnabled' not in installation or 'presentEntitlementsEditorForIPA' not in installation:
    raise SystemExit("error: the Entitlements setting must gate the first step of IPA installation")
if 'forceConfirmation:YES' not in installation or 'presentInstallationConfirmationForFile' not in installation:
    raise SystemExit("error: Done must lead to an explicit installation confirmation")
if 'completionBlock(NO, editorError)' not in installation or 'cancelEditing' not in editor or 'onCancel' not in installation:
    raise SystemExit("error: Cancel must abort the complete install transaction")
if 'NSLocalizedString(@"Done", nil)' not in editor or 'NSLocalizedString(@"Cancel", nil)' not in editor or 'doneItem.enabled = NO' not in editor:
    raise SystemExit("error: Entitlements editor must have Cancel/Done controls and block Done until source data loads")
if 'entitlementsByBinarySubpaths' not in editor or 'self.editorView.text = mainXML' not in editor or 'originalMainEntitlements' not in editor:
    raise SystemExit("error: editor must start from the selected IPA's original main executable Entitlements")
if 'TSSigning/Entitlements' not in editor or 'NSUUID.UUID.UUIDString' not in editor or 'savedEntitlementsPath' not in editor_header or 'TSCustomEntitlements.plist' in editor:
    raise SystemExit("error: edited Entitlements must be passed through a unique temporary plist, not persistent settings storage")
if 'TSCustomEntitlementsOverrideEnabled' in settings + installation + manager + editor:
    raise SystemExit("error: obsolete persistent Entitlements override switch remains")
if 'gEditedMainEntitlementsProvided' not in root_helper or 'entitlementsToUse = [gEditedMainEntitlements mutableCopy]' not in root_helper:
    raise SystemExit("error: RootHelper must replace the full main-app Entitlements dictionary")
if 'addEntriesFromDictionary:gEditedMainEntitlements' in root_helper:
    raise SystemExit("error: full Entitlements editing must support removing original keys, not only overlaying keys")
# The configured ldid path must not use -M/--merge-deep for the explicitly edited main binary.
# ldid's -M turns -S into an overlay over the existing signature and would restore deleted keys.
configured_sign = root_helper.split('static int signAdhocInternal', 1)[1].split('int signAdhoc(', 1)[0]
if 'BOOL replaceEntitlements' not in configured_sign or 'entitlements.count || replaceEntitlements' not in configured_sign:
    raise SystemExit("error: an explicitly empty Entitlements document must still be signed as a replacement")
if 'if (!replaceEntitlements)' not in configured_sign or 'createExactEntitlementsSigningConfig' not in configured_sign or 'signAdhocInternal(job[@"path"], job[@"entitlements"], YES, [job[@"replaceEntitlements"] boolValue])' not in root_helper:
    raise SystemExit("error: main-app Entitlements replacement must reach each signing worker and override profile merge defaults")
exact_config = root_helper.split('static NSString *createExactEntitlementsSigningConfig', 1)[1].split('static int runLdidWithSigningConfiguration', 1)[0]
for exact_option in ['preserveEntitlements"] = @NO', 'mergeOnly"] = @NO', 'mergeDeep"] = @NO', 'removeObjectForKey:@"mergeEntitlements"', 'profiles[profileName] = profile', 'chmod(path.fileSystemRepresentation, 0600)']:
    if exact_option not in exact_config:
        raise SystemExit(f"error: exact Entitlements profile must preserve signing identity while disabling {exact_option}")
if 'runLdidWithSigningConfiguration(arguments, &output, exactEntitlementsConfigPath)' not in configured_sign:
    raise SystemExit("error: edited main-app Entitlements must use the temporary exact-replacement ldid profile")
if 'configPathOverride ?: gSigningConfiguration[@"ldidConfigPath"]' not in root_helper or 'runLdid(configuredArguments, errorOutput)' not in root_helper:
    raise SystemExit("error: exact ldid profile override must retain the selected profile and run through the existing ldid launcher")
if 'replaceMainEntitlements' not in root_helper or '@"replaceEntitlements":@YES' not in root_helper:
    raise SystemExit("error: RootHelper must tag the main executable for exact Entitlements replacement")
replacement_branch = configured_sign.split('if (replaceEntitlements)', 1)[1].split('} else {', 1)[0]
if '@[@"--merge-deep", @"-M"]' in replacement_branch:
    raise SystemExit("error: explicit Entitlements replacement must not merge with the embedded dictionary")
if 'isSameFile(bundleMainExecutablePath, mainExecutablePath)' not in root_helper or 'packageType isEqualToString:@"FMWK"' not in root_helper:
    raise SystemExit("error: edited Entitlements must be scoped to the main executable; extensions/frameworks retain their own signing state")
if 'replaceMainEntitlements:session.replaceMainEntitlements' not in installation or 'customEntitlementsPath:session.entitlementsPath' not in installation or 'protectFromHomeScreenDeletion:session.protectFromHomeScreenDeletion' not in installation:
    raise SystemExit("error: install retries must preserve the exact per-install Entitlements file and Home Screen protection choice")
if 'gEditedMainEntitlementsProvided = YES' not in root_helper or 'gEditedMainEntitlementsProvided = NO' not in root_helper:
    raise SystemExit("error: RootHelper must correctly distinguish a provided empty Entitlements dictionary from no editor input")
if 'TSEditEntitlementsBeforeInstallEnabled' not in settings or '[trollStoreUserDefaults() setBool:sender.on forKey:key]' not in settings:
    raise SystemExit("error: the native Settings Entitlements switch must persist its preference")
if 'TSProtectHomeScreenDeletionEnabled' not in advanced or 'Make app undeletable from Home Screen' not in advanced:
    raise SystemExit("error: Advanced must expose the per-install Home Screen deletion protection switch")
if 'isOn:stored ? [stored boolValue] : NO' not in advanced or 'TS_NON_DELETABLE_MARKER' not in uicache or 'IsDeletable' not in uicache:
    raise SystemExit("error: native special-install deletion protection must default off and be persisted in Launch Services metadata")
marker_write = root_helper.find('TS_NON_DELETABLE_MARKER')
registration_call = root_helper.find('registerPath(updatedAppURL.path', marker_write)
if marker_write < 0 or registration_call < 0 or 'writeToURL:nonDeletableMarkerURL' not in root_helper[marker_write:registration_call]:
    raise SystemExit("error: per-app deletion marker must be persisted before Launch Services registration")
if not all(token in root_helper for token in (
    'NSString *appContainerPath = canonicalAppPath.stringByDeletingLastPathComponent;',
    '[fm removeItemAtPath:appContainerPath error:&removeError]',
    'BOOL bundleGone = ![fm fileExistsAtPath:appContainerPath];',
)):
    raise SystemExit("error: TrollStore in-app uninstall path must physically remove and verify the protected app container")
if 'protect-home-screen-deletion' not in manager or 'protect-home-screen-deletion' not in root_helper or 'TS_NON_DELETABLE_MARKER' not in root_helper:
    raise SystemExit("error: install must persist per-app Home Screen protection in the app container")
if 'TS_NON_DELETABLE_MARKER' not in uicache or 'dictToRegister[@"IsDeletable"]' not in uicache or 'isTrollStoreMainApp' not in uicache:
    raise SystemExit("error: Launch Services refresh must reapply non-deletable metadata for protected apps and TrollStore")
if 'PreventUninstall' in injector or 'Prevent Uninstall Limitations' in injector or (ROOT / 'TweakPresets/PreventUninstall').exists():
    raise SystemExit("error: obsolete Tweak-based PreventUninstall pseudo-feature remains")
if 'TweakPresets' not in injector or 'isEqualToString:@"framework"' not in injector or 'Delete Imported Files' not in injector or 'presentStagedImportAtPath' not in injector:
    raise SystemExit("error: framework-first preset detection and staged-import delete/cancel controls are missing")
if 'AutoInitializeBundledLdid' not in settings or 'return value ?: @NO;' not in settings or 'AutoInitializeBundledLdid' not in scene:
    raise SystemExit("error: bundled ldid auto-initialization setting is missing or does not default to off")
if 'handleLdidAutoInitialization' not in scene or 'isExecutableFileAtPath:activeLdidPath' not in scene:
    raise SystemExit("error: auto-initialization must only activate bundled ldid when the active executable is missing")
all_objc_sources = "\n".join(path.read_text(encoding="utf-8", errors="replace") for path in ROOT.rglob("*") if path.is_file() and path.suffix in {".m", ".h"})
if 'fetchLatestLdidVersion' in all_objc_sources or 'github.com/opa334/ldid' in all_objc_sources or 'ldid.version' in all_objc_sources:
    raise SystemExit("error: upstream ldid version-check/download/metadata code remains")
if '--entitlements' not in manager or 'gEditedMainEntitlementsProvided' not in root_helper or 'TSEditEntitlementsBeforeInstallEnabled' not in installation:
    raise SystemExit("error: per-install complete Entitlements path is incomplete")
if 'onSave' not in editor_header or 'savedEntitlementsPath' not in editor_header or 'presentInstallationConfirmationForFile' not in installation:
    raise SystemExit("error: Done must hand the temp Entitlements document to install confirmation")
if 'modalInPresentation = YES' not in installation or 'completion(outputPath)' not in editor or 'dismissViewControllerAnimated:YES completion:completion' not in editor:
    raise SystemExit("error: editor must require explicit Done/Cancel and return to the prior page instead of silently swipe-dismissing")
if 'updateFinalPreview' not in editor or 'Merged Entitlements Preview' in editor:
    raise SystemExit("error: editor preview must describe the final complete main-app dictionary, not an overlay merge")
if 'installationMethod:(int)session.method' not in installation or 'replaceMainEntitlements:session.replaceMainEntitlements' not in installation or 'customEntitlementsPath:session.entitlementsPath' not in installation or 'stealthInstall:session.stealthInstall' not in installation:
    raise SystemExit("error: install retry must preserve the original installation parameters")
if 'Retry with Custom' not in installation or 'Retry with installd' not in installation or 'retryCountsByError' not in installation or 'Copy Debug Log' not in installation:
    raise SystemExit("error: install error recovery/retry controls are incomplete")
if 'replaceMainEntitlements' not in manager or 'case 189:' not in manager or 'return 189;' not in root_helper or 'cleanup-install' not in root_helper:
    raise SystemExit("error: explicit installd failure and guarded cleanup path are incomplete")
if 'TSBundlePreSigned' not in root_helper or 'skipAdhocSigning' not in root_helper or 'codesign_sign_adhoc' not in root_helper or 'falling back to bundled ldid' not in root_helper:
    raise SystemExit("error: pre-signed fast path / OS-specific signer selection is incomplete")
if 'signedMachOPaths' not in root_helper or 'codeBundlePaths' not in root_helper or 'bundlesDeepestFirst' not in root_helper:
    raise SystemExit("error: nested Mach-O files and code bundles must be signed before outer resource sealing")
if 'CFErrorRef errors = NULL' not in codesign or 'if (errors) CFRelease(errors)' not in codesign:
    raise SystemExit("error: native signing failure handling must initialize and release returned CFError objects")
if 'NOTE: If the installd placeholder installation fails, TrollStore automatically falls back to using the Custom method.' in (ROOT / 'TrollStore/TSSettingsAdvancedListController.m').read_text(encoding="utf-8"):
    raise SystemExit("error: the installation-method setting must describe user-confirmed fallback, not silent fallback")
if 'Using the edited main-app Entitlements document' not in installation or 'Complete main-app Entitlements document' not in editor or 'Original Entitlements (read only)' not in editor or 'gEditedMainEntitlementsProvided' not in root_helper:
    raise SystemExit("error: complete edited Entitlements confirmation or runtime replacement semantics are incomplete")
# iOS 16 SDK's nullability-completeness diagnostics are promoted to errors by this build.
# The manager exposes optional output/error paths, so express both pointer levels explicitly.
manager_header = (ROOT / "TrollStore/TSApplicationsManager.h").read_text(encoding="utf-8")
manager_impl = (ROOT / "TrollStore/TSApplicationsManager.m").read_text(encoding="utf-8")
if "NS_ASSUME_NONNULL_BEGIN" not in manager_header or "NS_ASSUME_NONNULL_END" not in manager_header:
    raise SystemExit("error: TSApplicationsManager public declarations must have a complete nullability context")
for marker in (
    "log:(NSString * _Nullable * _Nullable)logOut",
    "customEntitlementsPath:(NSString * _Nullable)entitlementsPath",
    "uninstallApp:(NSString * _Nullable)appId",
    "uninstallAppByPath:(NSString * _Nullable)path",
    "changeAppRegistration:(NSString * _Nullable)appPath toState:(NSString * _Nullable)newState",
):
    if marker not in manager_header:
        raise SystemExit("error: TSApplicationsManager nullable API contract is incomplete: " + marker)
for marker in (
    "log:(NSString * _Nullable * _Nullable)logOut",
    "uninstallApp:(NSString * _Nullable)appId",
    "uninstallAppByPath:(NSString * _Nullable)path",
    "changeAppRegistration:(NSString * _Nullable)appPath toState:(NSString * _Nullable)newState",
):
    if marker not in manager_impl:
        raise SystemExit("error: TSApplicationsManager implementation does not match nullability contract: " + marker)
grid_layout = (ROOT / "TrollStore/TSAppCollectionViewController.m").read_text(encoding="utf-8")
if "if (@available(iOS 16.0, *))" not in grid_layout:
    raise SystemExit("error: collection layout must guard the iOS 16 API with an availability check")
if "horizontalGroupWithLayoutSize:groupSize repeatingSubitem:item count:2" not in grid_layout:
    raise SystemExit("error: iOS 16+ collection layout must use the repeatingSubitem API")
if "horizontalGroupWithLayoutSize:groupSize subitem:item count:2" not in grid_layout:
    raise SystemExit("error: iOS 14/15 collection layout fallback is missing")

# UIButtonConfiguration and UIButton.configuration were introduced in iOS 15.
# Keep all such uses behind runtime availability checks and retain a native
# UIButton/stack-view implementation for the iOS 14 deployment target.
root_controller = (ROOT / "TrollStore/TSRootViewController.m").read_text(encoding="utf-8")
if root_controller.count("if (@available(iOS 15.0, *))") < 2:
    raise SystemExit("error: dock UIButtonConfiguration use must be guarded for iOS 14")
for marker in (
    "[UIButtonConfiguration plainButtonConfiguration]",
    "button.configuration = configuration;",
    "[button viewWithTag:1401]",
    "[button viewWithTag:1402]",
    "legacyContent.axis = UILayoutConstraintAxisVertical;",
):
    if marker not in root_controller:
        raise SystemExit("error: iOS 14-compatible dock button implementation is incomplete: " + marker)

# UITableView.sectionHeaderTopPadding was introduced in iOS 15. Guard every
# use so the project continues to compile with an iOS 14 deployment target.
for rel in ("TrollStore/TSSettingsAdvancedListController.m", "TrollStore/TSSettingsListController.m", "TrollStore/TSThemeManager.m"):
    source = (ROOT / rel).read_text(encoding="utf-8")
    if "sectionHeaderTopPadding" in source and "if (@available(iOS 15.0, *))" not in source:
        raise SystemExit("error: " + rel + " must guard UITableView.sectionHeaderTopPadding for iOS 14")
for rel in ("TrollStore/TSSettingsAdvancedListController.m", "TrollStore/TSSettingsListController.m"):
    source = (ROOT / rel).read_text(encoding="utf-8")
    if "if (@available(iOS 15.0, *)) {\n        self.tableView.sectionHeaderTopPadding = 8.0;\n    }" not in source:
        raise SystemExit("error: iOS 15 section-header padding guard is missing from " + rel)

# Objective-C UTType is an NSObject class: Swift static members such as
# UTType.image/data/archive/package are not Objective-C class properties.
objc_sources = "\n".join(
    path.read_text(encoding="utf-8")
    for path in sorted(list(ROOT.rglob("*.m")) + list(ROOT.rglob("*.h")))
)
if re.search(r"\bUTType\.(?:image|data|archive|package)\b", objc_sources):
    raise SystemExit("error: Swift-only UTType static members remain in Objective-C sources")
if "contentEdgeInsets" in objc_sources or "imageEdgeInsets" in objc_sources or "titleEdgeInsets" in objc_sources:
    raise SystemExit("error: deprecated UIButton inset properties remain in Objective-C sources")
root_controller_source = (ROOT / "TrollStore/TSRootViewController.m").read_text(encoding="utf-8")
if "UIButtonConfigurationImagePlacementLeading" in objc_sources:
    raise SystemExit("error: invalid UIButtonConfigurationImagePlacementLeading enum remains")
if "configuration.imagePlacement = NSDirectionalRectEdgeTop" not in root_controller_source:
    raise SystemExit("error: custom glass dock must stack tab icons above their labels")
if not all(token in root_controller_source for token in ("navigationController.navigationBar.prefersLargeTitles = (index != 3)", "rootController.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeAlways", "rootController.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever", "case 3:")):
    raise SystemExit("error: lazy tab creation must preserve the large Apps title and compact titles for other sections")
if "@interface TSRootViewController : UIViewController" not in (ROOT / "TrollStore/TSRootViewController.h").read_text(encoding="utf-8"):
    raise SystemExit("error: app shell must be a standalone UIViewController, not a UITabBarController overlay")
if "UITabBarController" in root_controller_source or "self.tabBar" in root_controller_source:
    raise SystemExit("error: legacy system tab bar must be fully removed from the root shell")
for marker in ("ensureTabLoadedAtIndex:", "shouldAutomaticallyForwardAppearanceMethods", "beginAppearanceTransition:", "endAppearanceTransition", "tabTransitionInFlight", "UIVisualEffectView", "dockIsFloating"):
    if marker not in root_controller_source:
        raise SystemExit("error: modern root navigation is missing lifecycle/transition marker " + marker)
if not re.search(r"NSTimeInterval duration = useStandardSlide \? 0\.22 : 0\.16;", root_controller_source):
    raise SystemExit("error: reference transitions must remain immediate 160ms fades, with a restrained 220ms standard alternative")
app_table_ui = (ROOT / "TrollStore/TSAppTableViewController.m").read_text(encoding="utf-8")
if not all(token in app_table_ui for token in ("Switch to Grid Layout", "switchToGridAction", "self.navigationItem.rightBarButtonItem = installBarButtonItem", "__weak typeof(self) weakSelf = self", "[weakSelf switchToGridLayout]")) or "rightBarButtonItems = @[installBarButtonItem, layoutButton]" in app_table_ui:
    raise SystemExit("error: Apps screen must show only the plus icon, preserve the grid action, and avoid a retained-menu self cycle")
if not all(token in root_controller_source for token in ("MIN(width - 2.0 * margin, 440.0)", "configuration.imagePadding = 2", "UIBlurEffectStyleSystemChromeMaterial", "configuration.baseForegroundColor = foreground", "dockTopSeparator", "self.currentTabIndex = index", "self.dockSelectionPill.hidden = !self.dockIsFloating")):
    raise SystemExit("error: standard/floating bottom bar layout or immediate selected-state treatment is incomplete")
if "UIView animateWithDuration:0.27" in root_controller_source or "UIView animateWithDuration:0.34" in root_controller_source or "usingSpringWithDamping:0.58" in root_controller_source:
    raise SystemExit("error: tab navigation still contains the old delayed/spring-heavy animation chain")
theme_manager_source = (ROOT / "TrollStore/TSThemeManager.m").read_text(encoding="utf-8")
if "UIColor.secondarySystemBackgroundColor" not in theme_manager_source:
    raise SystemExit("error: theme manager must retain grouped rounded-card styling")
appearance_source = settings_source
if not all(token in theme_manager_source for token in ('+ (NSInteger)floatingBarStyle', 'return legacyEnabled && ![legacyEnabled boolValue] ? 1 : 0;', '+ (BOOL)floatingBarEnabled { return [self floatingBarStyle] != 1; }')):
    raise SystemExit("error: bottom bar style must preserve legacy preferences while supporting floating, standard and floating-2 modes")
if 'setInteger:0 forKey:@"TSFloatingBarStyle"' not in root_controller_source or 'setBool:YES forKey:@"TSFloatingTabBarEnabled"' not in root_controller_source:
    raise SystemExit("error: first launch must select the video-matched floating bottom bar")
if not all(token in appearance_source for token in ('TSFloatingBarStyle', 'setBool:(index != 1) forKey:@"TSFloatingTabBarEnabled"', 'TSAppearanceChanged')):
    raise SystemExit("error: bottom bar style selection must persist both current and legacy settings and refresh the root navigation")
if "id savedMode=[TSThemeDefaults() objectForKey:@\"TSThemeMode\"]" not in theme_manager_source or "savedMode ? [savedMode integerValue] : 2" not in theme_manager_source or "mode==1 ? UIUserInterfaceStyleLight" not in theme_manager_source or "mode==2 ? UIUserInterfaceStyleDark" not in theme_manager_source:
    raise SystemExit("error: first launch must match the dark appearance in the stored video while preserving explicit theme choices and quick-menu modes")
if "TSAppearanceController" in settings_source or (ROOT / "TrollStore/TSAppearanceController.m").exists() or (ROOT / "TrollStore/TSAppearanceController.h").exists():
    raise SystemExit("error: duplicate legacy appearance settings controller must stay removed")
if not all(token in settings_source for token in ("UIMenu *appearanceMenu", "ThemeSystem", "ThemeLight", "ThemeDark", "setThemeMode:", "paintbrush.pointed.fill")):
    raise SystemExit("error: the Settings paintbrush menu must expose Follow System, Light and Dark appearance modes")
if not all(token in appearance_source for token in ("UIColorPickerViewController", "supportsAlpha = YES", "colorPickerViewControllerDidSelectColor:", "TSThemeAccentCustomColor", "Change Theme Color")):
    raise SystemExit("error: theme color editing must use the native alpha-enabled color picker and persist custom RGBA values")
if not all(token in settings_source for token in ("TSShowSystemApps", "TSShowAppFilter", "TSShowTrollStoreBadge", "TSShowAppTypeInGrid", "TSChoiceListController", "TSAppearanceChanged", "UIColorPickerViewController")):
    raise SystemExit("error: personalization preferences must expose the video-matched app, filter, badge, layout, bar and animation controls")
if not all(token in app_table_ui for token in ("TSShowSystemApps", "TSShowAppFilter", "TSShowTrollStoreBadge", "TSAppAppearanceSettingsChanged", "updateAppCategoryControlAppearance")):
    raise SystemExit("error: list layout preferences must actually filter system apps and update the app-category/badge UI")
if not all(token in grid_layout for token in ("TSShowSystemApps", "TSShowAppFilter", "TSShowTrollStoreBadge", "TSShowAppTypeInGrid", "TSAppAppearanceSettingsChanged", "updateCategoryControlAppearance")):
    raise SystemExit("error: grid layout preferences must actually filter system apps and update category/type badges")
if 'self.navigationItem.searchController = _searchController' in app_table_ui or 'self.navigationItem.searchController=_searchController' in grid_layout or 'presentSearchPrompt' not in app_table_ui or 'presentSearchPrompt' not in grid_layout:
    raise SystemExit("error: Apps screens must keep the video-matched clean header and expose search from the top-right menu")
if "plus.circle.fill" not in app_table or "plus.circle.fill" not in (ROOT / "TrollStore/TSIPAPackageStore.m").read_text(encoding="utf-8") or "plus.circle.fill" not in (ROOT / "TrollStore/TSPluginStoreController.m").read_text(encoding="utf-8"):
    raise SystemExit("error: top-right add affordances must match the filled circular plus icon from the reference video")
for rel in ("TrollStore/TSIPAPackageStore.m", "TrollStore/TSTweakInjector.m", "TrollStore/TSSigningSettingsController.m"):
    source = (ROOT / rel).read_text(encoding="utf-8")
    if "[UTType typeWithIdentifier:@\"public.data\"]" not in source:
        raise SystemExit(f"error: {rel} must use Objective-C UTType lookup methods")

grid_table = (ROOT / "TrollStore/TSAppCollectionViewController.m").read_text(encoding="utf-8")
for source in (app_table, grid_table):
    for category_label in ('NSLocalizedString(@"All"', 'NSLocalizedString(@"User"', 'NSLocalizedString(@"Troll"', 'NSLocalizedString(@"System"'):
        if category_label not in source:
            raise SystemExit("error: app source filtering must expose the video-matched All/User/Troll/System categories")
    if 'TSAppSourceCategoryV2' not in source or 'oldCategory == 0 ? 2' not in source or 'oldCategory == 2 ? 3' not in source:
        raise SystemExit("error: legacy three-segment app source preferences must migrate safely to the four-category layout")
if 'enumerateApplicationsOfType:type' not in app_table or 'category == 0 || category == 1' not in app_table or 'category == 0 || category == 3' not in app_table or '_cachedAllAppCatalog' not in app_table:
    raise SystemExit("error: All/User/Troll/System catalogs must include the correct LaunchServices and TrollStore paths")
if 'TSAppSourceCategory' not in app_table or 'TSAppSourceCategory' not in grid_table or 'TSIsUserAppContainerPath' not in app_table or 'TSGridIsUserAppContainerPath' not in grid_table:
    raise SystemExit("error: app source filtering and per-app update controls are not based on the actual installed container")
if 'canEditRowAtIndexPath' not in app_table or 'isManagedByTrollStoreAtBundlePath:_cachedAppInfos[indexPath.row].bundlePath' not in app_table:
    raise SystemExit("error: uninstall swipe actions must remain limited to TrollStore-managed app containers")
if not all(token in app_table for token in ('TSIsUserAppContainerPath(appInfo.bundlePath)', 'BOOL trollManagedApp', 'if (userManagedApp)', 'if (trollManagedApp)', 'TSAppUpdateManager setUpdatesBlocked')):
    raise SystemExit("error: All view actions must be selected by the actual app container and support per-app update locking")
if not all(token in grid_table for token in ('TSGridIsTrollStoreAppPath', 'TSGridIsUserAppContainerPath', 'if (userContainer)', 'if (trollManaged)', 'TSAppUpdateManager setUpdatesBlocked')):
    raise SystemExit("error: grid app actions must distinguish TrollStore, user, and system apps before showing privileged actions")
for strings_rel in ("TrollStore/Resources/zh-Hans.lproj/Localizable.strings", "TrollHelper/Resources/zh-Hans.lproj/Localizable.strings"):
    strings = (ROOT / strings_rel).read_text(encoding="utf-8")
    if not all(re.search(r'^"' + key + r'"\s*=', strings, re.M) for key in ("All", "User", "Troll")):
        raise SystemExit(f"error: {strings_rel} must localize the four video-matched app categories")
if 'TSStealthInstallEnabled' not in settings or 'TSStealthInstallEnabled' not in manager or 'BOOL stealthInstall' not in root_helper or 'TSOriginalBundleIdentifier' not in root_helper or 'return 188' not in root_helper:
    raise SystemExit("error: opt-in stealth installation flow is incomplete")
if 'TS%016llX' not in root_helper or 'TS_%016llX' in root_helper:
    raise SystemExit("error: stealth bundle identifier suffix must use a conventional alphanumeric component")
if 'TS_ACTIVE_MARKER' not in (ROOT / 'Shared/TSUtil.m').read_text() or 'Only consider apps installed in a TrollStore-managed container' not in (ROOT / 'Shared/TSUtil.m').read_text():
    raise SystemExit("error: stealth update discovery must only match TrollStore-managed app containers")
if any('OPTFLAG = -O3' not in (ROOT / rel).read_text() for rel in ('TrollStore/Makefile', 'RootHelper/Makefile', 'TrollHelper/Makefile', 'TweakPresets/AppLock/Makefile', 'TweakPresets/BackgroundAssist/Makefile')) or '-O3' not in (ROOT / 'Exploits/fastPathSign/Makefile').read_text() or 'SWIFT_OPTFLAG = -O -whole-module-optimization -num-threads 1' not in app_make:
    raise SystemExit("error: production optimization must cover Objective-C/C targets and the optional Swift target")
if 'filteredAppInfosFromCatalog' not in app_table or '_cachedTrollStoreAppCatalog' not in app_table or '_cachedAppStoreAppCatalog' not in app_table or '_cachedSystemAppCatalog' not in app_table:
    raise SystemExit("error: app-list catalog caching/search optimization is incomplete")
if 'fileMayContainMachOAtPath' not in root_helper or 'MicroCore fast path' not in root_helper:
    raise SystemExit("error: MicroCore must prefilter non-Mach-O files before ChOma parsing")
if 'enumerateApplicationsOfType:type block:appendAppProxy' not in app_table or 'self->_cachedAppInfos=@[];' not in app_table or 'category != strongSelf->_sourceCategory' not in app_table:
    raise SystemExit("error: app source catalog must use LaunchServices enumeration and avoid showing stale rows during category scans")
util_source = (ROOT / 'Shared/TSUtil.m').read_text()
if 'select(maxFD + 1' not in util_source or 'kMaxCapturedOutputBytes' not in util_source or 'void printMultilineNSString(NSString* stringToPrint)' not in util_source:
    raise SystemExit("error: subprocess output must be drained concurrently with bounded capture and required logging helper retained")
if 'getNSStringFromFile' in util_source:
    raise SystemExit("error: removed getNSStringFromFile API should not be referenced from this implementation")
if 'BOOL stealthInstall, BOOL protectFromHomeScreenDeletion, NSArray<NSString *> *pluginPaths)' not in root_helper or 'installApp(tmpPackagePath, YES, force, NO, useInstalldMethod, skipUICache, stealthInstall, protectFromHomeScreenDeletion, pluginPaths ?: @[])' not in root_helper:
    raise SystemExit("error: stealth install option is not propagated through IPA install handling")
if "TSDonateListController" in settings or "donat" in settings.lower():
    raise SystemExit("error: donation UI reference remains in Settings")

# Audit the new feature surface: local package store (without source feeds), safe repackaging,
# process-memory decryption, guarded maintenance, ldid in-process injection and UI settings.
repackager = (ROOT / "TrollStore/TSAppRepackager.m").read_text(encoding="utf-8")
archive = (ROOT / "TrollStore/TSArchiveExtractor.m").read_text(encoding="utf-8")
package_store = (ROOT / "TrollStore/TSIPAPackageStore.m").read_text(encoding="utf-8")
decrypt_ui = (ROOT / "TrollStore/TSAppDecryptor.m").read_text(encoding="utf-8")
decrypt_root = (ROOT / "RootHelper/TSAppDecryptor.m").read_text(encoding="utf-8")
maintenance = (ROOT / "RootHelper/TSAppMaintenance.m").read_text(encoding="utf-8")
injector = (ROOT / "TrollStore/TSTweakInjector.m").read_text(encoding="utf-8")
if not all(token in repackager for token in ("removeURLSchemes", "removeWidgets", "removeWatch", "CFBundleIdentifier", "CFBundleDisplayName", "CFBundleShortVersionString")):
    raise SystemExit("error: repackaging must edit bundle metadata and support URL/widget/watch removal")
if "ARCHIVE_EXTRACT_SECURE_NODOTDOT" not in archive or "ARCHIVE_EXTRACT_SECURE_SYMLINKS" not in archive or "AE_IFLNK" not in archive or "archiveContainsInstallableIPAAtPath" not in archive:
    raise SystemExit("error: archive extraction/creation must guard traversal, preserve symlinks, and validate IPA ZIPs")
if not all(token in package_store for token in ("@\"ipa\"", "@\"tipa\"", "@\"tar\"", "@\"zip\"", "@\"deb\"", "https", "Software sources are not included")):
    raise SystemExit("error: local IPA/TIPA/TAR/ZIP/DEB management and direct HTTPS download are incomplete")
if "archiveContainsInstallableIPAAtPath" not in package_store or "TS-ZIP-IPA-" not in package_store:
    raise SystemExit("error: ZIP files with a verified Payload app must open install/repackage actions directly")
if "task_for_pid" not in decrypt_root or "vm_read_overwrite" not in decrypt_root or "cryptidOffset" not in decrypt_root or "No encrypted Mach-O region was decrypted" not in decrypt_root:
    raise SystemExit("error: decrypt flow must read live-process memory and refuse to emit a fake IPA")
if "#import <libproc.h>" in decrypt_root or "proc_listpids(" in decrypt_root or "proc_pidpath(" in decrypt_root:
    raise SystemExit("error: iOS RootHelper must not depend on the macOS-only libproc API")
if "#import <mach/vm_map.h>" not in decrypt_root or "vm_read_overwrite(" not in decrypt_root:
    raise SystemExit("error: iOS RootHelper must use vm_map.h/vm_read_overwrite")
if "mach/mach_vm.h" in decrypt_root or "mach_vm_read_overwrite(" in decrypt_root:
    raise SystemExit("error: unsupported mach_vm API remains in iOS RootHelper")
if "mach_vm_address_t" in decrypt_root or "mach_vm_size_t" in decrypt_root:
    raise SystemExit("error: iOS decryptor must use vm_address_t/vm_size_t types")
if "vm_size_t readLength = 0" not in decrypt_root:
    raise SystemExit("error: vm_read_overwrite output size must use vm_size_t")
if "#import <sys/sysctl.h>" not in decrypt_root or "KERN_PROC_ALL" not in decrypt_root or "KERN_PROCARGS2" not in decrypt_root:
    raise SystemExit("error: decryptor process discovery must use the iOS-available Darwin sysctl interfaces")
if "NSString *processError = nil; pid_t pid = 0;" not in decrypt_root:
    raise SystemExit("error: decryptor process discovery error output must use the declared NSString type")
if "Decrypt & Export IPA" not in decrypt_ui or "Copy Debug Log" not in decrypt_ui:
    raise SystemExit("error: application list decrypt entry or debug log action is missing")
if not all(token in maintenance for token in ("TSAppMaintenanceClearCache", "TSAppMaintenanceClearData", "TSAppMaintenanceClearAllCaches", "TSAppMaintenanceInjectDylib", "--iosinject", "--verify")):
    raise SystemExit("error: guarded cache/data maintenance or bundled ldid injection is incomplete")
if "isEqualToString:@\"framework\"" not in injector or "Delete Imported Files" not in injector or "presentStagedImportAtPath" not in injector:
    raise SystemExit("error: framework-first preset detection and staged-import delete/cancel controls are missing")
if 'stringByResolvingSymlinksInPath' not in maintenance or 'Documents/Packages' not in maintenance:
    raise SystemExit("error: root-helper destructive operations and injection payload path must be symlink-safe and sandboxed to owned paths")
if 'MCMAppDataContainer containerWithIdentifier:containerIdentifier createIfNecessary:YES' not in maintenance or 'Removed and recreated the data container' not in maintenance:
    raise SystemExit("error: clear-data must remove the container and request recreation of an empty MCM container")
if 'constructContainerizationForEntitlements(entitlements, &containerIdentifier)' not in maintenance or 'This application declares that it does not use a standard data container' not in maintenance or maintenance.index('constructContainerizationForEntitlements(entitlements, &containerIdentifier)') > maintenance.index('removeItemAtPath:dataPath'):
    raise SystemExit("error: clear-data must validate container semantics before deleting any data")
if 'TSDecryptRuntimeOffsetForFileRange' not in decrypt_root or 'FAT_CIGAM_64' not in decrypt_root or 'sizeof(struct mach_header_64)' not in decrypt_root:
    raise SystemExit("error: decryptor must map Mach-O file offsets to runtime addresses and support fat Mach-O byte orders")
if 'TrollStore_RESOURCE_DIRS = Resources' not in app_make:
    raise SystemExit("error: built-in preset dynamic libraries must be included as application resources")
if "UICollectionViewCompositionalLayout" not in grid_table or "TSAppSourceCategory" not in grid_table or "TSAppearanceChanged" not in grid_table or "buildCatalogForCategory" not in grid_table:
    raise SystemExit("error: two-column four-category source filters or live theme updates are incomplete")
if "TSAppearanceChanged" not in app_table or "TSFloatingBarHeight" not in (ROOT / "TrollStore/TSThemeManager.m").read_text(encoding="utf-8"):
    raise SystemExit("error: list theme updates or floating-bar settings are incomplete")
if not all(token in app_table for token in ("catalogQueue", "maxConcurrentOperationCount = 1", "[self.catalogQueue cancelAllOperations]", "operation:(NSOperation *)operation", "currentOperation.isCancelled", "_cachedIcons removeAllObjects")):
    raise SystemExit("error: Apps list catalog/search work must be bounded, cancellable and invalidate stale icon cache on app changes")
if not all(token in grid_table for token in ("catalogQueue", "maxConcurrentOperationCount=1", "[self.catalogQueue cancelAllOperations]", "operation:(NSOperation *)operation", "currentOperation.isCancelled")):
    raise SystemExit("error: Apps grid catalog/search work must be bounded and stop stale scans after a newer refresh")
if any(token in source for source in (app_table, grid_table) for token in ("[NSOperationQueue currentOperation]", "[NSOperation currentOperation]")):
    raise SystemExit("error: cancellation checks must use the explicitly passed NSOperation instance, not an unavailable current-operation class method")

# Certificate-backed CMS signing and mode/template UI checks.
signing_manager = (ROOT / "TrollStore/TSSigningManager.m").read_text(encoding="utf-8")
signing_ui = (ROOT / "TrollStore/TSSigningSettingsController.m").read_text(encoding="utf-8")
apple_internal_template = json.loads((ROOT / "TrollStore/Resources/SigningTemplates/apple-internal-profile-template.json").read_text(encoding="utf-8"))
if apple_internal_template.get("schema") != "ldid.custom-signature" or apple_internal_template.get("appleInternalProfile", {}).get("enabled") is not True or apple_internal_template.get("validation", {}).get("checkCertificateChain") is not True or apple_internal_template.get("validation", {}).get("requireChainToRoot") is not True:
    raise SystemExit("error: Apple Internal preset must enforce the uploaded ldid custom-signature policy and trusted-root certificate-chain validation")
if not all(token in signing_manager for token in ("apple-internal-profile", "AppleInternalProfile", "customSignatureTemplatePath", "developerCertificateCount", "cmsSignerCount", "hasSelectedCertificateData")):
    raise SystemExit("error: Apple Internal template must require a marked, unexpired profile and exact imported certificate evidence")
if "Apple Internal Development" not in signing_manager or not all(token in signing_ui for token in ("Apple Internal Profile", "AppleInternalProfile = true", "Required Profile Marker", "caveat")):
    raise SystemExit("error: signing UI must describe the Apple Internal marker and its special provisioning requirements")
if not all(token in root_helper for token in ("runAppleInternalProfileSignature", "--signature-apply", "customSignatureTemplatePath", "apple-internal-profile", "Apple Internal policy")):
    raise SystemExit("error: RootHelper must invoke the dedicated Apple Internal custom-signature policy, not ordinary CMS/ad-hoc signing")
if "apple-internal-profile" not in signing_manager or 'pathForResource:@"apple-internal-profile-template"' not in signing_manager:
    raise SystemExit("error: Apple Internal policy template resource must be staged into the protected signing runtime directory")
if 'initWithTitle:NSLocalizedString(@"Done", nil) style:UIBarButtonItemStyleDone target:self action:@selector(donePressed)' not in signing_ui:
    raise SystemExit("error: signing settings Done button must use the localized title initializer and preserve its done action")
if '"Done"' not in (ROOT / "TrollStore/Resources/zh-Hans.lproj/Localizable.strings").read_text(encoding="utf-8"):
    raise SystemExit("error: signing settings Done button must have a zh-Hans localization")
settings_source = (ROOT / "TrollStore/TSSettingsListController.m").read_text(encoding="utf-8")
helper_make = (ROOT / "RootHelper/Makefile").read_text(encoding="utf-8")
if not all(token in signing_manager for token in ("SecPKCS12Import", "importPEMCertificateData", "TSSigningCredentials", "TSSigningDefaultCredentialID", "kSecAttrAccessibleWhenUnlockedThisDeviceOnly", "templateDefinitionsForMode", "jobs", "p12", "privateKey", "TSExtractProvisioningProfileCMSContent", "DeveloperCertificates", "TSDERFromPEM(NSData *pemData);", "provisioningProfileDetailsForCredentialIdentifier")):
    raise SystemExit("error: signing manager must support P12/PEM identities, secure key storage, signing profiles and validation")
if not all(token in signing_ui for token in ("Import P12 Identity", "Import PEM Certificate + Key", "Import Provisioning Profile", "Real Signing", "TrollStore Signing", "UIColor.systemRedColor", "Issuer", "Validity Period", "OIDs", "Valid From", "Valid Until", "View Certificate Details", "View Provisioning Profile Details", "Profile Entitlements", "Certificates Included in Profile", "Delete Certificate", "Use This Template", "Requested ldid Jobs", "UITableViewAutomaticDimension")):
    raise SystemExit("error: signing UI must expose mode selection, import/delete, template detail/caveat and issuer/date/OID certificate details")
if 'signingMethodAndCertificatesPressed' not in settings_source or 'Signing Method & Certificates' not in settings_source:
    raise SystemExit("error: Settings must link to the signing method and certificate manager")
if 'TrollStore/TSApplicationsManager.m' in str(ROOT) and 'prepareRootHelperSigningConfiguration' not in manager:
    raise SystemExit("error: installs must pass an immutable signing-configuration snapshot to RootHelper")
if 'Security' not in app_make or 'Security' not in helper_make:
    raise SystemExit("error: both the app and RootHelper must link Security.framework")
if '$(HELPER_NAME)_LDFLAGS = -L../ChOma/external/ios -lcrypto' not in helper_make or '$(HELPER_NAME)_LIBRARIES = archive' not in helper_make or '$(HELPER_NAME)_LIBRARIES += crypto' in helper_make:
    raise SystemExit("error: RootHelper must use the upstream ChOma static libcrypto linker configuration")
if '#import <Security/CMSDecoder.h>' in signing_manager or 'CMSDecoderCreate' in signing_manager:
    raise SystemExit("error: iOS profile parsing must not depend on the macOS-only CMSDecoder API")
if not all(token in root_helper for token in (
    'NSMutableArray *recursiveArguments = [NSMutableArray arrayWithObjects:@"-M", @"--deep", nil];',
    '[recursiveArguments addObject:@"--super-deep"];',
    '[recursiveArguments addObject:appPath];',
    'runLdidWithSigningConfiguration(recursiveArguments, &signOutput, nil)',
)):
    raise SystemExit("error: Real Signing and Pure Certificate Signing must use the configurable recursive ldid bundle path")
if not all(token in root_helper for token in (
    'static BOOL ldidSupportsSignatureApplyDeepOptions(void)',
    '[binary rangeOfData:marker options:0 range:NSMakeRange(0, binary.length)]',
    'arrayWithObjects:@"--signature-apply", templatePath, bundlePath, nil',
    'if (ldidSupportsSignatureApplyDeepOptions())',
    '[arguments addObject:@"--deep"]',
    '[arguments addObject:@"--super-deep"]',
    "continuing with the template's existing signing scope",
)):
    raise SystemExit("error: Apple Internal custom signatures must capability-gate recursive-depth options")
if '@[@"--signature-validate", appPath]' not in root_helper:
    raise SystemExit("error: both real-signing paths must run the post-signature validator")
real_sign_start = root_helper.find('static int signAdhocInternal(NSString *filePath')
real_sign_block = root_helper[real_sign_start:root_helper.find('static NSUInteger signWorkerCount', real_sign_start)]
if "CMS mode is selected by the profile's P12 or PEM identity. Never add -s here." not in real_sign_block:
    raise SystemExit("error: true signing must not add the ad-hoc -s option")
if 'if (status == errSecSuccess && result)' not in signing_manager or 'kSecValueData' not in signing_manager:
    raise SystemExit("error: certificate and private-key material must be stored in Keychain")
if 'setDefaultCredentialIdentifier:identifier' not in signing_manager or 'records.firstObject' not in signing_manager:
    raise SystemExit("error: first imported certificate must become default and a deleted default must fall back to the first remaining identity")
if len(re.findall(r'case 173\s*:', manager)) != 1:
    raise SystemExit("error: installation error switch must have exactly one case 173")
if 'if (![mode isEqualToString:@"real"]) {' not in signing_manager or 'return @"trollstore-default";' not in signing_manager or 'if (![mode isEqualToString:@"real"]) return @[];' in signing_manager:
    raise SystemExit("error: TrollStore signing must use a fixed internal default and must not expose user-selectable templates")
if 'return @[];' not in signing_manager[signing_manager.find('+ (NSArray<NSDictionary *> *)templateDefinitionsForMode:'):signing_manager.find('+ (NSDictionary *)certificateDetailsForCredentialIdentifier:')]:
    raise SystemExit("error: template definitions must be empty for TrollStore ad-hoc mode")
if 'Fixed internal TrollStore ad-hoc defaults: SHA-256 and four ldid workers.' not in signing_manager or 'template = @{@"id":@"trollstore-default", @"hashType":@"sha256", @"jobs":@4};' not in signing_manager:
    raise SystemExit("error: TrollStore signing must build its fixed SHA-256/four-worker profile internally")
signing_sections = signing_ui[signing_ui.find('- (NSInteger)numberOfSectionsInTableView:'):signing_ui.find('- (NSInteger)tableView:', signing_ui.find('- (NSInteger)numberOfSectionsInTableView:'))]
if not all(token in signing_sections for token in ('if ([mode isEqualToString:@"real"]) return 4;', 'if ([mode isEqualToString:@"certificate-only"]) return 3;', 'return 2;')):
    raise SystemExit("error: signing settings must retain the mode-specific certificate/template sections and add the independent CodeDirectory flags section")
if 'TSOptionalCodeDirectoryFlags' not in signing_ui or 'codeDirectoryFlagChanged:' not in signing_ui or 'TSSigningCodeDirectoryFlags' not in signing_ui or 'ldidProfile[@"flags"]' not in signing_manager:
    raise SystemExit("error: independent persistent CodeDirectory flag switches must feed ldid profile flags")
if 'TSCertificateFieldsFromDER' not in signing_manager or 'TSCollectX509ExtensionOIDs' not in signing_manager or 'TSOIDStringFromDER' not in signing_manager:
    raise SystemExit("error: iOS certificate detail parser must extract X.509 issuer, validity and DER OIDs")
if 'SecCertificateCopyValues(' in signing_manager:
    raise SystemExit("error: macOS-only SecCertificateCopyValues must not be used in the iOS app")
if 'TSDisplayDate(notBeforeDate)' not in signing_manager or 'TSDisplayDate(notAfterDate)' not in signing_manager or 'sortedArrayUsingSelector:@selector(compare:)' not in signing_manager:
    raise SystemExit("error: certificate validity dates and ordered OID list must be extracted")
if signing_manager.count('NSString *ldidConfigPath') != 1 or 'ldidConfigPath = [runtime stringByAppendingPathComponent:' not in signing_manager:
    raise SystemExit("error: ldidConfigPath must be declared once and assigned without redeclaration")
if 'configuration[@"provisioningProfilePath"]' not in signing_manager or 'embedded.mobileprovision' not in root_helper:
    raise SystemExit("error: per-identity provisioning profile must be passed through and embedded in the app")
if '@"adhoc": @(!certificateSigning)' not in signing_manager or 'BOOL certificateSigning = [mode isEqualToString:@"real"] || pureCertificateSigning;' not in signing_manager:
    raise SystemExit("error: Real and Pure Certificate modes must select CMS signing, while TrollStore mode alone selects ad-hoc signing")
real_cms_guard = root_helper.find('if (realSigningMode) {', root_helper.find('int signApp(NSString* appPath)', root_helper.find('int signApp(NSString* appPath)') + 1))
coretrust_pass = root_helper.find('// Apply CoreTrust bypass', real_cms_guard)
if real_cms_guard < 0 or coretrust_pass < 0 or 'Genuine CMS signatures must never be rewritten by TrollStore' not in root_helper[real_cms_guard:coretrust_pass] or 'return 0;' not in root_helper[real_cms_guard:coretrust_pass]:
    raise SystemExit("error: real CMS path must return before the TrollStore CoreTrust bypass")
if 'currentOSSupportsBundledLdid' not in root_helper or 'if (@available(iOS 16.0, *)) return YES;' not in root_helper or 'case 195:' not in manager or 'iOS 16.0 or later' not in manager:
    raise SystemExit("error: the supplied ldid must be guarded for its declared iOS 16.0 minimum runtime")
if 'if (realSigningMode && !isLdidInstalled())' not in root_helper or 'if (realSigningMode && !currentOSSupportsBundledLdid())' not in root_helper:
    raise SystemExit("error: certificate signing must separately reject an uninitialized or unsupported bundled ldid before signing")
if 'TSKeychainDelete([identifier stringByAppendingString:@".identity"])' not in signing_manager or 'TSKeychainDelete([identifier stringByAppendingString:@".password"])' not in signing_manager:
    raise SystemExit("error: deleting a certificate must also delete its Keychain identity/private-key and password records")

print(f"[audit] {len(REQUIRED)} required files present")
print("[audit] video-matched app UI; App Intents refresh shortcut; framework presets with dylib compatibility; parallel independent signing; import cleanup; donation controller removed")
print(f"[audit] {len(plists)} plists and {len(strings_files)} strings resources validated")
print(f"[audit] {len(app_keys)} matching zh-Hans localization keys validated; {len(chinese_values)} translated values contain Chinese characters")
print("[audit] ChOma pin, supplied precompiled ldid, iOS vm_map.h/vm_read_overwrite API, embedded Security.framework linkage, complete per-install main-app Entitlements editor, retry state retention, default-off auto-init, app source catalog, per-app Home Screen deletion protection, stealth install, Mach-O prefilter, optimized Objective-C/C targets, and self-update association validated")


# Video-aligned four-tab UI, per-app reversible update controls, and the local-only plugin store.
root_ui = (ROOT / "TrollStore/TSRootViewController.m").read_text(encoding="utf-8")
if "TSPluginStoreController" not in root_ui or "case 2:" not in root_ui or "case 3:" not in root_ui:
    raise SystemExit("error: custom root navigation must expose Apps, Packages, Plugins, Settings")
if not all(token in root_ui for token in ("NSMutableArray *tabControllers", "[NSNull null]", "tabControllerAtIndex:", "self.tabControllers[index] = navigationController")):
    raise SystemExit("error: tab navigation stacks must be created on first access and cached in stable slots")
if re.search(r"for\s*\([^)]*\s+in\s+self\.loadedTabIndexes", root_ui):
    raise SystemExit("error: NSMutableIndexSet does not support Objective-C fast enumeration; use index iteration")
if root_ui.count("[self.loadedTabIndexes firstIndex]") != 2 or root_ui.count("indexGreaterThanIndex:index") != 2:
    raise SystemExit("error: loaded tab index iteration must use the NSIndexSet API in layout and safe-area updates")
if "UITabBarController" in root_ui or "animationControllerForTransitionFromViewController" in root_ui:
    raise SystemExit("error: previous system-tab/custom-animator overlay architecture is still present")
scene_source = (ROOT / "TrollStore/TSSceneDelegate.m").read_text(encoding="utf-8")
if not all(marker in scene_source for marker in ("prepareWindowForLaunch:_window", "loadViewIfNeeded", "makeKeyAndVisible")):
    raise SystemExit("error: launch must prepare theme and build the replacement root before the first visible frame")
update_helper = (ROOT / "RootHelper/TSAppUpdateControl.m").read_text(encoding="utf-8")
for marker in ("iTunesMetadata.plist", "iTunesMetadata_blocked.plist", "TS_MARKER", "TS_LITE_MARKER", "_LSPrivateRebuildApplicationDatabasesForSystemApps", "getKnowledgeUUID:andSequenceNumber:", "stableSamples >= 3", "rename(", "unlink("):
    if marker not in update_helper: raise SystemExit(f"error: per-app update control is missing safety/restore marker {marker}")
if "Both normal and blocked metadata files exist" in update_helper:
    raise SystemExit("error: stale reinstall metadata must be recoverable instead of permanently wedging update state")
plugin_ui = (ROOT / "TrollStore/TSPluginStoreController.m").read_text(encoding="utf-8")
for marker in (".dylib", ".framework", "deb", "zip", "Delete Plugin", "Delete Imported Files", "importPluginAtURL", "refreshLocalLibrary"):
    if marker not in plugin_ui: raise SystemExit(f"error: local plugin store is missing {marker}")
if any(token in plugin_ui for token in ("NSURLSession", "TSPluginRepositoryManager", "refreshRepositories", "addRepository", "remotePackages", "trollpackages.json", "https://")):
    raise SystemExit("error: plugin library must remain local-only and must not contain online repository code")
maintenance = (ROOT / "RootHelper/TSAppMaintenance.m").read_text(encoding="utf-8")
if any(token in maintenance for token in ("TSMachODependencyResolver", "TweakRuntime", "extraPayloads", "additionalPayloadsForPluginAtPath")):
    raise SystemExit("error: RootHelper must not auto-resolve or bundle jailbreak runtime/dependency payloads")
if "No additional jailbreak runtime or dependency was bundled or added." not in maintenance:
    raise SystemExit("error: injection result must disclose that jailbreak runtimes/dependencies are not auto-added")
if (ROOT / "TrollStore/TSPluginRepositoryManager.m").exists() or (ROOT / "RootHelper/TSMachODependencyResolver.m").exists() or (ROOT / "TrollStore/Resources/TweakRuntime").exists():
    raise SystemExit("error: removed repository manager or jailbreak runtime bundle is still present")

# RootHelper/main.m previously regressed with a block-scoped marker URL used by
# later rollback paths and an unmatched trailing #endif. Catch both before Theos.
root_helper_main = (ROOT / "RootHelper/main.m").read_text(encoding="utf-8")
preprocessor_stack = []
for line_number, line in enumerate(root_helper_main.splitlines(), 1):
    directive = re.match(r"^\s*#\s*(if|ifdef|ifndef|elif|else|endif)\b", line)
    if not directive:
        continue
    kind = directive.group(1)
    if kind in ("if", "ifdef", "ifndef"):
        preprocessor_stack.append(line_number)
    elif kind in ("elif", "else"):
        if not preprocessor_stack:
            raise SystemExit(f"error: orphan #{kind} in RootHelper/main.m at line {line_number}")
    elif kind == "endif":
        if not preprocessor_stack:
            raise SystemExit(f"error: unmatched #endif in RootHelper/main.m at line {line_number}")
        preprocessor_stack.pop()
if preprocessor_stack:
    raise SystemExit(f"error: unclosed preprocessor block(s) in RootHelper/main.m at lines {preprocessor_stack}")
marker_declaration = root_helper_main.find("NSURL *nonDeletableMarkerURL = nil;")
marker_assignment = root_helper_main.find("nonDeletableMarkerURL = [appContainer.url URLByAppendingPathComponent:TS_NON_DELETABLE_MARKER];")
if marker_declaration < 0 or marker_assignment < marker_declaration:
    raise SystemExit("error: nonDeletableMarkerURL must be function-scoped and initialized before install rollback paths")
if root_helper_main.count("removeItemAtURL:nonDeletableMarkerURL") < 4:
    raise SystemExit("error: install rollback paths must consistently remove only the transaction-owned non-deletable marker")
print("[audit] RootHelper/main.m preprocessor nesting and install-marker rollback scope validated")

# Objective-C ARC rejects forward gotos that bypass initialization of strong
# locals. RootHelper archive extraction uses a single-exit do/while scope so
# validation errors leave via break and still run ARC scope cleanup.
unarchive_source = (ROOT / "RootHelper/unarchive.m").read_text(encoding="utf-8")
extract_start = unarchive_source.find("int extract(NSString *fileToExtract, NSString *extractionPath)")
if extract_start < 0:
    raise SystemExit("error: RootHelper archive extractor implementation is missing")
extract_function = unarchive_source[extract_start:]
if re.search(r"\bgoto\s+[A-Za-z_][A-Za-z0-9_]*\s*;", extract_function) or re.search(r"^\s*[A-Za-z_][A-Za-z0-9_]*\s*:\s*$", extract_function, re.M):
    raise SystemExit("error: RootHelper extract() must not use goto/cleanup labels across ARC-managed locals")
if "do {" not in extract_function or "} while (0);" not in extract_function or "NSMutableSet<NSString *> *seenPaths = [NSMutableSet set];" not in extract_function:
    raise SystemExit("error: RootHelper extract() must use the ARC-safe single-exit scope and initialize seenPaths inside it")
print("[audit] RootHelper/unarchive.m ARC-safe cleanup control flow validated")
