#!/usr/bin/env python3
"""Static integrity checks for the restored original TrollStore UI + zh-Hans build."""
from pathlib import Path
import hashlib
import json
import plistlib
import re
import struct
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
PINNED_CHOMA = "964023ddac2286ef8e843f90df64d44ac6a673df"
REQUIRED = [
    "Makefile", "CHOMA-COMMIT.txt", ".gitmodules", "README.md",
    "TrollStore/Makefile", "TrollStore/main.m", "TrollStore/TSRootViewController.m",
    "TrollStore/TSAppTableViewController.m", "TrollStore/TSAppInfo.m",
    "TrollStore/TSApplicationsManager.m", "TrollStore/TSInstallationController.m",
    "TrollStore/TSSettingsListController.m", "TrollStore/TSSettingsAdvancedListController.m",
    "TrollStore/TSEntitlementsEditorViewController.h", "TrollStore/TSEntitlementsEditorViewController.m", "TrollStore/entitlements.plist",
    "TrollStore/Resources/Info.plist",
    "TrollStore/Resources/zh-Hans.lproj/Localizable.strings",
    "TrollStore/Resources/zh-Hans.lproj/InfoPlist.strings",
    "RootHelper/Makefile", "RootHelper/main.m", "RootHelper/entitlements.plist",
    "TrollHelper/Makefile", "TrollHelper/main.m", "TrollHelper/TSHRootViewController.m",
    "TrollHelper/Resources/Info.plist", "TrollHelper/entitlements.plist",
    "TrollHelper/Resources/zh-Hans.lproj/Localizable.strings",
    "TrollHelper/Resources/zh-Hans.lproj/InfoPlist.strings",
    "Shared/TSUtil.h", "Shared/TSUtil.m", "Shared/TSListControllerShared.m",
    "Shared/TSPresentationDelegate.m", "Exploits/fastPathSign/Makefile",
    "Exploits/fastPathSign/src/coretrust_bug.c", "Exploits/fastPathSign/src/codesign.m",
    "Scripts/bootstrap_choma.sh", "Scripts/validate_choma_api.py", "Scripts/validate_macho.py",
    "Scripts/validate_project.py", "bin/ldid", "bin/ldid.sha256", "ldid.cpp", "ldid.hpp", "ldid-reference/README.md", "ldid-reference/ldid-custom-signature-cli-2026-10-30.zip",
    "TrollStore/TSAppRepackager.m", "TrollStore/TSArchiveExtractor.m",
    "TrollStore/TSIPAPackageStore.m", "TrollStore/TSAppDecryptor.m",
    "TrollStore/TSTweakInjector.m", "TrollStore/TSAppCollectionViewController.m",
    "TrollStore/TSThemeManager.m", "TrollStore/TSAppearanceController.m",
    "TrollStore/TSAppRepackager.h", "TrollStore/TSArchiveExtractor.h", "TrollStore/TSIPAPackageStore.h",
    "TrollStore/TSAppDecryptor.h", "TrollStore/TSTweakInjector.h", "TrollStore/TSAppCollectionViewController.h",
    "TrollStore/TSThemeManager.h", "TrollStore/TSAppearanceController.h",
    "TrollStore/TSSigningManager.h", "TrollStore/TSSigningManager.m",
    "TrollStore/TSSigningSettingsController.h", "TrollStore/TSSigningSettingsController.m",
    "ldid-reference/CUSTOM-SIGNATURE-CLI-2026-10-30.md",
    "ldid-reference/build_libs-2026-10-30.yml",
    "ldid-reference/ldid-custom-signature-cli-2026-10-30.zip",
    "RootHelper/TSAppMaintenance.h", "RootHelper/TSAppDecryptor.h",
    "RootHelper/TSAppMaintenance.m", "RootHelper/TSAppDecryptor.m",
    "TweakPresets/AppLock/Makefile", "TweakPresets/AppLock/Tweak.m",
    "TweakPresets/BackgroundAssist/Makefile", "TweakPresets/BackgroundAssist/Tweak.m",
    "TweakPresets/PreventUninstall/README.md", "TweakPresets/README.md",
    "BUILD-FIX-2026-10-31-zh-Hans.md",
]
missing = [item for item in REQUIRED if not (ROOT / item).is_file()]
if missing:
    raise SystemExit("error: missing required project files: " + ", ".join(missing))

# This project is intentionally Objective-C/C-only. A stale Swift file would
# otherwise cause Theos to invoke generate-output-file-map and fail the build.
swift_sources = sorted(str(p.relative_to(ROOT)) for p in ROOT.rglob("*.swift"))
if swift_sources:
    raise SystemExit(f"error: this project must contain no Swift sources: {swift_sources}")

for rel in ("Makefile", "CHOMA-COMMIT.txt", "Scripts/bootstrap_choma.sh", "Scripts/validate_choma_api.py"):
    if PINNED_CHOMA not in (ROOT / rel).read_text(encoding="utf-8"):
        raise SystemExit(f"error: {rel} does not pin compatible ChOma revision {PINNED_CHOMA}")
root_make = (ROOT / "Makefile").read_text(encoding="utf-8")
helper_make = (ROOT / "TrollHelper/Makefile").read_text(encoding="utf-8")
if "TrollStorePersistenceHelper_FRAMEWORKS = UIKit CoreGraphics CoreServices CoreTelephony Security" not in helper_make:
    raise SystemExit("error: embedded TrollHelper must link Security.framework for RootHelper sources")
app_make = (ROOT / "TrollStore/Makefile").read_text(encoding="utf-8")
if "build-fastpaths: validate-project bootstrap-deps check-build-tools" not in root_make or "python3 ./Scripts/validate_project.py" not in root_make or "python3 ./Scripts/validate_macho.py \"$(LDID_BIN)\"" not in root_make:
    raise SystemExit("error: deterministic project and ldid validation must run before the Apple build toolchain")
if "build-fastpaths: validate-project bootstrap-deps check-build-tools" not in root_make or "build-targets: build-presets" not in root_make or "build-presets: build-fastpaths" not in root_make:
    raise SystemExit("error: dependency bootstrap / preset / compile order is incomplete")
for marker in (
    '[build] RootHelper', '[build] TrollStore', '[build] TrollHelper (embedded root helper)',
    '--jobs=$(BUILD_JOBS) -C ./RootHelper', '--jobs=$(BUILD_JOBS) -C ./TrollStore',
    '--jobs=$(BUILD_JOBS) -C ./TrollHelper',
):
    if marker not in root_make:
        raise SystemExit("error: build targets must run sequentially with per-target jobs and explicit diagnostics")
if '& p1=$$!' in root_make or 'wait $$p1' in root_make:
    raise SystemExit("error: backgrounded target builds hide subproject errors; build sequentially instead")
if "TrollStore_FILES = $(wildcard *.m) $(wildcard ../Shared/*.m)" not in app_make:
    raise SystemExit("error: Objective-C implementation files are not included in the TrollStore app target")
if "SWIFT_" in app_make:
    raise SystemExit("error: TrollStore Makefile must not reference Swift build settings")

# Every shipped iOS target is intentionally iOS 16+, and macOS preset builds
# must use the host codesign tool rather than the bundled iOS-only ldid binary.
for rel in (
    "TrollStore/Makefile", "RootHelper/Makefile", "TrollHelper/Makefile",
    "TweakPresets/AppLock/Makefile", "TweakPresets/BackgroundAssist/Makefile",
):
    makefile = (ROOT / rel).read_text(encoding="utf-8")
    if not re.search(r"^TARGET\s*:?=\s*iphone:clang:[^:\s]+:16\.0\s*$", makefile, re.M):
        raise SystemExit(f"error: {rel} must target iOS 16.0 or later")
for rel in ("TweakPresets/AppLock/Makefile", "TweakPresets/BackgroundAssist/Makefile"):
    makefile = (ROOT / rel).read_text(encoding="utf-8")
    if "TARGET_CODESIGN = /usr/bin/codesign" not in makefile or "TARGET_CODESIGN_FLAGS = --force --sign -" not in makefile:
        raise SystemExit(f"error: {rel} must use macOS host codesign with ad-hoc identity; never invoke the device ldid")
background_tweak = (ROOT / "TweakPresets/BackgroundAssist/Tweak.m").read_text(encoding="utf-8")
if "static UIBackgroundTaskIdentifier TSBackgroundTask = UIBackgroundTaskInvalid;" in background_tweak:
    raise SystemExit("error: UIBackgroundTaskInvalid must not be used as a file-scope initializer")
if "static UIBackgroundTaskIdentifier TSBackgroundTask;" not in background_tweak or "static BOOL TSBackgroundTaskActive;" not in background_tweak:
    raise SystemExit("error: BackgroundAssist must use zero-initialized task storage and an explicit active flag")
if "if (!TSBackgroundTaskActive) return;" not in background_tweak or "TSBackgroundTaskActive = YES;" not in background_tweak:
    raise SystemExit("error: BackgroundAssist task lifecycle must be guarded by the active flag")
if "/usr/bin/codesign is required for Theos tweak preset signing" not in root_make:
    raise SystemExit("error: build prerequisite must explicitly check macOS host codesign")

if any(p.name == ".Assets" for p in ROOT.rglob("*")):
    raise SystemExit("error: a .Assets path is not allowed")
if any("Donate" in p.name or "donat" in p.name.lower() for p in ROOT.rglob("*")):
    raise SystemExit("error: donation feature source remains in the project")
if (ROOT / "TrollStore/TSDonateListController.m").exists() or (ROOT / "TrollStore/TSDonateListController.h").exists():
    raise SystemExit("error: original donation controller was not removed")

plists = sorted(ROOT.rglob("*.plist"))
for path in plists:
    try:
        with path.open("rb") as stream:
            plistlib.load(stream)
    except Exception as exc:
        raise SystemExit(f"error: invalid plist {path.relative_to(ROOT)}: {exc}")

app_info = plistlib.loads((ROOT / "TrollStore/Resources/Info.plist").read_bytes())
helper_info = plistlib.loads((ROOT / "TrollHelper/Resources/Info.plist").read_bytes())
if app_info.get("CFBundleExecutable") != "TrollStore" or app_info.get("CFBundleIdentifier") != "com.opa334.TrollStore":
    raise SystemExit("error: main app bundle identity has changed")
if not {"trollstorehelper", "ldid"}.issubset(set(app_info.get("TSRootBinaries", []))):
    raise SystemExit("error: TSRootBinaries must include trollstorehelper and ldid")
if not any("public.tar-archive" in entry.get("LSItemContentTypes", []) for entry in app_info.get("CFBundleDocumentTypes", [])):
    raise SystemExit("error: original .tar self-update document association has been lost")
if helper_info.get("CFBundleExecutable") != "TrollStorePersistenceHelper":
    raise SystemExit("error: persistence helper bundle identity has changed")
for label, info in (("TrollStore", app_info), ("TrollHelper", helper_info)):
    if info.get("CFBundleDevelopmentRegion") != "zh-Hans":
        raise SystemExit(f"error: {label} must use zh-Hans as its default/fallback language")
    if info.get("CFBundleLocalizations") != ["zh-Hans"]:
        raise SystemExit(f"error: {label} must advertise zh-Hans as the only bundled localization so Chinese is visible on English devices too")

# The provided binary is the sole ldid source. Build assembly packages it dormant,
# and only the explicit/default-off initialization flow places it at the active path.
ldid = ROOT / "bin/ldid"
if ldid.stat().st_size < 1024 * 1024 or not (ldid.stat().st_mode & 0o111):
    raise SystemExit("error: bin/ldid must be an executable precompiled device binary")
expected_ldid_sha256 = (ROOT / "bin/ldid.sha256").read_text(encoding="utf-8").split()[0]
actual_ldid_sha256 = hashlib.sha256(ldid.read_bytes()).hexdigest()
if actual_ldid_sha256 != expected_ldid_sha256:
    raise SystemExit(f"error: supplied ldid checksum mismatch: {actual_ldid_sha256}")
root_make = (ROOT / "Makefile").read_text(encoding="utf-8")
helper_make = (ROOT / "TrollHelper/Makefile").read_text(encoding="utf-8")
if "TrollStorePersistenceHelper_FRAMEWORKS = UIKit CoreGraphics CoreServices CoreTelephony Security" not in helper_make:
    raise SystemExit("error: embedded TrollHelper must link Security.framework for RootHelper sources")
if 'cp "$(LDID_BIN)" "$$APP_DIR/ldid-bootstrap/ldid"' not in root_make:
    raise SystemExit("error: Makefile must stage the supplied ldid in ldid-bootstrap/ldid")
if 'cp "$(LDID_BIN)" "$$APP_DIR/ldid"' in root_make:
    raise SystemExit("error: the supplied ldid must not be active by default")

# Validate OpenStep .strings syntax using plutil and make sure every source key is present.
strings_files = [
    ROOT / "TrollStore/Resources/zh-Hans.lproj/Localizable.strings",
    ROOT / "TrollHelper/Resources/zh-Hans.lproj/Localizable.strings",
    ROOT / "TrollStore/Resources/zh-Hans.lproj/InfoPlist.strings",
    ROOT / "TrollHelper/Resources/zh-Hans.lproj/InfoPlist.strings",
]
for path in strings_files:
    result = subprocess.run(["plutil", "-lint", "--", str(path)], text=True, capture_output=True)
    if result.returncode:
        raise SystemExit(f"error: invalid strings resource {path.relative_to(ROOT)}: {result.stderr.strip() or result.stdout.strip()}")

def decode_quoted(value):
    try:
        return json.loads('"' + value + '"')
    except Exception:
        return value

def catalog_entries(path):
    entries = {}
    pattern = re.compile(r'\s*"((?:\\.|[^"\\])*)"\s*=\s*"((?:\\.|[^"\\])*)"\s*;')
    for line in path.read_text(encoding="utf-8").splitlines():
        m = pattern.match(line)
        if m:
            entries[decode_quoted(m.group(1))] = decode_quoted(m.group(2))
    return entries

def catalog_keys(path):
    return set(catalog_entries(path))

source_keys = set()
source_extensions = {".m", ".h"}
for path in ROOT.rglob("*"):
    if path.is_file() and path.suffix in source_extensions and any(part in {"TrollStore", "TrollHelper", "Shared"} for part in path.parts):
        text = path.read_text(encoding="utf-8", errors="replace")
        for match in re.finditer(r'NSLocalizedString\(@"((?:\\.|[^"\\])*)"\s*,', text):
            source_keys.add(decode_quoted(match.group(1)))
app_entries = catalog_entries(strings_files[0])
helper_entries = catalog_entries(strings_files[1])
app_keys = set(app_entries)
helper_keys = set(helper_entries)
chinese_values = [value for value in app_entries.values() if any("\u4e00" <= char <= "\u9fff" for char in value)]
if len(chinese_values) < 100:
    raise SystemExit(f"error: zh-Hans catalog appears untranslated; found only {len(chinese_values)} values containing Chinese characters")
missing_app = sorted(source_keys - app_keys)
missing_helper = sorted(source_keys - helper_keys)
if missing_app or missing_helper:
    missing = sorted(set(missing_app + missing_helper))
    raise SystemExit("error: zh-Hans catalog lacks source keys: " + repr(missing[:12]))
if app_keys != helper_keys:
    raise SystemExit("error: app and persistence-helper localization catalogs diverge")

# Ensure Entitlements editing is available both in the pre-install flow and Settings,
# the bundled custom ldid has no upstream check/download path, and app categories are split.
settings = (ROOT / "TrollStore/TSSettingsListController.m").read_text(encoding="utf-8")
installation = (ROOT / "TrollStore/TSInstallationController.m").read_text(encoding="utf-8")
scene = (ROOT / "TrollStore/TSSceneDelegate.m").read_text(encoding="utf-8")
app_table = (ROOT / "TrollStore/TSAppTableViewController.m").read_text(encoding="utf-8")
manager = (ROOT / "TrollStore/TSApplicationsManager.m").read_text(encoding="utf-8")
root_helper = (ROOT / "RootHelper/main.m").read_text(encoding="utf-8")
editor = (ROOT / "TrollStore/TSEntitlementsEditorViewController.m").read_text(encoding="utf-8")
codesign = (ROOT / "Exploits/fastPathSign/src/codesign.m").read_text(encoding="utf-8")
if 'NSLocalizedString(@"Edit Entitlements Before Install", nil)' not in installation or 'NSClassFromString(@"TSEntitlementsEditorViewController")' not in installation:
    raise SystemExit("error: Entitlements editor must be linked from the IPA pre-install flow")
if 'editCustomEntitlementsPressed' not in settings or 'TSEntitlementsEditorViewController' not in settings or 'Apply saved Entitlements on next install' not in settings:
    raise SystemExit("error: Settings must expose the Entitlements editor and next-install switch")
if 'setCustomEntitlementsEnabled:forSpecifier:' not in settings or 'TSCustomEntitlementsOverrideEnabled' not in settings:
    raise SystemExit("error: Settings Entitlements switch is not wired to the one-install override")
if 'customEntitlementsEnabledSpecifier setProperty:@NO forKey:@"default"' not in settings:
    raise SystemExit("error: custom Entitlements apply switch must default to off")
if 'NSString* saveTitle = self.onSave ? NSLocalizedString(@"Save & Install"' not in editor or 'NSLocalizedString(@"Save", nil)' not in editor:
    raise SystemExit("error: Entitlements editor must show Save in Settings and Save & Install for IPA flow")
if 'AutoInitializeBundledLdid' not in settings or 'return value ?: @NO;' not in settings or 'AutoInitializeBundledLdid' not in scene:
    raise SystemExit("error: bundled ldid auto-initialization setting is missing or does not default to off")
if 'handleLdidAutoInitialization' not in scene or 'isExecutableFileAtPath:activeLdidPath' not in scene:
    raise SystemExit("error: auto-initialization must only activate bundled ldid when the active executable is missing")
all_objc_sources = "\n".join(path.read_text(encoding="utf-8", errors="replace") for path in ROOT.rglob("*") if path.is_file() and path.suffix in {".m", ".h"})
if 'fetchLatestLdidVersion' in all_objc_sources or 'github.com/opa334/ldid' in all_objc_sources or 'ldid.version' in all_objc_sources:
    raise SystemExit("error: upstream ldid version-check/download/metadata code remains")
if 'TSCustomEntitlementsOverrideEnabled' not in manager or '--entitlements' not in manager or 'gCustomEntitlementsOverride' not in root_helper or 'TSCustomEntitlements.plist' not in editor:
    raise SystemExit("error: custom Entitlements path is incomplete")
if 'onSave' not in editor or 'handleAppInstallFromFile:pathToIPA completion:completionBlock' not in installation:
    raise SystemExit("error: Entitlements must be saved before install")
if 'installationMethod:(int)session.method' not in installation or 'preserveEntitlementsOverride:session.preserveEntitlementsOverride' not in installation or 'customEntitlementsPath:session.entitlementsPath' not in installation or 'stealthInstall:session.stealthInstall' not in installation:
    raise SystemExit("error: install retry must preserve the original installation parameters")
if 'setBool:NO forKey:@"TSCustomEntitlementsOverrideEnabled"' in manager or 'setBool:NO forKey:@"TSCustomEntitlementsOverrideEnabled"' not in installation:
    raise SystemExit("error: the one-shot Entitlements override must be consumed only by the installation controller")
if 'Retry with Custom' not in installation or 'Retry with installd' not in installation or 'retryCountsByError' not in installation or 'Copy Debug Log' not in installation:
    raise SystemExit("error: install error recovery/retry controls are incomplete")
if 'preserveEntitlementsOverride' not in manager or 'case 189:' not in manager or 'return 189;' not in root_helper or 'cleanup-install' not in root_helper:
    raise SystemExit("error: explicit installd failure and guarded cleanup path are incomplete")
if 'TSBundlePreSigned' not in root_helper or 'skipAdhocSigning' not in root_helper or 'codesign_sign_adhoc' not in root_helper or 'falling back to bundled ldid' not in root_helper:
    raise SystemExit("error: pre-signed fast path / OS-specific signer selection is incomplete")
if 'signedMachOPaths' not in root_helper or 'codeBundlePaths' not in root_helper or 'bundlesDeepestFirst' not in root_helper:
    raise SystemExit("error: nested Mach-O files and code bundles must be signed before outer resource sealing")
if 'CFErrorRef errors = NULL' not in codesign or 'if (errors) CFRelease(errors)' not in codesign:
    raise SystemExit("error: native signing failure handling must initialize and release returned CFError objects")
if 'NOTE: If the installd placeholder installation fails, TrollStore automatically falls back to using the Custom method.' in (ROOT / 'TrollStore/TSSettingsAdvancedListController.m').read_text(encoding="utf-8"):
    raise SystemExit("error: the installation-method setting must describe user-confirmed fallback, not silent fallback")
if 'Entitlements change: %lu keys overridden' not in installation or 'Merged Entitlements Preview' not in editor or 'Original Entitlements (read only)' not in editor or 'addEntriesFromDictionary:gCustomEntitlementsOverride' not in root_helper:
    raise SystemExit("error: Entitlements merge preview or runtime merge semantics are incomplete")
# iOS 16 SDK's nullability-completeness diagnostics are promoted to errors by this build.
# The manager exposes optional output/error paths, so express both pointer levels explicitly.
manager_header = (ROOT / "TrollStore/TSApplicationsManager.h").read_text(encoding="utf-8")
manager_impl = (ROOT / "TrollStore/TSApplicationsManager.m").read_text(encoding="utf-8")
if "NS_ASSUME_NONNULL_BEGIN" not in manager_header or "NS_ASSUME_NONNULL_END" not in manager_header:
    raise SystemExit("error: TSApplicationsManager public declarations must have a complete nullability context")
for marker in (
    "log:(NSString * _Nullable * _Nullable)logOut",
    "customEntitlementsPath:(NSString * _Nullable)entitlementsPath",
    "uninstallApp:(NSString * _Nullable)appId",
    "uninstallAppByPath:(NSString * _Nullable)path",
    "changeAppRegistration:(NSString * _Nullable)appPath toState:(NSString * _Nullable)newState",
):
    if marker not in manager_header:
        raise SystemExit("error: TSApplicationsManager nullable API contract is incomplete: " + marker)
for marker in (
    "log:(NSString * _Nullable * _Nullable)logOut",
    "uninstallApp:(NSString * _Nullable)appId",
    "uninstallAppByPath:(NSString * _Nullable)path",
    "changeAppRegistration:(NSString * _Nullable)appPath toState:(NSString * _Nullable)newState",
):
    if marker not in manager_impl:
        raise SystemExit("error: TSApplicationsManager implementation does not match nullability contract: " + marker)
grid_layout = (ROOT / "TrollStore/TSAppCollectionViewController.m").read_text(encoding="utf-8")
if "horizontalGroupWithLayoutSize:groupSize repeatingSubitem:item count:2" not in grid_layout:
    raise SystemExit("error: iOS 16+ collection layout must use the non-deprecated repeatingSubitem API")
if "horizontalGroupWithLayoutSize:groupSize subitem:item count:2" in grid_layout:
    raise SystemExit("error: deprecated NSCollectionLayoutGroup subitem selector remains")

# Objective-C UTType is an NSObject class: Swift static members such as
# UTType.image/data/archive/package are not Objective-C class properties.
objc_sources = "\n".join(
    path.read_text(encoding="utf-8")
    for path in sorted(list(ROOT.rglob("*.m")) + list(ROOT.rglob("*.h")))
)
if re.search(r"\bUTType\.(?:image|data|archive|package)\b", objc_sources):
    raise SystemExit("error: Swift-only UTType static members remain in Objective-C sources")
if "contentEdgeInsets" in objc_sources or "imageEdgeInsets" in objc_sources or "titleEdgeInsets" in objc_sources:
    raise SystemExit("error: deprecated UIButton inset properties remain in Objective-C sources")
root_controller_source = (ROOT / "TrollStore/TSRootViewController.m").read_text(encoding="utf-8")
if "UIButtonConfigurationImagePlacementLeading" in objc_sources:
    raise SystemExit("error: invalid UIButtonConfigurationImagePlacementLeading enum remains")
if "configuration.imagePlacement=NSDirectionalRectEdgeLeading" not in root_controller_source:
    raise SystemExit("error: floating dock must use NSDirectionalRectEdgeLeading for UIButtonConfiguration.imagePlacement")
appearance_source = (ROOT / "TrollStore/TSAppearanceController.m").read_text(encoding="utf-8")
if "UIButtonConfiguration plainButtonConfiguration" not in appearance_source or "NSDirectionalEdgeInsetsMake(0, 14, 0, 14)" not in appearance_source:
    raise SystemExit("error: appearance action buttons must use UIButtonConfiguration contentInsets")
for rel in ("TrollStore/TSIPAPackageStore.m", "TrollStore/TSTweakInjector.m", "TrollStore/TSSigningSettingsController.m", "TrollStore/TSAppearanceController.m"):
    source = (ROOT / rel).read_text(encoding="utf-8")
    if "[UTType typeWithIdentifier:@\"public.data\"]" not in source:
        raise SystemExit(f"error: {rel} must use Objective-C UTType lookup methods")

grid_table = (ROOT / "TrollStore/TSAppCollectionViewController.m").read_text(encoding="utf-8")
if 'NSLocalizedString(@"TrollStore", nil)' not in app_table or 'NSLocalizedString(@"App Store", nil)' not in app_table or 'NSLocalizedString(@"System", nil)' not in app_table:
    raise SystemExit("error: application source filtering must expose TrollStore, App Store, and System categories")
if 'enumerateApplicationsOfType:type' not in app_table or '(category == 1 ? 0 : 1)' not in app_table or '_cachedSystemAppCatalog' not in app_table:
    raise SystemExit("error: App Store and System catalogs must be separately enumerated and cached")
if 'TSAppSourceCategory' not in app_table or 'TSAppSourceCategory' not in grid_table or '_sourceCategory != 0' not in app_table or '_sourceCategory != 2' not in app_table:
    raise SystemExit("error: application source filtering and per-category actions are not persisted/guarded")
if 'canEditRowAtIndexPath' not in app_table or 'return _sourceCategory == 0;' not in app_table or 'if(_sourceCategory != 0) return;' not in app_table:
    raise SystemExit("error: App Store/System lists must not expose TrollStore uninstall/registration actions")
if 'TSStealthInstallEnabled' not in settings or 'TSStealthInstallEnabled' not in manager or 'BOOL stealthInstall' not in root_helper or 'TSOriginalBundleIdentifier' not in root_helper or 'return 188' not in root_helper:
    raise SystemExit("error: opt-in stealth installation flow is incomplete")
if 'TS%016llX' not in root_helper or 'TS_%016llX' in root_helper:
    raise SystemExit("error: stealth bundle identifier suffix must use a conventional alphanumeric component")
if 'TS_ACTIVE_MARKER' not in (ROOT / 'Shared/TSUtil.m').read_text() or 'Only consider apps installed in a TrollStore-managed container' not in (ROOT / 'Shared/TSUtil.m').read_text():
    raise SystemExit("error: stealth update discovery must only match TrollStore-managed app containers")
if 'OPTFLAG = -O3' not in app_make or 'OPTFLAG = -O3' not in (ROOT / 'RootHelper/Makefile').read_text() or 'OPTFLAG = -O3' not in (ROOT / 'TrollHelper/Makefile').read_text() or '-O3' not in (ROOT / 'Exploits/fastPathSign/Makefile').read_text():
    raise SystemExit("error: speed-oriented production compiler flags are not enabled for all iOS targets")
if 'filteredAppInfosFromCatalog' not in app_table or '_cachedTrollStoreAppCatalog' not in app_table or '_cachedAppStoreAppCatalog' not in app_table or '_cachedSystemAppCatalog' not in app_table:
    raise SystemExit("error: app-list catalog caching/search optimization is incomplete")
if 'fileMayContainMachOAtPath' not in root_helper or 'MicroCore fast path' not in root_helper:
    raise SystemExit("error: MicroCore must prefilter non-Mach-O files before ChOma parsing")
if 'enumerateApplicationsOfType:type block:appendAppProxy' not in app_table or 'self->_cachedAppInfos=@[]; [self.tableView reloadData];' not in app_table or 'category!=self->_sourceCategory' not in app_table:
    raise SystemExit("error: app source catalog must use LaunchServices enumeration and avoid showing stale rows during category scans")
util_source = (ROOT / 'Shared/TSUtil.m').read_text()
if 'select(maxFD + 1' not in util_source or 'kMaxCapturedOutputBytes' not in util_source or 'void printMultilineNSString(NSString* stringToPrint)' not in util_source:
    raise SystemExit("error: subprocess output must be drained concurrently with bounded capture and required logging helper retained")
if 'getNSStringFromFile' in util_source:
    raise SystemExit("error: removed getNSStringFromFile API should not be referenced from this implementation")
if 'int installApp(NSString* appPackagePath, BOOL sign, BOOL force, BOOL isTSUpdate, BOOL useInstalldMethod, BOOL skipUICache, BOOL stealthInstall)' not in root_helper or 'installApp(tmpPackagePath, YES, force, NO, useInstalldMethod, skipUICache, stealthInstall)' not in root_helper:
    raise SystemExit("error: stealth install option is not propagated through IPA install handling")
if "TSDonateListController" in settings or "donat" in settings.lower():
    raise SystemExit("error: donation UI reference remains in Settings")

# Audit the new feature surface: local package store (without source feeds), safe repackaging,
# process-memory decryption, guarded maintenance, ldid in-process injection and UI settings.
repackager = (ROOT / "TrollStore/TSAppRepackager.m").read_text(encoding="utf-8")
archive = (ROOT / "TrollStore/TSArchiveExtractor.m").read_text(encoding="utf-8")
package_store = (ROOT / "TrollStore/TSIPAPackageStore.m").read_text(encoding="utf-8")
decrypt_ui = (ROOT / "TrollStore/TSAppDecryptor.m").read_text(encoding="utf-8")
decrypt_root = (ROOT / "RootHelper/TSAppDecryptor.m").read_text(encoding="utf-8")
maintenance = (ROOT / "RootHelper/TSAppMaintenance.m").read_text(encoding="utf-8")
injector = (ROOT / "TrollStore/TSTweakInjector.m").read_text(encoding="utf-8")
if not all(token in repackager for token in ("removeURLSchemes", "removeWidgets", "removeWatch", "CFBundleIdentifier", "CFBundleDisplayName", "CFBundleShortVersionString")):
    raise SystemExit("error: repackaging must edit bundle metadata and support URL/widget/watch removal")
if "ARCHIVE_EXTRACT_SECURE_NODOTDOT" not in archive or "ARCHIVE_EXTRACT_SECURE_SYMLINKS" not in archive or "AE_IFLNK" not in archive or "archiveContainsInstallableIPAAtPath" not in archive:
    raise SystemExit("error: archive extraction/creation must guard traversal, preserve symlinks, and validate IPA ZIPs")
if not all(token in package_store for token in ("@\"ipa\"", "@\"tipa\"", "@\"tar\"", "@\"zip\"", "@\"deb\"", "https", "Software sources are not included")):
    raise SystemExit("error: local IPA/TIPA/TAR/ZIP/DEB management and direct HTTPS download are incomplete")
if "archiveContainsInstallableIPAAtPath" not in package_store or "TS-ZIP-IPA-" not in package_store:
    raise SystemExit("error: ZIP files with a verified Payload app must open install/repackage actions directly")
if "task_for_pid" not in decrypt_root or "vm_read_overwrite" not in decrypt_root or "cryptidOffset" not in decrypt_root or "No encrypted Mach-O region was decrypted" not in decrypt_root:
    raise SystemExit("error: decrypt flow must read live-process memory and refuse to emit a fake IPA")
if "#import <libproc.h>" in decrypt_root or "proc_listpids(" in decrypt_root or "proc_pidpath(" in decrypt_root:
    raise SystemExit("error: iOS RootHelper must not depend on the macOS-only libproc API")
if "#import <mach/vm_map.h>" not in decrypt_root or "vm_read_overwrite(" not in decrypt_root:
    raise SystemExit("error: iOS RootHelper must use vm_map.h/vm_read_overwrite")
if "mach/mach_vm.h" in decrypt_root or "mach_vm_read_overwrite(" in decrypt_root:
    raise SystemExit("error: unsupported mach_vm API remains in iOS RootHelper")
if "mach_vm_address_t" in decrypt_root or "mach_vm_size_t" in decrypt_root:
    raise SystemExit("error: iOS decryptor must use vm_address_t/vm_size_t types")
if "vm_size_t readLength = 0" not in decrypt_root:
    raise SystemExit("error: vm_read_overwrite output size must use vm_size_t")
if "#import <sys/sysctl.h>" not in decrypt_root or "KERN_PROC_ALL" not in decrypt_root or "KERN_PROCARGS2" not in decrypt_root:
    raise SystemExit("error: decryptor process discovery must use the iOS-available Darwin sysctl interfaces")
if "NSString *processError = nil; pid_t pid = 0;" not in decrypt_root:
    raise SystemExit("error: decryptor process discovery error output must use the declared NSString type")
if "Decrypt & Export IPA" not in decrypt_ui or "Copy Debug Log" not in decrypt_ui:
    raise SystemExit("error: application list decrypt entry or debug log action is missing")
if not all(token in maintenance for token in ("TSAppMaintenanceClearCache", "TSAppMaintenanceClearData", "TSAppMaintenanceClearAllCaches", "TSAppMaintenanceInjectDylib", "--iosinject", "--verify")):
    raise SystemExit("error: guarded cache/data maintenance or bundled ldid injection is incomplete")
if "TweakPresets" not in injector or "Prevent Uninstall Limitations" not in injector or "cannot prevent SpringBoard" not in injector:
    raise SystemExit("error: preset selection or honest prevention limitations are missing")
if 'stringByResolvingSymlinksInPath' not in maintenance or 'Documents/Packages' not in maintenance:
    raise SystemExit("error: root-helper destructive operations and injection payload path must be symlink-safe and sandboxed to owned paths")
if 'MCMAppDataContainer containerWithIdentifier:containerIdentifier createIfNecessary:YES' not in maintenance or 'Removed and recreated the data container' not in maintenance:
    raise SystemExit("error: clear-data must remove the container and request recreation of an empty MCM container")
if 'constructContainerizationForEntitlements(entitlements, &containerIdentifier)' not in maintenance or 'This application declares that it does not use a standard data container' not in maintenance or maintenance.index('constructContainerizationForEntitlements(entitlements, &containerIdentifier)') > maintenance.index('removeItemAtPath:dataPath'):
    raise SystemExit("error: clear-data must validate container semantics before deleting any data")
if 'TSDecryptRuntimeOffsetForFileRange' not in decrypt_root or 'FAT_CIGAM_64' not in decrypt_root or 'sizeof(struct mach_header_64)' not in decrypt_root:
    raise SystemExit("error: decryptor must map Mach-O file offsets to runtime addresses and support fat Mach-O byte orders")
if 'TrollStore_RESOURCE_DIRS = Resources' not in app_make:
    raise SystemExit("error: built-in preset dynamic libraries must be included as application resources")
if "UICollectionViewCompositionalLayout" not in grid_table or "TSAppSourceCategory" not in grid_table or "TSAppearanceChanged" not in grid_table:
    raise SystemExit("error: two-column source filters or live theme updates are incomplete")
if "TSAppearanceChanged" not in app_table or "TSFloatingBarHeight" not in (ROOT / "TrollStore/TSThemeManager.m").read_text(encoding="utf-8"):
    raise SystemExit("error: list theme updates or floating-bar settings are incomplete")

# Certificate-backed CMS signing and mode/template UI checks.
signing_manager = (ROOT / "TrollStore/TSSigningManager.m").read_text(encoding="utf-8")
signing_ui = (ROOT / "TrollStore/TSSigningSettingsController.m").read_text(encoding="utf-8")
if 'initWithTitle:NSLocalizedString(@"Done", nil) style:UIBarButtonItemStyleDone target:self action:@selector(donePressed)' not in signing_ui:
    raise SystemExit("error: signing settings Done button must use the localized title initializer and preserve its done action")
if '"Done"' not in (ROOT / "TrollStore/Resources/zh-Hans.lproj/Localizable.strings").read_text(encoding="utf-8"):
    raise SystemExit("error: signing settings Done button must have a zh-Hans localization")
settings_source = (ROOT / "TrollStore/TSSettingsListController.m").read_text(encoding="utf-8")
helper_make = (ROOT / "RootHelper/Makefile").read_text(encoding="utf-8")
if not all(token in signing_manager for token in ("SecPKCS12Import", "importPEMCertificateData", "TSSigningCredentials", "TSSigningDefaultCredentialID", "kSecAttrAccessibleWhenUnlockedThisDeviceOnly", "templateDefinitionsForMode", "jobs", "p12", "privateKey")):
    raise SystemExit("error: signing manager must support P12/PEM identities, secure key storage, signing profiles and validation")
if not all(token in signing_ui for token in ("Import P12 Identity", "Import PEM Certificate + Key", "Import Provisioning Profile", "Real Signing", "TrollStore Signing", "UIColor.systemRedColor", "Issuer", "Validity Period", "OIDs", "Valid From", "Valid Until", "View Certificate Details", "Delete Certificate")):
    raise SystemExit("error: signing UI must expose mode selection, import/delete, templates and issuer/date/OID certificate details")
if 'signingMethodAndCertificatesPressed' not in settings_source or 'Signing Method & Certificates' not in settings_source:
    raise SystemExit("error: Settings must link to the signing method and certificate manager")
if 'TrollStore/TSApplicationsManager.m' in str(ROOT) and 'prepareRootHelperSigningConfiguration' not in manager:
    raise SystemExit("error: installs must pass an immutable signing-configuration snapshot to RootHelper")
if 'Security' not in app_make or 'Security' not in helper_make:
    raise SystemExit("error: both the app and RootHelper must link Security.framework")
if 'runLdidWithSigningConfiguration(@[@"-M", @"--deep", @"--super-deep", appPath]' not in root_helper:
    raise SystemExit("error: real CMS signing must use the configured recursive ldid bundle path")
if '@[@"--signature-validate", appPath]' not in root_helper:
    raise SystemExit("error: both real-signing paths must run the post-signature validator")
real_sign_block = root_helper[root_helper.find('int signAdhoc(NSString *filePath'):root_helper.find('int signApp(NSString* appPath)', root_helper.find('int signAdhoc(NSString *filePath'))]
if "CMS mode is selected by the profile's P12 or PEM identity. Never add -s here." not in real_sign_block:
    raise SystemExit("error: true signing must not add the ad-hoc -s option")
if 'if (status == errSecSuccess && result)' not in signing_manager or 'kSecValueData' not in signing_manager:
    raise SystemExit("error: certificate and private-key material must be stored in Keychain")
if 'setDefaultCredentialIdentifier:identifier' not in signing_manager or 'records.firstObject' not in signing_manager:
    raise SystemExit("error: first imported certificate must become default and a deleted default must fall back to the first remaining identity")
if len(re.findall(r'case 173\s*:', manager)) != 1:
    raise SystemExit("error: installation error switch must have exactly one case 173")
if 'return value.length ? value : ([mode isEqualToString:@"real"] ? @"app-store-managed" : @"trollstore-default");' not in signing_manager:
    raise SystemExit("error: real-signing template must default to App Store, TrollStore template must remain independent")
if 'TSCertificateFieldsFromDER' not in signing_manager or 'TSCollectX509ExtensionOIDs' not in signing_manager or 'TSOIDStringFromDER' not in signing_manager:
    raise SystemExit("error: iOS certificate detail parser must extract X.509 issuer, validity and DER OIDs")
if 'SecCertificateCopyValues(' in signing_manager:
    raise SystemExit("error: macOS-only SecCertificateCopyValues must not be used in the iOS app")
if 'TSDisplayDate(notBeforeDate)' not in signing_manager or 'TSDisplayDate(notAfterDate)' not in signing_manager or 'sortedArrayUsingSelector:@selector(compare:)' not in signing_manager:
    raise SystemExit("error: certificate validity dates and ordered OID list must be extracted")
if signing_manager.count('NSString *ldidConfigPath') != 1 or 'ldidConfigPath = [runtime stringByAppendingPathComponent:' not in signing_manager:
    raise SystemExit("error: ldidConfigPath must be declared once and assigned without redeclaration")
if 'configuration[@"provisioningProfilePath"]' not in signing_manager or 'embedded.mobileprovision' not in root_helper:
    raise SystemExit("error: per-identity provisioning profile must be passed through and embedded in the app")
if '@("adhoc")' in signing_manager or '@"adhoc": @(![mode isEqualToString:@"real"])' not in signing_manager:
    raise SystemExit("error: real signing must select CMS mode while TrollStore signing uses ad-hoc mode")
if 'if (!realSigningMode &&' not in root_helper or 'Genuine CMS signatures must never be rewritten by TrollStore' not in root_helper:
    raise SystemExit("error: real CMS path must skip the TrollStore CoreTrust bypass")
if 'currentOSSupportsBundledLdid' not in root_helper or 'if (@available(iOS 16.0, *)) return YES;' not in root_helper or 'case 195:' not in manager:
    raise SystemExit("error: the iOS 16 deployment minimum of the supplied ldid must be guarded at runtime")
if 'TSKeychainDelete([identifier stringByAppendingString:@".identity"])' not in signing_manager or 'TSKeychainDelete([identifier stringByAppendingString:@".password"])' not in signing_manager:
    raise SystemExit("error: deleting a certificate must also delete its Keychain identity/private-key and password records")

print(f"[audit] {len(REQUIRED)} required files present")
print("[audit] original TrollStore Objective-C UI/controllers retained; Entitlements editor is available pre-install and in Settings; no Swift sources; donation controller removed")
print(f"[audit] {len(plists)} plists and {len(strings_files)} strings resources validated")
print(f"[audit] {len(app_keys)} matching zh-Hans localization keys validated; {len(chinese_values)} translated values contain Chinese characters")
print("[audit] ChOma pin, supplied precompiled ldid, iOS vm_map.h/vm_read_overwrite API, embedded Security.framework linkage, Entitlements merge/editor, retry state retention, default-off auto-init, app source catalog, stealth install, Mach-O prefilter, optimized Objective-C/C targets, and self-update association validated")
