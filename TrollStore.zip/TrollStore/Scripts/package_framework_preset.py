#!/usr/bin/env python3
"""Wrap an already-signed Theos dylib in a conventional iOS .framework bundle."""
from pathlib import Path
import argparse
import plistlib
import shutil
import sys


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--bundle-id", required=True)
    parser.add_argument("--minimum-ios", default="16.0")
    args = parser.parse_args()

    source = args.input.resolve()
    output = args.output.resolve()
    if not source.is_file() or source.suffix.lower() != ".dylib":
        raise SystemExit(f"error: signed input dylib does not exist: {source}")
    executable = output.stem
    if not executable or "/" in executable:
        raise SystemExit("error: invalid framework executable name")
    if output.exists():
        shutil.rmtree(output) if output.is_dir() else output.unlink()
    output.mkdir(parents=True)
    destination_binary = output / executable
    shutil.copy2(source, destination_binary)
    destination_binary.chmod(0o755)

    info = {
        "CFBundleDevelopmentRegion": "en",
        "CFBundleExecutable": executable,
        "CFBundleIdentifier": args.bundle_id,
        "CFBundleInfoDictionaryVersion": "6.0",
        "CFBundleName": executable,
        "CFBundlePackageType": "FMWK",
        "CFBundleShortVersionString": "1.0",
        "CFBundleVersion": "1",
        "MinimumOSVersion": args.minimum_ios,
        "CFBundleSupportedPlatforms": ["iPhoneOS"],
    }
    with (output / "Info.plist").open("wb") as handle:
        plistlib.dump(info, handle, fmt=plistlib.FMT_XML, sort_keys=True)
    # Ensure the packaged executable is byte-identical to the signed source.
    if source.read_bytes() != destination_binary.read_bytes():
        raise SystemExit("error: framework wrapper changed the signed Mach-O bytes")
    print(f"packaged {source.name} as {output}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except OSError as exc:
        raise SystemExit(f"error: framework packaging failed: {exc}")
