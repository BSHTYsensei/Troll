#!/usr/bin/env bash
# Regression test: Theos Swift support cache recovery uses standalone Swift 5.8.1.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/ts-swift-support-test.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT

THEOS_ROOT="$TMP/theos"
TOOLCHAIN="$TMP/swift-5.8.1-RELEASE.xctoolchain"
SWIFT_BIN="$TOOLCHAIN/usr/bin/swift"
SUPPORT="$THEOS_ROOT/vendor/swift-support"
mkdir -p "$THEOS_ROOT/makefiles" "$THEOS_ROOT/bin" "$SUPPORT/Sources" "$(dirname "$SWIFT_BIN")"
touch "$THEOS_ROOT/makefiles/common.mk" "$SUPPORT/Package.swift"

cat > "$SWIFT_BIN" <<'SWIFT'
#!/usr/bin/env bash
if [[ "${1:-}" == "--version" ]]; then
    echo 'Apple Swift version 5.8.1 (mock standalone toolchain)'
else
    exit 0
fi
SWIFT
chmod 755 "$SWIFT_BIN"

cat > "$THEOS_ROOT/bin/swift-bootstrapper.pl" <<'PERL'
use strict;
use warnings;
my $swift = shift;
my $support = shift;
my $message = shift;
die "wrong standalone swift compiler: $swift" unless $swift =~ /swift-5\.8\.1-RELEASE\.xctoolchain\/usr\/bin\/swift$/;
system($message) == 0 or die "could not print bootstrap message";
my $bin = "$support/.theos_build/release";
require File::Path;
File::Path::make_path($bin);
for my $tool (qw(generate-output-file-map parse-swiftc-output)) {
    open(my $fh, '>', "$bin/$tool") or die $!;
    print {$fh} "#!/bin/sh\nexit 0\n";
    close($fh);
    chmod 0755, "$bin/$tool";
}
open(my $marker, '>', "$support/.theos_build/theos_build_commit") or die $!;
print {$marker} "mock-commit mock-swift-version\n";
close($marker);
PERL

# Reproduce the stale-cache failure: marker exists, but required executables do not.
mkdir -p "$SUPPORT/.theos_build/release"
printf 'stale cache marker\n' > "$SUPPORT/.theos_build/theos_build_commit"
THEOS="$THEOS_ROOT" SWIFT58_TOOLCHAIN_DIR="$TOOLCHAIN" SWIFT_BIN="$SWIFT_BIN" \
    THEOS_NO_SWIFT_CACHE=3 /bin/bash "$ROOT/Scripts/bootstrap_theos_swift_support.sh"

for tool in generate-output-file-map parse-swiftc-output; do
    [[ -x "$SUPPORT/.theos_build/release/$tool" ]] || {
        echo "error: regression test did not produce $tool" >&2
        exit 1
    }
done

echo '[test] Theos Swift support cache recovery with standalone Swift 5.8.1 passed'
