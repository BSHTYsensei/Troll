#!/usr/bin/env bash
# Host-independent regression test for the stale Theos Swift-support cache failure.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/ts-swift-support-test.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT

THEOS_ROOT="$TMP/theos"
FAKE_BIN="$TMP/fake-bin"
SUPPORT="$THEOS_ROOT/vendor/swift-support"
mkdir -p "$THEOS_ROOT/makefiles" "$THEOS_ROOT/bin" "$SUPPORT/Sources" "$FAKE_BIN"
touch "$THEOS_ROOT/makefiles/common.mk" "$SUPPORT/Package.swift"

cat > "$FAKE_BIN/xcrun" <<'XCRUN'
#!/usr/bin/env bash
[[ "${1:-}" == "--find" && "${2:-}" == "swift" ]] || exit 2
printf '%s\n' "${FAKE_SWIFT_BIN}"
XCRUN
cat > "$FAKE_BIN/swift" <<'SWIFT'
#!/usr/bin/env bash
if [[ "${1:-}" == "--version" ]]; then
    echo 'Apple Swift version 6.2 (mock regression test)'
else
    exit 0
fi
SWIFT
chmod 755 "$FAKE_BIN/xcrun" "$FAKE_BIN/swift"

cat > "$THEOS_ROOT/bin/swift-bootstrapper.pl" <<'PERL'
use strict;
use warnings;
die "THEOS_NO_SWIFT_CACHE was not cleared for repair" if exists $ENV{THEOS_NO_SWIFT_CACHE};
my $swift = shift;
my $support = shift;
my $message = shift;
system($message) == 0 or die "could not print bootstrap message";
my $bin = "$support/.theos_build/release";
require File::Path;
File::Path::make_path($bin);
for my $tool (qw(generate-output-file-map parse-swiftc-output)) {
    open(my $fh, '>', "$bin/$tool") or die $!;
    print {$fh} "#!/bin/sh\nexit 0\n";
    close($fh);
    chmod 0755, "$bin/$tool";
}
open(my $marker, '>', "$support/.theos_build/theos_build_commit") or die $!;
print {$marker} "mock-commit mock-swift-version\n";
close($marker);
PERL

# Reproduce the CI bug: a successful-build cache marker exists, while the actual
# release executables are missing. The preflight must invalidate and repair it.
mkdir -p "$SUPPORT/.theos_build/release"
printf 'stale cache marker\n' > "$SUPPORT/.theos_build/theos_build_commit"
export FAKE_SWIFT_BIN="$FAKE_BIN/swift"
PATH="$FAKE_BIN:$PATH" THEOS="$THEOS_ROOT" THEOS_NO_SWIFT_CACHE=3 \
    /bin/bash "$ROOT/Scripts/bootstrap_theos_swift_support.sh"

for tool in generate-output-file-map parse-swiftc-output; do
    [[ -x "$SUPPORT/.theos_build/release/$tool" ]] || {
        echo "error: regression test did not produce $tool" >&2
        exit 1
    }
done

echo '[test] stale Theos Swift-support cache recovery passed'
