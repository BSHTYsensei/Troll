#!/usr/bin/env python3
"""Run fastPathSign per Mach-O architecture and preserve universal binaries."""
from __future__ import annotations

import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tempfile

from validate_macho_signature import has_valid_code_signature, macho_slices

ROOT = Path(__file__).resolve().parent.parent
SIGNER = Path(os.environ.get("FASTPATHSIGN_EXECUTABLE", ROOT / "Exploits/fastPathSign/fastPathSign"))
def resolve_lipo() -> str:
    configured = os.environ.get("LIPO_EXECUTABLE") or shutil.which("lipo")
    if configured:
        return configured
    xcrun = shutil.which("xcrun")
    if xcrun:
        result = subprocess.run([xcrun, "--find", "lipo"], check=False, text=True, capture_output=True)
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip()
    return "/usr/bin/lipo"


LIPO = resolve_lipo()


def run(command: list[str]) -> subprocess.CompletedProcess[str]:
    if os.environ.get("FASTPATHSIGN_DEBUG"):
        print("[debug] exec:", command, file=sys.stderr, flush=True)
    return subprocess.run(command, check=False, text=True)


def sign_thin_slice(path: Path, signer_args: list[str]) -> None:
    slices = macho_slices(path)
    if len(slices) != 1:
        raise RuntimeError(f"internal error: expected one thin slice in {path}, found {[a for a, _ in slices]}")
    arch = slices[0][0]
    if has_valid_code_signature(path, arch):
        return
    if not SIGNER.is_file() or not os.access(SIGNER, os.X_OK):
        raise RuntimeError(f"fastPathSign host signer is missing or not executable: {SIGNER}")
    result = run([str(SIGNER), *signer_args, str(path)])
    if result.returncode != 0:
        raise RuntimeError(f"fastPathSign failed for {arch} slice {path} (exit {result.returncode})")
    after = macho_slices(path)
    if len(after) != 1 or after[0][0] != arch:
        raise RuntimeError(f"fastPathSign changed the architecture of thin slice {path}; expected {arch}")
    if not has_valid_code_signature(path, arch):
        raise RuntimeError(f"fastPathSign returned success but {arch} slice still has no valid embedded CodeDirectory: {path}")


def sign_binary(binary: Path, signer_args: list[str] | None = None) -> None:
    signer_args = signer_args or []
    binary = binary.resolve()
    if not binary.is_file():
        raise RuntimeError(f"code object does not exist: {binary}")
    original_mode = stat.S_IMODE(binary.stat().st_mode)
    source_slices = macho_slices(binary)
    archs = [arch for arch, _ in source_slices]
    if len(set(archs)) != len(archs):
        raise RuntimeError(f"duplicate architecture slices in {binary}: {archs}")

    # Work beside the input so the final atomic replace stays on the same volume.
    with tempfile.TemporaryDirectory(prefix=".fastpathsign-slices-", dir=str(binary.parent)) as temp_name:
        temp = Path(temp_name)
        signed_slices: list[Path] = []
        for index, arch in enumerate(archs):
            thin = temp / f"slice-{index}-{arch}{binary.suffix}"
            if len(archs) == 1:
                shutil.copy2(binary, thin)
            else:
                result = run([LIPO, "-thin", arch, str(binary), "-output", str(thin)])
                if result.returncode != 0:
                    raise RuntimeError(f"lipo failed extracting {arch} from {binary}")
            extracted = macho_slices(thin)
            if len(extracted) != 1 or extracted[0][0] != arch:
                raise RuntimeError(f"lipo extraction produced the wrong architecture for {arch}: {thin}")
            sign_thin_slice(thin, signer_args)
            signed_slices.append(thin)

        if len(signed_slices) == 1:
            final_path = signed_slices[0]
        else:
            final_path = temp / f"universal{binary.suffix}"
            result = run([LIPO, "-create", *map(str, signed_slices), "-output", str(final_path)])
            if result.returncode != 0:
                raise RuntimeError(f"lipo failed reassembling signed slices for {binary}")

        final_archs = [arch for arch, _ in macho_slices(final_path)]
        if set(final_archs) != set(archs) or len(final_archs) != len(archs):
            raise RuntimeError(f"universal reassembly changed architecture set: expected {archs}, got {final_archs}")
        for arch in archs:
            if not has_valid_code_signature(final_path, arch):
                raise RuntimeError(f"reassembled {arch} slice has no valid embedded signature: {binary}")

        replacement = temp / f"replacement{binary.suffix}"
        shutil.copy2(final_path, replacement)
        os.chmod(replacement, original_mode)
        os.replace(replacement, binary)


def main(argv: list[str]) -> int:
    if not argv or argv[-1] in ("-h", "--help"):
        print("usage: fastpath_sign_all_slices.py [fastPathSign options] <Mach-O file>")
        return 0 if argv else 2
    try:
        # Theos passes the code object as the final argument. Preserve preceding
        # signer options (for example --entitlements <plist>) for each thin slice.
        sign_binary(Path(argv[-1]), argv[:-1])
        print(f"[fastPathSign] signed and preserved all slices: {argv[-1]}")
        return 0
    except (OSError, RuntimeError, subprocess.SubprocessError, ValueError) as exc:
        print(f"error: fastPathSign universal wrapper: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
