#!/usr/bin/env python3
"""Static regression checks for package icons, IPA editing and decrypt feedback."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(path: str) -> str:
    target = ROOT / path
    if not target.is_file():
        raise SystemExit(f"[FAIL] missing source: {path}")
    return target.read_text(errors="replace")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(f"[FAIL] {message}")
    print(f"[OK] {message}")


def main() -> None:
    repackager = read("TrollStore/TSAppRepackager.m")
    header = read("TrollStore/TSAppRepackager.h")
    settings = read("TrollStore/TSSettingsListController.m")
    app_info = read("TrollStore/TSAppInfo.m")
    package_store = read("TrollStore/TSIPAPackageStore.m")
    decryptor = read("TrollStore/TSAppDecryptor.m")

    require("importCustomIconAtURL" in header and "UIDocumentPickerViewController" in settings and
            "UTType.png" in settings and "UTType.jpeg" in settings,
            "custom app icon is imported from Files instead of probing TrollStore bundle icons")
    deprecated_picker_sources = []
    for source in (ROOT / "TrollStore").rglob("*"):
        if source.is_file() and source.suffix in {".m", ".mm", ".h", ".hpp"}:
            source_text = source.read_text(errors="replace")
            if "initWithDocumentTypes:" in source_text or "UIDocumentPickerModeImport" in source_text:
                deprecated_picker_sources.append(str(source.relative_to(ROOT)))
    require(not deprecated_picker_sources,
            "no deprecated UIDocumentPicker initializers or modes remain anywhere in TrollStore Objective-C sources")

    require("UniformTypeIdentifiers" in repackager and "initForOpeningContentTypes" in repackager and
            "asCopy:YES" in repackager and "initWithDocumentTypes:" not in repackager and
            "UIDocumentPickerModeImport" not in repackager and
            "UniformTypeIdentifiers" in settings and "initForOpeningContentTypes" in settings and
            "UTType.png" in settings and "UTType.jpeg" in settings and
            "initWithDocumentTypes:" not in settings and "UIDocumentPickerModeImport" not in settings and
            "UniformTypeIdentifiers" in read("TrollStore/Makefile"),
            "all custom icon pickers use the non-deprecated iOS 14 UniformTypeIdentifiers API")
    require("TrollStoreCustomAppIcon.png" in repackager and "1024.0, 1024.0" in repackager and
            "25 * 1024 * 1024" in repackager and "source.size.width > 4096.0" in repackager,
            "custom icon import normalizes and bounds the selected image before saving")
    require("CFBundleIcons" in repackager and "CFBundleIconFiles" in repackager and
            "TrollStoreCustomIcon" in repackager and "UIImagePNGRepresentation" in repackager,
            "repackaging writes standard iPhone/iPad icon variants and updates the app plist")
    require("Assets.car" in app_info and "CFBundleIconName" in app_info and
            "TSAppInfoReadArchiveEntry" in app_info and "64 * 1024 * 1024" in app_info and
            "if(closestIconSize.width == 0) return [self assetCatalogIconForSize:size]" in app_info,
            "package icon resolver supports Assets.car and bounded archive reads")
    require("stringByDeletingPathExtension" in app_info and
            'hasSuffix:@"x"' in app_info and "widthNum.doubleValue" in app_info,
            "package icon filename parsing handles PNG suffixes, scale suffixes and fractional iPad icon sizes")
    require("NSOperationQueue" in package_store and "NSCache" in package_store and
            "loadIconsForPackages" in package_store and "iconForSize:CGSizeMake(60.0, 60.0)" in package_store,
            "package icons load asynchronously and are cached outside table-cell rendering")
    icon_method_start = app_info.find("- (UIImage*)iconForSize:(CGSize)size")
    icon_method_end = app_info.find("\n- (", icon_method_start + 1)
    icon_method = app_info[icon_method_start:icon_method_end if icon_method_end >= 0 else None]
    require(icon_method_start >= 0 and "UIScreen.mainScreen" not in icon_method and
            "bestExactScale" in icon_method,
            "background package icon lookup does not query UIScreen and prefers the highest exact-size variant")
    require("self.removeWidgetsSwitch.on = NO" in repackager and "self.removeWatchSwitch.on = NO" in repackager,
            "IPA editor preserves optional widget and Watch extensions by default")
    require("stat(output.fileSystemRepresentation, &outputStat)" in decryptor and
            "S_ISREG(outputStat.st_mode)" in decryptor and "outputStat.st_size > 0" in decryptor,
            "decrypt UI does not report success unless a non-empty regular output IPA exists")
    require("verifiedOutput" in repackager and "sync_loadBasicInfo" in repackager and
            "customIconMatches" in repackager and "createZipFromDirectory" in repackager,
            "IPA editor reopens and validates the created archive and imported app icon before reporting success")


if __name__ == "__main__":
    main()
