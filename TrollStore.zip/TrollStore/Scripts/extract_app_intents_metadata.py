#!/usr/bin/env python3
"""Run Apple's App Intents metadata processor for a Theos-built iOS app."""
from pathlib import Path
import argparse
import re
import shutil
import subprocess
import sys


def run(command: list[str], *, cwd: Path | None = None) -> str:
    result = subprocess.run(command, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if result.returncode:
        raise RuntimeError(f"command failed ({result.returncode}): {' '.join(command)}\n{result.stdout}")
    return result.stdout.strip()


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--app", type=Path, required=True)
    parser.add_argument("--deployment-target", default="16.0")
    args = parser.parse_args()
    root, app = args.project_root.resolve(), args.app.resolve()
    source = root / "TrollStore/TSRefreshAppRegistrationsIntent.swift"
    binary = app / "TrollStore"
    if not source.is_file() or not binary.is_file():
        raise SystemExit("error: App Intents source or built TrollStore executable is missing")
    if not shutil.which("xcode-select") or not shutil.which("xcrun") or not shutil.which("xcodebuild"):
        raise SystemExit("error: App Intents metadata extraction requires Xcode command-line tools on macOS")
    developer = Path(run(["xcode-select", "-p"]))
    sdk = Path(run(["xcrun", "--sdk", "iphoneos", "--show-sdk-path"]))
    xcode_version_output = run(["xcodebuild", "-version"])
    version_match = re.search(r"Xcode\s+([0-9]+(?:\.[0-9]+)*)", xcode_version_output)
    if not version_match:
        raise SystemExit(f"error: could not parse Xcode version: {xcode_version_output}")
    xcode_version = version_match.group(1)
    toolchain = developer / "Toolchains/XcodeDefault.xctoolchain"
    processor = toolchain / "usr/bin/appintentsmetadataprocessor"
    if not processor.is_file():
        located = run(["xcrun", "--find", "appintentsmetadataprocessor"])
        processor = Path(located)
    const_files = sorted((root / "TrollStore/.theos/obj").rglob("TSRefreshAppRegistrationsIntent.swiftconstvalues"))
    if not const_files:
        raise SystemExit("error: Theos did not emit TSRefreshAppRegistrationsIntent.swiftconstvalues; check TrollStore_SWIFTFLAGS / Swift support")
    const_file = const_files[-1]
    triple = f"arm64-apple-ios{args.deployment_target}"
    command = [
        str(processor), "--toolchain-dir", str(toolchain), "--sdk-root", str(sdk),
        "--deployment-target", args.deployment_target, "--target-triple", triple,
        "--module-name", "TrollStore", "--output", str(app), "--binary-file", str(binary),
        "--compile-time-extraction", "--source-files", str(source),
        "--swift-const-vals", str(const_file), "--xcode-version", xcode_version,
    ]
    output = run(command, cwd=root)
    metadata = app / "Metadata.appintents"
    required = [metadata / "extract.actionsdata", metadata / "version.json"]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise SystemExit("error: App Intents metadata processor did not produce required files: " + ", ".join(missing) + ("\n" + output if output else ""))
    print(f"App Intents metadata generated at {metadata}")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, RuntimeError) as exc:
        raise SystemExit(f"error: App Intents metadata extraction failed: {exc}")
