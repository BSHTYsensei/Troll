#!/usr/bin/env bash
# Keep Swift 5.8.1 as the compiler for the iOS 16.5 SDK interfaces, but never
# link against its legacy iphoneos runtime dylibs. Use the active Xcode runtime
# for dylibs, and supplement only missing compatibility archives when needed.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
SWIFT58_TOOLCHAIN_DIR="${SWIFT58_TOOLCHAIN_DIR:-$HOME/Library/Developer/Toolchains/swift-5.8.1-RELEASE.xctoolchain}"
SOURCE_DIR="${SWIFT58_IOS_RUNTIME_DIR:-$SWIFT58_TOOLCHAIN_DIR/usr/lib/swift/iphoneos}"
XCODE_SWIFT_RUNTIME_DIR="${XCODE_SWIFT_RUNTIME_DIR:-}"
SDK_SWIFT_RUNTIME_DIR="${SDK_SWIFT_RUNTIME_DIR:-}"
DEST_DIR="${SWIFT_RUNTIME_COMPAT_DIR:-$PROJECT_ROOT/TrollStore/.theos/swift-runtime/compat-arm64}"
LIPO_BIN="${LIPO:-$(xcrun --find lipo 2>/dev/null || command -v lipo || true)}"
AR_BIN="${AR:-$(xcrun --find ar 2>/dev/null || command -v ar || true)}"

fail() {
    echo "error: [swift-runtime] $*" >&2
    exit 1
}

if [[ "${SWIFT_RUNTIME_TEST_ALLOW_NON_DARWIN:-0}" != "1" && "$(uname -s)" != "Darwin" ]]; then
    fail "Swift runtime link preparation must run on the macOS Theos build runner"
fi
[[ -d "$SOURCE_DIR" ]] || fail "Swift 5.8.1 compiler runtime directory is missing: $SOURCE_DIR"
[[ -n "$XCODE_SWIFT_RUNTIME_DIR" && -d "$XCODE_SWIFT_RUNTIME_DIR" ]] || fail "active Xcode iPhoneOS Swift runtime directory is missing: ${XCODE_SWIFT_RUNTIME_DIR:-<unset>}"
[[ -f "$XCODE_SWIFT_RUNTIME_DIR/libswiftCore.dylib" ]] || fail "active Xcode runtime is missing libswiftCore.dylib: $XCODE_SWIFT_RUNTIME_DIR"
[[ -n "$SDK_SWIFT_RUNTIME_DIR" && -d "$SDK_SWIFT_RUNTIME_DIR" ]] || fail "iPhoneOS SDK Swift runtime directory is missing: ${SDK_SWIFT_RUNTIME_DIR:-<unset>}"
[[ -n "$LIPO_BIN" && -x "$LIPO_BIN" ]] || fail "Apple lipo is unavailable; install/activate Xcode command-line tools"
[[ -n "$AR_BIN" && -x "$AR_BIN" ]] || fail "Apple ar is unavailable; install/activate Xcode command-line tools"

# Swift compiler generations can request these compatibility libraries. Prefer
# the active Xcode runtime or the target SDK import stub; only fill genuine gaps
# from the 5.8.1 compiler runtime. This is deliberately archive-only: legacy
# Swift 5.8.1 dylibs are never copied or added to the link search path.
compat_archives=(
    libswiftCompatibility50.a
    libswiftCompatibility51.a
    libswiftCompatibility56.a
    libswiftCompatibilityConcurrency.a
    libswiftCompatibilityDynamicReplacements.a
    libswiftCompatibilityPacks.a
)

parent_dir="$(dirname "$DEST_DIR")"
mkdir -p "$parent_dir"
stage_dir="$(mktemp -d "$parent_dir/.swift-compat-arm64.XXXXXX")"
cleanup() { rm -rf "$stage_dir"; }
trap cleanup EXIT

staged=0
provided_by_xcode=0
provided_by_sdk=0
missing_optional=0
for name in "${compat_archives[@]}"; do
    stem="${name%.a}"
    if [[ -f "$XCODE_SWIFT_RUNTIME_DIR/$name" || -f "$XCODE_SWIFT_RUNTIME_DIR/$stem.tbd" ]]; then
        provided_by_xcode=$((provided_by_xcode + 1))
        continue
    fi
    if [[ -f "$SDK_SWIFT_RUNTIME_DIR/$name" || -f "$SDK_SWIFT_RUNTIME_DIR/$stem.tbd" ]]; then
        provided_by_sdk=$((provided_by_sdk + 1))
        continue
    fi

    source="$SOURCE_DIR/$name"
    if [[ ! -f "$source" ]]; then
        if [[ "$name" == "libswiftCompatibility50.a" ]]; then
            fail "$name is absent from the active Xcode runtime, iPhoneOS SDK and Swift 5.8.1 compiler runtime"
        fi
        echo "[swift-runtime] optional compatibility archive not present in any runtime: $name"
        missing_optional=$((missing_optional + 1))
        continue
    fi

    # `lipo -verify_arch` is not a reliable validator for thin .a archives: it
    # can reject a perfectly valid archive even when `lipo -archs` reports arm64.
    # Check the archive's architecture list, thin only true fat archives, then
    # use `ar -t` to validate the archive container and its member table.
    archs="$($LIPO_BIN -archs "$source" 2>&1)" || fail "lipo could not inspect $source: $archs"
    if [[ " $archs " != *" arm64 "* ]]; then
        fail "$name does not contain arm64 objects (archs=$archs)"
    fi

    output="$stage_dir/$name"
    if [[ "$archs" == "arm64" ]]; then
        cp -p "$source" "$output"
    else
        "$LIPO_BIN" "$source" -thin arm64 -output "$output" || fail "could not extract arm64 members from $name"
    fi

    output_archs="$($LIPO_BIN -archs "$output" 2>&1)" || fail "lipo could not inspect staged archive $name: $output_archs"
    [[ "$output_archs" == "arm64" ]] || fail "$name did not become an arm64-only archive (archs=$output_archs)"
    members="$($AR_BIN -t "$output" 2>&1)" || fail "$name is not a readable static archive: $members"
    [[ -n "$members" ]] || fail "$name is an empty static archive"
    chmod 644 "$output"
    staged=$((staged + 1))
    echo "[swift-runtime] compatibility archive fallback: $name (arm64; $($AR_BIN -t "$output" | wc -l | tr -d ' ') members)"
done

printf 'format=1\narchitecture=arm64\nlink_runtime=%s\nsource_compiler_runtime=%s\nstaged_compat_archives=%s\nprovided_by_xcode=%s\nprovided_by_sdk=%s\nmissing_optional=%s\n' \
    "$XCODE_SWIFT_RUNTIME_DIR" "$SOURCE_DIR" "$staged" "$provided_by_xcode" "$provided_by_sdk" "$missing_optional" \
    > "$stage_dir/.trollstore-swift-runtime"

rm -rf "$DEST_DIR"
mv "$stage_dir" "$DEST_DIR"
trap - EXIT
printf '[swift-runtime] ready: Xcode dylibs=%s, compatibility archives staged=%s, Xcode=%s, SDK=%s\n' \
    "$XCODE_SWIFT_RUNTIME_DIR" "$staged" "$provided_by_xcode" "$provided_by_sdk"
