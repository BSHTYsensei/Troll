#!/usr/bin/env python3
"""Validate that bin/ldid is a 64-bit arm64 iOS-device Mach-O executable."""
import struct
import sys
from pathlib import Path

path = Path(sys.argv[1] if len(sys.argv) > 1 else "bin/ldid")
data = path.read_bytes()[:1024 * 1024]
if len(data) < 32 or data[:4] != bytes.fromhex("cffaedfe"):
    raise SystemExit(f"error: {path} is not a little-endian 64-bit Mach-O executable")
_, cpu, _, filetype, ncmds, sizeofcmds, _, _ = struct.unpack_from("<8I", data, 0)
if cpu != 0x0100000C or filetype != 2:
    raise SystemExit(f"error: {path} must be an arm64 executable (got cpu=0x{cpu:08x}, filetype={filetype})")
if 32 + sizeofcmds > len(data):
    raise SystemExit(f"error: {path} has a truncated Mach-O load-command table")
off = 32
platform = None
for _ in range(ncmds):
    if off + 8 > len(data):
        raise SystemExit(f"error: {path} has a truncated load command")
    cmd, cmdsize = struct.unpack_from("<II", data, off)
    if cmdsize < 8 or off + cmdsize > len(data):
        raise SystemExit(f"error: {path} has an invalid load-command size")
    if cmd == 0x32:  # LC_BUILD_VERSION
        if cmdsize < 24:
            raise SystemExit(f"error: {path} has a truncated LC_BUILD_VERSION")
        platform = struct.unpack_from("<I", data, off + 8)[0]
        break
    if cmd == 0x25:  # LC_VERSION_MIN_IPHONEOS (older deployment targets)
        platform = 2
        break
    off += cmdsize
if platform is None:
    raise SystemExit(f"error: {path} lacks an iOS deployment-platform load command")
if platform != 2:
    raise SystemExit(f"error: {path} targets Mach-O platform {platform}, expected iOS device (2)")
print(f"[deps] validated prebuilt iOS arm64 ldid: {path} ({path.stat().st_size:,} bytes)")
