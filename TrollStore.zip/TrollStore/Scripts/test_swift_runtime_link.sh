#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/trollstore-swift-runtime-link-test.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT

SOURCE="$TMP/swift-5.8.1/usr/lib/swift/iphoneos"
XCODE="$TMP/Xcode/Toolchains/XcodeDefault.xctoolchain/usr/lib/swift/iphoneos"
SDK="$TMP/iPhoneOS16.5.sdk/usr/lib/swift"
OUT="$TMP/project/TrollStore/.theos/swift-runtime/compat-arm64"
BIN="$TMP/bin"
mkdir -p "$SOURCE" "$XCODE" "$SDK" "$BIN"

# The active Xcode runtime always supplies the normal runtime dylib in this test.
printf 'xcode-runtime\n' > "$XCODE/libswiftCore.dylib"
# Xcode already supplies one compatibility archive; another exists as an SDK stub.
printf 'arm64\nVALID_ARCHIVE\n' > "$XCODE/libswiftCompatibility56.a"
printf 'sdk-stub\n' > "$SDK/libswiftCompatibilityConcurrency.tbd"
# The old toolchain contains two missing archives: one thin, one fat.
printf 'arm64\nVALID_ARCHIVE\n' > "$SOURCE/libswiftCompatibility50.a"
printf 'arm64 arm64e\nVALID_ARCHIVE\n' > "$SOURCE/libswiftCompatibility51.a"

cat > "$BIN/fake-lipo" <<'FAKE_LIPO'
#!/usr/bin/env bash
set -euo pipefail
if [[ "$1" == "-archs" ]]; then
    head -n 1 "$2"
elif [[ "$2" == "-thin" && "$3" == "arm64" && "$4" == "-output" ]]; then
    source="$1"; output="$5"
    { printf 'arm64\n'; tail -n +2 "$source"; } > "$output"
else
    echo "fake-lipo: unexpected invocation (verify_arch must not be used for archives): $*" >&2
    exit 2
fi
FAKE_LIPO

cat > "$BIN/fake-ar" <<'FAKE_AR'
#!/usr/bin/env bash
set -euo pipefail
[[ "$1" == "-t" && -f "$2" ]] || exit 2
grep -q '^VALID_ARCHIVE$' "$2" || exit 1
printf 'compatibility.o\n'
FAKE_AR
chmod 755 "$BIN/fake-lipo" "$BIN/fake-ar"

# Permit the script to run on this non-macOS test host while keeping production
# execution gated to Darwin. Mock lipo/ar inspect archive metadata, not Mach-O bytes.
SWIFT_RUNTIME_TEST_ALLOW_NON_DARWIN=1 \
SWIFT58_IOS_RUNTIME_DIR="$SOURCE" \
XCODE_SWIFT_RUNTIME_DIR="$XCODE" \
SDK_SWIFT_RUNTIME_DIR="$SDK" \
SWIFT_RUNTIME_COMPAT_DIR="$OUT" \
LIPO="$BIN/fake-lipo" \
AR="$BIN/fake-ar" \
    /bin/bash "$ROOT/Scripts/prepare_swift_link_runtime.sh"

[[ -f "$OUT/.trollstore-swift-runtime" ]]
[[ -f "$OUT/libswiftCompatibility50.a" ]]
[[ -f "$OUT/libswiftCompatibility51.a" ]]
[[ ! -e "$OUT/libswiftCompatibility56.a" ]]
[[ ! -e "$OUT/libswiftCompatibilityConcurrency.a" ]]
[[ "$(head -n 1 "$OUT/libswiftCompatibility50.a")" == "arm64" ]]
[[ "$(head -n 1 "$OUT/libswiftCompatibility51.a")" == "arm64" ]]
grep -q '^staged_compat_archives=2$' "$OUT/.trollstore-swift-runtime"
grep -q '^provided_by_xcode=1$' "$OUT/.trollstore-swift-runtime"
grep -q '^provided_by_sdk=1$' "$OUT/.trollstore-swift-runtime"
# Old runtime dylibs are intentionally never copied into the compatibility overlay.
[[ ! -e "$OUT/libswift_Concurrency.dylib" ]]
[[ "$(head -n 1 "$SOURCE/libswiftCompatibility51.a")" == "arm64 arm64e" ]]

# Verify the exact Make expression used by TrollStore/Makefile: Xcode runtime
# first, missing archive overlay second, SDK fallback last; no Swift 5.8.1 dylib path.
cat > "$TMP/path-override.mk" <<MAKEFILE
_THEOS_TARGET_SWIFT_LDPATHS := /mock/swift-5.8.1/usr/lib/swift/iphoneos /mock/iPhoneOS16.5.sdk/usr/lib/swift
XCODE_SWIFT_RUNTIME_DIR := /mock/Xcode/Toolchains/XcodeDefault.xctoolchain/usr/lib/swift/iphoneos
SWIFT_RUNTIME_COMPAT_DIR := /mock/project/TrollStore/.theos/swift-runtime/compat-arm64
_SWIFT_RUNTIME_SYSTEM_LDPATHS := \$(filter-out %/iphoneos,\$(_THEOS_TARGET_SWIFT_LDPATHS))
override _THEOS_TARGET_SWIFT_LDPATHS := \$(XCODE_SWIFT_RUNTIME_DIR) \$(SWIFT_RUNTIME_COMPAT_DIR) \$(_SWIFT_RUNTIME_SYSTEM_LDPATHS)
.PHONY: check
check:
	@test '\$(_THEOS_TARGET_SWIFT_LDPATHS)' = '/mock/Xcode/Toolchains/XcodeDefault.xctoolchain/usr/lib/swift/iphoneos /mock/project/TrollStore/.theos/swift-runtime/compat-arm64 /mock/iPhoneOS16.5.sdk/usr/lib/swift'
	@! printf '%s' '\$(_THEOS_TARGET_SWIFT_LDPATHS)' | grep -q 'swift-5.8.1'
	@echo '[test] Xcode runtime + compatibility archive fallback search path passed'
MAKEFILE
make -s -f "$TMP/path-override.mk" check

echo "[test] Swift runtime linking uses active Xcode dylibs and archive-only compatibility fallback"
