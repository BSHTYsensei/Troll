#!/usr/bin/env bash
# Compile the actual Theos Prefix.pch against the selected iPhoneOS SDK before
# launching the full build. This catches the exact Darwin/stdatomic module path
# failure on a macOS/Xcode runner instead of merely testing Make variable values.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
THEOS_DIR="${1:-${THEOS:-$HOME/theos}}"
SDK_VERSION="${2:-16.5}"
CLANG="${TS_XCODE_CLANG:-${XCODE_DEFAULT_CLANG:-}}"
CLANGXX="${TS_XCODE_CLANGXX:-${XCODE_DEFAULT_CLANGXX:-}}"
RESOURCE="${TS_XCODE_CLANG_RESOURCE_DIR:-}"

fail() { echo "error: $*" >&2; exit 1; }
[[ "$(uname -s)" == Darwin ]] || fail 'Objective-C SDK probe must run on the macOS/Xcode CI runner'
[[ -x "$CLANG" && -x "$CLANGXX" ]] || fail 'Xcode Clang and Clang++ paths were not provided'
[[ -d "$THEOS_DIR" ]] || fail "THEOS directory not found: $THEOS_DIR"
SDK_DIR="$THEOS_DIR/sdks/iPhoneOS${SDK_VERSION}.sdk"
[[ -d "$SDK_DIR" ]] || fail "iPhoneOS${SDK_VERSION}.sdk not found: $SDK_DIR"
PCH="$THEOS_DIR/Prefix.pch"
[[ -f "$PCH" ]] || fail "Theos Prefix.pch not found: $PCH"
[[ -n "$RESOURCE" ]] || RESOURCE="$("$CLANG" -print-resource-dir)"
[[ -f "$RESOURCE/include/stdatomic.h" ]] || fail "Xcode stdatomic.h missing: $RESOURCE/include/stdatomic.h"
[[ -f "$RESOURCE/include/__stddef_max_align_t.h" ]] || fail "Xcode __stddef_max_align_t.h missing: $RESOURCE/include/__stddef_max_align_t.h"

TMP="$(mktemp -d "${TMPDIR:-/tmp}/trollstore-objc-sdk-probe.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT
cat > "$TMP/probe.m" <<'OBJC'
#include <stdatomic.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
int main(void) {
    atomic_int value;
    atomic_init(&value, 1);
    return atomic_load(&value) - 1;
}
OBJC

# Use an isolated module cache so a CI-restored PCM cannot mask the compiler
# selected in this build. The wrapper forces the Xcode builtin resource dir.
set +e
/bin/bash "$ROOT/Scripts/xcode-clang-wrapper.sh" \
    -target arm64-apple-ios16.0 \
    -isysroot "$SDK_DIR" \
    -fmodules -fcxx-modules \
    -fmodules-cache-path="$TMP/module-cache" \
    -fobjc-arc -fsyntax-only -x objective-c -H \
    -include "$PCH" "$TMP/probe.m" \
    2>"$TMP/compiler.log"
status=$?
set -e
if [[ $status -ne 0 ]]; then
    cat "$TMP/compiler.log" >&2
    fail "Xcode Clang could not compile an Objective-C probe with Theos Prefix.pch (exit $status)"
fi
if grep -F '/Toolchains/swift-' "$TMP/compiler.log" | grep -E '/(usr/bin/\.\./lib|usr/lib)/swift/clang/include/' >/dev/null; then
    cat "$TMP/compiler.log" >&2
    fail 'Swift.org Clang builtin include directory still appears in the Objective-C header trace'
fi
if ! grep -F "$RESOURCE/include/stdatomic.h" "$TMP/compiler.log" >/dev/null; then
    cat "$TMP/compiler.log" >&2
    fail 'the Objective-C header trace did not resolve stdatomic.h from Xcode builtin headers'
fi
printf '[toolchain] Objective-C Prefix.pch probe passed; stdatomic.h: %s/include/stdatomic.h\n' "$RESOURCE"
