#!/usr/bin/env bash
# The TrollStore app is an arm64-only Theos target. Swift 5.8.1 ships some
# iphoneos runtime dylibs with an arm64e.old slice inside a fat header labelled
# arm64e. Newer Apple ld validates every fat slice and rejects those files even
# when the requested link architecture is only arm64. Build a link-only overlay
# containing the arm64 slices; never modify the signed Swift toolchain itself.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
TOOLCHAIN_DIR="${SWIFT58_TOOLCHAIN_DIR:-$HOME/Library/Developer/Toolchains/swift-5.8.1-RELEASE.xctoolchain}"
SOURCE_DIR="${SWIFT58_IOS_RUNTIME_DIR:-$TOOLCHAIN_DIR/usr/lib/swift/iphoneos}"
DEST_DIR="${SWIFT_RUNTIME_ARM64_DIR:-$PROJECT_ROOT/TrollStore/.theos/swift-runtime/iphoneos-arm64}"
LIPO_BIN="${LIPO:-$(xcrun --find lipo 2>/dev/null || command -v lipo || true)}"

fail() {
    echo "error: [swift-runtime] $*" >&2
    exit 1
}

[[ "$(uname -s)" == "Darwin" ]] || fail "arm64 Swift runtime staging must run on the macOS Theos build runner"
[[ -d "$SOURCE_DIR" ]] || fail "Swift 5.8.1 iPhoneOS runtime directory is missing: $SOURCE_DIR"
[[ -n "$LIPO_BIN" && -x "$LIPO_BIN" ]] || fail "Apple lipo is unavailable; install/activate Xcode command-line tools"

shopt -s nullglob
runtime_files=("$SOURCE_DIR"/*.dylib "$SOURCE_DIR"/*.a)
[[ ${#runtime_files[@]} -gt 0 ]] || fail "no Swift iPhoneOS runtime dylibs or archives found under $SOURCE_DIR"

parent_dir="$(dirname "$DEST_DIR")"
mkdir -p "$parent_dir"
stage_dir="$(mktemp -d "$parent_dir/.swift-runtime-arm64.XXXXXX")"
cleanup() { rm -rf "$stage_dir"; }
trap cleanup EXIT

staged_dylibs=0
staged_archives=0
skipped_no_arm64=0
for source in "${runtime_files[@]}"; do
    [[ -f "$source" ]] || continue
    name="${source##*/}"
    archs="$("$LIPO_BIN" -archs "$source" 2>&1)" || fail "lipo could not inspect $source: $archs"
    if [[ " $archs " != *" arm64 "* ]]; then
        echo "[swift-runtime] skip arm64e-only runtime: $name ($archs)"
        skipped_no_arm64=$((skipped_no_arm64 + 1))
        continue
    fi

    output="$stage_dir/$name"
    if [[ "$archs" == "arm64" ]]; then
        # lipo -thin requires a FAT input; already-thin arm64 runtime files
        # are copied byte-for-byte into the overlay instead.
        cp -p "$source" "$output"
    else
        "$LIPO_BIN" "$source" -thin arm64 -output "$output" || fail "could not extract the arm64 slice from $source"
    fi
    output_archs="$("$LIPO_BIN" -archs "$output" 2>&1)" || fail "lipo could not inspect staged runtime $output: $output_archs"
    [[ "$output_archs" == "arm64" ]] || fail "$name was not reduced to a single arm64 slice (got: $output_archs)"
    "$LIPO_BIN" -verify_arch arm64 "$output" || fail "staged runtime is missing a valid arm64 slice: $name"

    if [[ "$name" == *.dylib ]]; then
        chmod 755 "$output"
        staged_dylibs=$((staged_dylibs + 1))
    else
        chmod 644 "$output"
        staged_archives=$((staged_archives + 1))
    fi
    echo "[swift-runtime] arm64-only: $name"
done

[[ "$staged_dylibs" -gt 0 ]] || fail "no arm64 Swift runtime dylibs could be staged from $SOURCE_DIR"

printf 'format=1\narchitecture=arm64\nsource=%s\nstaged_dylibs=%s\nstaged_archives=%s\nskipped_no_arm64=%s\n' \
    "$SOURCE_DIR" "$staged_dylibs" "$staged_archives" "$skipped_no_arm64" \
    > "$stage_dir/.trollstore-swift-runtime"

# Publish only after every staged file has passed lipo validation. The original
# toolchain directory and its arm64e slices are left untouched.
rm -rf "$DEST_DIR"
mv "$stage_dir" "$DEST_DIR"
trap - EXIT
printf '[swift-runtime] ready: %s (dylibs=%s, archives=%s, skipped=%s)\n' \
    "$DEST_DIR" "$staged_dylibs" "$staged_archives" "$skipped_no_arm64"
