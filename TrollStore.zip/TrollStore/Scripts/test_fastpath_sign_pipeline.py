#!/usr/bin/env python3
"""Host-independent regression test for per-slice signing and universal reconstruction."""
from __future__ import annotations

import os
from pathlib import Path
import struct
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent.parent
VALIDATOR = ROOT / "Scripts/validate_macho_signature.py"
FINDER = ROOT / "Scripts/find_signed_theos_binary.py"
WRAPPER = ROOT / "Scripts/fastpath_sign_all_slices.py"
FRAMEWORK_PACKAGER = ROOT / "Scripts/package_framework_preset.py"
FAT_MAGIC = 0xCAFEBABE
CPU_TYPE_ARM64 = 0x0100000C
CSMAGIC_EMBEDDED_SIGNATURE = 0xFADE0CC0
CSMAGIC_CODEDIRECTORY = 0xFADE0C02


def signature_blob() -> bytes:
    code_directory = struct.pack(">II", CSMAGIC_CODEDIRECTORY, 44) + bytes(36)
    return struct.pack(">III", CSMAGIC_EMBEDDED_SIGNATURE, 64, 1) + struct.pack(">II", 0, 20) + code_directory


def make_thin(path: Path, arch: str, signed: bool) -> None:
    subtype = 2 if arch == "arm64e" else 0
    ncmds = 1 if signed else 0
    sizeofcmds = 16 if signed else 0
    header = struct.pack("<IiiIIIII", 0xFEEDFACF, CPU_TYPE_ARM64, subtype, 6, ncmds, sizeofcmds, 0, 0)
    if signed:
        blob = signature_blob()
        load = struct.pack("<IIII", 0x1D, 16, 48, len(blob))
        path.write_bytes(header + load + blob)
    else:
        path.write_bytes(header)


def write_fake_tools(directory: Path) -> tuple[Path, Path]:
    lipo = directory / "fake-lipo"
    lipo.write_text(r'''#!/usr/bin/env python3
import pathlib, struct, sys
FAT=0xCAFEBABE
CPU=0x0100000C

def slices(path):
    data=pathlib.Path(path).read_bytes()
    if len(data)>=8 and int.from_bytes(data[:4], "big")==FAT:
        count=struct.unpack_from(">I", data, 4)[0]
        out=[]
        for i in range(count):
            cpu, sub, off, size, align=struct.unpack_from(">iiIII", data, 8+i*20)
            out.append(("arm64e" if (sub & 0xffffff)==2 else "arm64", cpu, sub, data[off:off+size]))
        return out
    cpu, sub=struct.unpack_from("<ii", data, 4)
    return [("arm64e" if (sub & 0xffffff)==2 else "arm64", cpu, sub, data)]

args=sys.argv[1:]
if args[0]=="-archs":
    print(" ".join(x[0] for x in slices(args[1])))
elif args[0]=="-thin":
    arch, source=args[1], args[2]
    output=args[args.index("-output")+1]
    found=[x for x in slices(source) if x[0]==arch]
    if len(found)!=1: sys.exit(2)
    pathlib.Path(output).write_bytes(found[0][3])
elif args[0]=="-create":
    output=args[args.index("-output")+1]
    names=args[1:args.index("-output")]
    entries=[]
    for name in names:
        arch,cpu,sub,data=slices(name)[0]
        entries.append((cpu,sub,data))
    cursor=8+20*len(entries)
    records=[]
    for cpu,sub,data in entries:
        cursor=(cursor+4095)&~4095
        records.append((cpu,sub,cursor,len(data),12,data))
        cursor+=len(data)
    out=bytearray(records[-1][2]+records[-1][3])
    struct.pack_into(">II", out, 0, FAT, len(records))
    for i,(cpu,sub,off,size,align,data) in enumerate(records):
        struct.pack_into(">iiIII", out, 8+i*20, cpu, sub, off, size, align)
        out[off:off+size]=data
    pathlib.Path(output).write_bytes(out)
else:
    sys.exit(3)
''', encoding="utf-8")
    signer = directory / "fake-fastPathSign"
    signer.write_text(r'''#!/usr/bin/env python3
import pathlib, struct, sys
p=pathlib.Path(sys.argv[-1])
b=bytearray(p.read_bytes())
magic=struct.unpack_from("<I", b, 0)[0]
if magic != 0xFEEDFACF: sys.exit(2)
ncmds, sizeofcmds=struct.unpack_from("<II", b, 16)
if ncmds==0:
    blob=struct.pack(">III", 0xFADE0CC0, 64, 1)+struct.pack(">II", 0, 20)+struct.pack(">II", 0xFADE0C02, 44)+bytes(36)
    b[16:24]=struct.pack("<II", 1, 16)
    b.extend(struct.pack("<IIII", 0x1D, 16, 48, len(blob)))
    b.extend(blob)
    p.write_bytes(b)
''', encoding="utf-8")
    lipo.chmod(0o755)
    signer.chmod(0o755)
    return lipo, signer


def check(command: list[str], env: dict[str, str]) -> None:
    result = subprocess.run(command, env=env, text=True, capture_output=True)
    if result.returncode != 0:
        raise RuntimeError(f"command failed ({result.returncode}): {' '.join(command)}\n{result.stdout}\n{result.stderr}")


def main() -> int:
    try:
        with tempfile.TemporaryDirectory(prefix="fastpath-sign-test-") as temp_name:
            temp = Path(temp_name)
            lipo, signer = write_fake_tools(temp)
            env = os.environ.copy()
            env["LIPO_EXECUTABLE"] = str(lipo)
            env["FASTPATHSIGN_EXECUTABLE"] = str(signer)

            # Regress the exact CI failure: Theos leaves two thin architecture objects.
            obj = temp / "AppLock/.theos/obj"
            (obj / "arm64").mkdir(parents=True)
            (obj / "arm64e").mkdir(parents=True)
            make_thin(obj / "arm64/TSAppLock.dylib", "arm64", False)
            make_thin(obj / "arm64e/TSAppLock.dylib", "arm64e", False)
            dsym = obj / "arm64e/TSAppLock.dylib.dSYM/Contents/Resources/DWARF"
            dsym.mkdir(parents=True)
            make_thin(dsym / "TSAppLock.dylib", "arm64e", False)
            output = temp / "Resources/TSAppLock.dylib"
            check([
                sys.executable, str(FINDER), str(obj), "TSAppLock.dylib",
                "--signer-wrapper", str(WRAPPER), "--output", str(output),
                "--expect-arch", "arm64", "--expect-arch", "arm64e", "--lipo", str(lipo),
            ], env)
            check([sys.executable, str(VALIDATOR), str(output), "--expect-arch", "arm64", "--expect-arch", "arm64e"], env)

            # Also verify that direct TARGET_CODESIGN wrapper use does not collapse a fat input.
            unsigned_universal = temp / "input-universal.dylib"
            check([str(lipo), "-create", str(obj / "arm64/TSAppLock.dylib"), str(obj / "arm64e/TSAppLock.dylib"), "-output", str(unsigned_universal)], env)
            check([sys.executable, str(WRAPPER), str(unsigned_universal)], env)
            check([sys.executable, str(VALIDATOR), str(unsigned_universal), "--expect-arch", "arm64", "--expect-arch", "arm64e"], env)

            # The Framework packager must preserve the signed universal executable byte-for-byte.
            staged = temp / "TSAppLock.dylib"
            staged.write_bytes(unsigned_universal.read_bytes())
            framework = temp / "TSAppLock.framework"
            check([sys.executable, str(FRAMEWORK_PACKAGER), "--input", str(staged), "--output", str(framework), "--bundle-id", "com.example.tweak", "--minimum-ios", "16.0"], env)
            executable = framework / "TSAppLock"
            if executable.read_bytes() != staged.read_bytes() or not (executable.stat().st_mode & 0o111):
                raise RuntimeError("framework packaging changed the signed Mach-O or dropped executable permission")
            import plistlib
            with (framework / "Info.plist").open("rb") as stream:
                info = plistlib.load(stream)
            if info.get("CFBundlePackageType") != "FMWK" or info.get("CFBundleExecutable") != "TSAppLock":
                raise RuntimeError("framework Info.plist does not describe the packaged executable")

        print("[test] fastPathSign per-slice signing, universal reconstruction, and Framework wrapping passed")
        return 0
    except (OSError, RuntimeError, subprocess.SubprocessError) as exc:
        print(f"error: fastPathSign pipeline regression test: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
