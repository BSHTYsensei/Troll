#!/usr/bin/env python3
"""Check that every thin/fat Mach-O slice contains an embedded CodeDirectory."""
from __future__ import annotations
import argparse
import struct
import sys
from pathlib import Path
FAT_MAGIC=0xCAFEBABE; FAT_CIGAM=0xBEBAFECA; FAT_MAGIC_64=0xCAFEBABF; FAT_CIGAM_64=0xBFBAFECA
MH_MAGIC=0xFEEDFACE; MH_MAGIC_64=0xFEEDFACF; LC_CODE_SIGNATURE=0x1D
CSMAGIC_EMBEDDED_SIGNATURE=0xFADE0CC0; CSMAGIC_CODEDIRECTORY=0xFADE0C02
CPU_TYPE_ARM64=0x0100000C; CPU_TYPE_X86_64=0x01000007; CPU_TYPE_ARM=12; CPU_TYPE_X86=7

def fail(message): raise ValueError(message)
def arch_name(cputype, cpusubtype):
    subtype=cpusubtype & 0x00FFFFFF
    if cputype==CPU_TYPE_ARM64:
        if subtype==2: return 'arm64e'
        if subtype in (0,1): return 'arm64'
        return f'arm64-subtype-{subtype}'
    if cputype==CPU_TYPE_X86_64: return 'x86_64'
    if cputype==CPU_TYPE_ARM: return 'arm'
    if cputype==CPU_TYPE_X86: return 'i386'
    return f'cpu-{cputype:#x}-subtype-{subtype:#x}'

def split_slices(data):
    if len(data)<4: fail('file is too small to be a Mach-O')
    magic_be=int.from_bytes(data[:4],'big')
    if magic_be in (FAT_MAGIC,FAT_MAGIC_64): endian,is64='>',magic_be==FAT_MAGIC_64
    elif magic_be in (FAT_CIGAM,FAT_CIGAM_64): endian,is64='<',magic_be==FAT_CIGAM_64
    else: return [(None,None,data)]
    if len(data)<8: fail('truncated fat header')
    count=struct.unpack_from(endian+'I',data,4)[0]; ent_size=32 if is64 else 20
    if count==0 or 8+count*ent_size>len(data): fail('invalid fat architecture table')
    out=[]
    for i in range(count):
        off=8+i*ent_size
        if is64: cpu,sub,offset,size,_align,_reserved=struct.unpack_from(endian+'iiQQII',data,off)
        else: cpu,sub,offset,size,_align=struct.unpack_from(endian+'iiIII',data,off)
        if size==0 or offset>len(data) or size>len(data)-offset: fail(f'fat slice {i} has an out-of-bounds range')
        out.append((cpu,sub,data[offset:offset+size]))
    return out

def validate_thin(buf,label):
    if len(buf)<28: fail(f'{label}: truncated Mach-O header')
    le=int.from_bytes(buf[:4],'little'); be=int.from_bytes(buf[:4],'big')
    if le in (MH_MAGIC,MH_MAGIC_64): endian,magic='<',le
    elif be in (MH_MAGIC,MH_MAGIC_64): endian,magic='>',be
    else: fail(f'{label}: not a supported thin Mach-O slice')
    hsize=32 if magic==MH_MAGIC_64 else 28
    if len(buf)<hsize: fail(f'{label}: truncated Mach-O header')
    cpu,sub,_ft,ncmds,sizeofcmds=struct.unpack_from(endian+'iiIII',buf,4)
    end=hsize+sizeofcmds
    if end>len(buf): fail(f'{label}: load commands exceed slice size')
    sigs=[]; cur=hsize
    for _ in range(ncmds):
        if cur+8>end: fail(f'{label}: truncated load command')
        cmd,cmdsize=struct.unpack_from(endian+'II',buf,cur)
        if cmdsize<8 or cur+cmdsize>end: fail(f'{label}: invalid load command size')
        if cmd==LC_CODE_SIGNATURE:
            if cmdsize<16: fail(f'{label}: malformed LC_CODE_SIGNATURE')
            dataoff,datasize=struct.unpack_from(endian+'II',buf,cur+8)
            if datasize<12 or dataoff>len(buf) or datasize>len(buf)-dataoff: fail(f'{label}: code signature range is invalid')
            sigs.append((dataoff,datasize))
        cur+=cmdsize
    if len(sigs)!=1: fail(f'{label}: expected exactly one LC_CODE_SIGNATURE, found {len(sigs)}')
    off,size=sigs[0]; blob=buf[off:off+size]
    magic,length,count=struct.unpack_from('>III',blob,0)
    if magic!=CSMAGIC_EMBEDDED_SIGNATURE: fail(f'{label}: invalid embedded signature superblob magic {magic:#x}')
    if length<12 or length>len(blob) or count==0 or 12+count*8>length: fail(f'{label}: malformed embedded signature superblob')
    found=False
    for i in range(count):
        slot,boff=struct.unpack_from('>II',blob,12+i*8)
        if boff+8>length: fail(f'{label}: signature slot {slot:#x} points outside superblob')
        bmagic,blen=struct.unpack_from('>II',blob,boff)
        if blen<8 or boff+blen>length: fail(f'{label}: signature slot {slot:#x} has invalid blob length')
        if slot==0 and bmagic==CSMAGIC_CODEDIRECTORY:
            if blen<44: fail(f'{label}: CodeDirectory header is truncated')
            found=True
    if not found: fail(f'{label}: no primary CodeDirectory (CSSLOT_CODEDIRECTORY) in embedded signature')
    return arch_name(cpu,sub)

def main():
    p=argparse.ArgumentParser(description=__doc__); p.add_argument('macho',type=Path); p.add_argument('--expect-arch',action='append',default=[]); a=p.parse_args()
    try:
        slices=split_slices(a.macho.read_bytes()); found=[validate_thin(x[2],f'{a.macho} slice {i}') for i,x in enumerate(slices)]
        missing=sorted(set(a.expect_arch)-set(found))
        if missing: fail(f"{a.macho}: missing required architecture slice(s): {', '.join(missing)}; found {', '.join(found)}")
        print(f"[signature] {a.macho}: {', '.join(found)}; CodeDirectory present in every slice")
        return 0
    except (OSError,ValueError,struct.error) as e:
        print(f'error: {e}',file=sys.stderr); return 1
if __name__=='__main__': raise SystemExit(main())
