#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/trollstore-fastpath-host-sdk.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT

SDK="$TMP/MacOSX.sdk"
BIN="$TMP/bin"
mkdir -p \
  "$SDK/System/Library/Frameworks/Foundation.framework/Headers" \
  "$SDK/System/Library/Frameworks/CoreFoundation.framework/Headers" \
  "$SDK/usr/include" "$SDK/System/Library/Frameworks/CoreServices.framework" \
  "$SDK/System/Library/Frameworks/Security.framework" "$BIN" "$TMP/openssl/include"
: > "$SDK/System/Library/Frameworks/Foundation.framework/Headers/Foundation.h"
: > "$SDK/System/Library/Frameworks/CoreFoundation.framework/Headers/CoreFoundation.h"
: > "$SDK/usr/include/stdlib.h"
cat > "$BIN/fake-clang" <<'CLANG'
#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' "$@" > "$FASTPATHSIGN_ARG_LOG"
# Create the output file passed after -o, so the Make target can complete.
while (($#)); do
  if [[ "$1" == "-o" ]]; then
    shift
    : > "$1"
    chmod +x "$1"
    exit 0
  fi
  shift
done
exit 2
CLANG
cat > "$BIN/pkg-config" <<'PKG'
#!/usr/bin/env bash
case "${1:-}" in
  --cflags) printf '%s\n' "-I$FAKE_OPENSSL_INCLUDE" ;;
  --libs) printf '%s\n' '-lcrypto' ;;
  *) exit 2 ;;
esac
PKG
chmod +x "$BIN/fake-clang" "$BIN/pkg-config"

FASTPATHSIGN_ARG_LOG="$TMP/args.log" \
FAKE_OPENSSL_INCLUDE="$TMP/openssl/include" \
PATH="$BIN:$PATH" \
make --no-print-directory -C "$ROOT/Exploits/fastPathSign" \
  HOST_MACOSX_SDKROOT="$SDK" clean >/dev/null
FASTPATHSIGN_ARG_LOG="$TMP/args.log" \
FAKE_OPENSSL_INCLUDE="$TMP/openssl/include" \
PATH="$BIN:$PATH" \
make --no-print-directory -C "$ROOT/Exploits/fastPathSign" \
  CC="$BIN/fake-clang" \
  HOST_MACOSX_SDKROOT="$SDK" \
  HOST_MACOSX_DEPLOYMENT_TARGET=12.0 >/dev/null

args="$(cat "$TMP/args.log")"
grep -Fqx -- '-isysroot' "$TMP/args.log"
grep -Fqx -- "$SDK" "$TMP/args.log"
grep -Fqx -- '-mmacosx-version-min=12.0' "$TMP/args.log"
if grep -Fq 'iPhoneOS' "$TMP/args.log"; then
  echo 'error: fastPathSign host build received an iPhoneOS SDK path' >&2
  exit 1
fi
rm -f "$ROOT/Exploits/fastPathSign/fastPathSign"
echo '[test] fastPathSign host compiler receives the macOS SDK sysroot and deployment target'
