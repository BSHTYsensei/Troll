#!/usr/bin/env python3
"""Validate that the ChOma source revision matches TrollStore's fastPathSign API."""
from pathlib import Path
import argparse
import re
import subprocess
import sys

PINNED_COMMIT = "964023ddac2286ef8e843f90df64d44ac6a673df"

parser = argparse.ArgumentParser()
parser.add_argument("choma_dir", nargs="?", default="ChOma")
parser.add_argument("--expected-commit", default=PINNED_COMMIT)
args = parser.parse_args()
root = Path(args.choma_dir).resolve()

if not root.is_dir():
    raise SystemExit(f"error: ChOma directory does not exist: {root}")

# A source archive has no .git directory. Running `git -C <nested-dir>` in
# that case can silently return the *parent TrollStore checkout's* HEAD, which
# falsely reports the ChOma archive as the wrong revision. Only query Git when
# ChOma itself owns Git metadata; otherwise trust the revision marker written by
# Scripts/bootstrap_choma.sh and validate the pinned API below.
if (root / ".git").exists():
    try:
        actual_commit = subprocess.check_output(
            ["git", "-C", str(root), "rev-parse", "HEAD"],
            stderr=subprocess.DEVNULL, text=True,
        ).strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        actual_commit = ""
else:
    actual_commit = ""

if not actual_commit:
    marker = root / ".trollstore-choma-commit"
    actual_commit = marker.read_text(encoding="utf-8").strip() if marker.is_file() else ""

if actual_commit != args.expected_commit:
    raise SystemExit(
        "error: incompatible ChOma revision; "
        f"expected {args.expected_commit}, found {actual_commit or 'unmarked source archive'}"
    )

required_files = [
    "src/FAT.h",
    "src/MachOLoadCommand.h",
    "src/CodeDirectory.h",
    "src/CSBlob.h",
    "external/ios/libcrypto.a",
]
missing = [item for item in required_files if not (root / item).is_file()]
if missing:
    raise SystemExit("error: pinned ChOma checkout is incomplete: " + ", ".join(missing))

fat_header = (root / "src/FAT.h").read_text(encoding="utf-8", errors="replace")
load_header = (root / "src/MachOLoadCommand.h").read_text(encoding="utf-8", errors="replace")
cd_header = (root / "src/CodeDirectory.h").read_text(encoding="utf-8", errors="replace")

if not re.search(r"typedef\s+struct\s+FAT\b[\s\S]*?}\s*FAT\s*;", fat_header):
    raise SystemExit("error: ChOma/src/FAT.h does not declare the FAT type expected by fastPathSign")

expected_four_arg_api = re.compile(
    r"update_load_commands_for_coretrust_bypass\s*\(\s*"
    r"MachO\s*\*\s*macho\s*,\s*"
    r"CS_SuperBlob\s*\*\s*superblob\s*,\s*"
    r"uint64_t\s+originalCodeSignatureSize\s*,\s*"
    r"uint64_t\s+originalMachOSize\s*\)",
    re.S,
)
if not expected_four_arg_api.search(load_header):
    raise SystemExit(
        "error: ChOma MachOLoadCommand.h has an incompatible API; "
        "fastPathSign requires update_load_commands_for_coretrust_bypass with 4 arguments"
    )
if not re.search(r"void\s+csd_code_directory_update\s*\(\s*CS_DecodedBlob\s*\*\s*\w+\s*,\s*MachO\s*\*\s*\w+\s*\)", cd_header):
    raise SystemExit(
        "error: ChOma CodeDirectory.h lacks csd_code_directory_update required by fastPathSign"
    )

print(f"[deps] ChOma {actual_commit} verified: FAT.h + 4-argument load-command API + code-directory updater")
