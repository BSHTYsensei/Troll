#!/usr/bin/env bash
# Build Theos' host-side Swift support utilities with the project's standalone
# Swift 5.8.1 toolchain. This does not locate or invoke Xcode's swift binary.
set -euo pipefail

THEOS_ROOT="${THEOS:-${HOME}/theos}"
SWIFT58_TOOLCHAIN_DIR="${SWIFT58_TOOLCHAIN_DIR:-$HOME/Library/Developer/Toolchains/swift-5.8.1-RELEASE.xctoolchain}"
SUPPORT_DIR="${THEOS_VENDOR_SWIFT_SUPPORT_PATH:-${THEOS_ROOT}/vendor/swift-support}"
BOOTSTRAPPER="${THEOS_ROOT}/bin/swift-bootstrapper.pl"
SWIFT_BIN="${SWIFT_BIN:-${SWIFT58_TOOLCHAIN_DIR}/usr/bin/swift}"

fail() {
    echo "error: $*" >&2
    exit 1
}

[[ -f "${THEOS_ROOT}/makefiles/common.mk" ]] || fail "THEOS is not a valid Theos checkout: ${THEOS_ROOT}"
[[ -f "${BOOTSTRAPPER}" ]] || fail "Theos Swift bootstrapper is missing: ${BOOTSTRAPPER}"
[[ -x "${SWIFT_BIN}" ]] || fail "standalone Swift 5.8.1 executable is missing: ${SWIFT_BIN}"

swift_version_output="$("${SWIFT_BIN}" --version 2>&1)" || fail "could not execute standalone Swift toolchain: ${SWIFT_BIN}"
printf '%s\n' "${swift_version_output}" | grep -Eq '(Apple )?Swift version 5\.8\.1([[:space:]]|$)' || fail "Theos Swift host tools must be built with Swift 5.8.1; got: ${swift_version_output}"

# swift-support is a Theos git submodule. Some non-recursive Theos installations
# leave the directory present but empty, which is not a usable Swift support tree.
if [[ ! -f "${SUPPORT_DIR}/Package.swift" ]]; then
    if git -C "${THEOS_ROOT}" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
        echo "[swift-support] Initializing Theos vendor/swift-support submodule…"
        git -C "${THEOS_ROOT}" submodule update --init --recursive -- vendor/swift-support
    fi
fi
[[ -f "${SUPPORT_DIR}/Package.swift" ]] || fail "Theos Swift support sources are missing at ${SUPPORT_DIR}; initialize Theos with its vendor submodules"

BUILD_DIR="${SUPPORT_DIR}/.theos_build"
BIN_DIR="${BUILD_DIR}/release"
REQUIRED_TOOLS=("${BIN_DIR}/generate-output-file-map" "${BIN_DIR}/parse-swiftc-output")

missing=0
for tool in "${REQUIRED_TOOLS[@]}"; do
    if [[ ! -x "${tool}" ]]; then
        echo "[swift-support] Missing or non-executable: ${tool}"
        missing=1
    fi
done

# Invalidate incomplete cached SwiftPM output before Theos' bootstrapper runs.
if [[ "${missing}" -eq 1 ]]; then
    echo "[swift-support] Removing an incomplete cached build: ${BUILD_DIR}"
    rm -rf "${BUILD_DIR}"
fi

(
    unset THEOS_NO_SWIFT_CACHE
    PATH="$(dirname "${SWIFT_BIN}"):${PATH}" perl "${BOOTSTRAPPER}" "${SWIFT_BIN}" "${SUPPORT_DIR}" \
        'printf "%s\\n" "[swift-support] Building/verifying Theos Swift host tools with standalone Swift 5.8.1"'
)

for tool in "${REQUIRED_TOOLS[@]}"; do
    [[ -x "${tool}" ]] || fail "Swift support bootstrap completed without producing ${tool}; check SwiftPM output above"
done

printf '[swift-support] Ready: %s (Swift: %s)\n' "${BIN_DIR}" "$("${SWIFT_BIN}" --version | head -n 1)"
