#!/usr/bin/env bash
# Repair/validate Theos' host-side Swift support tools before compiling Swift targets.
# Theos caches a per-project marker under .theos/markers/swift_support. If that marker
# survives a CI cache restore while vendor/swift-support/.theos_build is incomplete,
# rules.mk skips swift-bootstrapper.pl and the build later fails with a missing
# generate-output-file-map executable. This preflight repairs that inconsistent state.
set -euo pipefail

THEOS_ROOT="${THEOS:-${HOME}/theos}"
SUPPORT_DIR="${THEOS_VENDOR_SWIFT_SUPPORT_PATH:-${THEOS_ROOT}/vendor/swift-support}"
BOOTSTRAPPER="${THEOS_ROOT}/bin/swift-bootstrapper.pl"

fail() {
    echo "error: $*" >&2
    exit 1
}

[[ -f "${THEOS_ROOT}/makefiles/common.mk" ]] || fail "THEOS is not a valid Theos checkout: ${THEOS_ROOT}"
[[ -x "$(command -v xcrun || true)" ]] || fail "xcrun is required to locate the Xcode Swift toolchain"
[[ -f "${BOOTSTRAPPER}" ]] || fail "Theos Swift bootstrapper is missing: ${BOOTSTRAPPER}"

SWIFT_BIN="${SWIFT_BIN:-$(xcrun --find swift 2>/dev/null || true)}"
[[ -n "${SWIFT_BIN}" && -x "${SWIFT_BIN}" ]] || fail "Xcode swift executable could not be found (xcrun --find swift)"

# swift-support is a Theos git submodule. Some non-recursive Theos installations
# leave the directory present but empty, which is not a usable Swift support tree.
if [[ ! -f "${SUPPORT_DIR}/Package.swift" ]]; then
    if git -C "${THEOS_ROOT}" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
        echo "[swift-support] Initializing Theos vendor/swift-support submodule…"
        git -C "${THEOS_ROOT}" submodule update --init --recursive -- vendor/swift-support
    fi
fi
[[ -f "${SUPPORT_DIR}/Package.swift" ]] || fail "Theos Swift support sources are missing at ${SUPPORT_DIR}; initialize Theos with its vendor submodules"

BUILD_DIR="${SUPPORT_DIR}/.theos_build"
BIN_DIR="${BUILD_DIR}/release"
REQUIRED_TOOLS=("${BIN_DIR}/generate-output-file-map" "${BIN_DIR}/parse-swiftc-output")

missing=0
for tool in "${REQUIRED_TOOLS[@]}"; do
    if [[ ! -x "${tool}" ]]; then
        echo "[swift-support] Missing or non-executable: ${tool}"
        missing=1
    fi
done

# Remove the entire partial SPM build when its products are missing. This also
# removes swift-bootstrapper.pl's success marker, preventing its cache fast-path
# from falsely accepting a broken build directory (including a stale theos_build_commit).
if [[ "${missing}" -eq 1 ]]; then
    echo "[swift-support] Removing an incomplete cached build: ${BUILD_DIR}"
    rm -rf "${BUILD_DIR}"
fi

# Use Theos' own bootstrapper so its lock, Swift-version/commit cache key and
# expected SPM_THEOS_BUILD invocation remain in sync with rules.mk. Clear the
# optional skip/cache override only for this repair step; it must not bypass the
# bootstrap when the output-file-map generator is absent.
(
    unset THEOS_NO_SWIFT_CACHE
    perl "${BOOTSTRAPPER}" "${SWIFT_BIN}" "${SUPPORT_DIR}" \
        'printf "%s\n" "[swift-support] Building/verifying Theos Swift host tools"'
)

for tool in "${REQUIRED_TOOLS[@]}"; do
    [[ -x "${tool}" ]] || fail "Swift support bootstrap completed without producing ${tool}; check Xcode/SwiftPM output above"
done

printf '[swift-support] Ready: %s (Swift: %s)\n' "${BIN_DIR}" "$("${SWIFT_BIN}" --version | head -n 1)"
