#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d "${TMPDIR:-/tmp}/trollstore-swift-runtime-test.XXXXXX")"
trap 'rm -rf "$TMP"' EXIT

mkdir -p "$TMP/toolchain/usr/lib/swift/iphoneos" "$TMP/bin"
printf 'arm64 arm64e\n' > "$TMP/toolchain/usr/lib/swift/iphoneos/libswiftDarwin.dylib"
printf 'arm64 arm64e\n' > "$TMP/toolchain/usr/lib/swift/iphoneos/libswift_StringProcessing.dylib"
printf 'arm64\n' > "$TMP/toolchain/usr/lib/swift/iphoneos/libswiftCore.dylib"
printf 'arm64 arm64e\n' > "$TMP/toolchain/usr/lib/swift/iphoneos/libswift_Concurrency.dylib"
printf 'arm64e\n' > "$TMP/toolchain/usr/lib/swift/iphoneos/libswiftArm64eOnly.dylib"

cat > "$TMP/bin/fake-lipo" <<'FAKE_LIPO'
#!/usr/bin/env bash
set -euo pipefail
if [[ "$1" == "-archs" ]]; then
    cat "$2"
elif [[ "$1" == "-verify_arch" ]]; then
    requested="$2"; file="$3"
    # Reproduce the CI failure: lipo lists arm64 after thinning this one
    # dylib, but its stricter architecture verification rejects the slice.
    [[ "${file##*/}" != "libswift_Concurrency.dylib" ]] || exit 1
    grep -qw "$requested" "$file" || exit 1
elif [[ "$2" == "-thin" && "$3" == "arm64" && "$4" == "-output" ]]; then
    source="$1"; output="$5"
    cp "$source" "$output"
    printf 'arm64\n' > "$output"
else
    echo "fake-lipo: unsupported arguments: $*" >&2
    exit 2
fi
FAKE_LIPO
chmod 755 "$TMP/bin/fake-lipo"

# The script normally requires macOS; simulate the platform for its unit test.
# fake-lipo makes architecture metadata observable without fabricating Mach-O bytes.
prepare_copy="$TMP/prepare_swift_runtime_test.sh"
sed 's/\[\[ "$(uname -s)" == "Darwin" \]\] || fail.*/# platform check bypassed by the unit test/' \
    "$ROOT/Scripts/prepare_swift_runtime_arm64.sh" > "$prepare_copy"
chmod 755 "$prepare_copy"

SWIFT58_TOOLCHAIN_DIR="$TMP/toolchain" \
SWIFT_RUNTIME_ARM64_DIR="$TMP/output/iphoneos-arm64" \
LIPO="$TMP/bin/fake-lipo" \
    /bin/bash "$prepare_copy"

OUT="$TMP/output/iphoneos-arm64"
[[ -f "$OUT/.trollstore-swift-runtime" ]]
for library in libswiftDarwin.dylib libswift_StringProcessing.dylib libswiftCore.dylib; do
    [[ -f "$OUT/$library" ]]
    [[ "$(cat "$OUT/$library")" == "arm64" ]]
done
[[ ! -e "$OUT/libswiftArm64eOnly.dylib" ]]
# A dylib with a failed strict arm64 validation is omitted so the preserved
# SDK /usr/lib/swift path can provide its import stub during final linking.
[[ ! -e "$OUT/libswift_Concurrency.dylib" ]]
# Ensure the source toolchain files were not modified.
[[ "$(cat "$TMP/toolchain/usr/lib/swift/iphoneos/libswiftDarwin.dylib")" == "arm64 arm64e" ]]
grep -q '^architecture=arm64$' "$OUT/.trollstore-swift-runtime"
grep -q '^staged_dylibs=3$' "$OUT/.trollstore-swift-runtime"
grep -q '^skipped_invalid_dylibs=1$' "$OUT/.trollstore-swift-runtime"

# Verify the exact GNU make expression used by TrollStore/Makefile: replace
# only Theos' toolchain /iphoneos search path and retain the system fallback.
cat > "$TMP/path-override.mk" <<MAKEFILE
_THEOS_TARGET_SWIFT_LDPATHS := /mock/swift-5.8.1/usr/bin/../lib/swift/iphoneos /usr/lib/swift
SWIFT_RUNTIME_ARM64_DIR := $OUT
_SWIFT_RUNTIME_SYSTEM_LDPATHS := \$(filter-out %/iphoneos,\$(_THEOS_TARGET_SWIFT_LDPATHS))
override _THEOS_TARGET_SWIFT_LDPATHS := \$(SWIFT_RUNTIME_ARM64_DIR) \$(_SWIFT_RUNTIME_SYSTEM_LDPATHS)
.PHONY: check
check:
	@test '\$(_THEOS_TARGET_SWIFT_LDPATHS)' = '$OUT /usr/lib/swift'
	@echo '[test] Theos Swift runtime link path replacement passed'
MAKEFILE
make -s -f "$TMP/path-override.mk" check

echo "[test] arm64-only Swift runtime staging passed; invalid dylib fallback preserved; source toolchain unchanged"
