# TrollStore Swift port — GitHub Actions build

**Important: extract this ZIP and commit its contents into the repository root. Do not upload only the ZIP as a single file.** GitHub Actions only discovers workflows committed as files under `.github/workflows/`; it cannot execute a workflow stored inside an archive.

The project consolidates the main app, root helper, and persistence-helper application logic into these three Swift files:

- `TrollStore/TrollStore.swift`
- `RootHelper/RootHelper.swift`
- `TrollHelper/TrollHelper.swift`

Necessary CoreTrust backend C/Objective-C support sources remain under `Exploits/fastPathSign/src/`. Existing icons, app resources, Info.plists, entitlements, and compiled launch-screen resources are retained. No `.Assets` directory is used, and donation-controller sources are not included.

## GitHub Actions build

After committing the extracted files at the repository root, `.github/workflows/build.yml` runs on a macOS GitHub Actions runner. It builds the macOS host utility `fastPathSign`, builds the three iOS targets concurrently, performs artifact layout checks, and uploads `_build/TrollStore.tar` as a workflow artifact.

The workflow uses a precompiled iOS arm64 `ldid` executable at `bin/ldid`. It **does not build `ldid.cpp`** and never executes the device binary on the macOS runner. The supplied `bin/ldid` is included in this ZIP and is validated before being copied into `TrollStore.app/ldid`.

If you prefer to keep the binary outside the Git repository, set repository variable `LDID_BINARY_URL` to a direct URL that downloads the binary. For an authenticated download, add repository secret `LDID_BINARY_TOKEN`; the workflow sends it as a Bearer token. When the URL is unset, the checked-in `bin/ldid` is used.

## How to use

1. Download and extract the archive locally.
2. Upload/commit **the extracted files and hidden `.github` directory** to the GitHub repository root.
3. Ensure `bin/ldid` is present and committed, or configure `LDID_BINARY_URL` (and `LDID_BINARY_TOKEN` if needed).
4. Push to the default branch or open **Actions → Build TrollStore Swift → Run workflow**.
5. Download the `TrollStore-Swift-build` artifact from the completed run.

## Local build

On macOS with Xcode, Theos, Homebrew, and a complete ChOma checkout:

```sh
make bootstrap-deps
make assemble_trollstore THEOS="$HOME/theos" LDID_BIN="$PWD/bin/ldid"
```

The Makefile fetches ChOma when its headers or required iOS `libcrypto.a` are missing. The upstream source is not embedded in the original uploaded ZIP because it was a submodule; GitHub Actions fetches it and caches the checkout between runs.

## What was checked in this package

- Restored project resources from the supplied `TrollStore-main.zip` instead of relying on the prior incomplete ZIP.
- Included the precompiled iOS arm64 `bin/ldid` provided by the user.
- Confirmed there are exactly three Swift source files for the app and helper targets; original CoreTrust backend support sources remain in place.
- Added bounded parallel signing in the install helper and parallel compilation of the three independent Theos targets.
- Checked Swift syntax parsing, plist parsing, workflow YAML, binary architecture/platform, ZIP integrity, and required resource paths.

## Known functional gaps

This is a focused Swift port, not full feature parity with upstream TrollStore. It currently supports IPA download/import, install/update of managed apps, custom Entitlements overlays, app removal, LaunchServices refresh, and persistence-helper refresh/reopen actions. The original `.tar` self-update and persistence-migration flow, initial persistence-helper installation into a system app, and the original JIT/developer-mode management UI are not implemented. The `.tar` document association is therefore intentionally removed instead of advertising a nonfunctional update handler. These features must be ported before treating this package as a drop-in, feature-complete TrollStore replacement.

A full Xcode/Theos link and device installation test cannot be run in this Linux packaging environment. GitHub Actions parses all Swift files, builds with the real macOS toolchain, and checks that all four bundled executables are arm64 iOS Mach-O files; it cannot prove that private LaunchServices APIs behave correctly on every iOS release. The first workflow run and a device test remain necessary.
