# TrollStore — Original UI, Simplified Chinese, pre-install Entitlements

This archive is based on the latest saved TrollStore project snapshot available in the Library on 2026-10-31. It preserves the original TrollStore app, Settings UI, installed-app list, app details/actions, URL scheme handling, installation confirmation/errors, advanced options, update flow, and persistence-helper UI/logic. The original Objective-C controllers and the pre-install Entitlements editor remain Objective-C. One narrowly scoped Swift App Intents source is added to expose a background app-registration refresh action to Apple Shortcuts; this does not convert the app UI to Swift.

## Changes in this build

- Built-in Simplified Chinese (`zh-Hans.lproj`) for the main TrollStore app and persistence helper. `zh-Hans` is explicitly the development/default localization, so UI strings default to Chinese even when the device language is English.
- Removed the donation controller and its Settings entry.
- Added an **Edit Entitlements Before Install** switch in Settings (default off). When enabled, importing an IPA opens an editor seeded from that IPA’s original main-executable Entitlements. The editable XML/visual document is the complete dictionary, not an overlay: deleting a key removes it from the signed main executable. Configured ldid profiles get a short-lived private copy with Entitlements preservation/merge disabled for this one signature, while certificate, hash and jobs settings remain unchanged; the supplied precompiled ldid is not replaced. Done continues to the normal install confirmation; Cancel aborts the entire install and returns to the previous page. A unique temporary plist is scoped to this installation and retries, then removed. App extensions retain their own original Entitlements. For configured ldid profiles, RootHelper creates a short-lived private profile copy that disables `preserveEntitlements`, `mergeOnly`, `mergeDeep`, and `mergeEntitlements` while retaining the selected certificate, profile, hash and jobs settings; this prevents profile defaults from merging removed keys back into the edited main-app dictionary. The supplied precompiled ldid remains unchanged.
- Removed the obsolete Tweak-based `PreventUninstall` pseudo-feature. Added a separate **Special Installation** switch in Advanced: when enabled, the next installed/updated app is registered with Launch Services `IsDeletable = false`; its marker is stored outside the replaceable `.app` bundle, and the app can still be uninstalled from TrollStore’s own app-management UI. The setting is per-app at install time, defaults off, and is not an MDM-wide restriction or an injected Tweak.
- Uses your supplied precompiled iOS arm64 `ldid` from `bin/ldid`. The build copies the exact binary to `TrollStore.app/ldid-bootstrap/ldid`, not to the active `TrollStore.app/ldid` path. The app never checks upstream ldid versions or downloads another ldid. Settings exposes **Auto-initialize bundled ldid** (default off) and an explicit **Initialize bundled ldid** action; either copies the bundled binary into the active path locally.
- Pins ChOma to `964023ddac2286ef8e843f90df64d44ac6a673df`, because the fastPathSign source depends on the matching `FAT.h`, four-argument load-command API, and CodeDirectory updater.

## Build

The default release profile is a Theos Makefile build pinned to the patched `iPhoneOS16.5.sdk`. It compiles the app, RootHelper, Persistence Helper and tweak presets as Objective-C/C; it does not compile or link Swift and therefore does not consume `libswiftCore.dylib`, `libswift_Concurrency.dylib`, or `libswiftCompatibility*.a`. The build uses the standalone macOS Command Line Tools installation at `/Library/Developer/CommandLineTools` for Clang, `lipo`, `strip`, `libtool`, `dsymutil`, and the macOS SDK needed by the `fastPathSign` host tool. It does not select `/Applications/Xcode*.app`, invoke `xcode-select`, `xcodebuild`, `xcrun`, or Apple's App Intents metadata processor. The iOS target SDK is taken from `$THEOS/sdks/iPhoneOS16.5.sdk`.

Run from the project root:

```sh
make assemble_trollstore THEOS="$HOME/theos" IOS_SDK_VERSION=16.5 LDID_BIN="$PWD/bin/ldid" BUILD_JOBS=1
```

The output is `_build/TrollStore.tar`. `make bootstrap-deps` validates the supplied ldid binary and downloads/validates the pinned ChOma dependency. The Refresh Apps App Intent source remains in the tree but is excluded from the default profile; its Settings entry and generated App Shortcut metadata are therefore omitted. This is intentional to remove the failing Swift runtime link stage. Re-enabling App Intents requires a complete compatible Apple Swift toolchain/runtime and Apple's metadata processor, so it is not supported by this no-Swift profile.

**Toolchain note:** The project build recipe itself does not require Xcode.app or `xcodebuild`; it uses Theos plus standalone macOS Command Line Tools. Theos is a build system, not a compiler, so a macOS Clang/toolchain and a macOS SDK are still required for the host signer. The iPhoneOS 16.5 SDK must already be installed under Theos. Theos' official macOS installation instructions still list full Xcode as a prerequisite, so installing/bootstrapping Theos with CLT only is a manually provisioned, upstream-unsupported setup; this Makefile cannot make a missing compiler or SDK appear.

The intended GitHub Actions workflow is managed separately from this archive. If using a workflow that expects a root `TrollStore.zip`, upload this ZIP to the repository root as `TrollStore.zip`; the workflow should extract it to its project directory before invoking the Makefile.

## Validation notes

The source tree includes the original app/helper resources and source files; only the original donation controller files are removed. Static checks validate plist and localization syntax, require Chinese as the default localization, verify translated Chinese values and source-key coverage, check presence of original UI controllers and pre-install custom-entitlement wiring, the default-off ldid initialization setting, no remote ldid update/download references, dormant packaging of `bin/ldid`, the app-category split, the ChOma pin, and the self-update association.

A complete iOS link and device installation test must run on the macOS/Theos toolchain. Static syntax and resource checks cannot validate all private-framework/runtime behavior on every iOS version.

## Current build-profile precedence (2026-11-06)

The dated Swift/Xcode troubleshooting notes below document earlier iterations and are retained as history. They are superseded for the default build by the Theos + standalone Command Line Tools iOS 16.5 no-Swift profile above: no Swift compiler, Swift runtime, App Intents framework, Xcode app path, `xcode-select`, Xcode metadata processor, `xcrun`, or `xcodebuild` invocation is part of the default target graph.

## Install/sign performance pass

This build keeps the supplied `bin/ldid` as the device-side signing executable and preserves the original install fallback while reducing repeated work:

- Fixes bundle ownership/modes in one traversal instead of walking the entire app twice.
- Snapshots file paths once during signing and reuses them for the post-sign Mach-O pass; directories are excluded from Mach-O parsing.
- Uses same-directory temporary Mach-O files and atomic `rename()` replacement, avoiding an additional cross-directory copy and never deleting the original before replacement succeeds.
- Uses a same-volume move for the extracted `.app` bundle when possible, with copy fallback for unsupported/cross-volume moves.
- Increases libarchive's input block from 10 KiB to 256 KiB for large IPA/tar extraction.
- Drains stdout/stderr concurrently while child processes run, so one full pipe cannot stall signing; captured diagnostics are capped at 4 MiB per stream.
- In the configured per-binary signing path, signs independent Mach-O files concurrently (bounded to four workers and the template/CPU limits), while each ldid child is limited to one internal worker to avoid nested oversubscription.
- Keeps nested code-bundle resource sealing bottom-up and serial. CodeResources and the outer bundle signature are not parallelized because those operations depend on inner bundle completion.
- The normal real-CMS path already delegates recursive signing and its internal `jobs` parallelism to the supplied ldid in one whole-bundle pass; it is not split into redundant per-file processes.

No throughput percentage is claimed: a real benchmark requires building with Theos on macOS and timing representative IPAs on target iOS hardware.

## Installation method and persistence refresh shortcut

- **Custom install** keeps the short path: stage/extract the IPA once, apply package/plugin changes before signing, sign the final bundle once, then register it through the existing MobileContainerManager path. Same-volume moves use rename where possible and fall back to copy when needed. It generally has fewer system-installer stages, but it is not guaranteed to beat `installd` on every device or storage layout.
- **installd install** remains available and unchanged as the system-installer path. It performs its placeholder/install bookkeeping and then finalizes registration. It may behave more durably across certain LaunchServices/icon-cache rebuild scenarios, but this is not a guarantee against iOS updates or every database reset. A failed `installd` attempt does not silently switch to Custom; the existing explicit fallback confirmation is preserved.
- **Optional Refresh Apps shortcut source** remains in the project as an App Intent, with a narrow RootHelper `refresh` action. It is excluded from the default Theos/no-Swift profile, so the Settings entry and App Shortcut metadata are not present in that build. When built with a complete compatible Apple Swift/App Intents toolchain, the Settings page uses a UIKit button to open Apple's documented `shortcuts://` URL; the shortcut itself appears under Shortcuts → App Shortcuts → TrollStore.
- When the optional shortcut is enabled, it executes only RootHelper's `refresh` operation, re-registering TrollStore and installed TrollStore apps. It does not run `refresh-all`, clear the system icon cache, terminate SpringBoard, reboot, or display the injected system persistence-helper UI.
- The App Intent requests background execution (`openAppWhenRun = false`, retained for the iOS 16 deployment target). Apple now recommends `supportedModes` on newer SDKs; on supported older systems this property is a background preference, not an absolute promise that every execution context will remain invisible. The important distinction is that the shortcut does not open the injected system app's UI.


## Performance and stealth-install additions

- Production Objective-C/C targets (TrollStore, RootHelper, PersistenceHelper, fastPathSign and both built-in tweak Framework presets) use `-O3`; the App Intents Swift target uses Theos' optimized threaded WMO mode (`-O -whole-module-optimization -num-threads 1`) so its per-source object output matches Theos' output-file-map/link rules. Release targets set `FINALPACKAGE=1 DEBUG=0`. This favors runtime speed over minimum binary size and may increase build time and output size compared with `-Os`.
- App-list scanning, sorting, and info loading run off the main thread; category catalogs are cached across searches, stale scans are discarded, and icons use a thread-safe bounded `NSCache`.
- The installed-application catalog supports a persisted two-column grid/list switch and three separate filters: TrollStore-installed applications, ordinary App Store applications, and system applications. System applications remain read-only for destructive maintenance and injection.
- The Settings toggle `Enable stealth install for new IPAs` is off by default. When enabled, future IPA installs get a randomized bundle identifier and lose `CFBundleURLTypes`; this can break deep links, OAuth/payment callbacks, or app-to-app URL handling. It reduces some fixed-ID fingerprints only and is not a global jailbreak hide or a guarantee against every detector. Existing installed apps are not modified in place.

## MicroCore install/sign fast path

This build uses an in-process MicroCore path rather than a persistent LaunchDaemon or batch-install UI. One helper invocation still performs the complete IPA extract/sign/register transaction, avoiding extra IPC and process-start overhead. During the CoreTrust pass, a four-byte Mach-O/FAT magic prefilter limits ChOma parsing to likely executable files instead of every asset in the app bundle. The Entitlements editor is controlled by a Settings switch (default off). When enabled, opening an IPA for installation first opens that IPA’s original main-executable Entitlements as the editable complete plist dictionary. Done proceeds to the explicit install confirmation; Cancel aborts the whole install and returns to the previous page. The temporary edited document is used only for this install and its retries, then deleted. The selected main executable receives the complete dictionary, including removal of keys deleted in the editor; extensions retain their own original Entitlements.

## Full application-management implementation (2026-10)

This revision adds a local package-management and application-maintenance layer to the original Objective-C TrollStore UI:

- `TSAppDecryptor` exposes decrypt-and-export from the running app process; the root helper reads loaded Mach-O pages from process memory, maps file offsets through segment commands, supports fat Mach-O byte orders, and refuses to emit an IPA when no encrypted region was actually decrypted. The operating system can still deny `task_for_pid`; this path reports that failure rather than pretending success.
- `TSAppRepackager` can edit the display name, bundle identifier and version, remove URL schemes, widget extensions, embedded Watch targets and standalone Watch app siblings, then emit a standard IPA for the existing install-confirmation pipeline. It does not replace application icons.
- `TSIPAPackageStore` manages local IPA/TIPA/TAR/ZIP/DEB packages, supports direct HTTPS file downloads, extracts DEB/ZIP libraries, exports installed bundles, and opens install/repackage actions for ZIP files that pass a `Payload/*.app/Info.plist` plus executable validation. No package-source/feed UI is included.
- Root helper maintenance commands support cache cleanup, full data-container cleanup/recreation, multi-app cache cleanup, and guarded `ldid --iosinject --inplace --sign --verify` injection. Destructive operations refuse protected/system bundles and validate resolved paths. Data cleanup refuses apps that do not have a standard data container.
- Built-in tweak source presets include an application-lock overlay and a finite background-task allowance. The build packages these presets as conventional `.framework` bundles while preserving the signed inner `MH_DYLIB` executable bytes. The injector prioritizes `.framework` and continues to accept existing third-party `.dylib` files and archives. Standard iOS background APIs still provide only the finite execution allowance granted by iOS. Home Screen deletion protection is configured separately under Advanced settings and uses per-app Launch Services registration metadata, not a Tweak injection.
- UI includes a compositional two-column application grid, persistent search and source filters, a customizable floating bottom dock, theme/accent/dark-mode controls, optional background image/opacity/blur, and animated tab transitions.
- Installation sessions retain the selected install method, Force state, stealth state, per-install complete edited Entitlements document and cumulative debug log during retry. installd failure does not silently switch methods; switching is user-confirmed and triggers guarded residue cleanup.
- The Entitlements editor shows the IPA’s original per-binary Entitlements for reference and starts its editable Visual/XML document with the complete original main-app dictionary. The final preview is the exact dictionary signed into the main executable: removed keys are removed, and omitted keys are not silently restored. App extensions retain their own original dictionaries. Cancel aborts installation; Done writes a one-install temporary plist and requires the normal installation confirmation.

### Important prebuilt-ldid compatibility note

The exact precompiled `bin/ldid` supplied for this package is preserved byte-for-byte and verified by `bin/ldid.sha256`. Its Mach-O build metadata declares **minimum iOS 16.0** and **SDK 16.4.0**. All app, helper, and tweak-preset Theos targets now use an iOS 16.0 deployment minimum. The supplied device-side `bin/ldid` source is never invoked as a macOS build tool and remains byte-for-byte unchanged. All TrollStore-owned Theos outputs (main app, helpers, and both preset dylibs) use the shared macOS host `fastPathSign` pipeline; the two multi-architecture preset targets route through the architecture-preserving wrapper so each slice is signed independently. The staged `TrollStore.app/ldid-bootstrap/ldid` copy is also passed through `fastPathSign` before packaging; only the source file under `bin/ldid` retains its original hash. Do not patch the Mach-O version fields as a substitute for an actual compatible build. Editable ldid source is maintained only in the separate `ldid.zip`; this TrollStore source archive intentionally contains no ldid source tree and retains only the supplied precompiled `bin/ldid` executable plus its checksum.

The source archive used here is the latest complete saved TrollStore snapshot available in this session (dated 2026-10-31), combined with the supplied 2026-10-30 prebuilt ldid. It was not produced by cloning an unspecified live repository/branch. A full macOS/Theos build and on-device smoke test must still be run with the intended device/OS matrix before release.


The detailed Chinese feature and verification report for the 2026-11-01 optimization is in [`INSTALL-SIGN-SHORTCUTS-REPORT-zh-Hans.md`](INSTALL-SIGN-SHORTCUTS-REPORT-zh-Hans.md). The earlier implementation report remains in [`IMPLEMENTATION-REPORT-zh-Hans.md`](IMPLEMENTATION-REPORT-zh-Hans.md).


## Certificate-backed real signing (2026-10-30 ldid)

The **Signing Method & Certificates** page is available from Settings in the full TrollStore build. **TrollStore Signing** remains the default for backward compatibility and is shown in red; it uses ad-hoc signing and TrollStore's CoreTrust path. **Real Signing** uses a genuine CMS signature generated by the selected certificate identity and does not run the TrollStore CoreTrust bypass.

The certificate manager accepts either a `.p12` identity or a certificate `.pem` plus matching private-key `.key`/`.pem` (including encrypted PEM keys). Multiple identities can be stored; the first imported identity becomes the default, and later identities can be selected as default, inspected, or deleted. P12/private-key material is stored in the Keychain; temporary signing copies are created with restrictive file permissions and removed after RootHelper returns. The certificate detail page is laid out in the requested order: **Issuer → Validity Period (Valid From / Valid Until) → OIDs**.

A `.mobileprovision`/`.provisionprofile` can be attached to an identity. It is optional to the UI import flow, but real iOS distribution/development installs generally need a matching profile when signing with a developer identity. Apple's profile documentation says the profile binds an App ID, signing certificate and (for development/ad-hoc) registered devices, and its entitlements act as an allowlist. App Store-downloaded apps normally do not contain an embedded profile because Apple checks signing/provisioning during distribution; re-signing such an app with another identity is not equivalent to App Store distribution.

The real-signing template defaults to **App Store**. Other presets include App Store Connect, TestFlight, Apple Development, Developer Distribution, Ad Hoc, and Enterprise/In-House. TrollStore signing has its own Default, Fast, and Compatibility presets. These presets select ldid hash/parallel-signing options and a profile name; a preset label cannot turn an arbitrary certificate into an Apple App Store identity or manufacture a profile. The app validates the resulting CMS/code signature with `--signature-validate` after both the recursive whole-bundle path and the custom-Entitlements per-binary path. Certificate-chain validation remains off by default in the ldid profile.

The exact 2026-10-30 prebuilt ldid is in `bin/ldid` (SHA-256 `b0f181e3c207e281809af3321ebb4433a36eb984f50d855721a2e49b903384db`). Its metadata is arm64 / minimum iOS 16.0.0 / SDK 16.4.0. The editable source and CLI implementation are kept only in the separate `ldid.zip`; no ldid source directory is included in this TrollStore archive.


The 2026-10-30 prebuilt ldid has minimum iOS 16.0.0 (SDK 16.4.0). All app/helper/preset deployment targets are now iOS 16.0 or later. The helper still checks the bundled binary metadata at runtime instead of relying only on file existence.
## GitHub Actions / Theos host signing fix (2026-10-31)

The single-architecture app/helper Theos targets use the shared macOS host `Exploits/fastPathSign/fastPathSign` through `TARGET_CODESIGN`. The two multi-architecture tweak presets use `Scripts/fastpath_sign_all_slices.py`: before invoking either Theos subproject, the root Makefile explicitly restores this wrapper’s executable bit (GitHub checkouts may store it as mode 100644); it then splits universal inputs, runs fastPathSign on each thin architecture, and uses `lipo` to reconstruct the universal file. Preset staging can assemble arm64 and arm64e from separate Theos objects, excludes dSYM debug binaries, signs missing slices, and verifies an embedded CodeDirectory in both architectures; final app assembly validates the main executable, both helpers, both preset dylibs, and the staged ldid copy. The prebuilt `bin/ldid` is an iOS arm64 device executable (minimum iOS 16.0), not a macOS host tool; never add it to the Runner PATH or use it as `TARGET_CODESIGN`. All five iOS Theos targets now have an iOS 16.0 deployment minimum. See [`BUILD-FIX-2026-10-31-zh-Hans.md`](BUILD-FIX-2026-10-31-zh-Hans.md) for the cause and validation scope. For the 2026-11-01 installation/signing concurrency, App Intents refresh shortcut, Framework preset wrapping, template descriptions, and import cleanup changes, see [`INSTALL-SIGN-SHORTCUTS-REPORT-zh-Hans.md`](INSTALL-SIGN-SHORTCUTS-REPORT-zh-Hans.md).

## Video-inspired navigation, plugin repository, and per-app update control

- The main interface uses four floating navigation destinations (Apps, Packages, Plugins, Settings) with vertically stacked SF Symbol icons and labels, a blue selected state, and the existing fade/scale page transition. The Apps page exposes four source filters: All, User, Troll, and System. Existing three-filter preferences are migrated once to the new mapping.
- A selected normal App Store app can have updates blocked or restored individually from its app action sheet. The Settings → Blocked App Updates page lists every locked bundle and restores the original `iTunesMetadata.plist` when tapped. TrollStore-managed apps and system applications are excluded. RootHelper validates the LaunchServices proxy, bundle identifier, real app-container path, TrollStore markers, Info.plist identity, and regular non-symlink metadata before renaming anything. It then requests a LaunchServices rebuild, waits for the knowledge token to settle, refreshes the App Store cache, and rolls the rename back if the refresh cannot be confirmed. This relies on private LaunchServices behaviour and must be verified on each target iOS build; it is not an Apple-supported update-management API.
- The Plugins page reads the live `iosdumpzzz/iosdump.repo` Debian `Packages` index, keeps a local cache, searches package metadata, retains the newest version per package/architecture, shows dependencies and architecture, and downloads only safe relative `.deb` paths with a valid SHA-256 and optional size verification. Downloaded packages are placed in Packages for inspection. The existing Packages page can extract DEBs and locate their dynamic libraries; the existing Tweak Injector can inject a compatible library into an individual app.
- The app does **not** run `dpkg` or install system-level jailbreak packages. Components such as AppData and AirDrop in the referenced repository declare `mobilesubstrate` dependencies; these are system/jailbreak tweaks and cannot become active on a TrollStore-only device merely by downloading or injecting a library into an ordinary app. The Plugin page labels this dependency rather than pretending the package was installed.

## Theos Swift support preflight (2026-11-01)

The root `check-build-tools` step now runs `Scripts/bootstrap_theos_swift_support.sh` before any Theos target is built. This verifies both `generate-output-file-map` and `parse-swiftc-output` under `$(THEOS)/vendor/swift-support/.theos_build/release`, initializes the Theos `vendor/swift-support` submodule if the checkout is non-recursive, and repairs partial SwiftPM caches. In particular, it removes an incomplete `.theos_build` before invoking Theos' own `swift-bootstrapper.pl`, so an old `theos_build_commit` marker cannot cause the bootstrapper to falsely skip a missing executable. The script uses the Xcode-selected `swift` binary and temporarily clears `THEOS_NO_SWIFT_CACHE` only for this repair/verification. The original precompiled iOS `bin/ldid` is not modified or used as a host tool.

If this preflight fails, inspect the preceding `swift build` output and confirm that the selected Xcode contains a working SwiftPM toolchain. The GitHub Actions workflow must install/checkout Theos with `vendor/swift-support` available; caching its `.theos_build` directory is no longer required.


## Swift SDK compatibility and video-matched UI (2026-11-01)

- The patched `iPhoneOS16.5.sdk` contains Swift 5.8 textual interfaces. `Scripts/bootstrap_swift_5_8_toolchain.sh` verifies those interfaces and installs/verifies the signed Swift 5.8.1 toolchain from Swift.org when needed.
- Only TrollStore's target Swift compilation uses `TARGET_SWIFTC` from that toolchain. Xcode's Swift remains in use for Theos host-tool bootstrap and Apple's App Intents metadata processor.
- The Persistence Helper candidate picker explicitly excludes `com.apple.shortcuts`, and RootHelper independently returns `EPERM` if a direct `install-persistence-helper` request targets that bundle ID. The `Refresh Apps` App Intent belongs to TrollStore itself; Apple Shortcuts remains a normal, separate app and is never injected, replaced, or repurposed.
- The Apps root uses the large left-aligned title shown in the video; the other root pages use compact titles. The Apps page has only the blue plus menu in the top-right. The existing grid/list switch remains available inside that menu, so the visual simplification does not remove functionality.
- On first launch, TrollStore defaults to Dark appearance to match the saved screen recording. Explicitly saved System/Light/Dark choices are preserved.
- `Previews/TrollStore-UI-Video-Reference-Preview-2026-11-01.png` is a contact sheet of actual frames extracted from the user's saved video. It is a visual reference used for a source-level layout audit, not a simulator-rendered screenshot of the edited binary.


### Swift 5.8 SDK compatibility / Shortcuts safety / UI reference (2026-11-01)

The iPhoneOS16.5 SDK's SwiftUI textual interfaces identify Swift 5.8, while the observed GitHub Runner compiler is Swift 6.1.2. `Scripts/bootstrap_swift_5_8_toolchain.sh` verifies the SDK marker, installs the official Swift 5.8.1 macOS toolchain only when absent, verifies the package's Swift Open Source Developer ID signature, and passes its compiler through Theos `TARGET_SWIFTC` for the TrollStore target only. Xcode's own compiler remains selected for Theos host tools and the App Intents metadata processor. This avoids changing the iPhoneOS16.5 SDK or globally switching the Runner's Xcode. The next GitHub macOS build must still confirm that Swift 5.8.1 imports all target modules and that Xcode's metadata processor accepts the emitted App Intents constants.

### Theos iOS 16.5 no-Swift build profile (2026-11-06)

The default root Makefile now compiles the TrollStore app and helpers through Theos against `iPhoneOS16.5.sdk` as Objective-C/C targets. App Intents is kept as source but not part of this profile, so no Swift runtime archives or dylibs enter the link command and the Refresh Apps App Shortcut UI/metadata are omitted. Earlier Swift runtime-link workarounds are historical and are not used by the default build. The Xcode Swift/App Intents path is deliberately not mixed into this Makefile profile.

The `before-TrollStore-all` hook now runs `Scripts/prepare_swift_link_runtime.sh`. It supplements only missing compatibility `.a` archives from Swift 5.8.1; it never copies its runtime dylibs. For archives, the script checks `lipo -archs` and the archive member table with `ar -t`. It deliberately does not run `lipo -verify_arch` on static archives, because that check can reject a readable thin archive even when `lipo -archs` reports `arm64`—the immediate cause of the `libswiftCompatibility50.a` pre-link failure. The overlay is limited to compatibility archives and is not embedded in TrollStore.app. `Scripts/test_swift_runtime_link.sh` verifies Xcode-first runtime lookup, SDK stubs, arm64 archive fallback, and that no Swift 5.8.1 runtime dylib enters the link path. RootHelper, TrollHelper, and the arm64/arm64e tweak presets are unchanged. See [`SWIFT-ARM64-RUNTIME-LINK-FIX-2026-11-06-zh-Hans.md`](SWIFT-ARM64-RUNTIME-LINK-FIX-2026-11-06-zh-Hans.md) for the strategy and macOS Runner validation boundary.

The Apple Shortcuts app is explicitly excluded from the Persistence Helper picker, and RootHelper returns `EPERM` for direct attempts to install Persistence Helper into `com.apple.shortcuts`. The TrollStore-owned `Refresh Apps` App Shortcut remains available independently and continues to run only the narrow app-registration refresh. The settings entry opens the Shortcuts app with the documented `shortcuts://` URL and shows the exact navigation path to App Shortcuts. No undocumented WorkflowKit UI selector is guessed: WorkflowKit's reverse-engineered database APIs are not a verified navigation API for an app's App Shortcuts page.

The UI reference sheet in `Previews/` contains real frames from the stored screen recording. The app source was audited against its four navigation destinations, large Apps title, compact Settings title, dark default, grouped cards, category filters and translucent floating dock. This sheet is not claimed to be a newly rendered Simulator capture.

### Swift 5.8.1 package-signature verification compatibility (2026-11-01)

`pkgutil --check-signature` changed its positive Status wording on newer macOS releases. The Swift toolchain bootstrap now accepts the documented Apple trust status variants (`signed by a certificate trusted by Mac OS X`, `signed by a certificate trusted by macOS`, and `signed by a developer certificate issued by Apple for distribution`) while still requiring the exact Swift.org signer `Developer ID Installer: Swift Open Source (V9AUD2URP3)`. It continues to reject unsigned, revoked, untrusted, or differently signed packages. `Scripts/test_swift_pkg_signature.sh` covers these cases and runs as part of `make validate-project`; signature validation is not disabled or bypassed.

- **TrollStore signing mode** is always ad-hoc/CoreTrust. It has no user-selectable signing templates; the internal default is SHA-256 with four ldid workers. Real CMS signing retains its certificate-backed templates.

### iOS 16.5 Shortcuts entry compatibility (2026-11-01)

`ShortcutsLink` and `ShortcutsUIButton` are not declared by the selected iPhoneOS 16.5 SDK in the actual Theos build, so both symbol paths have been removed from the build. `TSRefreshAppRegistrationsIntent.swift` now imports only AppIntents and keeps the AppIntent/AppShortcutsProvider. The Objective-C settings controller uses UIKit's `UIApplication openURL:options:completionHandler:` with Apple's documented `shortcuts://` URL. The screen explains that the App Shortcut is automatically discoverable in the App Shortcuts category and directs users to TrollStore → Refresh Apps; it does not claim that the URL opens the app-specific page.

Private API use is authorized by the project owner, but research did not establish a verified iOS 16.5 private selector or URL that navigates directly to the current app's App Shortcuts page. WorkflowKit is a private backend for shortcut storage/import, not a documented UI deep-link service; its database-import examples require additional process initialization/entitlements. This revision therefore avoids speculative private class/selector calls and uses Apple's supported URL route. Apple Shortcuts remains excluded from Persistence Helper installation at both UI and RootHelper levels.


### fastPathSign macOS host SDK isolation (2026-11-02)

The first Xcode Clang isolation pass fixed the compiler binary but did not supply a sysroot to the standalone macOS `fastPathSign` host utility. Directly invoking the absolute Xcode Clang path without `-isysroot` caused the compiler to look at `/System/Library/Frameworks` and miss Foundation, CoreFoundation, libc, and Mach-O headers. The root Makefile now resolves `HOST_MACOSX_SDKROOT` with `xcrun --sdk macosx --show-sdk-path`, validates the host SDK headers, and passes the path only to `Exploits/fastPathSign`. Its Makefile uses this path for both compile and link with `-isysroot` and `-mmacosx-version-min=12.0`. The iOS Theos targets continue using their own iPhoneOS SDK and the same XcodeDefault compiler; Swift 5.8.1 remains isolated to `TARGET_SWIFTC`. `Scripts/test_fastpath_host_sdk.sh` simulates the host compile and asserts the macOS sysroot is used and no iPhoneOS SDK leaks into the host build.

### Swift toolchain / Xcode Clang isolation (updated 2026-11-05)

The Swift 5.8.1 toolchain is used only for TrollStore's `TARGET_SWIFTC`. A CI failure showed that an ordinary Objective-C compile opened `stdatomic.h` from the lexical path `swift-5.8.1-RELEASE.xctoolchain/usr/bin/../lib/swift/clang/include`, then failed to find `__stddef_max_align_t.h`; Darwin, Foundation, CoreFoundation, and UIKit module errors were downstream failures. The first isolation pass was not sufficient: its regression test checked Make variable values and environment propagation, but did not execute a compiler invocation or inspect the resource directory selected by Clang.

The corrected setup now applies `Scripts/xcode-clang.mk` **after** `$(THEOS)/makefiles/common.mk` in every target Makefile. This matters because Theos loads the user rc file and resolves platform/target compiler settings while processing `common.mk`. The final `TARGET_CC`, `TARGET_CXX`, and `TARGET_LD` values are wrappers, not raw `clang` names. The wrappers execute the active XcodeDefault Clang, remove any inherited `-resource-dir` and explicit include/module-map arguments pointing into a Swift.org `usr/lib/swift/clang` tree, including the `usr/bin/../lib` spelling shown in the CI trace, clear process-global include/config override variables, and append the exact resource directory reported by that Xcode compiler. Project-specific include paths remain explicit Theos `*_CFLAGS` and are not removed.

The wrapper verifies both Xcode builtin files (`stdatomic.h` and `__stddef_max_align_t.h`) before invoking the compiler. Clang module caches are isolated by the Xcode compiler-version fingerprint, preventing a cache restored from another compiler distribution from being reused. Swift 5.8.1 remains separately passed by absolute path through `TARGET_SWIFTC`; no SDK header is copied, the iPhoneOS 16.5 SDK is not patched, and Clang Modules remain enabled.

`Scripts/test_xcode_clang_isolation.sh` invokes mock compiler executables with polluted resource-dir, `-isystem`, `-fmodule-map-file`, `-Xclang`, and environment overrides, and verifies the final argv and selected executable without compiling source code. The iOS Objective-C/C/C++ sources are compiled only by Theos target rules; no separate raw-Clang Objective-C probe is run. Theos loads each project's target configuration, then `Scripts/xcode-clang.mk` pins `TARGET_CC`, `TARGET_CXX`, and `TARGET_LD` to the compiler wrappers and uses an Xcode-version-specific module cache. The actual TrollStore, RootHelper, TrollHelper, and tweak target builds are the compilation tests.


### Theos Swift WMO output-map / missing object fix (2026-11-05)

The TrollStore app's single App Intents Swift source is compiled by Theos' normal Swift target rule. Theos generates an output-file-map and includes one tagged `*.swift.<tag>.o` object per Swift source in the final link. The previous project override set `SWIFT_OPTFLAG = -O -whole-module-optimization` but omitted Theos' `-num-threads 1` setting. Swift's non-threaded WMO mode emits one module object instead of the per-source object expected by Theos, so the final `clang++` link could fail with a missing `TSRefreshAppRegistrationsIntent.swift.<tag>.o`. The target now explicitly uses `-O -whole-module-optimization -num-threads 1`, preserving optimized whole-module compilation while matching Theos' output-file-map model.

The root Theos build also removes only TrollStore's cached `.swift-stamp`, temporary stamp, generated output-file-map JSON, and this Swift source's stale object files immediately before invoking the TrollStore subproject. This prevents a partially restored `.theos` CI cache from claiming Swift outputs exist when the object files are absent. Theos still owns Swift compilation, object-map generation, and final linking; no standalone `swiftc`, Clang, or Xcode project build is introduced.

## Signing flag reference

See [CODEDIRECTORY-FLAGS-zh-Hans.md](CODEDIRECTORY-FLAGS-zh-Hans.md) for the CodeDirectory flag meanings, bit values, locked/system-managed flags, and safety notes.

## 自定义签名与持久化助手修复（2026-11-25）

本次修复详情见 `PATCH-REPORT-2026-11-25-zh-Hans.md`。重点包括：

- 修复顶层 App Bundle 根目录等于暂存根目录时被路径校验错误拒绝的问题；嵌套 Bundle 可执行文件符号链接仅允许解析到同一个待签名 App 内。
- 持久化助手安装、卸载统一通过宿主 `Info.plist` 的 `CFBundleExecutable` 解析原始目录项，保留宿主原始符号链接以便失败回滚和卸载恢复。
- P12 / PEM+KEY 导入增加格式识别、DER/PEM 规范化、File Provider 通用 UTType 支持、有限大小的读取回退和更准确的错误提示；证书/私钥不匹配与密钥解密失败也有独立错误码。
- 软件包列表采用两行文件名和显式 Auto Layout，避免小屏幕宽度下标题被压缩。

验证脚本：`Scripts/test_custom_install_signing_regressions.py`，已接入 `make validate-project`。

注意：随源码提供的 `bin/ldid` Mach-O 声明最低 iOS 16.0。需要支持 iOS 14/15 的证书签名时，应重新构建并验证对应最低系统版本的 ldid。
