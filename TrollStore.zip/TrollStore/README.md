# TrollStore — Original UI, Simplified Chinese, pre-install Entitlements

This archive is based on the supplied `TrollStore-main.zip`. It preserves the original TrollStore app, Settings UI, installed-app list, app details/actions, URL scheme handling, installation confirmation/errors, advanced options, update flow, and persistence-helper UI/logic. The original Objective-C controllers are intentionally preserved, and the pre-install Entitlements editor is also implemented in Objective-C. The project contains no Swift source files.

## Changes in this build

- Built-in Simplified Chinese (`zh-Hans.lproj`) for the main TrollStore app and persistence helper. `zh-Hans` is explicitly the development/default localization, so UI strings default to Chinese even when the device language is English.
- Removed the donation controller and its Settings entry.
- Added **Edit Entitlements Before Install** to the IPA installation confirmation. The editor validates an XML plist dictionary before starting installation; its enabled overrides apply to that installation only, only to the main app executable, preserving unspecified keys and leaving extensions on TrollStore's original per-binary entitlement handling.
- Uses your supplied precompiled iOS arm64 `ldid` from `bin/ldid`. The build copies the exact binary to `TrollStore.app/ldid-bootstrap/ldid`, not to the active `TrollStore.app/ldid` path. The app never checks upstream ldid versions or downloads another ldid. Settings exposes **Auto-initialize bundled ldid** (default off) and an explicit **Initialize bundled ldid** action; either copies the bundled binary into the active path locally.
- Pins ChOma to `964023ddac2286ef8e843f90df64d44ac6a673df`, because the fastPathSign source depends on the matching `FAT.h`, four-argument load-command API, and CodeDirectory updater.

## Build

Run on macOS with Xcode, Theos, the required Theos SDK, Homebrew dependencies, and network access for downloading the pinned ChOma archive:

```sh
make assemble_trollstore THEOS="$HOME/theos" LDID_BIN="$PWD/bin/ldid"
```

The output is `_build/TrollStore.tar`. `make bootstrap-deps` validates the supplied ldid binary and downloads/validates the pinned ChOma dependency. The app, root helper, and persistence helper are built from Objective-C/C sources; no Swift toolchain or Swift bootstrap is needed.

The intended GitHub Actions workflow is managed separately from this archive. If using a workflow that expects a root `TrollStore.zip`, upload this ZIP to the repository root as `TrollStore.zip`; the workflow should extract it to its project directory before invoking the Makefile.

## Validation notes

The source tree includes the original app/helper resources and source files; only the original donation controller files are removed. Static checks validate plist and localization syntax, require Chinese as the default localization, verify translated Chinese values and source-key coverage, check presence of original UI controllers and pre-install custom-entitlement wiring, the default-off ldid initialization setting, no remote ldid update/download references, dormant packaging of `bin/ldid`, the app-category split, the ChOma pin, and the self-update association.

A complete iOS link and device installation test must run on the macOS/Theos toolchain. Static syntax and resource checks cannot validate all private-framework/runtime behavior on every iOS version.

## Install/sign performance pass

This build applies conservative I/O optimizations while keeping the bundled `bin/ldid` as the signing executable and retaining the existing signing order and install fallback: 

- Fixes bundle ownership/modes in one traversal instead of walking the entire app twice.
- Snapshots file paths once during signing and reuses them for the post-sign Mach-O pass; directories are excluded from Mach-O parsing.
- Uses same-directory temporary Mach-O files and atomic `rename()` replacement, avoiding an additional cross-directory copy and never deleting the original before replacement succeeds.
- Uses a same-volume move for the extracted `.app` bundle when possible, with copy fallback for unsupported/cross-volume moves.
- Increases libarchive's input block from 10 KiB to 256 KiB for large IPA/tar extraction.
- Drains stdout/stderr concurrently while child processes run, so one full pipe cannot stall signing; captured diagnostics are capped at 4 MiB per stream.

No throughput percentage is claimed: a real benchmark requires building with Theos on macOS and timing representative IPAs on target iOS hardware.


## Performance and stealth-install additions

- Theos production targets use `-O3` for Objective-C/C code; all targets use Objective-C/C optimization flags favoring runtime speed; these flags may increase binary size/build time compared with Theos' default `-Os`.
- App-list scanning, sorting, and info loading run off the main thread; category catalogs are cached across searches, stale scans are discarded, and icons use a thread-safe bounded `NSCache`.
- The installed-application catalog supports a persisted two-column grid/list switch and three separate filters: TrollStore-installed applications, ordinary App Store applications, and system applications. System applications remain read-only for destructive maintenance and injection.
- The Settings toggle `Enable stealth install for new IPAs` is off by default. When enabled, future IPA installs get a randomized bundle identifier and lose `CFBundleURLTypes`; this can break deep links, OAuth/payment callbacks, or app-to-app URL handling. It reduces some fixed-ID fingerprints only and is not a global jailbreak hide or a guarantee against every detector. Existing installed apps are not modified in place.

## MicroCore install/sign fast path

This build uses an in-process MicroCore path rather than a persistent LaunchDaemon or batch-install UI. One helper invocation still performs the complete IPA extract/sign/register transaction, avoiding extra IPC and process-start overhead. During the CoreTrust pass, a four-byte Mach-O/FAT magic prefilter limits ChOma parsing to likely executable files instead of every asset in the app bundle. The pre-install Entitlements editor is also available from Settings; the apply switch defaults off and is consumed by a single install (retained only for the recoverable force-install retry).

## Full application-management implementation (2026-10)

This revision adds a local package-management and application-maintenance layer to the original Objective-C TrollStore UI:

- `TSAppDecryptor` exposes decrypt-and-export from the running app process; the root helper reads loaded Mach-O pages from process memory, maps file offsets through segment commands, supports fat Mach-O byte orders, and refuses to emit an IPA when no encrypted region was actually decrypted. The operating system can still deny `task_for_pid`; this path reports that failure rather than pretending success.
- `TSAppRepackager` can edit the display name, bundle identifier and version, remove URL schemes, widget extensions, embedded Watch targets and standalone Watch app siblings, then emit a standard IPA for the existing install-confirmation pipeline. It does not replace application icons.
- `TSIPAPackageStore` manages local IPA/TIPA/TAR/ZIP/DEB packages, supports direct HTTPS file downloads, extracts DEB/ZIP libraries, exports installed bundles, and opens install/repackage actions for ZIP files that pass a `Payload/*.app/Info.plist` plus executable validation. No package-source/feed UI is included.
- Root helper maintenance commands support cache cleanup, full data-container cleanup/recreation, multi-app cache cleanup, and guarded `ldid --iosinject --inplace --sign --verify` injection. Destructive operations refuse protected/system bundles and validate resolved paths. Data cleanup refuses apps that do not have a standard data container.
- Built-in tweak source presets include an application-lock overlay and a finite background-task allowance. A dylib loaded inside an ordinary app cannot block SpringBoard from uninstalling that app, and standard iOS background APIs cannot provide unlimited background execution; a fake “always works” preset is intentionally not supplied for either behavior. The `TweakPresets/PreventUninstall` directory documents the SpringBoard/jailbreak or supervised-device requirement.
- UI includes a compositional two-column application grid, persistent search and source filters, a customizable floating bottom dock, theme/accent/dark-mode controls, optional background image/opacity/blur, and animated tab transitions.
- Installation sessions retain the selected install method, Force state, stealth state, custom Entitlements overlay/file and cumulative debug log during retry. installd failure does not silently switch methods; switching is user-confirmed and triggers guarded residue cleanup.
- The Entitlements editor has a read-only original layer, visual/XML override editing, common presets and a merged preview. Unspecified original keys are preserved by the RootHelper merge path.

### Important prebuilt-ldid compatibility note

The exact precompiled `bin/ldid` supplied for this package is preserved byte-for-byte and verified by `bin/ldid.sha256`. Its Mach-O build metadata declares **minimum iOS 16.0** and **SDK 16.4.0**. All app, helper, and tweak-preset Theos targets now use an iOS 16.0 deployment minimum. The supplied device-side `bin/ldid` source is never invoked as a macOS build tool and remains byte-for-byte unchanged. All TrollStore-owned Theos outputs (main app, helpers, and both preset dylibs) use the shared macOS host `fastPathSign` pipeline; the two multi-architecture preset targets route through the architecture-preserving wrapper so each slice is signed independently. The staged `TrollStore.app/ldid-bootstrap/ldid` copy is also passed through `fastPathSign` before packaging; only the source file under `bin/ldid` retains its original hash. Do not patch the Mach-O version fields as a substitute for an actual compatible build. The `ldid.cpp`, `ldid.hpp`, and `ldid-reference/ldid-inprocess-selfcontained.zip` are reference material; the build uses the supplied precompiled executable.

The source archive used here is the latest complete local TrollStore snapshot available in this session (dated 2026-10-25), combined with the user's newer ldid upload from 2026-10-27. It was not produced by cloning an unspecified live repository/branch. A full Xcode/Theos build and on-device smoke test must still be run on macOS with the intended device/OS matrix before release.


The detailed Chinese feature and verification report is in [`IMPLEMENTATION-REPORT-zh-Hans.md`](IMPLEMENTATION-REPORT-zh-Hans.md).


## Certificate-backed real signing (2026-10-30 ldid)

The **Signing Method & Certificates** page is available from Settings in the full TrollStore build. **TrollStore Signing** remains the default for backward compatibility and is shown in red; it uses ad-hoc signing and TrollStore's CoreTrust path. **Real Signing** uses a genuine CMS signature generated by the selected certificate identity and does not run the TrollStore CoreTrust bypass.

The certificate manager accepts either a `.p12` identity or a certificate `.pem` plus matching private-key `.key`/`.pem` (including encrypted PEM keys). Multiple identities can be stored; the first imported identity becomes the default, and later identities can be selected as default, inspected, or deleted. P12/private-key material is stored in the Keychain; temporary signing copies are created with restrictive file permissions and removed after RootHelper returns. The certificate detail page is laid out in the requested order: **Issuer → Validity Period (Valid From / Valid Until) → OIDs**.

A `.mobileprovision`/`.provisionprofile` can be attached to an identity. It is optional to the UI import flow, but real iOS distribution/development installs generally need a matching profile when signing with a developer identity. Apple's profile documentation says the profile binds an App ID, signing certificate and (for development/ad-hoc) registered devices, and its entitlements act as an allowlist. App Store-downloaded apps normally do not contain an embedded profile because Apple checks signing/provisioning during distribution; re-signing such an app with another identity is not equivalent to App Store distribution.

The real-signing template defaults to **App Store**. Other presets include App Store Connect, TestFlight, Apple Development, Developer Distribution, Ad Hoc, and Enterprise/In-House. TrollStore signing has its own Default, Fast, and Compatibility presets. These presets select ldid hash/parallel-signing options and a profile name; a preset label cannot turn an arbitrary certificate into an Apple App Store identity or manufacture a profile. The app validates the resulting CMS/code signature with `--signature-validate` after both the recursive whole-bundle path and the custom-Entitlements per-binary path. Certificate-chain validation remains off by default in the ldid profile.

The exact 2026-10-30 prebuilt ldid is in `bin/ldid` (SHA-256 `d23eb53e6c5b07f5cae72f0e93ab1b87214aa68ed4a59bc32286f8b15cb8b769`). Its metadata is arm64 / minimum iOS 16.0.0 / SDK 16.4.0. Source and CLI notes are stored in `ldid-reference/`.


The 2026-10-30 prebuilt ldid has minimum iOS 16.0.0 (SDK 16.4.0). All app/helper/preset deployment targets are now iOS 16.0 or later. The helper still checks the bundled binary metadata at runtime instead of relying only on file existence.
## GitHub Actions / Theos host signing fix (2026-10-31)

The single-architecture app/helper Theos targets use the shared macOS host `Exploits/fastPathSign/fastPathSign` through `TARGET_CODESIGN`. The two multi-architecture tweak presets use `Scripts/fastpath_sign_all_slices.py`: before invoking either Theos subproject, the root Makefile explicitly restores this wrapper’s executable bit (GitHub checkouts may store it as mode 100644); it then splits universal inputs, runs fastPathSign on each thin architecture, and uses `lipo` to reconstruct the universal file. Preset staging can assemble arm64 and arm64e from separate Theos objects, excludes dSYM debug binaries, signs missing slices, and verifies an embedded CodeDirectory in both architectures; final app assembly validates the main executable, both helpers, both preset dylibs, and the staged ldid copy. The prebuilt `bin/ldid` is an iOS arm64 device executable (minimum iOS 16.0), not a macOS host tool; never add it to the Runner PATH or use it as `TARGET_CODESIGN`. All five iOS Theos targets now have an iOS 16.0 deployment minimum. See [`BUILD-FIX-2026-10-31-zh-Hans.md`](BUILD-FIX-2026-10-31-zh-Hans.md) for the cause and validation scope.
