# Swift 5.8.1 工具链包签名状态误判修复

日期：2026-11-01

## 用户遇到的问题

CI 已成功从 Swift.org 下载约 976 MB 的 Swift 5.8.1 官方 macOS 工具链包，但安装前检查终止：

`error: Swift toolchain package is not signed by a trusted certificate`

## 根本原因

下载地址与 Swift.org 官方签名身份均未发现配置错误。旧脚本把 `pkgutil --check-signature` 的成功状态文案写死为：

`Status: signed by a certificate trusted by Mac OS X`

较新 macOS 的 `pkgutil` 可使用另一种成功状态文案：

`Status: signed by a developer certificate issued by Apple for distribution`

旧脚本虽然已经查到正确的 Swift Open Source Developer ID，但因为第二条字符串匹配失败，错误地拒绝了有效签名包。

## 修复内容

- 新增 `Scripts/swift_pkg_signature.sh`，集中解析 `pkgutil` 的签名状态。
- 仍然要求证书链包含完全匹配的身份：`Developer ID Installer: Swift Open Source (V9AUD2URP3)`。
- 兼容三种明确成功状态：
  - `signed by a certificate trusted by Mac OS X`
  - `signed by a certificate trusted by macOS`
  - `signed by a developer certificate issued by Apple for distribution`
- 默认拒绝任何其他状态，包括 `no signature`、`revoked signature`、`signed by a certificate that is not trusted`。
- 验证失败时打印完整 `pkgutil` 输出，方便从 CI 日志区分签名身份错误、撤销状态或 macOS 输出格式变更。
- 新增 `Scripts/test_swift_pkg_signature.sh`，并接入 `make validate-project`。
- 不使用 `installer -allowUntrusted`，不跳过 Gatekeeper/签名检查，不嵌入或替换 Swift 编译器二进制。
- 保留 Swift 5.8.1 对 iPhoneOS 16.5 SDK Swift 5.8 接口的编译器匹配方案，以及原有目标 SDK。

## 回归测试

通过：

- 旧版 macOS `pkgutil` 成功状态。
- 新版 macOS `pkgutil` Apple Developer ID 成功状态。
- macOS 文案变体成功状态。
- 无签名状态拒绝。
- 已撤销签名状态拒绝。
- 错误签名人拒绝。
- 不可信证书状态拒绝。
- `bash -n` 脚本语法检查。
- `make validate-project` 全项目静态检查、Theos Swift support 缓存恢复测试、签名流水线回归、预编译 ldid 校验。

## 验证边界

当前执行环境不是 macOS/Xcode，无法在这里直接调用 Apple `pkgutil` 检查用户 Runner 下载的实际 `.pkg`，也无法运行实际 Swift 5.8.1 iOS SDK 编译。本补丁修复了已由代码确认的状态文案误判，并通过真实格式样例的解析回归测试；下一次 GitHub Actions 将对下载包执行真实证书验证和安装。
