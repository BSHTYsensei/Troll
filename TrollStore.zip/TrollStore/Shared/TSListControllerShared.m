#import "TSListControllerShared.h"
#import "TSUtil.h"
#import "TSPresentationDelegate.h"
#import <objc/runtime.h>

static NSString *TSSymbolForPreferenceTitle(NSString *title) {
    NSString *value = title.lowercaseString ?: @"";
    if ([value containsString:@"developer"] || [value containsString:@"开发者"]) return @"wrench.and.screwdriver.fill";
    if ([value containsString:@"respring"] || [value containsString:@"注销"]) return @"power";
    if ([value containsString:@"refresh"] || [value containsString:@"刷新"]) return @"arrow.clockwise";
    if ([value containsString:@"cache"] || [value containsString:@"缓存"] || [value containsString:@"清理"]) return @"trash.fill";
    if ([value containsString:@"blocked"] || [value containsString:@"屏蔽"]) return @"hand.raised.fill";
    if ([value containsString:@"plugin"] || [value containsString:@"插件"]) return @"puzzlepiece.extension.fill";
    if ([value containsString:@"appearance"] || [value containsString:@"theme"] || [value containsString:@"主题"]) return @"paintbrush.pointed.fill";
    if ([value containsString:@"system apps"] || [value containsString:@"系统应用"]) return @"iphone.gen3";
    if ([value containsString:@"app filter"] || [value containsString:@"应用筛选"]) return @"line.3.horizontal.decrease.circle";
    if ([value containsString:@"trollstore app badge"] || [value containsString:@"应用标识"]) return @"seal.fill";
    if ([value containsString:@"app type"] || [value containsString:@"应用类型"]) return @"tag.fill";
    if ([value containsString:@"app list layout"] || [value containsString:@"应用列表布局"]) return @"list.bullet.rectangle";
    if ([value containsString:@"bottom bar"] || [value containsString:@"底栏"]) return @"rectangle.bottomthird.inset.filled";
    if ([value containsString:@"animation"] || [value containsString:@"动画效果"]) return @"sparkles";
    if ([value containsString:@"icon"] || [value containsString:@"图标"]) return @"app.badge";
    if ([value containsString:@"transfer"] || [value containsString:@"转移"]) return @"arrow.left.arrow.right";
    if ([value containsString:@"sign"] || [value containsString:@"ldid"] || [value containsString:@"签名"]) return @"signature";
    if ([value containsString:@"persistence"] || [value containsString:@"持久"]) return @"shield.lefthalf.filled";
    if ([value containsString:@"entitlement"] || [value containsString:@"权限"]) return @"lock.fill";
    if ([value containsString:@"url"] || [value containsString:@"scheme"] || [value containsString:@"链接"]) return @"link";
    if ([value containsString:@"install"] || [value containsString:@"安装"]) return @"square.and.arrow.down.fill";
    if ([value containsString:@"uninstall"] || [value containsString:@"卸载"]) return @"trash.fill";
    if ([value containsString:@"advanced"] || [value containsString:@"高级"]) return @"gearshape.2.fill";
    if ([value containsString:@"account"] || [value containsString:@"账户"]) return @"person.crop.circle.fill";
    if ([value containsString:@"security"] || [value containsString:@"安全"]) return @"checkmark.shield.fill";
    return @"gearshape.fill";
}

static BOOL TSCellContainsSwitch(UIView *view) {
    if ([view isKindOfClass:UISwitch.class]) return YES;
    for (UIView *subview in view.subviews) if (TSCellContainsSwitch(subview)) return YES;
    return NO;
}

// TSListControllerShared is compiled into both the main app and the persistence
// helper. TSThemeManager belongs only to the main app, so do not create a static
// Objective-C class reference here: the helper must remain linkable without it.
// When the main app hosts this controller, invoke the theme methods dynamically;
// when the persistence helper hosts it, fall back to standard UIKit styling.
static Class TSSharedThemeManagerClass(void) {
    return NSClassFromString(@"TSThemeManager");
}

static UIColor *TSSharedAccentColor(void) {
    Class themeManager = TSSharedThemeManagerClass();
    SEL selector = NSSelectorFromString(@"accentColor");
    Method method = themeManager ? class_getClassMethod(themeManager, selector) : NULL;
    if (method) {
        id (*implementation)(id, SEL) = (id (*)(id, SEL))method_getImplementation(method);
        UIColor *color = implementation(themeManager, selector);
        if ([color isKindOfClass:UIColor.class]) return color;
    }
    return UIColor.systemBlueColor;
}

static void TSSharedApplyThemeTableSelector(SEL selector, UITableView *tableView) {
    Class themeManager = TSSharedThemeManagerClass();
    Method method = themeManager ? class_getClassMethod(themeManager, selector) : NULL;
    if (method) {
        void (*implementation)(id, SEL, UITableView *) = (void (*)(id, SEL, UITableView *))method_getImplementation(method);
        implementation(themeManager, selector, tableView);
    } else if (tableView) {
        tableView.backgroundColor = UIColor.systemBackgroundColor;
        tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    }
}

static void TSSharedApplyThemeCellSelector(SEL selector, UITableViewCell *cell) {
    Class themeManager = TSSharedThemeManagerClass();
    Method method = themeManager ? class_getClassMethod(themeManager, selector) : NULL;
    if (method) {
        void (*implementation)(id, SEL, UITableViewCell *) = (void (*)(id, SEL, UITableViewCell *))method_getImplementation(method);
        implementation(themeManager, selector, cell);
    } else if (cell) {
        cell.backgroundColor = UIColor.clearColor;
        cell.contentView.backgroundColor = UIColor.clearColor;
    }
}

@implementation TSListControllerShared

- (void)viewDidLoad {
    [super viewDidLoad];
    TSSharedApplyThemeTableSelector(@selector(styleCardTableView:), self.tableView);
    self.tableView.contentInset = UIEdgeInsetsMake(2.0, 0.0, 8.0, 0.0);
    self.tableView.scrollIndicatorInsets = UIEdgeInsetsMake(2.0, 0.0, 8.0, 0.0);
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    TSSharedApplyThemeTableSelector(@selector(styleCardTableView:), self.tableView);
    for (UITableViewCell *cell in self.tableView.visibleCells) {
        TSSharedApplyThemeCellSelector(@selector(styleCardTableViewCell:), cell);
        NSString *title = cell.textLabel.text ?: @"";
        BOOL hasSwitch = TSCellContainsSwitch(cell);
        BOOL destructive = [title.lowercaseString containsString:@"uninstall"] || [title containsString:@"卸载"];
        BOOL actionRow = !hasSwitch;
        UIColor *rowColor = destructive ? UIColor.systemRedColor : (actionRow ? TSSharedAccentColor() : UIColor.labelColor);
        cell.textLabel.textColor = rowColor;
        cell.textLabel.font = [UIFont systemFontOfSize:16.5 weight:UIFontWeightMedium];
        cell.detailTextLabel.textColor = UIColor.secondaryLabelColor;
        cell.detailTextLabel.font = [UIFont systemFontOfSize:12.0 weight:UIFontWeightRegular];

        UIImageSymbolConfiguration *configuration = [UIImageSymbolConfiguration configurationWithPointSize:16.0 weight:UIImageSymbolWeightRegular];
        cell.imageView.image = [UIImage systemImageNamed:TSSymbolForPreferenceTitle(title) withConfiguration:configuration];
        cell.imageView.tintColor = hasSwitch ? UIColor.secondaryLabelColor : rowColor;
        cell.tintColor = TSSharedAccentColor();
        cell.imageView.contentMode = UIViewContentModeScaleAspectFit;
        cell.layoutMargins = UIEdgeInsetsMake(0.0, 14.0, 0.0, 14.0);
        cell.preservesSuperviewLayoutMargins = NO;
    }
    for (NSInteger section = 0; section < self.tableView.numberOfSections; section++) {
        UIView *header = [self.tableView headerViewForSection:section];
        UIView *footer = [self.tableView footerViewForSection:section];
        for (UIView *view in [NSArray arrayWithObjects:header ?: (id)[NSNull null], footer ?: (id)[NSNull null], nil]) {
            if (![view isKindOfClass:UIView.class]) continue;
            for (UIView *subview in view.subviews) {
                if ([subview isKindOfClass:UILabel.class]) {
                    UILabel *label = (UILabel *)subview;
                    label.textColor = UIColor.secondaryLabelColor;
                    label.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightRegular];
                }
            }
        }
    }
}

- (BOOL)isTrollStore
{
	return YES;
}

- (NSString*)getTrollStoreVersion
{
	if([self isTrollStore])
	{
		return [NSBundle.mainBundle objectForInfoDictionaryKey:@"CFBundleVersion"];
	}
	else
	{
		NSString* trollStorePath = trollStoreAppPath();
		if(!trollStorePath) return nil;

		NSBundle* trollStoreBundle = [NSBundle bundleWithPath:trollStorePath];
		return [trollStoreBundle objectForInfoDictionaryKey:@"CFBundleVersion"];
	}
}

- (void)downloadTrollStoreAndRun:(void (^)(NSString* localTrollStoreTarPath))doHandler
{
	NSURL* trollStoreURL = [NSURL URLWithString:@"https://github.com/opa334/TrollStore/releases/latest/download/TrollStore.tar"];
	NSURLRequest* trollStoreRequest = [NSURLRequest requestWithURL:trollStoreURL];

	NSURLSessionDownloadTask* downloadTask = [NSURLSession.sharedSession downloadTaskWithRequest:trollStoreRequest completionHandler:^(NSURL *location, NSURLResponse *response, NSError *error)
	{
		if(error)
		{
			UIAlertController* errorAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Error downloading TrollStore: %@", nil), error] preferredStyle:UIAlertControllerStyleAlert];
			UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];
			[errorAlert addAction:closeAction];

			dispatch_async(dispatch_get_main_queue(), ^
			{
				[TSPresentationDelegate stopActivityWithCompletion:^
				{
					[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:nil];
				}];
			});
		}
		else
		{
			NSString* tarTmpPath = [NSTemporaryDirectory() stringByAppendingPathComponent:@"TrollStore.tar"];
			[[NSFileManager defaultManager] removeItemAtPath:tarTmpPath error:nil];
			[[NSFileManager defaultManager] copyItemAtPath:location.path toPath:tarTmpPath error:nil];

			doHandler(tarTmpPath);
		}
	}];

	[downloadTask resume];
}

- (void)_installTrollStoreComingFromUpdateFlow:(BOOL)update
{
	if(update)
	{
		[TSPresentationDelegate startActivity:NSLocalizedString(@"Updating TrollStore", nil)];
	}
	else
	{
		[TSPresentationDelegate startActivity:NSLocalizedString(@"Installing TrollStore", nil)];
	}

	[self downloadTrollStoreAndRun:^(NSString* tmpTarPath)
	{
		int ret = spawnRoot(rootHelperPath(), @[@"install-trollstore", tmpTarPath], nil, nil);
		[[NSFileManager defaultManager] removeItemAtPath:tmpTarPath error:nil];

		if(ret == 0)
		{
			respring();

			if([self isTrollStore])
			{
				exit(0);
			}
			else
			{
				dispatch_async(dispatch_get_main_queue(), ^
				{
					[TSPresentationDelegate stopActivityWithCompletion:^
					{
						[self reloadSpecifiers];
					}];
				});
			}
		}
		else
		{
			dispatch_async(dispatch_get_main_queue(), ^
			{
				[TSPresentationDelegate stopActivityWithCompletion:^
				{
					UIAlertController* errorAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Error installing TrollStore: trollstorehelper returned %d", nil), ret] preferredStyle:UIAlertControllerStyleAlert];
					UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];
					[errorAlert addAction:closeAction];
					[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:nil];
				}];
			});
		}
	}];
}

- (void)installTrollStorePressed
{
	[self _installTrollStoreComingFromUpdateFlow:NO];
}

- (void)updateTrollStorePressed
{
	[self _installTrollStoreComingFromUpdateFlow:YES];
}

- (void)rebuildIconCachePressed
{
	[TSPresentationDelegate startActivity:NSLocalizedString(@"Rebuilding Icon Cache", nil)];

	dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^
	{
		spawnRoot(rootHelperPath(), @[@"refresh-all"], nil, nil);

		dispatch_async(dispatch_get_main_queue(), ^
		{
			[TSPresentationDelegate stopActivityWithCompletion:nil];
		});
	});
}

- (void)refreshAppRegistrationsPressed
{
	[TSPresentationDelegate startActivity:NSLocalizedString(@"Refreshing", nil)];

	dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^
	{
		spawnRoot(rootHelperPath(), @[@"refresh"], nil, nil);
		respring();

		dispatch_async(dispatch_get_main_queue(), ^
		{
			[TSPresentationDelegate stopActivityWithCompletion:nil];
		});
	});
}

- (void)uninstallPersistenceHelperPressed
{
	if([self isTrollStore])
	{
		spawnRoot(rootHelperPath(), @[@"uninstall-persistence-helper"], nil, nil);
		[self reloadSpecifiers];
	}
	else
	{
		UIAlertController* uninstallWarningAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Warning", nil) message:NSLocalizedString(@"Uninstalling the persistence helper will revert this app back to it's original state, you will however no longer be able to persistently refresh the TrollStore app registrations. Continue?", nil) preferredStyle:UIAlertControllerStyleAlert];
	
		UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil];
		[uninstallWarningAlert addAction:cancelAction];

		UIAlertAction* continueAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Continue", nil) style:UIAlertActionStyleDestructive handler:^(UIAlertAction* action)
		{
			spawnRoot(rootHelperPath(), @[@"uninstall-persistence-helper"], nil, nil);
			exit(0);
		}];
		[uninstallWarningAlert addAction:continueAction];

		[TSPresentationDelegate presentViewController:uninstallWarningAlert animated:YES completion:nil];
	}
}

- (void)handleUninstallation
{
	if([self isTrollStore])
	{
		exit(0);
	}
	else
	{
		[self reloadSpecifiers];
	}
}

- (NSMutableArray*)argsForUninstallingTrollStore
{
	return @[@"uninstall-trollstore"].mutableCopy;
}

- (void)uninstallTrollStorePressed
{
	UIAlertController* uninstallAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Uninstall", nil) message:NSLocalizedString(@"You are about to uninstall TrollStore, do you want to preserve the apps installed by it?", nil) preferredStyle:UIAlertControllerStyleAlert];
	
	UIAlertAction* uninstallAllAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Uninstall TrollStore, Uninstall Apps", nil) style:UIAlertActionStyleDestructive handler:^(UIAlertAction* action)
	{
		NSMutableArray* args = [self argsForUninstallingTrollStore];
		spawnRoot(rootHelperPath(), args, nil, nil);
		[self handleUninstallation];
	}];
	[uninstallAlert addAction:uninstallAllAction];

	UIAlertAction* preserveAppsAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Uninstall TrollStore, Preserve Apps", nil) style:UIAlertActionStyleDestructive handler:^(UIAlertAction* action)
	{
		NSMutableArray* args = [self argsForUninstallingTrollStore];
		[args addObject:@"preserve-apps"];
		spawnRoot(rootHelperPath(), args, nil, nil);
		[self handleUninstallation];
	}];
	[uninstallAlert addAction:preserveAppsAction];

	UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil];
	[uninstallAlert addAction:cancelAction];

	[TSPresentationDelegate presentViewController:uninstallAlert animated:YES completion:nil];
}

@end