#import "TSPresentationDelegate.h"
#import <QuartzCore/QuartzCore.h>
#import <math.h>

@interface TSOrbitingBallsView : UIView
@end

@implementation TSOrbitingBallsView
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;
    self.backgroundColor = UIColor.clearColor;
    self.userInteractionEnabled = NO;
    NSArray<UIColor *> *colors = @[UIColor.systemRedColor, UIColor.systemGreenColor, UIColor.systemYellowColor];
    CGFloat ballSize = 13.0;
    CGFloat orbitRadius = 17.0;
    CGPoint center = CGPointMake(CGRectGetMidX(self.bounds), CGRectGetMidY(self.bounds));
    for (NSUInteger i = 0; i < colors.count; i++) {
        CALayer *ball = [CALayer layer];
        ball.bounds = CGRectMake(0, 0, ballSize, ballSize);
        ball.cornerRadius = ballSize / 2.0;
        ball.backgroundColor = colors[i].CGColor;
        ball.shadowColor = UIColor.blackColor.CGColor;
        ball.shadowOpacity = 0.18;
        ball.shadowRadius = 2.0;
        ball.shadowOffset = CGSizeMake(0, 1);
        CGFloat angle = ((CGFloat)i * (2.0 * M_PI / 3.0));
        ball.position = CGPointMake(center.x + cos(angle) * orbitRadius, center.y + sin(angle) * orbitRadius);
        [self.layer addSublayer:ball];

        // Three differently tilted elliptical paths intersect at the center,
        // creating the red/green/yellow crossing-orbit loading animation.
        UIBezierPath *orbit = [UIBezierPath bezierPath];
        CGRect ellipse = CGRectMake(center.x - orbitRadius, center.y - orbitRadius * 0.62,
                                    orbitRadius * 2.0, orbitRadius * 1.24);
        [orbit appendPath:[UIBezierPath bezierPathWithOvalInRect:ellipse]];
        CGAffineTransform rotation = CGAffineTransformMakeTranslation(-center.x, -center.y);
        rotation = CGAffineTransformRotate(rotation, angle);
        rotation = CGAffineTransformTranslate(rotation, center.x, center.y);
        [orbit applyTransform:rotation];

        CAKeyframeAnimation *animation = [CAKeyframeAnimation animationWithKeyPath:@"position"];
        animation.path = orbit.CGPath;
        animation.duration = 1.35;
        animation.repeatCount = HUGE_VALF;
        animation.calculationMode = kCAAnimationPaced;
        animation.rotationMode = kCAAnimationRotateAuto;
        animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionLinear];
        animation.timeOffset = (CFTimeInterval)i * (animation.duration / 3.0);
        [ball addAnimation:animation forKey:@"ts.crossing-orbit"];
    }
    return self;
}
@end


@implementation TSPresentationDelegate

static UIViewController* g_presentationViewController;
static UIAlertController* g_activityController;

+ (UIViewController*)presentationViewController
{
	return g_presentationViewController;
}

+ (void)setPresentationViewController:(UIViewController*)vc
{
	g_presentationViewController = vc;
}

+ (UIAlertController*)activityController
{
	return g_activityController;
}

+ (void)setActivityController:(UIAlertController*)ac
{
	g_activityController = ac;
}

+ (void)startActivity:(NSString*)activity withCancelHandler:(void (^)(void))cancelHandler
{
	if(self.activityController)
	{
		self.activityController.title = activity;
	}
	else
	{
		self.activityController = [UIAlertController alertControllerWithTitle:activity message:@"\n\n\n" preferredStyle:UIAlertControllerStyleAlert];
		TSOrbitingBallsView* activityIndicator = [[TSOrbitingBallsView alloc] initWithFrame:CGRectZero];
		activityIndicator.translatesAutoresizingMaskIntoConstraints = NO;
		[self.activityController.view addSubview:activityIndicator];
		[NSLayoutConstraint activateConstraints:@[
			[activityIndicator.centerXAnchor constraintEqualToAnchor:self.activityController.view.centerXAnchor],
			[activityIndicator.topAnchor constraintEqualToAnchor:self.activityController.view.topAnchor constant:58.0],
			[activityIndicator.widthAnchor constraintEqualToConstant:56.0],
			[activityIndicator.heightAnchor constraintEqualToConstant:56.0]
		]];

		if(cancelHandler)
		{
			UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:^(UIAlertAction* action)
			{
				self.activityController = nil;
				cancelHandler();
			}];
			[self.activityController addAction:cancelAction];
		}

		[self presentViewController:self.activityController animated:YES completion:nil];
	}
}

+ (void)startActivity:(NSString*)activity
{
	[self startActivity:activity withCancelHandler:nil];
}

+ (void)stopActivityWithCompletion:(void (^)(void))completionBlock
{
	if(!self.activityController) return;

	[self.activityController dismissViewControllerAnimated:YES completion:^
	{
		self.activityController = nil;
		if(completionBlock) completionBlock();
	}];
}

+ (void)presentViewController:(UIViewController *)viewControllerToPresent animated:(BOOL)flag completion:(void (^)(void))completionBlock
{
	[self.presentationViewController presentViewController:viewControllerToPresent animated:flag completion:completionBlock];
}

@end