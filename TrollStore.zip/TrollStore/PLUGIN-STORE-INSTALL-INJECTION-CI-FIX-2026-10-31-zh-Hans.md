# 插件本地仓库与安装时注入 CI 修复报告

日期：2026-10-31

## 本轮修复的 CI 错误

原日志错误：

```objc
NSString *dependencyText = (item[@"Depends"] ?: @"").lowercaseString;
```

Clang 将 `item[...]` 表达式推断成 `id _Null_unspecified`，因此不能直接访问 `lowercaseString`。本轮按用户确认的真实需求，移除了原来把 Plugins 页面当成在线 DEB 仓库索引浏览器的实现，并重写为本地插件库管理器；旧的 `item[@"Depends"]` 解析路径已不存在，因此该编译错误不再存在。列表行使用明确的 `NSString *` 类型，不再对未类型化的 `id` 访问字符串属性。

## 插件功能定义

插件页面现在是本地存储区，不是在线 tweak 商店：

- 支持导入和保存 `.dylib`、`.framework`、`.deb`、`.zip`。
- DEB/ZIP 原始文件保留在 `Documents/Plugins`，同时安全解压到对应的 `.contents` 目录。
- 从归档中枚举可注入的 `.dylib` 和 `.framework`；用户可查看库列表并删除插件包。
- 不执行 DEB 的安装脚本，不调用 dpkg，也不将系统级包伪装成可由 TrollStore 独立安装的 tweak。

## 设置开关及安装流程

- 普通 TrollStore 版本增加“安装时启用插件注入”设置，持久化键为 `TSPluginInjectionEnabled`，默认关闭。
- 开关关闭：安装 IPA 不显示插件选择页面、不传入注入参数，沿用原安装流程。
- 开关开启且插件库非空：安装 IPA 时展示多选列表。用户可选一个或多个库，也可以不选任何库继续普通安装；点取消则取消本次安装。
- 选择结果作为 `pluginPaths` 保存在安装会话中；切换安装方法或重试时会保留选择。
- `TSApplicationsManager` 对路径做本地插件目录和扩展名检查，再将每个库作为 `--inject-dylib <path>` 参数传给 RootHelper。
- RootHelper 再次校验 staging app 路径、插件真实路径、扩展名及 Framework 可执行文件；在临时解包的目标应用上运行内置 ldid 的 `--iosinject --inplace --sign --verify`，随后由原安装过程统一执行最终 `signApp`。不会为每个插件单独重复整个 App 签名过程。
- TrollStore Lite 保留本地插件存储，但不显示不受支持的安装时注入开关。

## 已修改/新增的核心文件

- `TrollStore/TSPluginStore.h/.m`：本地插件存储、归档展开、库枚举、路径校验、删除。
- `TrollStore/TSPluginStoreController.h/.m`：插件页面和文件导入 UI。
- `TrollStore/TSPluginSelectionController.h/.m`：IPA 安装前的动态库多选 UI。
- `TrollStore/TSSettingsListController.m`：安装时注入设置开关，默认关闭；Lite 版本隐藏不可用开关。
- `TrollStore/TSInstallationController.m`：开关判断、选择流程、安装会话和重试参数保留。
- `TrollStore/TSApplicationsManager.h/.m`：注入参数传递和客户端路径检查。
- `RootHelper/TSAppMaintenance.h/.m`：临时 IPA 目标路径、插件路径和 Mach-O 类型验证，以及 ldid 注入。
- `RootHelper/main.m`：解析重复 `--inject-dylib` 参数并在最终签名前注入。
- `TrollStore/Resources/zh-Hans.lproj/Localizable.strings`：插件相关简体中文文案。

## 安全与兼容性边界

1. 这里只从 DEB 的 `data.tar*` 或 ZIP 内容中提取动态库，不执行包内安装脚本、维护脚本或 control 阶段命令。
2. 注入的 dylib/framework 必须与目标设备架构及目标 App 进程兼容；错误的动态库可能使 App 崩溃或无法启动。应先用非重要应用测试，并保留原 IPA。
3. 依赖 MobileSubstrate、ElleKit、PreferenceLoader、Crane 或 SpringBoard 注入环境的 tweak，不会因为把其 dylib 注入一个普通 App 就自动获得这些依赖。对应 loader、配置 plist、资源和服务仍需单独满足。
4. 注入发生在临时解包的 IPA 上，完成后再进入既有签名/安装流程；若注入失败，会在替换已安装应用前返回错误。
5. 逐 App 禁止升级/恢复升级功能和四栏 UI 保留在本次基线中。

## 静态验证结果

- 所有本轮变更 Objective-C 源文件括号/括弧配对检查通过。
- 插件相关 `NSLocalizedString` 均有简体中文键，无重复键。
- 确认旧 `item[@"Depends"]` 错误表达式已移除。
- 确认普通版本注入设置默认关闭，Lite 版本不显示注入开关。
- 确认 `pluginPaths` 从选择界面传至安装会话、ApplicationsManager、RootHelper，并在最终签名前处理。
- `Scripts/fastpath_sign_all_slices.py` 保持可执行权限（0755）。
- 原始 `bin/ldid` SHA-256：`d23eb53e6c5b07f5cae72f0e93ab1b87214aa68ed4a59bc32286f8b15cb8b769`，与输入工程一致，未修改。

## 尚未完成的验证

当前执行环境没有 macOS、Xcode iPhoneOS SDK 或 Theos 工具链，因此不能在这里运行真实的 iOS arm64 编译和真机安装测试。本报告中的验证是静态检查；请在 GitHub Actions 重新运行 CI。若出现新的编译错误，应以新日志为准继续修正。
