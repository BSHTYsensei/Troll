# TrollStore 真签名与签名方式设置更新

## 本轮实现

本轮以资料库存储的 `TrollStore-Full-Implementation-zh-Hans.zip` 工程为基线，并替换为 2026-10-30 上传的新版 `ldid`，实现证书 CMS 真签名与巨魔 ad-hoc 签名的独立设置和安装路径。

### 1. 设置中的签名方式

设置新增“签名方式与证书”入口，提供两种互斥模式：

- **真签名**：使用导入的证书和私钥生成 CMS/PKCS#7 代码签名。
- **巨魔签名**：继续使用 ad-hoc 签名和 TrollStore 的 CoreTrust 路径。此选项在 UI 中以红色字体显示。

为保持既有安装行为，初次升级时默认仍为“巨魔签名”；真签名模式的默认模板为 **App Store**。两种模式分别保存模板选择，切换模式不会覆盖另一种模式的模板。

### 2. 证书身份管理

支持导入：

- `.p12` / `.pfx`：输入 P12 密码。
- PEM 证书 + PEM 私钥：分两次选择证书文件和私钥文件，支持加密 PEM 私钥密码。
- 可选 `.mobileprovision`：绑定到所选证书身份，用于需要描述文件的安装/分发场景。

第一个成功导入的身份自动成为默认身份。之后可以导入多份身份、设置任意一份为默认、查看详情或删除。删除身份时会同步删除对应 Keychain 项与身份目录。

证书私钥及 P12 原始材料保存在 Keychain（`WhenUnlockedThisDeviceOnly`）；不会写入 `NSUserDefaults`。RootHelper 签名期间使用的短期材料放在应用私有 `TSSigning/Runtime` 目录，目录权限为 `0700`、临时文件为 `0600`，RootHelper 返回后删除。证书公开信息和可选描述文件保存在应用私有目录。

点击证书后可进入详情页，按用户指定顺序纵向显示：

1. **签发者**
2. **有效期**：生效时间、失效时间
3. **OID**：从 `SecCertificateCopyValues` 返回的证书字段/OID 集合提取并排序显示

### 3. 签名模板

真签名模式提供：

- App Store（默认）
- App Store Connect
- TestFlight
- Apple Development
- Developer Distribution
- Ad Hoc
- Enterprise / In-House

巨魔签名模式提供：

- TrollStore Default
- TrollStore Fast
- TrollStore Compatibility

模板作为 ldid 配置 profile，分别控制 SHA-256 哈希和并行任务数（`jobs`）。它们是本应用提供的本地签名预设，不会凭空改变证书身份或分发资格。设置页明确提示：实际身份和权限由证书及 provisioning profile 决定；选择 App Store 不会生成 Apple 签发的证书、描述文件、审核结果或分发授权。

### 4. 真签名安装路径

- 真签名使用新版 ldid 的 P12 或 PEM 证书/私钥配置生成 CMS/PKCS#7 签名。
- 普通真签名使用 ldid 的递归 bundle 签名路径，并启用 `--deep --super-deep`。
- 使用 Entitlements 覆盖层时，走逐二进制深度合并路径；未指定的原始 Entitlements 保留，再对签名结果执行相同的签后验证。
- 真签名绝不附加 `-s` ad-hoc 参数。
- 真签名路径不执行 TrollStore CoreTrust bypass，也不使用 TrollStore 合成 Entitlements。
- 完成后使用 `ldid --signature-validate` 检查签名结构、代码哈希与 profile 关联。CMS 数学签名验证与证书链信任验证仍然分离；本工程没有默认开启证书链验证。
- 导入的 provisioning profile 会复制为应用包内的 `embedded.mobileprovision`。若没有 profile 且源应用也没有现成 profile，安装流程会在签名完成后返回描述文件警告（错误码 193），而不是把“有 CMS 签名”误报为“必然可安装/启动”。

### 5. 新版 ldid

已将 2026-10-30 存储中的预编译二进制放入 `bin/ldid`，并将对应源码 `ldid.cpp`、`ldid.hpp`、命令行说明、构建配置和原始源码 ZIP 保留在 `ldid-reference/`。

- SHA-256：`d23eb53e6c5b07f5cae72f0e93ab1b87214aa68ed4a59bc32286f8b15cb8b769`
- 架构：arm64
- 最低系统版本：iOS 16.0.0
- SDK 元数据：iOS 16.4.0

构建流程使用已提供的完整预编译二进制，不会尝试用当前 Linux 环境重新编译 ldid 源码。

## 使用说明

1. 打开 TrollStore → 设置 → 签名方式与证书。
2. 选择“真签名”。
3. 导入 P12，或依次导入 PEM 证书和对应私钥；第一次导入的身份自动成为默认身份。
4. 可选：选择对应身份并导入 provisioning profile。
5. 在证书下方选择真签名模板。默认是 App Store。
6. 需要回到 TrollStore 原有方式时，切换到红色的“巨魔签名”，再选择其独立模板。

## 重要边界

- “App Store”模板只是本地 ldid 预设名称和签名参数选择，不代表 Apple 已签发证书/profile，也不代表应用已通过 App Review。真正的 App Store 分发需要有效的 Apple 开发者分发流程和匹配的 App ID / profile / 证书。
- 证书 CMS 签名本身不等于 iOS 设备安装授权。开发/Ad Hoc 等本地安装场景通常需要与签名身份、Bundle ID、设备和 Entitlements 匹配的 provisioning profile；App Store 下载的应用通常不包含 embedded provisioning profile，因为商店分发检查发生在 Apple 的发布流程中。
- 真签名默认只做 CMS 数学签名和代码结构/哈希验证，不默认信任证书链。证书链检查需要由用户明确启用并提供正确的信任锚；OpenSSL 默认 trust store 不等同于 iOS 系统信任库。
- 新版 ldid 的 Mach-O 元数据最低 iOS 16.0.0；本工程全部 app/helper/preset Theos 目标的最低部署版本也已统一为 iOS 16.0。RootHelper 仍保留运行时版本门控，不会仅因文件存在就误调用不兼容二进制。TrollStore Lite 使用外部系统 ldid，不套用这个内置二进制版本门控。
- 当前运行环境是 Linux x86_64，没有 Xcode、iPhoneOS SDK、`xcrun` 或 Theos。已完成源代码静态审计、工程文件检查、plist/strings 检查和 ldid Mach-O 架构校验；没有声称完成 Theos 编译或 iPhone 真机签名/安装测试。

## 本轮自动检查

通过：

- `python3 -m py_compile Scripts/validate_project.py`
- `python3 Scripts/validate_project.py`：79 项必需文件、6 份 plist、4 份 strings、489 个简体中文键及签名/证书相关静态断言通过。
- `python3 Scripts/validate_macho.py bin/ldid`：新版 arm64 ldid 文件校验通过。

未执行：Xcode/Theos 全量构建、真机 P12/PEM CMS 签名、真实 provisioning profile 安装启动测试。
