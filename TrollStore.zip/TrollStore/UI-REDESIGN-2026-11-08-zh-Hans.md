# TrollStore UI：按用户录屏复刻（2026-11-08）

## 设计基准

本次改造以用户提供的 2026-11-08 iPhone 屏幕录制为直接参考，不沿用此前错误的“全宽标准 TabBar”方向，也不复制第三方修改版代码或资源。

## 对齐的视觉与交互

- 根界面采用纯黑/深色背景，应用、软件包、插件页使用左对齐大标题；设置页使用居中紧凑标题。
- 底部为悬浮胶囊导航：四个等宽入口，宽度约为屏幕宽度减 80 pt，高约 62 pt，距底部约 8 pt；选中项使用中性灰胶囊底，图标和文字使用主题强调色，未选中项为灰色。
- 应用页顶部为大标题、右上角蓝色圆形加号和紧凑筛选分段控件；默认不常驻搜索栏，搜索仍可从加号菜单进入。
- 软件包和插件页面使用大标题、左侧编辑入口、右侧圆形加号按钮，以及深色圆角列表卡片。
- 设置使用独立圆角卡片分组；个性化区域包括系统应用、筛选栏、TrollStore 标识、网格类型标签等开关，以及列表布局、底栏样式、主题颜色、应用图标和应用内动画选项。
- 主题外观菜单提供跟随系统、浅色、深色；主题颜色使用系统颜色选择器，支持光谱/网格/滑块、透明度和预设色。
- 底栏样式页提供悬浮、标准、悬浮 2；页面切换动画提供淡入淡出（默认）和标准模式；应用列表提供列表/网格选择。
- 默认页面切换采用短时淡入淡出；标准模式采用克制的短距离滑动。底栏选中状态立即响应点击，不串联延迟缩放/弹簧动画；支持 Reduce Motion。
- 首次进入设置页时将较重的 Preferences specifier 构建延后到下一次主队列执行，避免阻塞根控制器启动导航动画。

## 功能行为

- “显示系统应用”控制系统应用在目录中的显示，并同步禁用不可用的系统筛选。
- “显示应用筛选”关闭时隐藏筛选控件并回到全部应用。
- TrollStore 标识及网格应用类型标签开关会实际控制相应视图内容。
- 列表/网格布局、底栏样式和切页动画选项保存后立即应用。
- 更换应用图标前检查当前构建是否声明备用图标；没有备用图标时明确提示，不显示虚假的成功状态。
- 插件库只展示当前代码真正支持的导入与刷新操作；未实现的文件夹/文本文件创建没有伪装成可用按钮。

## 主要变更文件

- `TrollStore/TSRootViewController.m` / `.h`
- `TrollStore/TSThemeManager.m` / `.h`
- `TrollStore/TSSettingsListController.m`
- `TrollStore/TSChoiceListController.m` / `.h`
- `TrollStore/TSAppTableViewController.m` / `.h`
- `TrollStore/TSAppCollectionViewController.m`
- `TrollStore/TSIPAPackageStore.m`
- `TrollStore/TSPluginStoreController.m`
- `Shared/TSListControllerShared.m`
- 简体中文本地化资源与 `Scripts/validate_project.py`

## 验证范围与限制

`make validate-project` 用于验证项目文件、plist/strings、本地化和 fastPathSign 静态检查。此环境没有 Theos 与 Apple iOS SDK，因此验证通过不等于已完成 iOS 目标编译；仍需在 macOS + Theos 环境编译，并在设备上检查 Safe Area、深浅色、快速连续切页及系统 Reduce Motion 行为。
