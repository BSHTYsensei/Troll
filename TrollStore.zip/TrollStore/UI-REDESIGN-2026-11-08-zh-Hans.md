# TrollStore 底栏与切页动画调整（2026-11-08）

## 参考方向

参考 Telegram 公开发布记录中标注为 `ios|dump` 的 TrollStore 2.1 二次 UI 版本：标准底栏、取消首次启动时底栏从屏幕下方漂入的装饰动画，以及将部分切换动画调整为淡入淡出。这里仅复用可观察到的交互/布局方向，没有搬运第三方修改版的二进制或代码。

## 本次实现

- 默认采用全宽、贴底、覆盖 Home Indicator 安全区的标准底栏；保留原来的悬浮胶囊样式，通过“启用悬浮底栏”设置重新开启。
- 标准底栏取消悬浮胶囊、外框和投影，使用系统材质背景及细分隔线。
- 页面切换由原先带水平位移的弹簧动画调整为 160 ms 淡入淡出。
- 选中图标/文字和悬浮模式的选中指示器在点击后立即更新，不再等页面动画结束。
- 删除原先 120 ms 按压缩放 + 240 ms 弹簧复位的串行动画，保留轻触觉反馈。
- 首次启动仍然不播放底栏入场动画；保留 Reduce Motion 系统辅助功能设置。
- 同步外观设置开关的默认状态、本地化字符串和项目验证脚本。

## 涉及文件

- `TrollStore/TSRootViewController.m`
- `TrollStore/TSRootViewController.h`
- `TrollStore/TSThemeManager.m`
- `TrollStore/TSAppearanceController.m`
- `TrollStore/Resources/zh-Hans.lproj/Localizable.strings`
- `TrollHelper/Resources/zh-Hans.lproj/Localizable.strings`
- `Scripts/validate_project.py`

## 验证

已通过 `make validate-project`：资源、plist、本地化目录、项目文件和 fastPathSign 静态测试均通过。

当前执行环境没有 Theos 和 iOS SDK，未在此处执行真正的 iOS 目标编译或设备运行测试。请在 macOS + Theos 环境执行完整构建，并在设备上检查底栏安全区、深浅色外观、快速连续点按和 Reduce Motion 行为。
