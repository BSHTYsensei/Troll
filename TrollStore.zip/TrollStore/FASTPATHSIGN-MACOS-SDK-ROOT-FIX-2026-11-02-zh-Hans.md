# fastPathSign macOS Host SDK sysroot 修复

日期：2026-11-02
基线：`TrollStore-XcodeClang-Isolation-2026-11-01.zip`

## 1. CI 错误根因

最近的 GitHub Actions 日志显示失败发生在 `Exploits/fastPathSign` 的主机工具编译，而不是 iOS Theos target：

- `Foundation/Foundation.h` 从 `/System/Library/Frameworks` 查找失败。
- `CoreFoundation/CoreFoundation.h` 查找失败。
- `stdlib.h`、`stdio.h`、`math.h` 和 `mach-o/*` 等 SDK 头文件均不可见。

上一轮已把 host compiler 固定到 XcodeDefault Clang，但通过绝对路径直接调用 Xcode Clang 不会自动选择 macOS SDK。fastPathSign 的命令没有 `-isysroot`，因而把主机工具当成没有 SDK 的裸 clang 调用；同时它也不能继承 Theos 的 iPhoneOS SDK。

## 2. 修复内容

### 根 Makefile

- 新增 `HOST_MACOSX_SDKROOT`，默认通过 `xcrun --sdk macosx --show-sdk-path` 解析。
- 新增 `HOST_MACOSX_DEPLOYMENT_TARGET`，默认为 12.0。
- `check-build-tools` 检查 macOS SDK 路径、Foundation.framework 头文件和标准 C `stdlib.h`。
- 构建日志打印 fastPathSign 使用的 macOS SDK。
- 递归构建 `Exploits/fastPathSign` 时只向该 host target 传递 `HOST_MACOSX_SDKROOT`，iOS Theos targets 不接收此变量。

### fastPathSign Makefile

- 保留 XcodeDefault Clang 作为 host 编译器。
- 编译和链接都明确加入 `-isysroot "$(HOST_MACOSX_SDKROOT)"`。
- 显式加入 `-mmacosx-version-min=12.0`。
- 明确链接 Foundation、CoreFoundation、CoreServices、Security 和现有 libcrypto。
- standalone 构建时也会自行通过 `xcrun --sdk macosx` 解析 SDK；若 SDK 头文件缺失则提前给出清晰错误。

### 回归测试

新增 `Scripts/test_fastpath_host_sdk.sh`：

- 构造最小的模拟 MacOSX SDK 头文件布局。
- 使用测试 Clang 收集实际传入参数。
- 确认编译参数包含 `-isysroot <MacOSX.sdk>`。
- 确认编译参数包含 `-mmacosx-version-min=12.0`。
- 拒绝出现 `iPhoneOS` SDK 路径。
- 接入 `make validate-project` 与 Bash 语法检查。

## 3. 验证结果

已执行：

`make validate-project LDID_BIN=bin/ldid`

结果通过：

- Xcode Clang 与 Swift.org Clang 隔离模拟测试。
- fastPathSign MacOSX host SDK sysroot 参数测试。
- Theos Swift support 损坏缓存恢复测试。
- Swift.org 安装包签名状态解析测试：3 种可信状态接受、4 种不可信状态拒绝。
- 项目审计：109 个必需文件存在。
- 6 个 plist、4 个 strings 资源校验通过。
- 简体中文 638 个键匹配，630 个译值包含中文。
- fastPathSign 按 slice 签名、Universal 重建、Framework 包装回归通过。
- 预编译 arm64 `bin/ldid` 架构和完整性校验通过，原二进制未修改。
- ZIP 完整性检查通过。

## 4. 验证边界

当前编辑环境不是 macOS/Xcode，模拟测试验证的是 Makefile 的 sysroot 传递与编译参数，不是实际的 Apple Foundation/SDK 编译。下一次 GitHub macOS Runner 预期日志应显示：

- 编译器：`XcodeDefault.xctoolchain/usr/bin/clang`
- sysroot：`xcrun --sdk macosx --show-sdk-path` 输出的 `MacOSX.sdk`
- 参数：`-isysroot .../MacOSX.sdk`
- 部署目标：`-mmacosx-version-min=12.0`

iOS TrollStore、RootHelper、TrollHelper、AppLock 和 BackgroundAssist targets 仍使用各自 Theos 的 iPhoneOS SDK，不会使用 MacOSX SDK。Swift 5.8.1 仍只用于 TrollStore Swift target。
