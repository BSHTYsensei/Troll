# TrollStore — iOS 16.5 Shortcuts navigation build fix

Date: 2026-11-01
Base: `TrollStore-ShortcutsLink-TrollDefault-2026-11-01.zip`

## 1. Build error

The GitHub Actions compiler reports `cannot find 'ShortcutsLink' in scope` with the project's iPhoneOS 16.5 SDK. The earlier Objective-C `ShortcutsUIButton` attempt failed too. Both controls are therefore unavailable to this concrete SDK/toolchain combination and must not be referenced by source compiled against it.

Changes:

- Removed `import SwiftUI`, `ShortcutsLink`, `ShortcutsUIButton`, the Swift factory, `UIHostingController`, and the generated `TrollStore-Swift.h` dependency from the settings controller.
- Kept `TSRefreshAppRegistrationsIntent` and `TrollStoreAppShortcuts` in AppIntents Swift; the App Shortcut still auto-registers with the main TrollStore app.
- Replaced the page entry with a standard UIKit `UIButton` calling `UIApplication openURL:options:completionHandler:` for Apple's documented `shortcuts://` URL.
- Added instructions: open Shortcuts → App Shortcuts → TrollStore → Refresh Apps. Users can use the App Shortcut in a custom shortcut or Personal Automation.
- Added error feedback if iOS cannot open Shortcuts, and retained the Done exit button.
- Removed the unnecessary SwiftUI framework linkage from TrollStore's Theos Makefile.

## 2. Private API decision

The project owner explicitly permits private API usage. Research confirms `WorkflowKit.framework` is a private Shortcuts backend and has APIs for importing/storing workflow records. However, the reverse-engineered references found do not establish a verified iOS 16.5 private API for navigating to the current host app's App Shortcuts page. WorkflowKit database examples involve workflow import, database initialization and entitlement/process-context requirements; they are not an equivalent UI deep link.

No speculative private class name, selector, URL path, or database write was added. Apple's documented URL schemes include `shortcuts://` (open Shortcuts), `shortcuts://create-shortcut`, and `shortcuts://open-shortcut?name=...`; Apple does not document a URL that targets one app's App Shortcuts page. The native `ShortcutsLink` remains the intended public UI on SDKs that expose it, but the selected iOS 16.5 SDK does not compile it.

Importantly, AppShortcutsProvider shortcuts are automatically available after app installation. The user does not need the helper injected into Shortcuts and does not need to convert the App Shortcut into a standalone shortcut before using it as an action in automation.

## 3. Persistence Helper separation

- `com.apple.shortcuts` remains excluded by the TrollStore UI picker.
- RootHelper independently rejects `install-persistence-helper` requests targeting `com.apple.shortcuts` with `EPERM`.
- The refresh App Intent remains part of TrollStore itself and only performs the `refresh` helper command.

## 4. Verification

`make validate-project` passed in this environment:

- stale Theos Swift-support cache recovery regression;
- Swift package signature-status compatibility tests (3 accepted, 4 rejected);
- project audit (105 required files);
- plist and strings resource validation;
- 638 matching zh-Hans localization keys;
- fastPathSign per-slice signing, universal reconstruction and Framework wrapping regression;
- prebuilt arm64 `bin/ldid` validation.

Not run: full macOS Theos/Xcode compilation or on-device navigation testing. The new code removes the failing SwiftUI symbol references entirely, but final proof requires the next GitHub macOS build.
