# CodeDirectory 签名标志说明

本页说明签名设置中的 CodeDirectory `CS_*` 标志。数值与语义以 Apple XNU 的 `osfmk/kern/cs_blobs.h` 为依据：<https://github.com/apple-oss-distributions/xnu/blob/main/osfmk/kern/cs_blobs.h>。

> **重要区别**：这些是代码签名标志，不是 Mach-O header flags，也不是 `CS_EXECSEG_*` 可执行段标志。将某一位写入 CodeDirectory 不会自动创建对应 Entitlement、Apple 证书、描述文件或系统信任。某些位只是运行时状态，不能靠签名伪造。

## 设置页中可独立开关的标志

每个开关独立保存，多个开关可以同时开启。关闭开关只表示不额外添加该位，不会清除 ldid 或签名模式自动产生的位。

| 标志 | 位值 | 作用与风险 |
|---|---:|---|
| `CS_HARD` | `0x00000100` | 不加载校验无效的代码页。加强完整性约束，但可能影响需要动态修改代码页的程序。 |
| `CS_KILL` | `0x00000200` | 进程变为签名无效时终止进程。配置不兼容时可能导致应用直接退出。 |
| `CS_CHECK_EXPIRATION` | `0x00000400` | 强制检查签名有效期；签名证书/材料过期可能影响运行。 |
| `CS_RESTRICT` | `0x00000800` | 告知 dyld 将代码视为受限代码，可能触发额外加载限制。 |
| `CS_ENFORCEMENT` | `0x00001000` | 要求执行代码签名强制策略。不要在不了解目标系统策略时启用。 |
| `CS_GET_TASK_ALLOW` | `0x00000004` | 表示具有 `get-task-allow` Entitlement。单独添加标志位不会创建该 Entitlement，也不会保证调试器获得权限。 |
| `CS_REQUIRE_LV` | `0x00002000` | 要求 Library Validation。可能阻止加载不符合库验证规则的动态库或注入库。 |
| `CS_RUNTIME` | `0x00010000` | 启用 Hardened Runtime 相关策略。ldid 会尝试根据 SDK、最低系统版本或平台策略推导 runtime version；仍需确认目标环境兼容。 |
| `CS_LINKER_SIGNED` | `0x00020000` | 表示由链接器自动签名。通常应由链接器/构建流程决定，不应为普通应用随意伪造。 |

## 自动管理或锁定的标志

| 标志 | 位值 | 为什么不开放普通开关 |
|---|---:|---|
| `CS_VALID` | `0x00000001` | 动态有效状态，由系统验证过程维护。 |
| `CS_ADHOC` | `0x00000002` | Ad-hoc 签名标志。TrollStore 签名模式自动开启；证书 CMS 模式自动关闭，设置页显示锁定状态。 |
| `CS_INSTALLER` | `0x00000008` | 表示具有 installer Entitlement；单独设置位不会授予安装器权限。 |
| `CS_FORCED_LV` | `0x00000010` | 由 Hardened System Policy 强制要求库验证，属于系统策略。 |
| `CS_INVALID_ALLOWED` | `0x00000020` | macOS 专用的无效页策略位，不适用于常规 iOS 应用。 |
| `CS_ENTITLEMENTS_VALIDATED` | `0x00004000` | 表示签名允许受限 Entitlements，由签名/系统验证流程管理。 |
| `CS_NVRAM_UNRESTRICTED` | `0x00008000` | 对应受限 NVRAM Entitlement；设置页显示为锁定项，单独写位不会授予权限。 |
| `CS_EXEC_SET_HARD` | `0x00100000` | 将 `CS_HARD` 传播给 exec 的子进程，改变子进程策略。 |
| `CS_EXEC_SET_KILL` | `0x00200000` | 将 `CS_KILL` 传播给 exec 的子进程。 |
| `CS_EXEC_SET_ENFORCEMENT` | `0x00400000` | 将强制执行策略传播给 exec 的子进程。 |
| `CS_EXEC_INHERIT_SIP` | `0x00800000` | 将 installer/SIP 相关状态传播给子进程，属于特权策略。 |
| `CS_KILLED` | `0x01000000` | 表示进程曾因代码无效而被内核终止，是运行时状态。 |
| `CS_NO_UNTRUSTED_HELPERS` | `0x02000000` | 表示内核未加载非平台签名的 dyld/Rosetta 运行时，属于系统加载状态。 |
| `CS_PLATFORM_BINARY` | `0x04000000` | 表示平台二进制；不能通过自行添加标志获得 Apple 平台信任。 |
| `CS_PLATFORM_PATH` | `0x08000000` | macOS 平台路径状态，不适用于普通 iOS 应用。 |
| `CS_DEBUGGED` | `0x10000000` | 表示进程当前或曾处于允许无效页的调试状态，是运行时状态。 |
| `CS_SIGNED` | `0x20000000` | 表示进程具有签名（签名可能随后失效），由系统状态管理。 |
| `CS_DEV_CODE` | `0x40000000` | 标记开发者签名代码，涉及开发/生产代码加载隔离，不能用来制造开发者信任。 |
| `CS_DATAVAULT_CONTROLLER` | `0x80000000` | 对应 Data Vault controller Entitlement，属于特权能力标志。 |

## 当前实现的安全边界

- 设置页可修改的标志独立保存于 TrollStore 用户偏好设置；签名时只把已开启的名称写入 ldid 配置 `flags`。
- 不写入 `flagsClear`，因此用户关闭开关不会清除签名模式自动添加的标志。
- `CS_ADHOC` 由当前签名模式锁定管理；`CS_VALID` 和其他系统状态/特权标志不开放伪造入口。
- `CS_GET_TASK_ALLOW` 只是 CodeDirectory 位；若应用没有匹配 Entitlement，不能仅凭该位获得调试权限。
- 不建议为普通第三方应用开启 `CS_HARD`、`CS_KILL`、`CS_RESTRICT`、`CS_ENFORCEMENT`、`CS_REQUIRE_LV` 或 `CS_RUNTIME`，除非已在目标 iOS 版本和实际二进制上验证。
- 目前安装流程没有可靠的底层阶段百分比回调，因此三球动画表示“正在处理”，不会显示虚构的百分比。若要显示真实进度，需要给解包、签名、注入、复制和注册阶段增加可验证的进度回调。

## 后续可优化项

1. 在 ldid 增加结构化的 flags 回显/验证接口，安装后重新读取 CodeDirectory，核对最终标志是否与配置一致。
2. 按二进制类型和签名模式定义“必需标志策略”，由后端锁定必需项，而不是仅依赖 UI。
3. 在签名前对互斥/不兼容组合进行预检，并明确提示可能导致启动失败的标志。
4. 增加安装阶段回调，分别报告解包、Mach-O 分析、签名、插件注入、文件复制和注册进度。

