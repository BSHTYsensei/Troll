# TrollStore Swift SDK / Shortcuts 安全边界 / 视频 UI 对照（2026-11-01）

## 一、Swift 编译错误根因

GitHub Actions 日志显示，TrollStore 目标使用 Swift 6.1.2 编译器，而保存在 `iPhoneOS16.5.sdk` 中的 `SwiftUI.swiftinterface` 是由 Apple Swift 5.8 编译的。错误发生在导入系统 SwiftUI / `_AppIntents_UIKit` 模块阶段，不是 `TSRefreshAppRegistrationsIntent.swift` 的业务代码语法错误。

仅传入 `-swift-version 5` 不会把 Swift 6.1.2 编译器变成 Swift 5.8，也不应通过篡改 SDK 的 `.swiftinterface` 绕过兼容性检查。

## 二、本轮工具链修复

1. 保留当前补丁版 `iPhoneOS16.5.sdk`，不替换 SDK、不删除私有 Framework 接口。
2. 新增 `Scripts/bootstrap_swift_5_8_toolchain.sh`，检查 SDK 内 SwiftUI textual interface 的编译器版本标记确实属于 Swift 5.8。
3. 若缺少独立 Swift 5.8.1 toolchain，则从 Swift.org 官方地址下载 macOS 安装包。
4. 安装前使用 `pkgutil --check-signature` 校验签名，要求签发者为 `Developer ID Installer: Swift Open Source (V9AUD2URP3)`，并要求系统报告证书受信任。
5. 仅对 TrollStore Swift target 通过 Theos `TARGET_SWIFTC` 指定 Swift 5.8.1。Xcode 自带 Swift 仍用于 Theos 主机工具构建和 `appintentsmetadataprocessor`。
6. 不全局修改 `TOOLCHAINS`、`DEVELOPER_DIR` 或 `xcode-select`，避免影响 Clang、签名工具和其他 targets。
7. Swift 目标保留 `SWIFT_OPTFLAG = -O -whole-module-optimization` 与 `-emit-const-values-path`，没有为绕过 SDK 错误而移除 App Intents 编译元数据。

下一次 macOS CI 必须验证 Swift 5.8.1 能成功导入 SDK 的 SwiftUI/AppIntents 模块，以及 Xcode 当前版本的 App Intents metadata processor 能读取该目标生成的常量文件。当前容器不是 macOS，不能在此处声称真实 Apple SDK 编译通过。

## 三、Shortcuts.app 永远不作为 Persistence Helper 注入目标

- `TSSettingsListController` 的系统 App 候选枚举跳过 `com.apple.shortcuts`。
- RootHelper 的 `install-persistence-helper` 特权命令再次检查 Bundle ID；直接传入 `com.apple.shortcuts` 时记录拒绝原因并返回 `EPERM`。
- `Refresh Apps` App Intent / App Shortcut 归 TrollStore 主 App 所有。它只调用 RootHelper 的窄 `refresh` 命令，不调用 `refresh-all`、不 respring，也不需要打开 Persistence Helper。
- `ShortcutsLink()` 是嵌入设置页的 SwiftUI 入口，用于跳转到 TrollStore 在 Apple Shortcuts 中的 App Shortcuts 页面。用户可以继续正常使用 Shortcuts.app，添加 TrollStore 自己的刷新动作，并在其中创建自动化；Shortcuts.app 不被替换、改造、注入或占用。

## 四、视频 UI 对照结果

参考图：`Previews/TrollStore-UI-Video-Reference-Preview-2026-11-01.png`。该图由用户存储录屏的真实画面帧组成，不是假装由 iOS Simulator 重新运行新代码得到的截图。

| 对照项 | 录屏参考 | 当前源码 | 结果 |
|---|---|---|---|
| 根导航 | 应用 / 安装包 / 插件 / 设置 | 四个同序根导航 | 一致 |
| 应用页标题 | 左对齐大标题 | Apps Navigation 使用 Large Titles | 一致 |
| 设置页标题 | 紧凑居中标题 | Settings Navigation 关闭 Large Titles | 一致 |
| 底部 Dock | 半透明圆角胶囊，图标在文字上方 | `UIVisualEffectView` + 四项 `UIStackView` | 一致 |
| Dock 尺寸 | 约 64pt 高，最大宽度约 440pt | 默认 64pt / 最大 440pt | 一致 |
| 应用过滤 | 全部 / 用户 / 巨魔 / 系统 | 四分类保留 | 一致 |
| 右上角操作 | 一个蓝色加号 | 只显示加号；网格切换移入其菜单 | 视觉一致，功能保留 |
| 外观 | 深色背景、蓝色强调 | 首次启动默认深色，已保存的主题优先 | 一致 |
| 设置卡片 | 深色分组圆角卡片 | 保留系统分组色与圆角卡片 | 一致 |

### 预览范围说明

预览板用于直观看录屏中的目标布局及核对源码设置。由于本环境没有 Xcode/UIKit Simulator，不能把它宣称为新版本运行时截图。下一次 CI 编译成功后，仍应在目标设备或 Simulator 上捕获新构建画面，与此预览进行最终像素级检查。

## 五、验证结果

已在当前项目副本执行 `make validate-project`：

- 103 个必需文件存在。
- 6 个 plist 和 4 个 strings 资源格式检查通过。
- 639 个简体中文键一致，其中 631 个值包含中文字符。
- Theos Swift support 缓存缺失恢复模拟测试通过。
- fastPathSign per-slice 签名、Universal 重建和 Framework 包装回归通过。
- 预编译 iOS arm64 `bin/ldid` 架构与文件校验通过，未替换或修改该二进制。
- 编译期静态审计确认 Shortcuts.app 同时被候选 UI 和 RootHelper 特权命令阻止。
- UI 对照验证确认应用大标题、设置紧凑标题、加号菜单、浮动 Dock 和深色默认设置。

## 六、官方技术依据

- Apple Xcode / Swift 版本表：Xcode 14.3.1 对应 Swift 5.8.1。
- Swift.org macOS package installer：工具链安装到用户 `~/Library/Developer/Toolchains/`，安装包由 Swift Open Source Developer ID 签名。
- Theos variables：`TARGET_SWIFTC` 用于指定目标 Swift 编译器。
- Apple App Shortcuts 文档：App Shortcut 由应用自己的 `AppShortcutsProvider` / `AppIntent` 声明，并可通过 `ShortcutsLink` 打开当前 App 的 Shortcuts 页面。

外部参考：
- https://developer.apple.com/support/xcode/
- https://www.swift.org/install/macos/package_installer/
- https://theos.dev/docs/variables
- https://developer.apple.com/documentation/appintents/app-shortcuts
- https://developer.apple.com/documentation/appintents/shortcutsuibutton


## 2026-11-01 Swift 工具链签名状态误判补充

新版 macOS 的 `pkgutil --check-signature` 可能返回 `signed by a developer certificate issued by Apple for distribution`，而不是旧脚本硬编码的 `signed by a certificate trusted by Mac OS X`。当前引导脚本已兼容两者及 macOS 文案变体，但始终要求 `Developer ID Installer: Swift Open Source (V9AUD2URP3)` 完全匹配；不接受无签名、撤销或其他签名身份。`Scripts/test_swift_pkg_signature.sh` 已进入 `make validate-project`。未关闭签名验证或使用不受信任安装选项。

## 2026-11-01 后续修正

- 使用 `ShortcutsLink()` + `UIHostingController`；不再依赖 `ShortcutsUIButton`。
- TrollStore/ad-hoc 模式不再显示模板选择器，固定使用内部 SHA-256 / 4 jobs；仅 Real CMS Signing 保留模板。
