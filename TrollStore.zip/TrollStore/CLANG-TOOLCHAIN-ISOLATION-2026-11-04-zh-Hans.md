# TrollStore：修复 Swift 5.8.1 Clang 头文件路径污染

日期：2026-11-04

## 日志中的根因线索

本次 GitHub Actions 日志在编译 `main.m`、`TSAppCollectionViewController.m` 时，显示 `stdatomic.h` 是从以下目录加载的：

`swift-5.8.1-RELEASE.xctoolchain/usr/lib/swift/clang/include`

随后该目录中的头文件引用 `__stddef_max_align_t.h` 失败，Darwin、CoreFoundation、Foundation、UIKit 等模块无法构建。这些模块错误属于同一个头文件搜索路径问题的连锁反应，不是 22 个独立源码错误。

日志能够证明 Swift.org toolchain 的 Clang include 目录进入了 Objective-C 编译器的搜索路径，但仅凭当前日志无法断定究竟是哪一个环境变量注入了该目录。因此修复覆盖 Clang 官方支持的全部五种环境变量，而不是猜测某一个变量：

- `CPATH`
- `C_INCLUDE_PATH`
- `CPLUS_INCLUDE_PATH`
- `OBJC_INCLUDE_PATH`
- `OBJCPLUS_INCLUDE_PATH`

## 已实施的修复

1. 新增 `Scripts/clang-include-env.mk`，通过 GNU Make `unexport` 阻止上述五个进程级 include 路径变量进入编译器 recipe 环境。
2. 根 `Makefile` 加载该保护片段，覆盖从项目根目录启动的构建和递归子构建。
3. `Scripts/xcode-clang.mk` 加载相同保护片段，并继续通过 `override TARGET_CC/TARGET_CXX` 固定 Theos C/Objective-C/C++ 编译器为当前 Xcode 的 `XcodeDefault.xctoolchain/usr/bin/clang{,++}`。
4. `Exploits/fastPathSign/Makefile` 也加载相同片段，防止独立构建 macOS host 工具时受到外部 Clang include 路径污染。
5. 根 `check-build-tools` 使用 Xcode Clang 的 `-print-resource-dir` 查询真实 builtin headers 目录，并在编译前检查 `stdatomic.h` 与 `__stddef_max_align_t.h` 均存在。
6. 扩展 `Scripts/test_xcode_clang_isolation.sh`：在模拟的 Swift 5.8.1 include 目录下同时设置上述五个变量，验证 XcodeDefault 编译器选择正确，并验证这些变量不会泄漏给编译 recipe。
7. 更新 `Scripts/validate_project.py`，把共享 include 环境保护片段及其入口纳入项目完整性审计。

## 保留的构建配置

- TrollStore Swift/App Intents 仍使用 Swift 5.8.1 的绝对路径 `TARGET_SWIFTC`。
- 普通 Objective-C/C/C++ 继续使用 XcodeDefault Clang。
- iPhoneOS 16.5 SDK 未被修改，未复制任何内部头文件。
- 没有关闭 Clang Modules，也没有降低编译错误级别。
- 项目专属第三方头文件目录仍由 Makefile 中的 `*_CFLAGS` 显式传递。
- fastPathSign 继续使用 macOS SDK sysroot，不会混用 iPhoneOS SDK。

## 已完成的验证

执行 `make validate-project LDID_BIN=bin/ldid` 成功，包含：

- Xcode Clang 选择及五种 include 环境变量隔离测试通过。
- fastPathSign macOS host SDK 参数测试通过。
- Theos Swift-support 缓存恢复模拟测试通过。
- Swift.org package 签名解析测试通过：3 种可信状态接受、4 种不可信状态拒绝。
- 项目审计：110 个必需文件存在。
- 6 个 plist、4 个 strings 资源验证通过。
- 简体中文：638 个键匹配，630 个译值含中文。
- fastPathSign 分片签名、Universal 重建、Framework 包装测试通过。
- `bin/ldid` arm64 Mach-O 完整性验证通过，原始预编译 ldid 未修改。

## 尚未验证的边界

当前环境不是 macOS/Xcode Runner，不能在这里执行真正的 iPhoneOS 16.5 SDK + Xcode Clang + Swift 5.8.1 全量 Theos 编译。因此不能声称 GitHub Actions 已经构建成功。下一次 CI 应确认：

- Objective-C 命令使用 XcodeDefault `clang`。
- `stdatomic.h` 不再来自 Swift.org `usr/lib/swift/clang/include`。
- Xcode Clang builtin headers 能正常解析 `__stddef_max_align_t.h`。
- Swift 源码仍由 Swift 5.8.1 编译，App Intents 元数据步骤仍执行。

如果同一错误仍出现，应启用 Theos 详细构建日志检查实际 clang 命令中是否显式带有指向 Swift.org toolchain 的 `-I`、`-isystem` 或 `-resource-dir`。当前日志没有提供完整编译命令，不能排除 `.theosrc` 或 CI workflow 额外注入命令行参数的可能性。
