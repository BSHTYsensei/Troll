# TrollStore iOS 16+ 全量静态审计与 CI 修复报告

日期：2026-10-31  
基线：文件库中的 `TrollStore-Real-Signing-iOS16-CI-Fixed.zip`（version 3）  
本轮产物：在原包上修复 iOS Mach VM API、补充嵌入式 Helper 框架链接，并扩展静态回归检查。

## 1. 本次编译错误修复

原错误：

```text
mach_vm.h unsupported
call to undeclared function 'mach_vm_read_overwrite'
```

原因：iOS SDK 不支持 `mach/mach_vm.h`。iOS SDK 的 `mach/vm_map.h` 提供 `vm_read_overwrite`，其接口使用 `vm_address_t`、`vm_size_t` 和 `vm_size_t *outsize`。

修改 `RootHelper/TSAppDecryptor.m`：

- 删除 `#import <mach/mach_vm.h>`。
- 改用 `#import <mach/vm_map.h>`。
- 将 `mach_vm_address_t` 改为 `vm_address_t`。
- 将 `mach_vm_size_t` 改为 `vm_size_t`。
- 将 `mach_vm_read_overwrite` 改为 `vm_read_overwrite`。
- 对读入长度、缓冲区地址作显式类型转换。
- 不添加手工函数声明，不伪造兼容头文件。

两处远程内存读取（远程 C 字符串和 Mach-O 数据块）均已切换到 iOS SDK 接口。进程枚举仍使用 `sysctl` / `KERN_PROC_ALL` / `KERN_PROCARGS2`，没有重新引入 macOS `libproc`。

API 参考：Apple Developer Documentation — `vm_read_overwrite`：
https://developer.apple.com/documentation/kernel/1585371-vm_read_overwrite

## 2. 额外发现并修复

`TrollHelper/Makefile` 将 `RootHelper/*.m` 编入 `TrollStorePersistenceHelper`（`EMBEDDED_ROOT_HELPER=1`），但该 Helper 的 Frameworks 列表缺少 `Security`。`RootHelper/main.m` 与共用代码包含 Security.framework 类型/调用，因此本轮将 `Security` 加入 `TrollStorePersistenceHelper_FRAMEWORKS`，并把该要求加入 `Scripts/validate_project.py` 回归检查。

没有把 ChOma / OpenSSL / fastPathSign 硬塞进 embedded helper：`RootHelper/main.m` 在 `EMBEDDED_ROOT_HELPER` 模式下有专门的预处理分支，签名实现被排除；ChOma 仍只由独立 RootHelper 与 fastPathSign 构建目标使用。这避免无谓链接依赖。

## 3. 全工程检查范围

本轮检查的归档解压结果：

- 173 个文件。
- 85 个源码/头文件：41 个 Objective-C `.m`、2 个 C/C++ 实现文件、42 个头文件。
- 工程要求的 80 个关键文件由项目验证脚本逐项检查。
- 6 份 plist、4 份 `.strings` 资源。
- 简体中文本地化 490 个匹配键，其中 482 个翻译值包含中文字符。

检查了：

- Root Makefile 的 bootstrap、host tools、presets、RootHelper、TrollStore、TrollHelper 构建顺序。
- 五个 iOS Theos 子目标的 iOS 16.0 deployment target。
- 两个 Tweak preset 的 host `/usr/bin/codesign` 配置，避免在 macOS Runner 上执行 iOS arm64 `bin/ldid`。
- `BackgroundAssist` 后台任务句柄零初始化与 active flag 生命周期。
- RootHelper 的 Darwin 进程枚举和 Mach VM 头文件/API。
- TrollHelper embedded RootHelper 的 Frameworks 声明。
- 内置 ldid 架构、Mach-O 平台/最低系统版本和 SHA-256。
- plist、strings、本地化键、资源/文件布局与 ZIP 完整性。

## 4. 自动验证结果

通过：

- `python3 -m py_compile Scripts/*.py`
- `python3 Scripts/validate_project.py`：80 项关键文件、6 份 plist、4 份 strings、490 个简体中文键及项目静态断言通过。
- `python3 Scripts/validate_macho.py bin/ldid`：内置二进制验证通过。
- `bash -n Scripts/bootstrap_choma.sh`
- ZIP 完整性测试（`unzip -t`）。
- `bin/ldid` 执行权限仍为 `755`，文件大小 `8,448,488` 字节。
- `bin/ldid` SHA-256 仍为：`d23eb53e6c5b07f5cae72f0e93ab1b87214aa68ed4a59bc32286f8b15cb8b769`。
- 运行时代码中不再引用 `mach/mach_vm.h`、`mach_vm_read_overwrite`、`mach_vm_address_t` 或 `mach_vm_size_t`；验证脚本中保留这些字符串作为反向回归断言。

## 5. 尚未完成的验证与环境限制

本次执行环境是 Linux x86_64，只有通用 Clang 17，没有 `xcrun`、`xcodebuild`、Xcode iPhoneOS SDK 或 Theos。因此：

- 没有声称完成 Objective-C 对 iPhoneOS16.5 SDK 的真实编译。
- 没有声称完成 Theos 全量链接、IPA/TAR 产物组装或真机安装测试。
- 当前 ZIP 未包含 ChOma 子模块实体；`.gitmodules` 指向上游仓库，`Scripts/bootstrap_choma.sh` 会在 CI 下载固定提交 `964023ddac2286ef8e843f90df64d44ac6a673df`。本地无法执行 `validate_choma_api.py`，因为 ChOma 目录尚未 bootstrap。
- 本 ZIP 的 `.github` 目录只有 issue template，没有 workflow 文件；GitHub Actions workflow 必须由实际仓库提供。
- `task_for_pid` 是否能读取目标进程内存仍取决于设备版本、helper 权限和运行时策略，需在越狱设备实测。

因此本轮结果是完成全工程静态审计并修复当前 SDK 编译错误，不是对真实 macOS/Xcode CI 或设备行为的虚假通过声明。


## 第十轮签名链补充（2026-10-31）

旧版审计记录中关于两个 preset 使用 `/usr/bin/codesign` 的结论已被本轮修复取代。当前 `TrollStore`、`RootHelper`、`TrollHelper` 通过 `TARGET_CODESIGN` 使用 `fastPathSign` 主机签名器；两个 arm64+arm64e 预设通过 `fastpath_sign_all_slices.py` 分别签署各薄切片并由 `lipo` 重建 universal 文件，避免底层 CoreTrust 流程覆盖丢失架构；打包进 app 的 ldid 副本也由 `fastPathSign` 签名，原始 `bin/ldid` 文件保持哈希不变。

构建脚本现在先清理两个 preset 的旧产物，再从 Theos 对象目录中挑选同时含 arm64 与 arm64e 且具有嵌入 CodeDirectory 的最终通用 Mach-O；最终组装时再次检查 app、两个 helper、ldid 副本和两个 preset。`validate_macho_signature.py` 只检查嵌入签名结构存在及边界，不代替 iOS/macOS 的完整信任策略验证。

本轮 Linux 容器验证通过 `make validate-project`、Python 语法检查、签名解析器的正反合成 Mach-O 测试，以及提供的 `bin/ldid` 原始哈希/架构检查。没有在本环境运行真实 macOS + Theos + iPhoneOS SDK 构建或设备签名验证。
