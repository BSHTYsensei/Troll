# Objective-C UTType 编译错误修复（2026-11-26）

## 问题

Theos iPhoneOS 16.5 SDK 编译 `TSAppRepackager.m` 时报告 `UTType.png` 不存在。上轮把 Swift 的 `UTType.png` / `UTType.jpeg` 成员写法直接用于 Objective-C，语言绑定不匹配。

## 修复

在以下两个 Objective-C 文件中统一改为 UniformTypeIdentifiers 提供的全局常量：

- `TrollStore/TSAppRepackager.m`
- `TrollStore/TSSettingsListController.m`

```objc
NSArray<UTType *> *contentTypes = @[UTTypePNG, UTTypeJPEG];
UIDocumentPickerViewController *picker =
    [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:contentTypes asCopy:YES];
```

保留 iOS 14+ 的 `initForOpeningContentTypes:asCopy:`，不恢复已弃用的 `initWithDocumentTypes:inMode:`。

## 验证

- 新增/更新 `test_package_editor_regressions.py`，验证两个调用点使用 `UTTypePNG` / `UTTypeJPEG`，并禁止 Swift 风格的 `UTType.png` / `UTType.jpeg` 出现在 Objective-C 源文件。
- `make validate-project` 完成全部本地静态、资源、签名导入、文件协调、IPA 编辑和 ldid 校验。
- 当前环境没有 Apple SDK / xcodebuild，因此未声称已完成设备目标的完整编译。
