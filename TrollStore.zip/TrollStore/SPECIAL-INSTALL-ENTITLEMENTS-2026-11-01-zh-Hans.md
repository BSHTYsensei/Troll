# TrollStore 特殊安装与 Entitlements 编辑修订报告

**日期：2026-11-01**  
**基线：** Library 中保存的 `TrollStore-InstallSign-Shortcuts-Framework-Optimized-2026-11-01.zip`  
**原则：** 保留此前的快捷指令、安装/签名加速、installd/Custom、Framework 插件、导入管理、证书签名、重打包、维护、脱壳和 UI 功能；只替换本轮明确要求调整的旧防卸载入口和 Entitlements 编辑实现。

## 1. 旧防卸载 Tweak 已移除

- 旧的 `TweakPresets/PreventUninstall` 预设目录不再存在；`TSTweakInjector` 不再把防删除做成 Tweak 注入选项。
- 应用锁、后台任务辅助等其他 Framework 预设及 `.dylib` 兼容没有删除。

## 2. Advanced 中增加特殊安装保护

设置位置：**Settings → Advanced → Special Installation → Make app undeletable from Home Screen**。默认关闭。

开启后，本次安装/通过 TrollStore 更新的目标 App 会在其 MCM App Bundle Container 根目录写入 `_TrollStoreNonDeletable` 标记；标记不在可替换的 `.app` 目录内部，因此正常 App 更新不会清除它。RootHelper 的 Launch Services 注册路径读取该标记，并对这个 App 注册 `IsDeletable = false`。

- 该功能按 App 生效，不是全设备 MDM 禁止删除策略，也不需要注入 Tweak。
- 受保护 App 仍可由 TrollStore 内部应用管理/卸载操作移除；卸载容器时标记一起清理。
- 关闭开关影响后续安装/更新，不会回溯移除已安装 App 的标记；需要取消既有保护时，使用 TrollStore 内部卸载后重新安装。
- Launch Services 的 `IsDeletable` 属于 TrollStore 使用的私有注册元数据，iOS 版本间可能变化，必须在目标 iOS 版本真机验证。

## 3. Entitlements 编辑开关和完整事务

设置位置：**Settings → Entitlements Editor → Edit Entitlements Before Install**。默认关闭。

开启后的流程：

1. 用户选择 IPA 后，先从该 IPA 的主可执行文件中提取原始 Entitlements。编辑器以完整原始字典作为 XML/Visual 文档初始值，并可查看各嵌套二进制原始 Entitlements。
2. 用户可编辑值、添加/删除键，或重置为 IPA 原文档。预览显示的是最终主应用字典。
3. 点击 **Cancel**：关闭编辑器并取消本次安装事务，返回原页面；不会显示安装确认，也不会启动 RootHelper。
4. 点击 **Done**：校验 XML plist 根类型必须是字典，生成本次安装专属临时 plist，然后强制显示正常安装确认；用户再点 Install 才继续。
5. 安装重试沿用同一份临时 plist；成功、失败、安装确认取消、插件选择取消或重打包取消后清理该临时文件。

最终签名语义是**主应用 Entitlements 整份替换**：用户删除的键不会保留，空字典也作为显式输入签名。App Extension 使用各自原始 Entitlements，不会被主 App 的编辑文档覆盖。

### 签名模板兼容性修正

此前的配置模板会默认设置 `preserveEntitlements=true` 和 `mergeDeep=true`。即使 RootHelper 只传 `-S <plist>`，这些 profile 默认仍可能使 ldid 把输入文档合并到原始签名字典中，导致被用户删除的键复活。

现在 RootHelper 对主可执行文件单独创建一次性 ldid JSON 配置副本：复制原有 `defaults` 和当前选中的 `profile`，将 `preserveEntitlements`、`mergeOnly`、`mergeDeep` 设为 false，并删除 `mergeEntitlements`；证书/私钥路径、密码引用、Team ID、hash、jobs 等其他配置保持不变。临时 JSON 配置权限为 0600，签名后删除。

这条路径仅使用已支持的 `--config` / `--profile` 选项，因此不要求替换用户提供的预编译 `bin/ldid`，也没有修改该二进制内容。正常未编辑 Entitlements 的签名仍沿用原模板 preserve/merge 行为。

## 4. API 和实现边界

- `TSApplicationsManager` 的会话参数更名为 `replaceMainEntitlements`，避免旧的 `preserveEntitlementsOverride` 名称继续暗示“合并保留”。
- RootHelper 在并发签名任务中显式标记主可执行文件的替换行为；串行和并发 worker 使用相同参数。
- 真实 CMS 签名/ad-hoc 签名均传入明确的 plist；模板副本只影响本次主二进制签名，不影响其他二进制或后续安装。
- 自动追加 `container-required` 和 TrollStore Lite 的兼容 Entitlement 不会修改用户明确编辑的主应用字典。

## 5. 验证

本轮静态校验结果：

- `python3 Scripts/validate_project.py`：通过，99 个必需文件存在；6 个 plist 和 4 个 strings 资源通过格式校验；638 个简体中文键匹配，630 个翻译值含中文。
- `python3 Scripts/test_fastpath_sign_pipeline.py`：通过，覆盖分 slice 签名、arm64/arm64e universal 重建和 Framework 包装。
- `python3 -m py_compile Scripts/*.py`、`bash -n Scripts/bootstrap_choma.sh`：通过。
- `sha256sum -c bin/ldid.sha256`：通过；原始预编译 ldid 未更换。
- `python3 Scripts/validate_macho.py bin/ldid`：确认其为 arm64 iOS Mach-O，8,448,488 bytes。

**未完成：** 当前环境不是 macOS，未运行 Xcode/Theos 编译，也未在 iPhone 上验证 Launch Services 删除状态、安装确认交互、签名结果或快捷指令自动化。`IsDeletable` 是私有注册元数据，必须通过目标设备测试才能确认最终 iOS 行为。
