# TrollStore / TrollInstallerX 编译与持久化助手审查报告

日期：2026-11-26

## 1. 本轮修复的编译问题

### UIDocumentPicker 弃用 API

原日志指向 `TrollStore/TSAppRepackager.m`，但全仓库扫描还找到第二处同样会触发 `-Werror` 的调用：`TrollStore/TSSettingsListController.m` 的自定义图标导入入口。

两处都已改为 iOS 14+ API：

- `UniformTypeIdentifiers` 的 `UTType.png` / `UTType.jpeg`
- `initForOpeningContentTypes:asCopy:YES`
- TrollStore target 的 `UniformTypeIdentifiers` framework 已链接
- 回归脚本现在扫描全部 Objective-C/Objective-C++ 源码，防止旧的 `initWithDocumentTypes:inMode:` 或 `UIDocumentPickerModeImport` 再次进入代码

### TrollInstallerX 源码根目录探测

当前安装器源码采用“编译时不嵌入 TrollStore.tar、运行时从 Files 导入”的布局，因此没有 `Resources/TrollStore.tar` 是有意设计，不是文件漏打包。

已增加 `Scripts/validate_custom_installer_root.py`，并让 `build.sh` 调用它。安装器自身的 `validate_custom_payload.py` 在没有 tar 时会验证运行时导入契约；提供真实 tar 时仍会做哈希与内容验证。

**仍需同步修改外部 CI 工作流：** 发出 `Expected exactly one custom TrollInstallerX source root ... and embedded payload` 的 root finder 不在本次 ZIP 的源码中，因此 ZIP 内无法改写它。请删除该工作流强制要求嵌入 tar 的旧判断，并替换为：

```bash
cd TrollInstallerX
python3 Scripts/validate_custom_installer_root.py .
python3 Scripts/validate_custom_payload.py
./build.sh
```

不要创建空的或占位 `TrollStore.tar` 来骗过扫描。那样既不能安装，也会破坏运行时哈希校验。

## 2. 持久化助手检查与修复

### 直接安装路径（RootHelper）

检查了系统宿主选择、原始主可执行文件备份、持久化标记、PersistenceHelper 与 `trollstorehelper` 的替换、文件权限、回滚和卸载恢复路径。

当前逻辑会检查标记、主可执行文件、RootHelper、备份文件以及 arm64 Mach-O 头；不再仅凭一个 marker 就报告“已安装”。首次安装完成后还会做健康状态后置检查，失败则尝试恢复原可执行文件。用户态注册的修复助手不再被误认为系统持久化宿主。

### 间接安装路径（TrollInstallerX vnode）

修正了原先失败清理路径的高风险问题：如果 vnode 解映射失败，旧清理逻辑仍可能删除临时 `mount` 路径；而该路径此时可能还映射到系统 App 容器。

现在：

- 每次重定向前，在 mount 的同级目录写入 boot-session 恢复标记。
- 标记记录 boot-session identifier、原始/目标 `v_data`（十六进制字符串）以及目标目录原始 UID/GID。
- 解映射前核对 boot session、`v_data` 指针；先恢复原 UID/GID，再恢复 vnode 映射，并分别做 read-back 验证。
- 标记只在映射和权限都确认恢复后清除。
- 进程异常退出后，如果仍在同一次启动，扫描/安装会拒绝继续，清理函数也不会删除工作目录；提示重启后再试。
- 只有确认 boot session 已改变，才会清理过期恢复标记。
- 宿主选择仍核对 Bundle ID；拒绝软链接主可执行文件；校验持久化 helper 与 root helper 是 arm64 Mach-O 可执行文件，并核对备份与 marker。

## 3. 使用持久化助手时的预期流程

间接安装成功后，需要打开被选中的系统宿主 App，让其中的 Persistence Helper 页面继续完成安装/修复。若 TrollStore 显示无法打开，官方 TrollInstallerX 使用说明建议在 Persistence Helper 中刷新 App registrations；间接安装遇到失败时，官方说明也建议重启后重试，必要时换一个宿主 App：

https://github.com/alfiecg24/TrollInstallerX/blob/main/README.md

直接安装和间接安装受设备芯片、iOS 版本与可用 exploit 路径影响，不是每台设备都使用同一条路径。

## 4. 已执行的本地检查

通过：

- `make validate-project`（TrollStore）
- 112 项工程文件、资源与 plist/string 检查
- 953 个简体中文资源键匹配检查
- RootHelper 预处理器嵌套与安装回滚范围检查
- 证书导入、File Provider / NSFileCoordinator、签名流水线回归
- IPA 编辑、自定义图标、应用包图标解析和解密输出校验回归
- 全仓库旧 DocumentPicker API 扫描：无弃用调用残留
- TrollInstallerX source-root、runtime payload、Persistence Helper / vnode recovery 与 UI crash guard 回归
- `bash -n build.sh`
- TrollStore 与 TrollInstallerX 所有 Swift 文件的 `swiftc -frontend -parse`

## 5. 未能在当前环境完成的验证

当前运行环境没有 `xcodebuild`、`xcrun` 和 Apple iOS SDK。因此这里没有完成真正的 iOS 编译、代码签名、设备安装、Persistence Helper 宿主启动、respring 或真机回滚测试。

所以本报告能确认的是源码级路径、静态约束和可执行回归脚本通过；**不能把它表述为持久化助手已经在真机验证可正常启动**。vnode 相关代码尤其需要在目标 iOS 版本与设备上验证 exploit / kernel layout 的兼容性。
