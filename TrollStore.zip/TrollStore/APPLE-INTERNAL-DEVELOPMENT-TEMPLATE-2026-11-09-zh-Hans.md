# Apple Internal Development 签名模板

## 这是什么

这是给带有 Apple 内部 Profile 标记的真实签名材料使用的严格签名策略，不是普通 Apple Development、Enterprise 或 Ad Hoc 的别名。模板检查 `.mobileprovision` 中的布尔值 `AppleInternalProfile = true`，并在签名后验证 Profile CMS 数学签名、配置的签名者证书链、Team ID / Bundle ID、Profile Entitlements 白名单、DeveloperCertificates 与 App CMS 签名者的指纹关系。

它不生成 Apple 内部证书、私钥、Profile、Entitlements 或系统平台信任，也不保证普通设备会接受 Apple 内部应用。

## 描述文件要求

1. 必须是 Apple 签发的 CMS 签名 `.mobileprovision`，不能使用手工创建或编辑后重新打包的 plist。修改签名载荷会破坏 CMS 完整性。
2. Profile 必须包含真正的布尔值 `AppleInternalProfile = true`，而不是字符串 `"true"`。
3. Profile 必须未过期，包含 `TeamIdentifier`、`Entitlements.application-identifier` 和 `DeveloperCertificates`。
4. 当前导入的签名证书必须以完全相同的 DER 证书出现在 `DeveloperCertificates`。
5. Profile 的 Team ID、App ID 和 Entitlements 授权范围必须覆盖目标 App。签名器不会自行添加 Profile 未授权的权限。
6. Apple Internal CMS/证书链必须能验证到受信任根。模板默认强制证书链和根证书校验；当前 TrollStore 界面没有提供自定义 CA 根证书导入入口，因此该根必须已存在于随包 ldid/OpenSSL 可读取的信任来源中。若私有根不在信任来源内，签名会失败关闭；不能把描述文件本身或其中任意证书自动提升为信任根，也不能关闭校验来绕过。
7. 每个 `.appex` 都是独立签名单元，必须预先包含自己的 Apple Internal `.mobileprovision`，且它的证书、Team ID、Bundle ID 和权限要与该扩展匹配。主 App 的 Profile 不会复制到扩展。

普通公开 Apple Developer 账户通常不会获得 Apple Internal Profile 或内部签名身份。普通 Development Profile、Enterprise Profile 和 Ad Hoc Profile 都不能通过更改 plist 转换成 Apple Internal Profile。

## 实际调用

TrollStore 在选中此模板时，RootHelper 调用随包提供的 `ldid --signature-apply` Apple Internal 策略实现，并以当前 P12 或 PEM 证书/私钥签名。此流程与常规 `ldidrc` Profile 不同；不会降级到 ad-hoc 签名。若材料缺失、Profile 不符合标记、证书不匹配或证书链不受信任，签名会失败关闭。

## 工程构建

`RootHelper/Makefile` 只编译 `Shared/TSUtil.m`，不再将 UI 专用 `Shared/TSListControllerShared.m` 编入命令行 Helper。顶层构建在 RootHelper 编译前执行 Theos clean，以避免旧 `.theos` 对象文件残留后参与链接。
