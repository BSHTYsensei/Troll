# Optional built-in tweak presets

- `TSAppLock.dylib`: app-local Face ID / Touch ID / passcode lock overlay. It protects access to the injected app only.
- `TSBackgroundAssist.dylib`: requests iOS's documented finite `beginBackgroundTask` allowance. It does not force permanent background execution.
- `PreventUninstall/README.md`: explains why uninstall prevention cannot be implemented as a target-app dylib; requires MDM supervision or a SpringBoard jailbreak tweak.

Root `make` builds the first two presets with Theos and copies the generated device dylibs into `TrollStore/Resources/TweakPresets`, so they are embedded in the app and can be injected from the “Built-in Presets” picker. This environment does not have Theos/iPhoneOS SDK, so no misleading precompiled preset binaries are included in the source archive.

Build compatibility: all TrollStore app/helper/preset targets use an iOS 16.0 deployment minimum. The preset Makefiles use the same macOS host `Exploits/fastPathSign/fastPathSign` pipeline as the main TrollStore targets. The build selects the final universal Theos dylib only after confirming that both arm64 and arm64e slices contain an embedded CodeDirectory. The supplied `bin/ldid` source remains byte-for-byte unchanged and is never put on the macOS Runner PATH or invoked as a host command. Its staged app-bundle copy is passed to `fastPathSign` so the device-side executable has an embedded signature before optional activation.
