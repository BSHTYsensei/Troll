# Built-in Tweak Presets

Theos builds each preset as a normal Mach-O dynamic library (`MH_DYLIB`) and the root build signs every architecture slice with the fastPathSign wrapper. After signing, `Scripts/package_framework_preset.py` places the unchanged signed executable in a conventional iOS `.framework` bundle with a small `Info.plist`.

The embedded resources are:

- `TSAppLock.framework/TSAppLock`
- `TSBackgroundAssist.framework/TSBackgroundAssist`

The executable inside a framework is still a dynamic library; the `.framework` is a bundle layout, not a different Mach-O file type. The framework wrapper makes metadata and executable discovery more predictable for the injector. The runtime injector continues to accept user-provided `.dylib` files and older `.dylib` presets for backward compatibility.

Framework packaging copies the already-signed Mach-O bytes without rewriting or re-signing them. The final app assembly validates each embedded executable's arm64 and arm64e signatures before producing the TrollStore archive.

These are app-local injection presets. They do not inject SpringBoard and do not grant privileges beyond the entitlements and execution capabilities already available to the hosting process. Home Screen deletion protection, when enabled in TrollStore's Advanced settings, is a separate per-app Launch Services registration option and is not a Tweak preset.
