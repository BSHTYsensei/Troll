#import <UIKit/UIKit.h>
#import <LocalAuthentication/LocalAuthentication.h>

// An app-local lock overlay. It protects entry into the injected app, not SpringBoard
// or other processes. Build/inject only into apps for which you have permission.
@interface TSAppLockActionProxy : NSObject
+ (instancetype)shared;
- (void)unlock;
@end

static UIView *TSLockOverlay;
static BOOL TSLockShowing = NO;
static BOOL TSLockAuthenticated = NO;
static NSString *TSLockText(NSString *english, NSString *chinese) {
    NSString *language = NSLocale.preferredLanguages.firstObject.lowercaseString ?: @"";
    return [language hasPrefix:@"zh"] ? chinese : english;
}

static UIWindow *TSLockWindow(void) {
    UIApplication *app = UIApplication.sharedApplication;
    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in app.connectedScenes) {
            if (![scene isKindOfClass:UIWindowScene.class] || scene.activationState != UISceneActivationStateForegroundActive) continue;
            for (UIWindow *window in ((UIWindowScene *)scene).windows) if (window.isKeyWindow && !window.hidden) return window;
        }
    }
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    for (UIWindow *window in app.windows) if (window.isKeyWindow && !window.hidden) return window;
#pragma clang diagnostic pop
    return nil;
}

static void TSLockRemoveOverlay(void) {
    [TSLockOverlay removeFromSuperview]; TSLockOverlay = nil; TSLockShowing = NO; TSLockAuthenticated = YES;
}

static void TSLockAuthenticate(void) {
    if (TSLockAuthenticated) { TSLockRemoveOverlay(); return; }
    LAContext *context = [LAContext new]; context.localizedFallbackTitle = TSLockText(@"Use Passcode", @"使用设备密码");
    NSError *error = nil;
    if (![context canEvaluatePolicy:LAPolicyDeviceOwnerAuthentication error:&error]) return;
    [context evaluatePolicy:LAPolicyDeviceOwnerAuthentication localizedReason:TSLockText(@"Unlock this application", @"解锁此应用") reply:^(BOOL success, NSError *authError) {
        dispatch_async(dispatch_get_main_queue(), ^{ if (success) TSLockRemoveOverlay(); else if (TSLockOverlay) TSLockOverlay.accessibilityHint = authError.localizedDescription ?: TSLockText(@"Authentication failed. Try again.", @"验证失败，请重试"); });
    }];
}

static void TSLockShow(void) {
    if (TSLockAuthenticated || TSLockShowing) return;
    if (UIApplication.sharedApplication.applicationState != UIApplicationStateActive) return;
    UIWindow *window = TSLockWindow(); if (!window) return;
    TSLockShowing = YES;
    UIView *overlay = [[UIView alloc] initWithFrame:window.bounds]; overlay.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight; overlay.backgroundColor = [UIColor colorWithWhite:0.035 alpha:1];
    UIVisualEffectView *blur = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemMaterialDark]]; blur.frame = overlay.bounds; blur.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight; [overlay addSubview:blur];
    UIImageView *icon = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"lock.fill"]]; icon.tintColor = UIColor.whiteColor; icon.contentMode = UIViewContentModeScaleAspectFit; icon.translatesAutoresizingMaskIntoConstraints = NO;
    UILabel *title = [UILabel new]; title.text = TSLockText(@"Application Locked", @"应用已锁定"); title.textColor = UIColor.whiteColor; title.font = [UIFont systemFontOfSize:24 weight:UIFontWeightBold]; title.textAlignment = NSTextAlignmentCenter; title.translatesAutoresizingMaskIntoConstraints = NO;
    UILabel *hint = [UILabel new]; hint.text = TSLockText(@"Authenticate to continue.", @"请验证身份后继续"); hint.textColor = UIColor.lightTextColor; hint.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody]; hint.textAlignment = NSTextAlignmentCenter; hint.translatesAutoresizingMaskIntoConstraints = NO;
    UIButton *unlock = [UIButton buttonWithType:UIButtonTypeSystem]; [unlock setTitle:TSLockText(@"Unlock", @"解锁") forState:UIControlStateNormal]; unlock.tintColor = UIColor.whiteColor; unlock.backgroundColor = [UIColor.systemBlueColor colorWithAlphaComponent:0.9]; unlock.layer.cornerRadius = 14; unlock.translatesAutoresizingMaskIntoConstraints = NO;
    // Avoid relying on a private app delegate or SpringBoard hook for the unlock action.
    [unlock addTarget:[TSAppLockActionProxy shared] action:@selector(unlock) forControlEvents:UIControlEventTouchUpInside];
    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[icon,title,hint,unlock]]; stack.axis = UILayoutConstraintAxisVertical; stack.alignment = UIStackViewAlignmentCenter; stack.spacing = 18; stack.translatesAutoresizingMaskIntoConstraints = NO; [overlay addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[[icon.widthAnchor constraintEqualToConstant:56],[icon.heightAnchor constraintEqualToConstant:56],[unlock.widthAnchor constraintEqualToConstant:220],[unlock.heightAnchor constraintEqualToConstant:50],[stack.centerXAnchor constraintEqualToAnchor:overlay.centerXAnchor],[stack.centerYAnchor constraintEqualToAnchor:overlay.centerYAnchor],[stack.leadingAnchor constraintGreaterThanOrEqualToAnchor:overlay.leadingAnchor constant:24],[stack.trailingAnchor constraintLessThanOrEqualToAnchor:overlay.trailingAnchor constant:-24]]];
    [window addSubview:overlay]; TSLockOverlay = overlay;
}

@implementation TSAppLockActionProxy
+ (instancetype)shared { static TSAppLockActionProxy *proxy; static dispatch_once_t once; dispatch_once(&once, ^{ proxy=[self new]; }); return proxy; }
- (void)unlock { TSLockAuthenticate(); }
@end

__attribute__((constructor)) static void TSAppLockInitialize(void) {
    @autoreleasepool {
        dispatch_async(dispatch_get_main_queue(), ^{
            [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidEnterBackgroundNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *note) { TSLockAuthenticated = NO; }];
            [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidBecomeActiveNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *note) { TSLockShow(); }];
            [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidFinishLaunchingNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *note) { TSLockShow(); }];
            TSLockShow();
        });
    }
}
