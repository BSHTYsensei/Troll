# Prevent Uninstall is not an app-injected dylib preset

A dylib loaded inside the target application cannot intercept the SpringBoard icon menu or the system's uninstall transaction: those run in other processes. Making an in-app button labelled “Prevent Uninstall” would be misleading and would not prevent removal.

Actual uninstall prevention requires either a supervised-device management restriction (MDM / `allowAppRemoval` policy) or a jailbreak tweak loaded into the SpringBoard process. This TrollStore application intentionally refuses to inject into protected system applications and does not install a SpringBoard-level jailbreak tweak. Therefore no fake `TSPreventUninstall.dylib` is shipped.
