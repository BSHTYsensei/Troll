#import <UIKit/UIKit.h>

// This preset asks iOS for its documented finite background execution allowance.
// It deliberately does not spoof audio/location use or attempt an infinite keepalive.
// Keep the identifier zero-initialized: UIBackgroundTaskInvalid is an SDK constant
// expression that is not valid as a file-scope initializer with every SDK/toolchain.
// The separate active flag makes the initial zero value unambiguous.
static UIBackgroundTaskIdentifier TSBackgroundTask;
static BOOL TSBackgroundTaskActive;

static void TSEndBackgroundTask(void) {
    if (!TSBackgroundTaskActive) return;

    [[UIApplication sharedApplication] endBackgroundTask:TSBackgroundTask];
    TSBackgroundTask = UIBackgroundTaskInvalid;
    TSBackgroundTaskActive = NO;
}

static void TSRequestBackgroundAllowance(void) {
    UIApplication *app = UIApplication.sharedApplication;
    if (app.applicationState != UIApplicationStateBackground || TSBackgroundTaskActive) return;

    UIBackgroundTaskIdentifier task = [app beginBackgroundTaskWithName:@"TSBackgroundAssist"
                                                     expirationHandler:^{
        dispatch_async(dispatch_get_main_queue(), ^{
            TSEndBackgroundTask();
        });
    }];

    if (task == UIBackgroundTaskInvalid) return;
    TSBackgroundTask = task;
    TSBackgroundTaskActive = YES;
}
__attribute__((constructor)) static void TSBackgroundAssistInitialize(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSNotificationCenter *center = NSNotificationCenter.defaultCenter;
        [center addObserverForName:UIApplicationDidEnterBackgroundNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *note) { TSRequestBackgroundAllowance(); }];
        [center addObserverForName:UIApplicationWillEnterForegroundNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *note) { TSEndBackgroundTask(); }];
        [center addObserverForName:UIApplicationWillTerminateNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *note) { TSEndBackgroundTask(); }];
    });
}
