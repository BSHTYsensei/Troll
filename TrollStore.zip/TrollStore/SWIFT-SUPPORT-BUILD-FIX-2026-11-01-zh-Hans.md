# TrollStore 构建修复：Theos Swift support 缺失

日期：2026-11-01

## 报错

GitHub Actions 在构建 `TrollStore` Swift 源码时失败：

```text
/bin/bash: .../.theos/vendor/swift-support/.theos_build/release/generate-output-file-map: No such file or directory
```

Theos 已经执行到生成 `output-file-map` 的规则，但 Theos 自己的 Swift support 主机工具不存在。它不是 `TSRefreshAppRegistrationsIntent.swift` 的 Swift 语法错误，也不是 App Intents 的链接错误。

## 根因分析

Theos 的 `rules.mk` 在检测到 Swift 源文件后，会先创建项目级 `swift_support` marker。若 marker 已从 GitHub Actions 缓存恢复，Theos 会跳过 `swift-bootstrapper.pl`。与此同时，Theos 的 Swift support 仓库还会用 `.theos_build/theos_build_commit` 记录成功构建的 commit 和 Swift 版本。如果 CI 缓存只恢复了 marker/构建标志，却没有恢复 release 可执行文件，就可能出现“缓存认为已构建，但 `generate-output-file-map` 不存在”的不一致状态。

Theos 的 `vendor/swift-support` 是 Theos 本身的 git submodule。非递归检出也可能导致目录存在但 `Package.swift` 和源码不全。

## 修复内容

1. 新增 `Scripts/bootstrap_theos_swift_support.sh`，在主机端使用 `xcrun --find swift` 选择当前 Xcode 的 Swift 工具链。
2. 检查 Theos `vendor/swift-support/Package.swift`；若源码子模块未初始化且 Theos 本身是 Git checkout，则自动执行 `git submodule update --init --recursive -- vendor/swift-support`。
3. 同时验证 `generate-output-file-map` 和 `parse-swiftc-output` 两个 Theos 必需的可执行文件。
4. 如果任何一个缺失/不可执行，删除整个不完整 `.theos_build`，避免残留 `theos_build_commit` 使 bootstrapper 错误走缓存快路径。
5. 使用 Theos 自带的 `swift-bootstrapper.pl` 进行实际构建，保留其锁机制、Swift 版本/源码 commit 缓存键，以及 `SPM_THEOS_BUILD=1 swift build -c release` 行为；只在该修复步骤子进程内 unset `THEOS_NO_SWIFT_CACHE`，防止环境变量跳过引导。
6. 构建后再次验证两个 release 工具确实存在且可执行；如果没有生成就立即以明确错误终止，不会伪造空工具文件。
7. 将前置检查接入根 `Makefile` 的 `check-build-tools`，因此原本从仓库根目录执行 `make` / `make assemble_trollstore` 的 CI 会在 Theos 编译任何目标前先修复该问题。
8. 新增 `Scripts/test_swift_support_bootstrap.sh`，用 mock Theos checkout 重现“成功 marker 存在、release 工具丢失”的 CI 缓存故障，并验证自愈流程。`make validate-project` 会自动运行这项测试。

## CI 缓存建议

不要单独缓存 `$(THEOS)/vendor/swift-support/.theos_build`，也不要缓存项目 `.theos/markers` 而不缓存相应构建产物。最简单可靠的做法是仅缓存 Theos 下载/源码，Swift support 由上述 preflight 验证及按需重建。即使外层 Actions 误恢复残缺缓存，此脚本也会检查真实可执行文件，而不盲信 marker。

本次源代码 ZIP 没有包含原有 `.github/workflows` 文件，因此没有擅自替换未知的 GitHub Actions workflow；修复接入根 Makefile 的现有构建链。当前报错日志显示顶层目标为 `build-targets`，这条入口会经过 `build-fastpaths` 和 `check-build-tools`，因此能命中该预检。若以后改成直接 `make -C TrollStore`，需要先从仓库根目录运行该预检脚本。

## 验证结果

- `bash -n`：两个 Swift support 脚本语法通过。
- Mock stale-cache regression：通过，实际模拟成功 marker 留存但两个 release 工具缺失的情形。
- `make validate-project`：通过，101 个必需文件、plist/strings、本地化、签名流程静态检查通过。
- `Scripts/test_fastpath_sign_pipeline.py`：通过。
- `Scripts/validate_macho.py bin/ldid`：通过；`bin/ldid` SHA-256 与原有清单一致。
- ZIP 完整性：打包后执行 `unzip -t`。

## 验证限制

当前运行容器不是 macOS，没有 Xcode、Apple SDK 或真实 Theos Runner，不能在这里执行真实 SwiftPM release build、`appintentsmetadataprocessor` 或整套 TrollStore iOS 编译。因此本补丁修复了已定位的构建引导/缓存缺失问题，并通过模拟回归验证；是否在 Runner 上成功完成真实 Swift support 编译，仍应以新一轮 GitHub Actions 日志为准。如果 bootstrapper 重新构建本身失败，新的日志会直接显示 SwiftPM/Xcode 报错，而不再晚些时候才报一个含糊的 `No such file`。
