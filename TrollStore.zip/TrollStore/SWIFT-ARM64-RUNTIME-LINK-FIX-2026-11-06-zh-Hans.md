# Swift 5.8.1 编译与 Xcode runtime 链接分离（2026-11-06）

## 已遇到的 CI 错误

第一轮链接失败指出 Swift 5.8.1 的 `libswift_Concurrency.dylib` 存在旧 arm64e slice 元数据；第二轮预检查又在 `libswiftCompatibility50.a` 上失败：

```text
error: [swift-runtime] libswiftCompatibility50.a did not produce a valid arm64 static archive (archs=arm64)
```

第二个报错来自把 Mach-O dylib 的 `lipo -verify_arch` 规则用于静态 `.a`。`lipo -archs` 已报告 `arm64`，但 `-verify_arch` 对 thin archive 会出现误拒绝；它不是证明 archive member table 损坏的有效检查。继续给每一个 runtime 文件增加例外会变成无休止的库名单修补。

## 构建策略改动

从“Swift 5.8.1 编译器 + Swift 5.8.1 全套 runtime 链接”改为分离式工具链：

1. **编译阶段**仍使用经签名校验的 Swift 5.8.1 `swiftc`。这是为了读取 iPhoneOS 16.5 SDK 内由 Swift 5.8 生成的 SwiftUI / AppIntents textual interfaces，不篡改 SDK，也不重新切换到已知无法导入这些接口的 Swift 6 编译器。
2. **链接阶段**使用当前选中的 Xcode `XcodeDefault.xctoolchain/usr/lib/swift/iphoneos`，与 Theos 当前使用的 Xcode `clang++` / Apple `ld` 保持一致。
3. Theos 原有 SDK `/usr/lib/swift` 搜索目录保留在最后，供系统 import stub 兜底。
4. 只有当 Xcode runtime 与 iPhoneOS SDK 都缺少某个 Swift compatibility archive 时，才从 Swift 5.8.1 compiler runtime 补入对应 `.a`。不从旧工具链复制任何 `.dylib`，因此 `libswift_Concurrency.dylib` 等旧 arm64e slice 不再进入当前 Apple linker 的输入路径。
5. 对 `.a` 使用 `lipo -archs` 检查架构，并用 `ar -t` 检查 archive member table。若是真正的 fat archive，再 `lipo -thin arm64`；不会对静态 archive 调用 `lipo -verify_arch`。
6. 兼容库补充目录仅用于链接搜索，不会复制到最终 TrollStore.app。

## Makefile 编译入口

保持单一入口：

```bash
make assemble_trollstore BUILD_JOBS=1
```

根 Makefile 依次完成项目验证、依赖准备、fastPathSign、两个 tweak preset、RootHelper、TrollStore、TrollHelper 和最终打包。TrollStore 的 Swift 源仍由 Theos Swift target rule 根据 output-file-map 编译；Objective-C/C/C++ 仍由 Theos target rules 执行。没有引入 Xcode project 或手工拼接 Swift `.o`。

`TrollStore/Makefile` 仅替换 Swift runtime linker search paths：Xcode runtime → 缺失 compatibility archive overlay → SDK system runtime。`before-TrollStore-all` 只准备必要的 compatibility archives，不再扫描或裁切整套 Swift runtime。

## 回归验证

`Scripts/test_swift_runtime_link.sh` 使用 mock `lipo` / `ar` 验证：

- Xcode runtime 已提供的 `libswiftCore.dylib` 和 compatibility archive 优先使用；
- SDK `.tbd` import stub 被保留并优先于旧工具链 fallback；
- Xcode / SDK 缺少的 `libswiftCompatibility50.a`、`51.a` 可以按 arm64 archive 补充；
- fat `.a` 只提取 arm64，thin `.a` 不被无意义地重新裁切；
- 不调用 `lipo -verify_arch`；
- Swift 5.8.1 的 runtime dylib 不进入兼容归档 overlay 或最终 linker search path。

当前运行容器不是 macOS/Xcode，不能在此处实际执行 Apple `lipo`、Apple `ar`、iPhoneOS SDK 编译或最终链接。上述测试验证的是脚本逻辑与 Make 变量展开，不等于真实 Apple 工具链构建成功。最终仍需在 GitHub macOS Runner 执行 `make assemble_trollstore BUILD_JOBS=1`，确认 Theos 的实际 `clang++` 命令从 active Xcode runtime 解析 Swift runtime dylibs，并完成链接。


## 后续构建策略调整（2026-11-06）

本报告中的 Xcode runtime 优先/兼容库回退方案已被后续默认构建配置取代。根 Makefile 现在默认 `ENABLE_APP_INTENTS=0`，所有 iOS 主目标只编译 Objective-C/C，跳过 Swift/AppIntents 链接和 App Intents 元数据处理，避免将有问题的 Swift runtime 放进链接输入。`TSRefreshAppRegistrationsIntent.swift` 与对应 UI 源码仍保留，但快捷指令入口在默认构建中隐藏。默认目标 SDK 固定为 Theos 的 `iPhoneOS16.5.sdk`。
