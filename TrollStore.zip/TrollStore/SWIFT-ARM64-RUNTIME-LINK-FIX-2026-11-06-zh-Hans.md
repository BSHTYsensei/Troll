# Swift 5.8.1 arm64 runtime 链接修复（2026-11-06）

## CI 错误

Theos 编译 `TrollStore` 的 Swift App Intents 对象后，最终由 Theos 的 `clang++` 链接阶段失败：

```text
ld: multiple errors: cpu type/subtype in slice (arm64e.old) does not match fat header (arm64e)
.../swift-5.8.1-RELEASE.xctoolchain/usr/lib/swift/iphoneos/libswiftDarwin.dylib
.../swift-5.8.1-RELEASE.xctoolchain/usr/lib/swift/iphoneos/libswift_StringProcessing.dylib
```

这不是未定义符号，也不是 App Intents 源码错误。Swift 5.8.1 的 iPhoneOS runtime dylib 中包含旧 ABI `arm64e.old` slice，但 fat header 把该 slice 标为新 `arm64e`。新版 Apple `ld` 会验证 fat header 与内部 Mach-O slice 的 CPU subtype，因而拒绝这些库，即使当前应用只请求 `arm64`。

Apple 在 iOS 14 / Xcode 12 时代改变了 arm64e ABI；Theos 的 arm64e Deployment 文档说明了新旧 ABI 不兼容。TrollStore app 本身固定 `ARCHS = arm64`，没有必要从 Swift runtime 链接 arm64e slice。

## 修复方案

- 保留 Swift 5.8.1 `swiftc`，保留现有 iPhoneOS 16.5 SDK 与 Swift 5.8 textual interface 匹配。
- 不修改 Swift.org 安装包或原始 `.xctoolchain/usr/lib/swift/iphoneos` 文件。
- 新增 `Scripts/prepare_swift_runtime_arm64.sh`：由 Theos 的 `before-TrollStore-all` hook 触发，将 Swift iPhoneOS runtime 目录中的 arm64 `.dylib` / `.a` 提取为 arm64-only 副本，输出到 `TrollStore/.theos/swift-runtime/iphoneos-arm64`。
- Theos 的 `_THEOS_TARGET_SWIFT_LDPATHS` 将 iPhoneOS runtime 搜索路径替换为该 arm64-only overlay，并保留 `/usr/lib/swift` 系统运行时 fallback。
- 原始 Swift 工具链目录保持不变；staging 目录只用于 Theos 链接搜索，不将 Swift runtime dylib 复制进 TrollStore.app。
- `TrollStore/Makefile` 仍由 Theos 编译 Swift、Objective-C 并完成最终链接；没有引入 Xcode project 或独立 Swift/Clang 编译流程。
- RootHelper、TrollHelper、TSAppLock、TSBackgroundAssist 不使用此 overlay；两个 tweak 的 arm64 + arm64e 产物不受影响。

## 验证

`Scripts/test_swift_runtime_arm64.sh` 使用 mock `lipo` 验证：arm64 + arm64e 输入被提取为单一 arm64 输出；arm64-only 输入保持 arm64；arm64e-only 文件不进入 arm64 overlay；源工具链文件不被修改。该测试纳入 `make validate-project`。

当前执行环境不是 macOS/Xcode，无法在此处实际运行 Apple `lipo` 或 iPhoneOS 16.5 SDK 的全量链接。下一次 GitHub macOS Runner 应由 Theos hook 真正准备 runtime overlay，然后继续 Theos 的 TrollStore link；必须确认两条错误 dylib 的链接来源改为 `TrollStore/.theos/swift-runtime/iphoneos-arm64`。如果还出现原始 Swift 5.8.1 `usr/lib/swift/iphoneos` 路径，说明 Theos 运行时链接路径覆盖未进入最终规则，需要查看完整 `clang++` 链接命令。
