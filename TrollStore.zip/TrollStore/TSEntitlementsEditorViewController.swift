import Foundation
import UIKit

@objc(TSEntitlementsEditorViewController)
final class TSEntitlementsEditorViewController: UIViewController {
    private let toggle = UISwitch()
    private let editor = UITextView()
    private let defaults = UserDefaults(suiteName: NSHomeDirectory() + "/Library/Preferences/com.opa334.TrollStore.plist") ?? .standard
    private let enabledKey = "TSCustomEntitlementsOverrideEnabled"
    private let fileName = "TSCustomEntitlements.plist"

    private var entitlementFileURL: URL {
        let root = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        return root.appendingPathComponent(fileName)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = NSLocalizedString("Custom Entitlements", comment: "")
        view.backgroundColor = .systemGroupedBackground
        let saveItem = UIBarButtonItem(title: NSLocalizedString("Save", comment: ""), style: .done, target: self, action: #selector(save))
        let resetItem = UIBarButtonItem(title: NSLocalizedString("Reset", comment: ""), style: .plain, target: self, action: #selector(reset))
        // Keep UIKit's automatic Back button intact when pushed from the original Preferences UI.
        navigationItem.rightBarButtonItems = [saveItem, resetItem]
        buildLayout()
        toggle.isOn = defaults.bool(forKey: enabledKey)
        loadDocument()
    }

    private func buildLayout() {
        let scroll = UIScrollView()
        scroll.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(scroll)
        NSLayoutConstraint.activate([
            scroll.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            scroll.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            scroll.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            scroll.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])

        let content = UIStackView()
        content.axis = .vertical
        content.spacing = 16
        content.translatesAutoresizingMaskIntoConstraints = false
        scroll.addSubview(content)
        NSLayoutConstraint.activate([
            content.topAnchor.constraint(equalTo: scroll.contentLayoutGuide.topAnchor, constant: 18),
            content.leadingAnchor.constraint(equalTo: scroll.frameLayoutGuide.leadingAnchor, constant: 16),
            content.trailingAnchor.constraint(equalTo: scroll.frameLayoutGuide.trailingAnchor, constant: -16),
            content.bottomAnchor.constraint(equalTo: scroll.contentLayoutGuide.bottomAnchor, constant: -22)
        ])

        let toggleRow = UIStackView()
        toggleRow.axis = .horizontal
        toggleRow.alignment = .center
        toggleRow.spacing = 12
        let toggleLabel = UILabel()
        toggleLabel.text = NSLocalizedString("Apply custom Entitlements during installation", comment: "")
        toggleLabel.font = .preferredFont(forTextStyle: .body)
        toggleLabel.numberOfLines = 0
        toggleRow.addArrangedSubview(toggleLabel)
        toggleRow.addArrangedSubview(toggle)
        toggleRow.backgroundColor = .secondarySystemGroupedBackground
        toggleRow.isLayoutMarginsRelativeArrangement = true
        toggleRow.layoutMargins = UIEdgeInsets(top: 14, left: 14, bottom: 14, right: 14)
        toggleRow.layer.cornerRadius = 12
        toggle.translatesAutoresizingMaskIntoConstraints = false
        toggleLabel.setContentHuggingPriority(.defaultLow, for: .horizontal)
        toggle.setContentHuggingPriority(.required, for: .horizontal)
        content.addArrangedSubview(toggleRow)

        let help = UILabel()
        help.text = NSLocalizedString("When enabled, keys in this plist override matching Entitlements in the main app executable during TrollStore's normal signing flow. Unspecified keys are preserved. Extensions retain their own Entitlements.", comment: "")
        help.font = .preferredFont(forTextStyle: .footnote)
        help.textColor = .secondaryLabel
        help.numberOfLines = 0
        content.addArrangedSubview(help)

        let editorLabel = UILabel()
        editorLabel.text = NSLocalizedString("Entitlements property list (XML)", comment: "")
        editorLabel.font = .preferredFont(forTextStyle: .headline)
        content.addArrangedSubview(editorLabel)

        editor.font = .monospacedSystemFont(ofSize: 13, weight: .regular)
        editor.autocapitalizationType = .none
        editor.autocorrectionType = .no
        editor.spellCheckingType = .no
        editor.smartQuotesType = .no
        editor.smartDashesType = .no
        editor.backgroundColor = .secondarySystemGroupedBackground
        editor.layer.cornerRadius = 12
        editor.layer.borderWidth = 1 / UIScreen.main.scale
        editor.layer.borderColor = UIColor.separator.cgColor
        editor.textContainerInset = UIEdgeInsets(top: 12, left: 10, bottom: 12, right: 10)
        editor.accessibilityLabel = NSLocalizedString("Entitlements property list (XML)", comment: "")
        editor.heightAnchor.constraint(greaterThanOrEqualToConstant: 300).isActive = true
        content.addArrangedSubview(editor)

        let footer = UILabel()
        footer.text = NSLocalizedString("Only add keys you understand. Invalid property lists are rejected before installation. Some entitlements are restricted by iOS and cannot be made functional by signing alone.", comment: "")
        footer.font = .preferredFont(forTextStyle: .footnote)
        footer.textColor = .secondaryLabel
        footer.numberOfLines = 0
        content.addArrangedSubview(footer)
    }

    private func loadDocument() {
        if let data = try? Data(contentsOf: entitlementFileURL),
           let plist = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil),
           let xml = try? PropertyListSerialization.data(fromPropertyList: plist, format: .xml, options: 0),
           let text = String(data: xml, encoding: .utf8) {
            editor.text = text
        } else {
            editor.text = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n<plist version=\"1.0\">\n<dict>\n</dict>\n</plist>\n"
        }
    }

    @objc private func save() {
        guard let data = editor.text.data(using: .utf8),
              let object = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil),
              let plist = object as? [String: Any] else {
            showError(NSLocalizedString("The Entitlements document is not a valid XML plist dictionary.", comment: ""))
            return
        }
        do {
            let folder = entitlementFileURL.deletingLastPathComponent()
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            let output = try PropertyListSerialization.data(fromPropertyList: plist, format: .xml, options: 0)
            try output.write(to: entitlementFileURL, options: .atomic)
            defaults.set(toggle.isOn, forKey: enabledKey)
            let alert = UIAlertController(title: NSLocalizedString("Saved", comment: ""), message: NSLocalizedString("Entitlements settings were saved.", comment: ""), preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: ""), style: .default))
            present(alert, animated: true)
        } catch {
            showError(error.localizedDescription)
        }
    }

    @objc private func reset() {
        editor.text = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n<plist version=\"1.0\">\n<dict>\n</dict>\n</plist>\n"
        toggle.isOn = false
    }

    private func showError(_ message: String) {
        let alert = UIAlertController(title: NSLocalizedString("Invalid Entitlements", comment: ""), message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: ""), style: .default))
        present(alert, animated: true)
    }
}
