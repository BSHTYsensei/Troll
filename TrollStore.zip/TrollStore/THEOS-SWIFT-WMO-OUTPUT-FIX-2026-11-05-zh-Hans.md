# TrollStore：修复 Theos Swift 对象文件缺失

日期：2026-11-05

## CI 错误

链接阶段报告：

`clang++: error: no such file or directory: .../TSRefreshAppRegistrationsIntent.swift.<tag>.o`

该目标文件由 Theos 的 Swift `output-file-map` 生成，并由 Theos 加入最终链接对象列表。问题并非应由手工 `clang++` 补编，而是 Swift 编译输出模式需要与 Theos 的多输出规则一致。

## 根因

项目原来在 `TrollStore/Makefile` 显式设置：

```makefile
SWIFT_OPTFLAG = -O -whole-module-optimization
```

这覆盖了 Theos 优化构建采用的：

```makefile
SWIFT_OPTFLAG = -O -whole-module-optimization -num-threads 1
```

Swift 编译器文档说明，非线程 WMO 会生成整个模块的单个对象文件；线程 WMO 则按 output-file-map 为每个输入源生成对象文件。Theos 的 `instance/rules.mk` 生成每个 `*.swift.<tag>.o` 链接目标，并由 Swift support 的 `generate-output-file-map` 和一次 `swiftc -output-file-map` 调用生成这些对象。因此，丢失 `-num-threads 1` 会使 Swift 的对象输出模式与 Theos 期望不一致。

## 修改

1. `TrollStore/Makefile` 将 Swift 优化设置改为 `-O -whole-module-optimization -num-threads 1`。保留 WMO，不降低优化等级。
2. 根 `Makefile` 在每次调用 TrollStore 子项目之前，仅删除该目标的 `.swift-stamp`、临时 stamp、旧 output-file-map 和该 Swift 源文件的旧对象。Theos 随后正常重新生成映射、编译 Swift、链接 App。
3. `Scripts/validate_project.py` 强制检查线程 WMO 参数和 Swift 输出缓存失效步骤，避免未来误删 `-num-threads 1`。
4. 更新 README，解释 Swift 输出文件映射与缓存一致性。

## 构建模式

所有 iOS 目标仍只通过 Theos Makefile 编译。没有增加独立 `swiftc`、Clang 或 Xcode project 编译，也没有手工制造 `.o` 文件。Swift 5.8.1 仍只用于 Theos 的 `TARGET_SWIFTC`。

## 验证范围

静态审计可以验证 Makefile 参数、缓存清理目标和项目完整性。当前执行环境不是 macOS/Xcode，不能执行 iPhoneOS 16.5 SDK 的实际 Theos 构建，因此这次修改仍需由 GitHub macOS Runner 完成最终编译确认。
