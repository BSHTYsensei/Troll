# TrollStore：第二轮修复 Swift 5.8.1 Clang 头文件污染

日期：2026-11-05

## 为什么 2026-11-04 的修复没有解决 CI

随后收到的 CI 日志仍然明确显示：

`stdatomic.h` 来自 `swift-5.8.1-RELEASE.xctoolchain/usr/bin/../lib/swift/clang/include`（该路径与 `usr/lib/swift/clang/include` 指向同一目录）

并在该目录的 `stdatomic.h` 内找不到 `__stddef_max_align_t.h`。这证明之前仅清理五种进程级 include 环境变量、并检查 Make 变量值，仍未控制最终 Clang 命令的实际资源目录/参数。

上一轮回归测试只确认 `TARGET_CC`、`TARGET_CXX` 的变量值以及 `CPATH` 等变量是否被 unexport；它没有执行实际编译器，也没有检查 `-resource-dir`、`-isystem` 或 `-fmodule-map-file`。因此该测试不能证明 `stdatomic.h` 一定来自 Xcode Clang。上一轮验证范围不足，这次已纠正。

## 本轮实施的修改

1. 所有 Theos 子项目的 `Scripts/xcode-clang.mk` include 移到 `$(THEOS)/makefiles/common.mk` 之后。Theos 会在 `common.mk` 中载入用户 `rc.mk` 并解析目标平台配置，因此最终固定编译器的动作应在这些配置加载之后执行。
2. 新增 `Scripts/xcode-clang-wrapper-common.sh`，实际调用当前 Xcode 的 `XcodeDefault.xctoolchain/usr/bin/clang` 或 `clang++`。
3. 新增 C/Objective-C wrapper 与 C++ wrapper，分别作为 Theos 的 `TARGET_CC`、`TARGET_CXX` 和 `TARGET_LD`。
4. wrapper 无条件移除命令行已有的 `-resource-dir`，并过滤指向 Swift.org Clang 资源目录的显式参数。过滤规则同时识别规范路径 `*/Toolchains/swift-*.xctoolchain/usr/lib/swift/clang*` 和 CI 日志中出现的可执行文件相对路径 `*/Toolchains/swift-*.xctoolchain/usr/bin/../lib/swift/clang*`；覆盖 `-I`、`-isystem`、`-iquote`、`-idirafter`、`-F`、`-iframework`、`-include`、`-imacros` 及 module-map 参数。最后追加从实际 Xcode Clang 查询到的 `-resource-dir`。
5. wrapper 清除五种全局 Clang include 环境变量，以及 `CCC_OVERRIDE_OPTIONS` 和 Clang config 目录覆盖变量；项目自己的 Theos `*_CFLAGS` 仍然保留。
6. `MODULESFLAGS` 增加按 Xcode Clang 版本指纹区分的 `-fmodules-cache-path`，避免恢复其他工具链产生的 PCM 模块缓存。
7. 新增 `Scripts/verify_xcode_clang_objc.sh`。macOS CI 构建前用真正的 Xcode Clang、iPhoneOS 16.5 SDK、Theos `Prefix.pch`、Foundation/UIKit 和新建模块缓存做 Objective-C 语法编译；它还检查 `stdatomic.h` 的实际头文件跟踪路径。
8. 重写 `Scripts/test_xcode_clang_isolation.sh`，用伪造 compiler 可执行文件检查最终编译器、argv、resource-dir、Swift include 参数过滤和环境隔离，不再只检查 Make 变量。

## 为什么这次修复更接近根因

错误不是 SDK 缺少一个头文件，而是编译器把 Swift.org toolchain 中的兼容头目录当作 Xcode Clang builtin include 目录。`stdatomic.h` 与 `__stddef_max_align_t.h` 是同一 Clang resource include 集合中的配套文件，不能从其他 Clang 发行版随意拼接。wrapper 把实际编译器和 resource directory 固定为同一个 Xcode toolchain，并过滤能把 Swift.org Clang include tree 注入回来的参数。

## 保持不变

- TrollStore 的 App Intents Swift 源码仍由 Swift 5.8.1 编译。
- iPhoneOS 16.5 SDK 未被修改，也没有从另一个工具链复制头文件。
- 未关闭 Clang Modules，未降低 `-Werror`，未改动安装、签名、插件或应用功能源码。
- `bin/ldid` 保持原样。

## 验证范围与限制

本地可执行的 mock wrapper 回归测试、shell 语法检查和项目静态审计可以完成；真正的 `Prefix.pch + Foundation/UIKit + iPhoneOS SDK` 编译探针必须在 macOS/Xcode Runner 运行。当前编辑环境不是 macOS，不能诚实地宣称 iPhoneOS SDK 全量编译已经成功。下一次 CI 应首先出现：

`[toolchain] Objective-C Prefix.pch probe passed; stdatomic.h: <Xcode Clang resource dir>/include/stdatomic.h`

只有此探针通过后，才有意义继续评估完整 TrollStore 目标的其他编译错误。
