# TrollStore：第二轮修复 Swift 5.8.1 Clang 头文件污染

日期：2026-11-05

## 为什么 2026-11-04 的修复没有解决 CI

随后收到的 CI 日志仍然明确显示：

`stdatomic.h` 来自 `swift-5.8.1-RELEASE.xctoolchain/usr/bin/../lib/swift/clang/include`（该路径与 `usr/lib/swift/clang/include` 指向同一目录）

并在该目录的 `stdatomic.h` 内找不到 `__stddef_max_align_t.h`。这证明之前仅清理五种进程级 include 环境变量、并检查 Make 变量值，仍未控制最终 Clang 命令的实际资源目录/参数。

上一轮回归测试只确认 `TARGET_CC`、`TARGET_CXX` 的变量值以及 `CPATH` 等变量是否被 unexport；它没有执行实际编译器，也没有检查 `-resource-dir`、`-isystem` 或 `-fmodule-map-file`。因此该测试不能证明 `stdatomic.h` 一定来自 Xcode Clang。上一轮验证范围不足，这次已纠正。

## 本轮实施的修改

1. 所有 Theos 子项目的 `Scripts/xcode-clang.mk` include 移到 `$(THEOS)/makefiles/common.mk` 之后。Theos 会在 `common.mk` 中载入用户 `rc.mk` 并解析目标平台配置，因此最终固定编译器的动作应在这些配置加载之后执行。
2. 新增 `Scripts/xcode-clang-wrapper-common.sh`，实际调用当前 Xcode 的 `XcodeDefault.xctoolchain/usr/bin/clang` 或 `clang++`。
3. 新增 C/Objective-C wrapper 与 C++ wrapper，分别作为 Theos 的 `TARGET_CC`、`TARGET_CXX` 和 `TARGET_LD`。
4. wrapper 无条件移除命令行已有的 `-resource-dir`，并过滤指向 Swift.org Clang 资源目录的显式参数。过滤规则同时识别规范路径 `*/Toolchains/swift-*.xctoolchain/usr/lib/swift/clang*` 和 CI 日志中出现的可执行文件相对路径 `*/Toolchains/swift-*.xctoolchain/usr/bin/../lib/swift/clang*`；覆盖 `-I`、`-isystem`、`-iquote`、`-idirafter`、`-F`、`-iframework`、`-include`、`-imacros` 及 module-map 参数。最后追加从实际 Xcode Clang 查询到的 `-resource-dir`。
5. wrapper 清除五种全局 Clang include 环境变量，以及 `CCC_OVERRIDE_OPTIONS` 和 Clang config 目录覆盖变量；项目自己的 Theos `*_CFLAGS` 仍然保留。
6. `MODULESFLAGS` 增加按 Xcode Clang 版本指纹区分的 `-fmodules-cache-path`，避免恢复其他工具链产生的 PCM 模块缓存。
7. 上一版曾新增 `Scripts/verify_xcode_clang_objc.sh`，尝试在 Theos 正式构建前直接调用 Clang 编译临时 Objective-C 探针；该独立探针现已删除，原因见本文后续修订。
8. 重写 `Scripts/test_xcode_clang_isolation.sh`，用伪造 compiler 可执行文件检查最终编译器、argv、resource-dir、Swift include 参数过滤和环境隔离，不再只检查 Make 变量。

## 为什么这次修复更接近根因

错误不是 SDK 缺少一个头文件，而是编译器把 Swift.org toolchain 中的兼容头目录当作 Xcode Clang builtin include 目录。`stdatomic.h` 与 `__stddef_max_align_t.h` 是同一 Clang resource include 集合中的配套文件，不能从其他 Clang 发行版随意拼接。wrapper 把实际编译器和 resource directory 固定为同一个 Xcode toolchain，并过滤能把 Swift.org Clang include tree 注入回来的参数。

## 保持不变

- TrollStore 的 App Intents Swift 源码仍由 Swift 5.8.1 编译。
- iPhoneOS 16.5 SDK 未被修改，也没有从另一个工具链复制头文件。
- 未关闭 Clang Modules，未降低 `-Werror`，未改动安装、签名、插件或应用功能源码。
- `bin/ldid` 保持原样。

## 验证范围与限制

本地可执行 mock wrapper 回归测试、shell 语法检查和项目静态审计。iPhoneOS SDK 的真实 Objective-C/C/C++ 编译必须由 macOS/Xcode Runner 上的 Theos 子项目构建完成；当前编辑环境不是 macOS，不能诚实地宣称 iPhoneOS SDK 全量编译已经成功。

## 2026-11-05 后续修复：wrapper 执行权限

新一轮 CI 在启动 `test_xcode_clang_isolation.sh` 时报告：

`/bin/sh: .../Scripts/xcode-clang-wrapper.sh: Permission denied`

这次失败发生在编译器进程启动前，与 Clang 头文件搜索路径无关。Theos 的 `TARGET_CC` / `TARGET_CXX` 是直接执行的编译器程序；若仓库导入、ZIP 解压或提交过程将 wrapper 的权限变成 `0644`，Theos 就无法执行它。

为避免依赖 ZIP 元数据或仓库文件模式，本次增加了两道明确处理：

1. 根 `Makefile` 的 `validate-project` 首先执行 `chmod 755`，再启动隔离测试。
2. `Scripts/xcode-clang.mk` 在配置 `TARGET_CC` / `TARGET_CXX` 前执行 `chmod 755`，确保每个 Theos 子项目在 Makefile 解析阶段恢复 wrapper 执行权限；若权限修改失败则立即报出明确错误。
3. 隔离回归测试会验证两个 wrapper 最终都具有执行权限。测试前将 wrapper 人为降为 `0644`，随后确认配置能恢复成 `0755` 并实际执行 mock compiler。
4. Theos 真正的编译器命令仍使用可执行 wrapper 文件。

这项修改不改变 Swift 5.8.1、Xcode Clang、SDK 或 TrollStore 功能代码。

## 2026-11-05 后续修订：仅由 Theos 执行 iOS 目标编译

最新 CI 报告：

`error: the Objective-C header trace did not resolve stdatomic.h from Xcode builtin headers`

该错误来自上一版的独立 `verify_xcode_clang_objc.sh`，而不是 Theos 的 TrollStore 编译目标。这个脚本直接执行 wrapper 编译临时 `probe.m`，再用 `clang -H` 的文本输出匹配某个完整资源目录路径。不同 Apple Clang 版本可能以不同形式展示 builtin include，因而这项路径字符串断言不适合作为构建阻断条件；更重要的是，它引入了用户明确不需要的第二套 Objective-C 编译入口。

本次修订：

1. 删除 `Scripts/verify_xcode_clang_objc.sh`，并从 `check-build-tools` 及 shell 语法检查中移除其调用。
2. `check-build-tools` 只检查 Theos、Xcode Clang 可执行文件、资源头文件是否存在，以及 Swift/App Intents 构建依赖；不再自行编译 Objective-C 探针。
3. TrollStore、RootHelper、TrollHelper、TSAppLock 和 TSBackgroundAssist 的 C/Objective-C/C++ 源码仍由各自 Theos Makefile 编译。每个子项目先包含 `$(THEOS)/makefiles/common.mk`，随后包含 `Scripts/xcode-clang.mk`，由该片段设置最终的 Theos `TARGET_CC`、`TARGET_CXX` 与 `TARGET_LD`。
4. 保留 wrapper 的参数/环境隔离、执行权限恢复、Xcode Clang resource directory 固定和按版本隔离的 Modules cache；删除的只是独立编译探针，不是编译器隔离措施。
5. 下一轮 CI 应直接观察 Theos 的 `[build] TrollStore` 编译阶段。若原始 `stdatomic.h` 错误重现，应以 Theos 输出的实际编译命令为依据继续修复；不能再由 `-H` 文本匹配提前判失败。

因此，本项目 iOS 目标的 Objective-C/C/C++ 编译唯一入口是 Theos。`fastPathSign` 仍是运行于 macOS CI 主机的 host 工具，不属于 iOS Theos 目标；其独立主机工具构建不用于编译 TrollStore 的 iOS 源码。
