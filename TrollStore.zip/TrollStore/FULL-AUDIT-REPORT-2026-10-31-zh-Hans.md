# TrollStore iOS 16+ 全工程静态审计报告（2026-10-31）

## 本轮针对的真实 CI 错误

1. `TSApplicationsManager.h`：多个 Objective-C 指针声明没有 nullability specifier，被 `-Wnullability-completeness -Werror` 提升为错误。
2. `TSAppCollectionViewController.m`：仍调用 `horizontalGroupWithLayoutSize:subitem:count:`，该 selector 从 iOS 16.0 起弃用，被 `-Werror=deprecated-declarations` 提升为错误。

## 修复内容

- 为 `TSApplicationsManager.h` 增加 `NS_ASSUME_NONNULL_BEGIN/END`。
- 对 `logOut` 的双指针输出参数显式标注内外两层均可空；对 Entitlements 路径、卸载应用 ID/路径及注册状态参数标注可空。
- 同步修正 `TSApplicationsManager.m` 中对应实现签名，保持头文件与实现一致。
- 将 collection compositional layout 更新为 `horizontalGroupWithLayoutSize:repeatingSubitem:count:`，不改变两列布局。
- 将上述两类错误加入 `Scripts/validate_project.py` 的回归检查。
- 根 `Makefile` 增加 `validate-project`，正式 Apple 工具链构建前先执行 Python 脚本语法检查、工程完整性/资源/本地化检查以及内置 ldid Mach-O 检查。

## 全工程静态检查范围

审计了工程中 174 个文件；其中 83 个 Objective-C/C 源文件与头文件通过词法括号、字符串/注释边界扫描。额外检查了全部五个 Theos 子工程 Makefile、根 Makefile、构建依赖顺序、macOS 与 iOS 签名工具边界、iOS 16.0 最低部署版本、资源 plist、strings、本地化键、ChOma 固定提交、预编译 ldid 文件及解密器使用的 iOS Darwin API。

## 已执行并通过的检查

- `make validate-project`：通过。
- `python3 -m py_compile Scripts/*.py`：通过。
- `python3 Scripts/validate_project.py`：80 项必需文件、6 份 plist、4 份 strings、490 个简体中文键及项目既有功能断言通过。
- `python3 Scripts/validate_macho.py bin/ldid`：通过，确认预编译的 arm64 iOS 设备端 Mach-O 可识别。
- `bin/ldid` SHA-256 与 `bin/ldid.sha256` 一致：`d23eb53e6c5b07f5cae72f0e93ab1b87214aa68ed4a59bc32286f8b15cb8b769`。
- Clang 17 对 `TSApplicationsManager.h` 执行 `-Wnullability-completeness -Werror` 头文件检查（使用最小 Foundation 声明桩）：通过。
- 83 个 Objective-C/C 文件的括号、字符串、字符字面量和注释词法扫描：通过。
- `bash -n Scripts/bootstrap_choma.sh`：通过。
- 五个 Theos 子工程 Makefile 使用最小 Theos include stub 解析：通过；根 Makefile `make -n all` 构建依赖图解析：通过。该步骤仅验证 Make 语法，不代表构建。
- ZIP 压缩完整性：通过。

## 未执行 / 外部依赖

当前工作环境为 Linux x86_64，不包含 macOS、Xcode、iPhoneOS 16.5 SDK 或 Theos。因此没有执行 Objective-C/iOS SDK 全量编译、最终链接、codesign、真机安装或运行时解密验证。

CI 需要按仓库脚本拉取固定提交的 ChOma：`964023ddac2286ef8e843f90df64d44ac6a673df`，并提供 Theos、iPhoneOS SDK、Homebrew libarchive/OpenSSL 依赖。实际编译结果以 GitHub Actions 在 macOS Runner 上的日志为准。
