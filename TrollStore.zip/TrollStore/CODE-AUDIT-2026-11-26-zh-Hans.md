# TrollStore 源码审查与修改报告（2026-11-26）

## 本轮范围

本包是 TrollStore 主应用源码工程。审查集中在 IPA 软件包列表、IPA 编辑器、自定义图标导入、归档图标解析、脱壳结果反馈、RootHelper/签名与证书回归，以及构建静态验证。该报告记录可由当前源码和测试直接支持的结论，不代表已完成 Apple SDK 编译或真机验收。

## 已修改

### IPA 软件包图标

- 列表不再只根据扩展名显示统一占位图；从 IPA/TIPA 的 `Payload/*.app/Info.plist` 读取图标元数据。
- 支持传统 `CFBundleIconFiles` PNG 文件名解析，并对 `.png`、`@2x`/`@3x` 和小数尺寸名称进行处理。
- 没有独立 PNG 图标时，尝试从 `Assets.car` / `CFBundleIconName` 加载资源目录图标。
- 图标解析加入归档条目类型和大小限制：主 Info.plist 8 MiB、扩展 Info.plist 4 MiB、PNG 16 MiB、Assets.car 64 MiB。
- 列表图标在后台最多两个并发任务中加载，以 NSCache 缓存；避免在 cell 重用/滚动时同步解压。
- 后台图标路径不再访问 `UIScreen.mainScreen`；精确尺寸有多个变体时优先选择最高 scale。

`Assets.car` 的实际解码依赖目标 iOS 运行时的 `NSBundle` / UIKit 资源加载行为。当前没有设备运行环境，因此该分支已做源码级与回归检查，但不能宣称所有资产目录变体都已真机验证。

### IPA 编辑器与自定义图标

- 自定义图标入口改为从 Files 导入 PNG/JPEG，不再探测 TrollStore 自身包内是否包含可替换图标。
- 导入图片限制 25 MiB、最长边 4096 像素，归一化方向并输出 1024×1024 PNG，存入应用私有 Documents。
- 编辑器提供预览和导入按钮；打包时写入常用 iPhone/iPad 图标变体并更新目标 App 的 `Info.plist`。
- 默认保留 Widget、Watch 扩展及 URL Schemes；需要清理时由用户显式开启，以免默认操作破坏目标 App 功能。
- 重打包完成后重新打开输出 IPA，验证 ZIP/Info.plist/Bundle ID；若导入了自定义图标，还会验证图标可读。验证失败会删除不合格输出并报告失败。

此功能是“导入图标并应用到正在编辑的目标 IPA”，不是运行时替换 TrollStore 自身主屏幕图标。iOS 宿主 App 的备用图标需要预先声明在应用包中，不能把 Files 中任意外部图片直接设置为宿主图标。

### 脱壳反馈

- UI 在 RootHelper 返回成功后，会检查输出路径是否存在、是否为非空普通文件；没有实际 IPA 输出时不会再显示成功。
- 失败时清理部分输出并展示错误。
- **FairPlay/DRM 解密核心未修改。** 现有核心依赖 `task_for_pid`、进程内存读取等权限；目标进程权限/系统保护不允许时仍可能失败。本轮没有增强或绕过第三方应用 DRM，也没有把脱壳描述为已修复。请仅在拥有授权、且系统允许的范围内使用。

### 其他构建与回归

- 保留上一轮 RootHelper 未使用静态函数的编译条件修复、证书导入错误分类、文件提供商读取回退、签名后验证与中文资源同步。
- 本轮进一步把归档图标后台路径改为不访问 `UIScreen`，并为尺寸解析固定 `en_US_POSIX` 数字 locale。

## 自动化检查结果

执行 `make validate-project` 成功，输出包含：

- 112 个必需项目文件存在；5 个 plist 和 4 个 strings 资源通过检查。
- 953 个简体中文键与 helper 资源匹配，其中 943 个译文含中文字符。
- RootHelper 预处理条件、解压清理、证书导入、File Provider、签名流水线和 UI 回归检查通过。
- 新增 IPA 图标导入、图片尺寸约束、图标变体写入、Assets.car 有界读取、图标文件名解析、异步图标缓存、脱壳输出文件校验、输出 IPA 复验均通过。
- fastPathSign 的 per-slice 签名、Universal 重建和 Framework wrapping 测试通过。
- 内置 arm64 iOS `ldid` 文件架构检查通过。

上述主要是源码静态/模拟回归测试，不能代替实际签名、安装和 iOS UI 运行测试。

## 尚未完成 / 限制

- 当前执行环境没有 `xcodebuild`、`xcrun`、Apple SDK 和 Theos，因此没有完成 iOS 目标的真实编译。
- 没有真机验证 Files 导入、iCloud 文件提供商行为、Assets.car 图标兼容、IPA 重签名安装、证书导入或各系统版本 UI。
- 脱壳核心没有被增强，`task_for_pid` 权限限制仍然存在。
- 没有增加汇编优化。当前没有可靠 profile 证据表明本轮所涉 UI/归档路径受某段可替换汇编热点限制；引入手写 ASM 会增加架构与系统兼容风险。

## 使用建议

在 macOS/Xcode/Theos 环境先按项目文档构建 TrollStore，再生成安装资源 tar；对新构建的安装器导入与本源码版本匹配的 tar。安装器源码包内的 SHA-256 绑定必须同步到新 tar 中四个二进制的哈希，详见 `TrollInstallerX` 包内的安装器报告和 `Scripts/update_custom_payload_hashes.py`。

## 追加编译修复（2026-11-26）：Objective-C UTType 全局常量

CI 日志指出 `UTType.png` 不存在。原因是把 Swift 的 `UTType.png` 成员语法直接用于 Objective-C。现已在 `TSAppRepackager.m` 和 `TSSettingsListController.m` 改为 `UTTypePNG` / `UTTypeJPEG` 全局常量，保留 `initForOpeningContentTypes:asCopy:YES`。回归脚本新增断言，确保两个调用点使用 Objective-C API 名称，且不再出现 Swift 风格的 `UTType.png` / `UTType.jpeg`。

重新运行 `make validate-project` 后通过；这包括本次 IPA 编辑与图标导入相关测试。它仍是 Theos 静态/模拟回归验证，不等同于在 GitHub macOS runner 上的最终 iOS SDK 编译。
