# TrollStore 源码修复与专项审计报告（2026-11-25）

## 结论

本次修复了 `RootHelper/main.m` 在嵌入式 Persistence Helper 构建时触发的 `-Werror,-Wunused-function`，并改进了应用列表、网格卡片和设置列表在 Dynamic Type 下的自适应布局。证书文件导入及签名主流程已做源码级核查，并增加了回归断言。

**本报告不代表已在 Apple SDK 上完成 iOS 编译，也不代表已在真实设备上完成证书导入或签名验证。** 当前工作环境没有 `xcrun`、`xcodebuild`、Theos 环境变量或 `ChOma/` 子模块检出目录，不能执行完整 iOS 构建或真机测试。

## 1. 编译错误修复

报错函数：`createPrivateTemporaryFile(...)`。

原因：同一个 `RootHelper/main.m` 被独立 RootHelper 与嵌入式 Persistence Helper 共用。该函数只服务于独立 RootHelper 的签名分支；嵌入式 Helper 通过 `EMBEDDED_ROOT_HELPER` 关闭签名实现，因此函数在嵌入式目标中只有定义、没有调用，触发 `-Werror,-Wunused-function`。

修复：仅用 `#ifndef EMBEDDED_ROOT_HELPER` 包住这个静态函数定义；独立 RootHelper 的调用保留，嵌入式版本不再编译无用函数。没有关闭警告，也没有把警告降级。

同时把该问题加入 `Scripts/test_custom_install_signing_regressions.py`，检查函数条件编译保护与真实调用点。

## 2. UI 布局改进

- 应用列表单元格：标题、Bundle ID 描述使用 `UIFontMetrics` 和 `adjustsFontForContentSizeCategory`；标题最多两行，描述最多两行；行高采用 `UITableViewAutomaticDimension`，上下约束形成完整高度链，不再固定 80pt。
- 应用网格卡片：名称、Bundle ID、来源标识使用 Dynamic Type 字体；卡片采用估算高度和上下完整约束，避免自适应字号后标签超出卡片。
- 设置主列表：标题与说明支持动态字号和多行显示；行高改为自动计算，避免固定行高挤压说明、开关和箭头。
- 高级设置：标题支持动态字号；分段控件行与开关行分别建立完整垂直约束链，行高自动计算；移除不再需要的冗余垂直居中约束。

这些更改消除已发现的固定行高和固定字号布局风险。由于当前环境无 iOS Simulator/设备，仍需在小屏设备、横屏、最大辅助功能字号和不同系统版本上做最终视觉验收。

## 3. 证书导入检查

源码检查覆盖：

- 文件选择器除 `.p12/.pfx`、`.pem`、`.key/.p8`、`.cer/.crt` 和 `.mobileprovision` 外，也接受 File Provider 常见的通用 `public.item`、`public.content`、`public.data` 等类型；读取时启用 security-scoped resource 和 `NSFileCoordinator`。
- 协调读取失败时，仍在安全作用域有效期间，对本地普通文件做一次受 64 MiB 限制的直接读取回退；不把云端未下载文件误当成有效证书数据。
- 文件需为可访问的普通文件；符号链接、不可读文件和超限文件会给出不同诊断。PEM 私钥读取失败时会清理暂存的证书数据，避免下次误用上次证书。
- PKCS#12 通过 `SecPKCS12Import` 解析；错误密码与损坏/无效文件分别诊断。PEM 支持 UTF-8 BOM、Windows/Unix 换行、X.509 PEM/DER 证书，以及常见 RSA/EC/PKCS#8 加密私钥标签。
- 私钥及证书相关资料写入私有目录，目录权限 0700、文件权限 0600；私钥/密码通过 `kSecAttrAccessibleWhenUnlockedThisDeviceOnly` 的 Keychain 项保存。

判断：当前代码已覆盖原先常见的“文件类型不被识别”和部分 File Provider 协调读取失败情形，重复出现笼统“文件错误”的风险会降低。但若文件仍在 iCloud/第三方云端、未下载到本机，或内容损坏/密码错误，仍会失败；未在真机上用 iCloud Drive、第三方 Provider 和实际证书文件验证。

注意：分离的 PEM 证书与私钥在导入时并不一定完成密钥配对验证；实际签名阶段由签名工具检查。证书/私钥不匹配映射为 197，错误的加密私钥/P12 密码映射为 198。

## 4. 签名链路检查

- TrollStore ad-hoc 签名与真实 CMS 证书签名分开处理。CMS 路径不会误加 `-s` ad-hoc 参数。
- 真实 CMS 签名在签名完成后运行 `ldid --signature-validate`，用于检查签名与代码哈希；Apple 对证书链、描述文件和设备授权的最终接受仍由系统安装/验证机制决定。
- 证书签名需要匹配的身份材料；常规 Real 模式还需要与 Team ID、App ID、Entitlements 和目标设备相匹配的 provisioning profile。缺少 profile 的路径会返回独立的 193 诊断：签名本身可能已完成，但这不等于应用一定可安装或启动。
- 加密的主可执行文件、额外加密二进制、需要 Developer Mode 的 Entitlements、profile 过期/不匹配、证书与私钥不匹配、私钥密码错误均有不同错误处理路径。
- Apple Internal 模式额外要求真实 Apple 签发的内部 profile、`AppleInternalProfile=true`、证书成员关系、Team/App ID 匹配和签名校验；普通开发者 profile 不能替代。

### 已确认的 iOS 版本限制

当前压缩包内 `bin/ldid` 是 arm64 iOS Mach-O，`LC_BUILD_VERSION` 声明最低 iOS 16.0，且 SHA-256 与 `bin/ldid.sha256` 一致。

- iOS 16.0 及以上：可使用当前内置 ldid 的 CMS/证书签名路径。
- iOS 15.x：TrollStore ad-hoc 路径可以尝试系统 `Security.framework` 的签名 SPI；如果该后端无法为目标二进制签名，当前 ldid 又不能在 iOS 15 上运行，则仍会失败。
- iOS 14.x：系统签名 SPI 不存在，当前 ldid 也不兼容，因此没有可用的当前 ad-hoc 签名后端。

源码的 Makefile 部署目标仍声明 iOS 14.0，这不等于所有签名功能都兼容 iOS 14。本次没有伪造或修改 ldid 的最低系统版本；而是给无可用 ad-hoc 后端的情况增加了独立的 199 诊断，并修正其文案，使 iOS 15 后端调用失败时也不会错误地声称系统 API 根本不存在。

## 5. 汇编优化评估

**没有加入汇编。** 当前已检查到的关键工作主要受文件系统、File Provider、Keychain/Security.framework、递归 bundle 遍历和 ldid 进程启动影响；没有测量结果证明某个 CPU 热循环是主要瓶颈。现有签名流程已经限制外层并行度，并在外层并行时把 ldid 内部 jobs 降为 1，避免线程数相乘造成过量并发。没有性能基准支持时加入 arm64/arm64e 汇编，只会增加 ABI、维护和兼容风险。

## 6. 本次可执行检查

以下检查在当前环境通过：

- `python3 Scripts/validate_project.py`：112 个必需文件、5 个 plist、4 个 strings、927 个匹配的简体中文键通过。
- `python3 Scripts/test_custom_install_signing_regressions.py`：Helper 编译条件、证书导入、File Provider、签名错误映射和 UI 自适应回归断言通过。
- `python3 Scripts/test_fastpath_sign_pipeline.py`：每个 Mach-O slice 签名、通用二进制重组和 Framework 包装测试通过。
- `python3 Scripts/test_nsfilecoordinator_contract.py`：NSFileCoordinator API 契约检查通过。
- `bash Scripts/test_theos_only_build.sh`、`bash Scripts/test_fastpath_host_sdk.sh`：构建配置与 SDK/sysroot 传递检查通过；这些是配置检查，不是 iOS 目标实际编译。
- `python3 Scripts/validate_macho.py bin/ldid`：arm64 iOS Mach-O 与最低系统版本检查通过。
- `python3 -m py_compile Scripts/*.py` 与全部 `Scripts/*.sh` 的 `bash -n` 检查通过。

以下项目未能完成：

- `Scripts/validate_choma_api.py`：压缩包只有 `.gitmodules` 和固定的 ChOma revision，没有 `ChOma/` 子模块源码；CI/构建机需运行 `Scripts/bootstrap_choma.sh` 检出指定提交后再验证。
- 完整 Theos/iOS 编译与链接：当前没有 `xcrun`、`xcodebuild`、Theos 安装或 `THEOS` 环境变量。
- 真机证书导入、CMS 签名、安装启动及 UI 视觉回归：本环境没有 iOS 设备，也没有用户证书/profile。

`bin/ldid` 是待打包的原始引导工具，源文件本身尚无 `LC_CODE_SIGNATURE`；工程 `Makefile` 会先把它复制到最终 app 的 `ldid-bootstrap/ldid`，再通过 `fastPathSign` 签名，并对最终产物运行 CodeDirectory 校验。因此对源目录下的 `bin/ldid` 单独运行“必须已有嵌入式签名”的产物校验并不代表最终打包失败。

## 7. 最终说明

本次完成的是源码修复、静态审计和现有回归脚本验证，不是一次在 Apple 工具链上的正式 release build。建议拿到压缩包后，在具备匹配 iOS SDK、Theos 和 ChOma 子模块的 macOS 构建机执行完整 `make`；安装到设备后，重点验证 iOS 15/16、File Provider 本地/云端文件、P12 与 PEM 真实身份，以及最大辅助功能字号布局。
