#import <stdio.h>
#import <stdlib.h>
#import <dirent.h>
#import <string.h>
#import <stdint.h>
#import "unarchive.h"
@import Foundation;
#import "uicache.h"
#import <sys/stat.h>
#import <sys/wait.h>
#import <fcntl.h>
#import <unistd.h>
#import <errno.h>
#import <limits.h>
#import <dlfcn.h>
#import <spawn.h>
#import <TSUtil.h>
#import <sys/utsname.h>
#import <mach-o/loader.h>
#import <mach-o/fat.h>
#import "devmode.h"
#import "jit.h"
#import "TSAppMaintenance.h"
#import "TSAppUpdateControl.h"
#import "TSAppDecryptor.h"
#ifndef EMBEDDED_ROOT_HELPER
#import "codesign.h"
#import "coretrust_bug.h"
#import "FAT.h"
#import "MachO.h"
#import "FileStream.h"
#import "Host.h"
#endif

#import <SpringBoardServices/SpringBoardServices.h>
#import <FrontBoardServices/FBSSystemService.h>
#import <Security/Security.h>
#import <libroot.h>

// Complete edited main-executable Entitlements document for one install transaction.
static NSDictionary *gEditedMainEntitlements = nil;
static BOOL gEditedMainEntitlementsProvided = NO;
static NSDictionary *gSigningConfiguration = nil;
static BOOL gRealSigningMissingProfile = NO;

// Create private extraction/work directories inside TrollStore's own MCM bundle
// container. Never hand libarchive a path beneath NSTemporaryDirectory(): on iOS
// that path can resolve through /var -> /private/var and trigger secure-symlink
// rejection. The MCM container is unique to this app; mkdtemp gives each operation
// a fresh 0700 directory and the resolved path is checked before use.
static NSString *createPrivateTemporaryDirectory(NSString *prefix)
{
    // Use TrollStore's own MCM app-data container instead of /tmp, /var/tmp, or
    // another app's container. createIfNecessary also makes first-time TrollStore
    // installation possible before the TrollStore.app bundle container exists.
    NSError *containerError = nil;
    MCMAppDataContainer *workspaceContainer = [MCMAppDataContainer containerWithIdentifier:APP_ID createIfNecessary:YES existed:nil error:&containerError];
    NSString *ownedContainer = workspaceContainer.url.path;
    char resolvedParent[PATH_MAX] = {0};
    if (!ownedContainer.length || !realpath(ownedContainer.fileSystemRepresentation, resolvedParent)) {
        NSLog(@"[temporary-directory] cannot resolve TrollStore's own app-data container %@: %@ (%s)", ownedContainer, containerError, strerror(errno));
        return nil;
    }
    NSString *canonicalParent = [NSString stringWithUTF8String:resolvedParent];
    NSArray<NSString *> *components = canonicalParent.pathComponents;
    BOOL isOwnedDataContainer =
        ([canonicalParent hasPrefix:@"/private/var/mobile/Containers/Data/Application/"] ||
         [canonicalParent hasPrefix:@"/var/mobile/Containers/Data/Application/"]) &&
        components.count == 8 && [[NSUUID alloc] initWithUUIDString:components.lastObject] != nil;
    struct stat parentStat;
    if (!isOwnedDataContainer || lstat(resolvedParent, &parentStat) != 0 ||
        !S_ISDIR(parentStat.st_mode) || S_ISLNK(parentStat.st_mode)) {
        NSLog(@"[temporary-directory] refusing non-owned/non-canonical TrollStore storage parent %@", canonicalParent);
        return nil;
    }

    NSString *safePrefix = prefix.length ? prefix : @"TrollStore";
    safePrefix = [[safePrefix componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"/\\"]] componentsJoinedByString:@"-"];
    NSString *templatePath = [canonicalParent stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.XXXXXX", safePrefix]];
    if (!templatePath.fileSystemRepresentation || strlen(templatePath.fileSystemRepresentation) >= PATH_MAX) return nil;
    char buffer[PATH_MAX] = {0};
    strlcpy(buffer, templatePath.fileSystemRepresentation, sizeof(buffer));
    char *created = mkdtemp(buffer);
    if (!created) {
        NSLog(@"[temporary-directory] mkdtemp in TrollStore container failed: %s", strerror(errno));
        return nil;
    }
    if (chmod(created, 0700) != 0) {
        int savedErrno = errno;
        rmdir(created);
        NSLog(@"[temporary-directory] chmod failed: %s", strerror(savedErrno));
        return nil;
    }
    struct stat createdStat;
    if (lstat(created, &createdStat) != 0 || !S_ISDIR(createdStat.st_mode) || S_ISLNK(createdStat.st_mode) ||
        createdStat.st_uid != getuid()) {
        rmdir(created);
        NSLog(@"[temporary-directory] created path failed ownership/type validation");
        return nil;
    }
    return [NSString stringWithUTF8String:created];
}

static NSString *canonicalExistingPath(NSString *path)
{
    if (![path isKindOfClass:NSString.class] || !path.length) return nil;
    char resolved[PATH_MAX] = {0};
    if (!realpath(path.fileSystemRepresentation, resolved)) return nil;
    return [NSString stringWithUTF8String:resolved];
}

// Create a unique 0700 staging directory next to an app bundle. Keeping the
// temporary copy on the same filesystem makes the final replacement a rename,
// and lets transfer/update roll back without deleting the original bundle first.
static NSString *createPrivateSiblingTemporaryDirectory(NSString *parentPath, NSString *prefix)
{
    NSString *canonicalParent = canonicalExistingPath(parentPath);
    struct stat parentStat;
    if (!canonicalParent.length || lstat(canonicalParent.fileSystemRepresentation, &parentStat) != 0 ||
        !S_ISDIR(parentStat.st_mode) || S_ISLNK(parentStat.st_mode)) return nil;

    NSString *safePrefix = prefix.length ? prefix : @"TrollStore-work";
    safePrefix = [[safePrefix componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"/\\"]] componentsJoinedByString:@"-"];
    NSString *templatePath = [canonicalParent stringByAppendingPathComponent:[NSString stringWithFormat:@".%@.XXXXXX", safePrefix]];
    if (!templatePath.fileSystemRepresentation || strlen(templatePath.fileSystemRepresentation) >= PATH_MAX) return nil;
    char buffer[PATH_MAX] = {0};
    strlcpy(buffer, templatePath.fileSystemRepresentation, sizeof(buffer));
    char *created = mkdtemp(buffer);
    if (!created) return nil;
    struct stat createdStat;
    if (chmod(created, 0700) != 0 || lstat(created, &createdStat) != 0 ||
        !S_ISDIR(createdStat.st_mode) || S_ISLNK(createdStat.st_mode) || createdStat.st_uid != getuid()) {
        rmdir(created);
        return nil;
    }
    return [NSString stringWithUTF8String:created];
}

static BOOL pathIsWithinDirectory(NSString *path, NSString *directory)
{
    if (!path.length || !directory.length) return NO;
    NSString *root = directory.stringByStandardizingPath;
    NSString *candidate = path.stringByStandardizingPath;
    return [candidate hasPrefix:[root stringByAppendingString:@"/"]];
}

static NSString *safeExecutablePathForBundle(NSString *bundlePath, id executableName, NSString *appRoot)
{
    if (![executableName isKindOfClass:NSString.class] || ![executableName length]) return nil;
    NSString *name = executableName;
    if ([name containsString:@"/"] || [name containsString:@"\\"] ||
        [name isEqualToString:@"."] || [name isEqualToString:@".."] ||
        [name hasPrefix:@"~"]) return nil;
    NSString *candidate = [bundlePath stringByAppendingPathComponent:name];
    NSString *resolved = canonicalExistingPath(candidate);
    NSString *canonicalBundle = canonicalExistingPath(bundlePath);
    NSString *canonicalRoot = canonicalExistingPath(appRoot);
    if (!resolved.length || !canonicalBundle.length || !canonicalRoot.length ||
        !pathIsWithinDirectory(resolved, canonicalBundle) || !pathIsWithinDirectory(resolved, canonicalRoot)) return nil;
    struct stat st;
    if (lstat(resolved.fileSystemRepresentation, &st) != 0 || !S_ISREG(st.st_mode)) return nil;
    return resolved;
}

static NSString *createPrivateTemporaryFile(NSString *prefix, NSString *fileName, NSData *data, NSString **directoryOut)
{
    if (!data || !fileName.length || [fileName containsString:@"/"] || [fileName containsString:@"\\"]) return nil;
    NSString *directory = createPrivateTemporaryDirectory(prefix);
    if (!directory) return nil;
    NSString *path = [directory stringByAppendingPathComponent:fileName];
    NSError *writeError = nil;
    if (![data writeToFile:path options:NSDataWritingAtomic error:&writeError] || chmod(path.fileSystemRepresentation, 0600) != 0) {
        NSLog(@"[temporary-file] could not write %@: %@ (%s)", path, writeError, strerror(errno));
        [[NSFileManager defaultManager] removeItemAtPath:directory error:nil];
        return nil;
    }
    if (directoryOut) *directoryOut = directory;
    return path;
}

static BOOL isManagedAppBundlePath(NSString *path)
{
    NSString *canonical = canonicalExistingPath(path);
    if (!canonical.length || ![canonical.pathExtension.lowercaseString isEqualToString:@"app"]) return NO;
    NSString *prefix = @"/private/var/containers/Bundle/Application/";
    if (![canonical hasPrefix:prefix]) return NO;
    NSArray<NSString *> *components = canonical.pathComponents;
    // /private/var/containers/Bundle/Application/<UUID>/<App>.app
    return components.count == 8 && [[components[5] lowercaseString] isEqualToString:@"application"] &&
        [components[6] length] > 0 && [[NSUUID alloc] initWithUUIDString:components[6]] != nil;
}

#ifdef EMBEDDED_ROOT_HELPER
#define MAIN_NAME rootHelperMain
#else
#define MAIN_NAME main
#endif

void cleanRestrictions(void);
BOOL uninstallPersistenceHelper(void);

extern mach_msg_return_t SBReloadIconForIdentifier(mach_port_t machport, const char* identifier);
@interface SBSHomeScreenService : NSObject
- (void)reloadIcons;
@end
extern NSString* BKSActivateForEventOptionTypeBackgroundContentFetching;
extern NSString* BKSOpenApplicationOptionKeyActivateForEvent;

extern void BKSTerminateApplicationForReasonAndReportWithDescription(NSString *bundleID, int reasonID, bool report, NSString *description);

#define kCFPreferencesNoContainer CFSTR("kCFPreferencesNoContainer")

typedef CFPropertyListRef (*_CFPreferencesCopyValueWithContainerType)(CFStringRef key, CFStringRef applicationID, CFStringRef userName, CFStringRef hostName, CFStringRef containerPath);
typedef void (*_CFPreferencesSetValueWithContainerType)(CFStringRef key, CFPropertyListRef value, CFStringRef applicationID, CFStringRef userName, CFStringRef hostName, CFStringRef containerPath);
typedef Boolean (*_CFPreferencesSynchronizeWithContainerType)(CFStringRef applicationID, CFStringRef userName, CFStringRef hostName, CFStringRef containerPath);
typedef CFArrayRef (*_CFPreferencesCopyKeyListWithContainerType)(CFStringRef applicationID, CFStringRef userName, CFStringRef hostName, CFStringRef containerPath);
typedef CFDictionaryRef (*_CFPreferencesCopyMultipleWithContainerType)(CFArrayRef keysToFetch, CFStringRef applicationID, CFStringRef userName, CFStringRef hostName, CFStringRef containerPath);

BOOL _installPersistenceHelper(LSApplicationProxy* appProxy, NSString* sourcePersistenceHelper, NSString* sourceRootHelper);

NSArray<LSApplicationProxy*>* applicationsWithGroupId(NSString* groupId)
{
	LSEnumerator* enumerator = [LSEnumerator enumeratorForApplicationProxiesWithOptions:0];
	enumerator.predicate = [NSPredicate predicateWithFormat:@"groupContainerURLs[%@] != nil", groupId];
	return enumerator.allObjects;
}

static NSSet<NSString *> *gCachedSystemURLSchemes;
static NSSet<NSString *> *gCachedImmutableAppBundleIdentifiers;
static dispatch_once_t gSystemApplicationMetadataOnce;

// The system-app catalogue is stable during one short-lived RootHelper
// operation. Build both lookups in one LaunchServices pass and reuse them for
// bundle-ID validation, URL-scheme filtering, and final registration.
static void loadSystemApplicationMetadata(void)
{
	dispatch_once(&gSystemApplicationMetadataOnce, ^{
		NSMutableSet<NSString *> *schemes = [NSMutableSet new];
		NSMutableSet<NSString *> *immutableIDs = [NSMutableSet new];
		LSEnumerator *enumerator = [LSEnumerator enumeratorForApplicationProxiesWithOptions:0];
		LSApplicationProxy *proxy = nil;
		while ((proxy = [enumerator nextObject])) {
			NSString *bundleID = proxy.bundleIdentifier;
			NSString *bundlePath = proxy.bundleURL.path ?: @"";
			BOOL isContainerApp = [bundlePath hasPrefix:@"/private/var/containers"];
			if (proxy.installed && !isContainerApp && bundleID.length) {
				[immutableIDs addObject:bundleID.lowercaseString];
			}
			if (isRemovableSystemApp(bundleID) || !isContainerApp) {
				for (id claimedScheme in proxy.claimedURLSchemes) {
					if ([claimedScheme isKindOfClass:NSString.class] && [claimedScheme length]) {
						[schemes addObject:[claimedScheme lowercaseString]];
					}
				}
			}
		}
		gCachedSystemURLSchemes = [schemes copy];
		gCachedImmutableAppBundleIdentifiers = [immutableIDs copy];
	});
}

NSSet<NSString*>* systemURLSchemes(void)
{
	loadSystemApplicationMetadata();
	return gCachedSystemURLSchemes ?: [NSSet set];
}

NSSet<NSString*>* immutableAppBundleIdentifiers(void)
{
	loadSystemApplicationMetadata();
	return gCachedImmutableAppBundleIdentifiers ?: [NSSet set];
}

NSDictionary* infoDictionaryForAppPath(NSString* appPath)
{
	if(!appPath) return nil;
	NSString* infoPlistPath = [appPath stringByAppendingPathComponent:@"Info.plist"];
	return [NSDictionary dictionaryWithContentsOfFile:infoPlistPath];
}

NSString* appIdForAppPath(NSString* appPath)
{
	if(!appPath) return nil;
	return infoDictionaryForAppPath(appPath)[@"CFBundleIdentifier"];
}

NSString* appMainExecutablePathForAppPath(NSString* appPath)
{
	if(!appPath) return nil;
	return [appPath stringByAppendingPathComponent:infoDictionaryForAppPath(appPath)[@"CFBundleExecutable"]];
}

NSString* appPathForAppId(NSString* appId)
{
	if(!appId) return nil;
	for(NSString* appPath in trollStoreInstalledAppBundlePaths())
	{
		if([appIdForAppPath(appPath) isEqualToString:appId])
		{
			return appPath;
		}
	}
	return nil;
}

NSString* findAppNameInBundlePath(NSString* bundlePath)
{
	if (![bundlePath isKindOfClass:NSString.class] || !bundlePath.length) return nil;
	NSString *canonicalBundlePath = canonicalExistingPath(bundlePath);
	if (!canonicalBundlePath.length) return nil;
	struct stat rootStat;
	if (lstat(canonicalBundlePath.fileSystemRepresentation, &rootStat) != 0 || !S_ISDIR(rootStat.st_mode) || S_ISLNK(rootStat.st_mode)) return nil;
	NSArray<NSString *> *items = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:canonicalBundlePath error:nil];
	NSMutableArray<NSString *> *regularApps = [NSMutableArray array];
	NSMutableArray<NSString *> *watchApps = [NSMutableArray array];
	for (NSString *item in items) {
		if (![item.pathExtension.lowercaseString isEqualToString:@"app"]) continue;
		NSString *candidate = [canonicalBundlePath stringByAppendingPathComponent:item];
		struct stat st;
		if (lstat(candidate.fileSystemRepresentation, &st) != 0 || !S_ISDIR(st.st_mode) || S_ISLNK(st.st_mode)) continue;
		NSString *infoPath = [candidate stringByAppendingPathComponent:@"Info.plist"];
		struct stat infoStat;
		NSString *resolvedInfoPath = canonicalExistingPath(infoPath);
		if (!resolvedInfoPath.length || !pathIsWithinDirectory(resolvedInfoPath, canonicalBundlePath) ||
			lstat(infoPath.fileSystemRepresentation, &infoStat) != 0 || !S_ISREG(infoStat.st_mode) || S_ISLNK(infoStat.st_mode)) continue;
		NSDictionary *info = infoDictionaryForAppPath(candidate);
		if (![info isKindOfClass:NSDictionary.class] || ![info[@"CFBundleIdentifier"] isKindOfClass:NSString.class] ||
			![info[@"CFBundleExecutable"] isKindOfClass:NSString.class] ||
			!safeExecutablePathForBundle(candidate, info[@"CFBundleExecutable"], candidate).length) continue;
		BOOL isWatchApp = [info[@"WKWatchKitApp"] respondsToSelector:@selector(boolValue)] && [info[@"WKWatchKitApp"] boolValue];
		NSDictionary *extension = [info[@"NSExtension"] isKindOfClass:NSDictionary.class] ? info[@"NSExtension"] : @{};
		NSString *extensionPoint = [extension[@"NSExtensionPointIdentifier"] isKindOfClass:NSString.class] ? extension[@"NSExtensionPointIdentifier"] : @"";
		isWatchApp = isWatchApp || [extensionPoint.lowercaseString containsString:@"watchkit"] || [item.lowercaseString containsString:@"watchkitapp"];
		[(isWatchApp ? watchApps : regularApps) addObject:item];
	}
	// Watch companion applications may be siblings of the primary iOS app in
	// Payload/. Exclude those, but never select an arbitrary app when multiple
	// independent primary applications remain.
	if (regularApps.count == 1) return regularApps.firstObject;
	if (regularApps.count > 1) {
		NSLog(@"[findAppNameInBundlePath] refusing ambiguous payload with multiple primary apps: %@", regularApps);
		return nil;
	}
	return watchApps.count == 1 ? watchApps.firstObject : nil;
}

NSString* findAppPathInBundlePath(NSString* bundlePath)
{
	NSString* appName = findAppNameInBundlePath(bundlePath);
	if(!appName) return nil;
	return [bundlePath stringByAppendingPathComponent:appName];
}

NSURL* findAppURLInBundleURL(NSURL* bundleURL)
{
	NSString* appName = findAppNameInBundlePath(bundleURL.path);
	if(!appName) return nil;
	return [bundleURL URLByAppendingPathComponent:appName];
}

static BOOL isMachoFileDescriptor(int fd)
{
	uint32_t magic = 0;
	ssize_t bytesRead = pread(fd, &magic, sizeof(magic), 0);
	if (bytesRead != sizeof(magic)) return NO;
	return magic == FAT_MAGIC || magic == FAT_CIGAM || magic == MH_MAGIC_64 || magic == MH_CIGAM_64;
}

// Walk from already-open directory descriptors. This avoids following a package
// symlink while changing ownership or mode bits, including a symlink inserted
// between directory enumeration and metadata updates.
static BOOL fixPermissionsInDirectoryFD(int directoryFD, NSUInteger depth)
{
	if (depth > 256) {
		NSLog(@"[permissions] refusing an app bundle deeper than 256 directory levels");
		return NO;
	}
	int enumerationFD = dup(directoryFD);
	if (enumerationFD < 0) return NO;
	DIR *directory = fdopendir(enumerationFD);
	if (!directory) {
		close(enumerationFD);
		return NO;
	}

	BOOL success = YES;
	for (;;) {
		errno = 0;
		struct dirent *entry = readdir(directory);
		if (!entry) {
			if (errno != 0) success = NO;
			break;
		}
		if (!strcmp(entry->d_name, ".") || !strcmp(entry->d_name, "..")) continue;

		struct stat itemStat;
		if (fstatat(dirfd(directory), entry->d_name, &itemStat, AT_SYMLINK_NOFOLLOW) != 0) {
			NSLog(@"[permissions] cannot inspect bundle entry %s: %s", entry->d_name, strerror(errno));
			success = NO;
			continue;
		}

		if (S_ISLNK(itemStat.st_mode)) {
			if ((itemStat.st_uid != 33 || itemStat.st_gid != 33) &&
				fchownat(dirfd(directory), entry->d_name, 33, 33, AT_SYMLINK_NOFOLLOW) != 0) {
				NSLog(@"[permissions] cannot update symlink owner for %s: %s", entry->d_name, strerror(errno));
				success = NO;
			}
			continue;
		}

		int itemFD = -1;
		if (S_ISDIR(itemStat.st_mode)) {
			itemFD = openat(dirfd(directory), entry->d_name, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
		} else if (S_ISREG(itemStat.st_mode)) {
			itemFD = openat(dirfd(directory), entry->d_name, O_RDONLY | O_NOFOLLOW | O_CLOEXEC);
		} else {
			NSLog(@"[permissions] unsupported special file in app bundle: %s", entry->d_name);
			success = NO;
			continue;
		}
		if (itemFD < 0) {
			NSLog(@"[permissions] cannot open bundle entry %s without following symlinks: %s", entry->d_name, strerror(errno));
			success = NO;
			continue;
		}

		struct stat openedStat;
		if (fstat(itemFD, &openedStat) != 0 || openedStat.st_dev != itemStat.st_dev ||
			openedStat.st_ino != itemStat.st_ino ||
			(S_ISDIR(itemStat.st_mode) ? !S_ISDIR(openedStat.st_mode) : !S_ISREG(openedStat.st_mode))) {
			NSLog(@"[permissions] bundle entry changed while being opened: %s", entry->d_name);
			close(itemFD);
			success = NO;
			continue;
		}

		mode_t desiredMode = S_ISDIR(openedStat.st_mode) || isMachoFileDescriptor(itemFD) ? 0755 : 0644;
		if ((openedStat.st_uid != 33 || openedStat.st_gid != 33) && fchown(itemFD, 33, 33) != 0) {
			NSLog(@"[permissions] cannot update owner for %s: %s", entry->d_name, strerror(errno));
			success = NO;
		}
		if ((openedStat.st_mode & 07777) != desiredMode && fchmod(itemFD, desiredMode) != 0) {
			NSLog(@"[permissions] cannot update mode for %s: %s", entry->d_name, strerror(errno));
			success = NO;
		}

		if (S_ISDIR(openedStat.st_mode) && !fixPermissionsInDirectoryFD(itemFD, depth + 1)) success = NO;
		close(itemFD);
	}
	closedir(directory);
	return success;
}

BOOL fixPermissionsOfAppBundle(NSString* appBundlePath)
{
	if (!appBundlePath.length) return NO;
	char resolvedPath[PATH_MAX] = {0};
	if (!realpath(appBundlePath.fileSystemRepresentation, resolvedPath)) {
		NSLog(@"[permissions] cannot resolve app bundle %@: %s", appBundlePath, strerror(errno));
		return NO;
	}
	struct stat pathStat;
	if (lstat(resolvedPath, &pathStat) != 0 || !S_ISDIR(pathStat.st_mode) || S_ISLNK(pathStat.st_mode)) return NO;
	int rootFD = open(resolvedPath, O_RDONLY | O_DIRECTORY | O_NOFOLLOW | O_CLOEXEC);
	if (rootFD < 0) return NO;
	struct stat openedRootStat;
	if (fstat(rootFD, &openedRootStat) != 0 || openedRootStat.st_dev != pathStat.st_dev ||
		openedRootStat.st_ino != pathStat.st_ino || !S_ISDIR(openedRootStat.st_mode)) {
		close(rootFD);
		return NO;
	}

	BOOL success = YES;
	if ((openedRootStat.st_uid != 33 || openedRootStat.st_gid != 33) && fchown(rootFD, 33, 33) != 0) {
		NSLog(@"[permissions] cannot update app bundle owner %@: %s", appBundlePath, strerror(errno));
		success = NO;
	}
	if ((openedRootStat.st_mode & 07777) != 0755 && fchmod(rootFD, 0755) != 0) {
		NSLog(@"[permissions] cannot update app bundle mode %@: %s", appBundlePath, strerror(errno));
		success = NO;
	}
	if (!fixPermissionsInDirectoryFD(rootFD, 0)) success = NO;
	close(rootFD);
	return success;
}

// Prefer a same-volume rename; if a cross-volume move fails, fall back to a copy.
static BOOL moveItemWithCopyFallback(NSString *sourcePath, NSString *destinationPath, NSError **errorOut)
{
	NSFileManager *fileManager = [NSFileManager defaultManager];
	if (!sourcePath.length || !destinationPath.length || [fileManager fileExistsAtPath:destinationPath]) {
		if (errorOut) *errorOut = [NSError errorWithDomain:NSCocoaErrorDomain code:NSFileWriteFileExistsError userInfo:@{NSLocalizedDescriptionKey:@"The staged install destination already exists or is invalid."}];
		return NO;
	}
	NSError *moveError = nil;
	if([fileManager moveItemAtPath:sourcePath toPath:destinationPath error:&moveError]) return YES;

	NSError *copyError = nil;
	if([fileManager copyItemAtPath:sourcePath toPath:destinationPath error:&copyError])
	{
		// The destination is committed once the full copy succeeds. Source cleanup
		// is best-effort because the caller also removes its private staging folder.
		NSError *cleanupError = nil;
		if (![fileManager removeItemAtPath:sourcePath error:&cleanupError])
			NSLog(@"[install] copied staged bundle but could not remove its source %@: %@", sourcePath, cleanupError);
		return YES;
	}
	// NSFileManager may leave a partial destination when a recursive copy fails.
	[fileManager removeItemAtPath:destinationPath error:nil];
	if(errorOut) *errorOut = copyError ?: moveError;
	return NO;
}

static BOOL rollbackAppBundleUpdate(NSString *newBundlePath, NSString *oldBundlePath, NSString *backupPath)
{
	NSFileManager *fm = NSFileManager.defaultManager;
	NSString *expectedParent = backupPath.length ? backupPath.stringByDeletingLastPathComponent : oldBundlePath.stringByDeletingLastPathComponent;
	if (!expectedParent.length && newBundlePath.length) expectedParent = newBundlePath.stringByDeletingLastPathComponent;
	NSString *canonicalParent = expectedParent.length ? canonicalExistingPath(expectedParent) : nil;
	if (newBundlePath.length) {
		struct stat stagedStat;
		if (lstat(newBundlePath.fileSystemRepresentation, &stagedStat) == 0) {
			NSString *canonicalStaged = canonicalExistingPath(newBundlePath);
			if (!canonicalParent.length || !S_ISDIR(stagedStat.st_mode) || S_ISLNK(stagedStat.st_mode) ||
				![canonicalStaged.stringByDeletingLastPathComponent isEqualToString:canonicalParent] ||
				![canonicalStaged.pathExtension.lowercaseString isEqualToString:@"app"]) {
				NSLog(@"[installApp] refusing to remove an unexpected staged update path %@", newBundlePath);
				return NO;
			}
			NSError *removeError = nil;
			if (![fm removeItemAtPath:canonicalStaged error:&removeError]) {
				NSLog(@"[installApp] cannot remove failed staged update %@: %@", canonicalStaged, removeError);
				return NO;
			}
		} else if (errno != ENOENT) {
			NSLog(@"[installApp] cannot inspect failed staged update %@: %s", newBundlePath, strerror(errno));
			return NO;
		}
	}
	if (backupPath.length) {
		struct stat backupStat;
		if (lstat(backupPath.fileSystemRepresentation, &backupStat) == 0) {
			NSString *canonicalBackup = canonicalExistingPath(backupPath);
			if (!oldBundlePath.length || !canonicalParent.length || !S_ISDIR(backupStat.st_mode) || S_ISLNK(backupStat.st_mode) ||
				![canonicalBackup.stringByDeletingLastPathComponent isEqualToString:canonicalParent] ||
				![canonicalBackup.lastPathComponent hasPrefix:@".TrollStore.UpdateBackup."]) {
				NSLog(@"[installApp] refusing to restore an unexpected update backup %@", backupPath);
				return NO;
			}
			struct stat originalStat;
			if (lstat(oldBundlePath.fileSystemRepresentation, &originalStat) == 0 || errno != ENOENT) {
				NSLog(@"[installApp] update rollback has an unexpected original bundle at %@; backup retained at %@", oldBundlePath, backupPath);
				return NO;
			}
			NSError *restoreError = nil;
			if (![fm moveItemAtPath:canonicalBackup toPath:oldBundlePath error:&restoreError]) {
				NSLog(@"[installApp] failed to restore previous app bundle %@ from %@: %@", oldBundlePath, canonicalBackup, restoreError);
				return NO;
			}
			if (!registerPath(oldBundlePath, NO, !shouldRegisterAsUserByDefault()))
				NSLog(@"[installApp] previous app bundle was restored but re-registration failed: %@", oldBundlePath);
		} else if (errno != ENOENT) {
			NSLog(@"[installApp] cannot inspect update backup %@: %s", backupPath, strerror(errno));
			return NO;
		}
	}
	return YES;
}

NSArray* TSURLScheme(void)
{
	return @[
		@{
			@"CFBundleURLName" : @"com.apple.Magnifier",
			@"CFBundleURLSchemes" : @[
				@"apple-magnifier"
			]
		}
	];
}

BOOL getTSURLSchemeState(NSString* customAppPath)
{
	NSString* pathToUse = customAppPath ?: trollStoreAppPath();

	NSDictionary* trollStoreInfoDict = infoDictionaryForAppPath(pathToUse);
	return (BOOL)trollStoreInfoDict[@"CFBundleURLTypes"];
}

void setTSURLSchemeState(BOOL newState, NSString* customAppPath)
{
	NSString* tsAppPath = trollStoreAppPath();
	NSString* pathToUse = customAppPath ?: tsAppPath;
	if(newState != getTSURLSchemeState(pathToUse))
	{
		NSDictionary* trollStoreInfoDict = infoDictionaryForAppPath(pathToUse);
		NSMutableDictionary* trollStoreInfoDictM = trollStoreInfoDict.mutableCopy;
		if(newState)
		{
			trollStoreInfoDictM[@"CFBundleURLTypes"] = TSURLScheme();
		}
		else
		{
			[trollStoreInfoDictM removeObjectForKey:@"CFBundleURLTypes"];
		}
		NSString* outPath = [pathToUse stringByAppendingPathComponent:@"Info.plist"];
		[trollStoreInfoDictM.copy writeToURL:[NSURL fileURLWithPath:outPath] error:nil];
	}
}

#ifdef TROLLSTORE_LITE

BOOL isLdidInstalled(void)
{
	// Since TrollStore Lite depends on ldid, we assume it exists
	return YES;
}

NSString *getLdidPath(void)
{
	return JBROOT_PATH(@"/usr/bin/ldid");
}

#else

int installLdid(NSString* ldidToCopyPath)
{
	if(!ldidToCopyPath.length || ![[NSFileManager defaultManager] isReadableFileAtPath:ldidToCopyPath]) return 1;

	NSString* ldidPath = [trollStoreAppPath() stringByAppendingPathComponent:@"ldid"];
	NSString* sourcePath = [ldidToCopyPath stringByStandardizingPath];
	NSString* targetPath = [ldidPath stringByStandardizingPath];
	NSFileManager* fileManager = [NSFileManager defaultManager];

	// Never remove the live tool if source and destination happen to be identical.
	if([sourcePath isEqualToString:targetPath])
	{
		return chmod(ldidPath.fileSystemRepresentation, 0755) == 0 ? 0 : 2;
	}

	NSString* temporaryPath = [ldidPath stringByAppendingFormat:@".new.%@", NSUUID.UUID.UUIDString];
	NSString* backupPath = [ldidPath stringByAppendingFormat:@".old.%@", NSUUID.UUID.UUIDString];
	NSError* copyError = nil;
	if(![fileManager copyItemAtPath:sourcePath toPath:temporaryPath error:&copyError])
	{
		NSLog(@"[ldid] failed to stage bundled binary: %@", copyError);
		return 3;
	}
	if(chmod(temporaryPath.fileSystemRepresentation, 0755) != 0)
	{
		[fileManager removeItemAtPath:temporaryPath error:nil];
		return 4;
	}

	BOOL hadExistingTool = [fileManager fileExistsAtPath:ldidPath];
	if(hadExistingTool && ![fileManager moveItemAtPath:ldidPath toPath:backupPath error:&copyError])
	{
		[fileManager removeItemAtPath:temporaryPath error:nil];
		NSLog(@"[ldid] failed to back up active binary: %@", copyError);
		return 5;
	}
	if(![fileManager moveItemAtPath:temporaryPath toPath:ldidPath error:&copyError])
	{
		if(hadExistingTool) [fileManager moveItemAtPath:backupPath toPath:ldidPath error:nil];
		[fileManager removeItemAtPath:temporaryPath error:nil];
		NSLog(@"[ldid] failed to activate bundled binary: %@", copyError);
		return 6;
	}
	if(hadExistingTool) [fileManager removeItemAtPath:backupPath error:nil];
	return 0;
}

BOOL isLdidInstalled(void)
{
	NSString* ldidPath = [trollStoreAppPath() stringByAppendingPathComponent:@"ldid"];
	return [[NSFileManager defaultManager] fileExistsAtPath:ldidPath];
}

NSString *getLdidPath(void)
{
	return [trollStoreAppPath() stringByAppendingPathComponent:@"ldid"];
}

#endif

int runLdid(NSArray* args, NSString** errorOutput)
{
	NSString *ldidPath = getLdidPath();
	NSMutableArray *argsM = args.mutableCopy ?: [NSMutableArray new];
	[argsM insertObject:ldidPath.lastPathComponent atIndex:0];

	NSUInteger argCount = argsM.count;
	char **argsC = calloc(argCount + 1, sizeof(char *));
	if(!argsC) return ENOMEM;
	for(NSUInteger i = 0; i < argCount; i++)
	{
		const char *utf8 = [[argsM objectAtIndex:i] UTF8String];
		argsC[i] = strdup(utf8 ?: "");
		if(!argsC[i])
		{
			for(NSUInteger j = 0; j < i; j++) free(argsC[j]);
			free(argsC);
			return ENOMEM;
		}
	}

	int stderrPipe[2] = {-1, -1};
	if(pipe(stderrPipe) != 0)
	{
		int savedError = errno;
		for(NSUInteger i = 0; i < argCount; i++) free(argsC[i]);
		free(argsC);
		return savedError;
	}
	posix_spawn_file_actions_t actions;
	int actionError = posix_spawn_file_actions_init(&actions);
	if(actionError != 0)
	{
		close(stderrPipe[0]); close(stderrPipe[1]);
		for(NSUInteger i = 0; i < argCount; i++) free(argsC[i]);
		free(argsC);
		return actionError;
	}
	actionError = posix_spawn_file_actions_adddup2(&actions, stderrPipe[1], STDERR_FILENO);
	if(actionError == 0) actionError = posix_spawn_file_actions_adddup2(&actions, stderrPipe[1], STDOUT_FILENO);
	if(actionError == 0) actionError = posix_spawn_file_actions_addclose(&actions, stderrPipe[0]);
	if(actionError == 0) actionError = posix_spawn_file_actions_addclose(&actions, stderrPipe[1]);
	if(actionError != 0)
	{
		posix_spawn_file_actions_destroy(&actions);
		close(stderrPipe[0]); close(stderrPipe[1]);
		for(NSUInteger i = 0; i < argCount; i++) free(argsC[i]);
		free(argsC);
		return actionError;
	}

	pid_t taskPID = 0;
	int spawnError = posix_spawn(&taskPID, ldidPath.fileSystemRepresentation, &actions, NULL, argsC, NULL);
	posix_spawn_file_actions_destroy(&actions);
	for(NSUInteger i = 0; i < argCount; i++) free(argsC[i]);
	free(argsC);
	close(stderrPipe[1]);
	if(spawnError != 0)
	{
		close(stderrPipe[0]);
		return spawnError;
	}

	// Drain stderr while the child runs; waiting before reading can deadlock on a full pipe.
	NSMutableData *stderrData = [NSMutableData data];
	const NSUInteger diagnosticLimit = 1024 * 1024;
	uint8_t buffer[8192];
	for(;;)
	{
		ssize_t bytesRead = read(stderrPipe[0], buffer, sizeof(buffer));
		if(bytesRead > 0)
		{
			// Keep diagnostics bounded while continuing to drain the pipe fully.
			NSUInteger available = stderrData.length < diagnosticLimit ? diagnosticLimit - stderrData.length : 0;
			NSUInteger appendLength = MIN((NSUInteger)bytesRead, available);
			if(appendLength) [stderrData appendBytes:buffer length:appendLength];
			continue;
		}
		if(bytesRead < 0 && errno == EINTR) continue;
		break;
	}
	close(stderrPipe[0]);

	int status = 0;
	pid_t waitResult;
	do { waitResult = waitpid(taskPID, &status, 0); } while(waitResult < 0 && errno == EINTR);
	if(waitResult < 0) return -222;
	if(errorOutput) *errorOutput = [[NSString alloc] initWithData:stderrData encoding:NSUTF8StringEncoding] ?: @"";
	if(WIFEXITED(status)) return WEXITSTATUS(status);
	if(WIFSIGNALED(status)) return 128 + WTERMSIG(status);
	return -223;
}

BOOL certificateHasDataForExtensionOID(SecCertificateRef certificate, CFStringRef oidString)
{
	if(certificate == NULL || oidString == NULL)
	{
		NSLog(@"[certificateHasDataForExtensionOID] attempted to check null certificate or OID");
		return NO;
	}
	
	CFDataRef extensionData = SecCertificateCopyExtensionValue(certificate, oidString, NULL);
	if(extensionData != NULL)
	{
		CFRelease(extensionData);
		return YES;
	}
	
	return NO;
}

BOOL codeCertChainContainsFakeAppStoreExtensions(SecStaticCodeRef codeRef)
{
	if(codeRef == NULL)
	{
		NSLog(@"[codeCertChainContainsFakeAppStoreExtensions] attempted to check cert chain of null static code object");
		return NO;
	}
	
	CFDictionaryRef signingInfo = NULL;
	OSStatus result;
  
	result = SecCodeCopySigningInformation(codeRef, kSecCSSigningInformation, &signingInfo);

	if(result != errSecSuccess)
	{
		NSLog(@"[codeCertChainContainsFakeAppStoreExtensions] failed to copy signing info from static code");
		return NO;
	}
	
	CFArrayRef certificates = CFDictionaryGetValue(signingInfo, kSecCodeInfoCertificates);
	if(certificates == NULL || CFArrayGetCount(certificates) == 0)
	{
		return NO;
	}

	// If we match the standard Apple policy, we are signed properly, but we haven't been deliberately signed with a custom root
	
	SecPolicyRef appleAppStorePolicy = SecPolicyCreateWithProperties(kSecPolicyAppleiPhoneApplicationSigning, NULL);

	SecTrustRef trust = NULL;
	SecTrustCreateWithCertificates(certificates, appleAppStorePolicy, &trust);

	if(SecTrustEvaluateWithError(trust, nil))
	{
		CFRelease(trust);
		CFRelease(appleAppStorePolicy);
		CFRelease(signingInfo);
		
		NSLog(@"[codeCertChainContainsFakeAppStoreExtensions] found certificate extension, but was issued by Apple (App Store)");
		return NO;
	}

	// We haven't matched Apple, so keep going. Is the app profile signed?
		
	CFRelease(appleAppStorePolicy);
	
	SecPolicyRef appleProfileSignedPolicy = SecPolicyCreateWithProperties(kSecPolicyAppleiPhoneProfileApplicationSigning, NULL);
	if(SecTrustSetPolicies(trust, appleProfileSignedPolicy) != errSecSuccess)
	{
		NSLog(@"[codeCertChainContainsFakeAppStoreExtensions] error replacing trust policy to check for profile-signed app");
		CFRelease(trust);
		CFRelease(signingInfo);
		return NO;
	}
		
	if(SecTrustEvaluateWithError(trust, nil))
	{
		CFRelease(trust);
		CFRelease(appleProfileSignedPolicy);
		CFRelease(signingInfo);
		
		NSLog(@"[codeCertChainContainsFakeAppStoreExtensions] found certificate extension, but was issued by Apple (profile-signed)");
		return NO;
	}
	
	// Still haven't matched Apple. Are we using a custom root that would take the App Store fastpath?
	CFRelease(appleProfileSignedPolicy);
	
	// Cert chain should be of length 3
	if(CFArrayGetCount(certificates) != 3)
	{
		CFRelease(signingInfo);
		
		NSLog(@"[codeCertChainContainsFakeAppStoreExtensions] certificate chain length != 3");
		return NO;
	}
		
	// AppleCodeSigning only checks for the codeSigning EKU by default
	SecPolicyRef customRootPolicy = SecPolicyCreateWithProperties(kSecPolicyAppleCodeSigning, NULL);
	SecPolicySetOptionsValue(customRootPolicy, CFSTR("LeafMarkerOid"), CFSTR("1.2.840.113635.100.6.1.3"));
	
	if(SecTrustSetPolicies(trust, customRootPolicy) != errSecSuccess)
	{
		NSLog(@"[codeCertChainContainsFakeAppStoreExtensions] error replacing trust policy to check for custom root");
		CFRelease(trust);
		CFRelease(signingInfo);
		return NO;
	}

	// Need to add our certificate chain to the anchor as it is expected to be a self-signed root
	SecTrustSetAnchorCertificates(trust, certificates);
	
	BOOL evaluatesToCustomAnchor = SecTrustEvaluateWithError(trust, nil);
	NSLog(@"[codeCertChainContainsFakeAppStoreExtensions] app signed with non-Apple certificate %@ using valid custom certificates", evaluatesToCustomAnchor ? @"IS" : @"is NOT");
	
	CFRelease(trust);
	CFRelease(customRootPolicy);
	CFRelease(signingInfo);
	
	return evaluatesToCustomAnchor;
}

#ifndef EMBEDDED_ROOT_HELPER
BOOL isSameFile(NSString *path1, NSString *path2)
{
	struct stat sb1;
	struct stat sb2;
	if (stat(path1.fileSystemRepresentation, &sb1) != 0 || stat(path2.fileSystemRepresentation, &sb2) != 0)
		return NO;
	return sb1.st_dev == sb2.st_dev && sb1.st_ino == sb2.st_ino;
}

// MicroCore fast path: cheaply classify file headers before asking ChOma to parse
// every file in a bundle. IPA assets and plists still get enumerated for metadata,
// but are not passed through FAT/Mach-O parsing during the CoreTrust pass.
static BOOL fileMayContainMachOAtPath(NSString *path)
{
	struct stat fileStat;
	if (lstat(path.fileSystemRepresentation, &fileStat) != 0 || !S_ISREG(fileStat.st_mode) || S_ISLNK(fileStat.st_mode)) return NO;
	int fd = open(path.fileSystemRepresentation, O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
	if (fd < 0) return NO;
	uint8_t magic[4] = {0};
	size_t totalRead = 0;
	while (totalRead < sizeof(magic)) {
		ssize_t bytesRead = read(fd, magic + totalRead, sizeof(magic) - totalRead);
		if (bytesRead < 0 && errno == EINTR) continue;
		if (bytesRead <= 0) {
			close(fd);
			return NO;
		}
		totalRead += (size_t)bytesRead;
	}
	close(fd);

	// Mach-O 32/64, swapped Mach-O and FAT/FAT64 headers in either byte order.
	return
		(magic[0] == 0xFE && magic[1] == 0xED && magic[2] == 0xFA && (magic[3] == 0xCE || magic[3] == 0xCF)) ||
		((magic[0] == 0xCE || magic[0] == 0xCF) && magic[1] == 0xFA && magic[2] == 0xED && magic[3] == 0xFE) ||
		(magic[0] == 0xCA && magic[1] == 0xFE && magic[2] == 0xBA && (magic[3] == 0xBE || magic[3] == 0xBF)) ||
		((magic[0] == 0xBE || magic[0] == 0xBF) && magic[1] == 0xBA && magic[2] == 0xFE && magic[3] == 0xCA);
}
#endif // !EMBEDDED_ROOT_HELPER

#ifdef EMBEDDED_ROOT_HELPER
// The embedded root helper is not able to sign apps
// But it does not need that functionality anyways

int signApp(NSString* appPath)
{
	return -1;
}
#else
static BOOL currentOSSupportsBundledLdid(void)
{
	// The supplied ldid build is confirmed by its author to support iOS 14+.
	// Its LC_BUILD_VERSION minimum is normalized to iOS 14.0 in the packaged binary.
	if (@available(iOS 14.0, *)) return YES;
	return NO;
}

static NSString *createExactEntitlementsSigningConfig(NSString **errorOutput)
{
	NSString *sourcePath = gSigningConfiguration[@"ldidConfigPath"];
	NSString *profileName = gSigningConfiguration[@"profileName"];
	if (![sourcePath isKindOfClass:NSString.class] || !sourcePath.length || ![profileName isKindOfClass:NSString.class] || !profileName.length) {
		if (errorOutput) *errorOutput = @"The active signing profile has no readable ldid configuration or profile name.";
		return nil;
	}
	NSData *sourceData = [NSData dataWithContentsOfFile:sourcePath];
	NSError *jsonError = nil;
	id rootObject = sourceData ? [NSJSONSerialization JSONObjectWithData:sourceData options:NSJSONReadingMutableContainers error:&jsonError] : nil;
	if (![rootObject isKindOfClass:NSMutableDictionary.class]) {
		if (errorOutput) *errorOutput = jsonError.localizedDescription ?: @"The active ldid configuration is not a JSON dictionary.";
		return nil;
	}
	NSMutableDictionary *root = rootObject;
	NSMutableDictionary *defaults = [root[@"defaults"] isKindOfClass:NSDictionary.class] ? [root[@"defaults"] mutableCopy] : [NSMutableDictionary new];
	NSMutableDictionary *profiles = [root[@"profiles"] isKindOfClass:NSDictionary.class] ? [root[@"profiles"] mutableCopy] : nil;
	NSMutableDictionary *profile = [profiles[profileName] isKindOfClass:NSDictionary.class] ? [profiles[profileName] mutableCopy] : nil;
	if (!profiles || !profile) {
		if (errorOutput) *errorOutput = [NSString stringWithFormat:@"The active ldid profile '%@' is missing.", profileName];
		return nil;
	}
	// The stock prebuilt ldid supports --config/--profile but does not need a new CLI
	// switch. Clone the active profile and turn off every entitlement merge/preserve
	// default, while retaining its certificate, team, hash and jobs settings.
	for (NSMutableDictionary *section in @[defaults, profile]) {
		section[@"preserveEntitlements"] = @NO;
		section[@"mergeOnly"] = @NO;
		section[@"mergeDeep"] = @NO;
		[section removeObjectForKey:@"mergeEntitlements"];
	}
	root[@"defaults"] = defaults;
	profiles[profileName] = profile;
	root[@"profiles"] = profiles;
	NSData *json = [NSJSONSerialization dataWithJSONObject:root options:NSJSONWritingPrettyPrinted error:&jsonError];
	if (!json) {
		if (errorOutput) *errorOutput = jsonError.localizedDescription ?: @"Unable to serialize an exact-Entitlements ldid profile.";
		return nil;
	}
	NSString *temporaryDirectory = nil;
	NSString *path = createPrivateTemporaryFile(@"TrollStore-signing-config", @"ldid-config.json", json, &temporaryDirectory);
	if (path && chmod(path.fileSystemRepresentation, 0600) != 0) {
		NSLog(@"[signApp] could not restrict temporary signing configuration permissions: %s", strerror(errno));
		[[NSFileManager defaultManager] removeItemAtPath:temporaryDirectory error:nil];
		path = nil;
	}
	if (!path) {
		if (errorOutput) *errorOutput = jsonError.localizedDescription ?: @"Unable to write the temporary exact-Entitlements ldid profile in TrollStore's private data container.";
		return nil;
	}
	return path;
}

static int runLdidWithSigningConfiguration(NSArray *arguments, NSString **errorOutput, NSString *configPathOverride)
{
	if (!gSigningConfiguration) return runLdid(arguments, errorOutput);
	NSString *configPath = configPathOverride ?: gSigningConfiguration[@"ldidConfigPath"];
	NSString *profileName = gSigningConfiguration[@"profileName"];
	if (![configPath isKindOfClass:NSString.class] || ![profileName isKindOfClass:NSString.class] || !configPath.length || !profileName.length) return 190;
	NSMutableArray *configuredArguments = [NSMutableArray arrayWithObjects:@"--config", configPath, @"--profile", profileName, nil];
	[configuredArguments addObjectsFromArray:arguments ?: @[]];
	return runLdid(configuredArguments, errorOutput);
}


static BOOL ldidSupportsSignatureApplyDeepOptions(void)
{
    NSString *ldidPath = getLdidPath();
    NSError *readError = nil;
    NSData *binary = [NSData dataWithContentsOfFile:ldidPath options:NSDataReadingMappedIfSafe error:&readError];
    if (!binary.length) {
        NSLog(@"[ldid] unable to inspect signature-apply capabilities at %@: %@", ldidPath, readError);
        return NO;
    }
    // Older bundled executables support --deep for normal signing but not after
    // --signature-apply. Gate those extra arguments on the exact new usage marker
    // so the Apple Internal path remains compatible with the shipped binary.
    NSString *markerString = @"[--p12 file | --cert cert.pem --key key.pem | --adhoc] [--deep] [--super-deep]";
    NSData *marker = [markerString dataUsingEncoding:NSUTF8StringEncoding];
    return marker.length && [binary rangeOfData:marker options:0 range:NSMakeRange(0, binary.length)].location != NSNotFound;
}

static int runAppleInternalProfileSignature(NSString *bundlePath, NSString **errorOutput)
{
    if (!isLdidInstalled()) {
        if (errorOutput) *errorOutput = @"The bundled ldid tool must be initialized before Apple Internal signing.";
        return 173;
    }
    if (!currentOSSupportsBundledLdid()) {
        if (errorOutput) *errorOutput = @"The bundled ldid tool requires iOS 14.0 or later.";
        return 195;
    }
    NSString *templatePath = gSigningConfiguration[@"customSignatureTemplatePath"];
    NSString *format = gSigningConfiguration[@"credentialFormat"];
    NSString *credentialPath = gSigningConfiguration[@"credentialPath"];
    if (![templatePath isKindOfClass:NSString.class] || !templatePath.length ||
        ![[NSFileManager defaultManager] fileExistsAtPath:templatePath] ||
        ![bundlePath isKindOfClass:NSString.class] || !bundlePath.length) {
        if (errorOutput) *errorOutput = @"Apple Internal signature template or input bundle is missing.";
        return 190;
    }
    NSMutableArray<NSString *> *arguments = [NSMutableArray arrayWithObjects:@"--signature-apply", templatePath, bundlePath, nil];
    if (ldidSupportsSignatureApplyDeepOptions()) {
        [arguments addObject:@"--deep"];
        if (![gSigningConfiguration[@"superDeep"] isKindOfClass:NSNumber.class] || [gSigningConfiguration[@"superDeep"] boolValue])
            [arguments addObject:@"--super-deep"];
    } else {
        NSLog(@"[ldid] bundled binary predates deep options for --signature-apply; continuing with the template's existing signing scope. Rebuild and replace ldid to enable this option for Apple Internal profiles.");
    }
    if ([format isEqualToString:@"p12"]) {
        if (![credentialPath isKindOfClass:NSString.class] || !credentialPath.length || ![[NSFileManager defaultManager] fileExistsAtPath:credentialPath]) {
            if (errorOutput) *errorOutput = @"Apple Internal P12 identity file is missing.";
            return 190;
        }
        [arguments addObjectsFromArray:@[@"--p12", credentialPath, @"--password", gSigningConfiguration[@"password"] ?: @""]];
    } else if ([format isEqualToString:@"pem"]) {
        NSString *certificatePath = gSigningConfiguration[@"certificatePath"];
        NSString *privateKeyPath = gSigningConfiguration[@"privateKeyPath"];
        if (![certificatePath isKindOfClass:NSString.class] || !certificatePath.length ||
            ![privateKeyPath isKindOfClass:NSString.class] || !privateKeyPath.length ||
            ![[NSFileManager defaultManager] fileExistsAtPath:certificatePath] ||
            ![[NSFileManager defaultManager] fileExistsAtPath:privateKeyPath]) {
            if (errorOutput) *errorOutput = @"Apple Internal PEM certificate or private key is missing.";
            return 190;
        }
        [arguments addObjectsFromArray:@[@"--cert", certificatePath, @"--key", privateKeyPath]];
        NSString *password = gSigningConfiguration[@"password"];
        if ([password isKindOfClass:NSString.class] && password.length) [arguments addObjectsFromArray:@[@"--password", password]];
    } else {
        if (errorOutput) *errorOutput = @"Apple Internal signing requires a P12 or PEM certificate/private-key identity.";
        return 190;
    }
    return runLdid(arguments, errorOutput);
}

static int signAdhocInternal(NSString *filePath, NSDictionary *entitlements, BOOL limitLdidJobs, BOOL replaceEntitlements)
{
	BOOL ldidRuntimeSupported = YES;
#ifndef TROLLSTORE_LITE
	ldidRuntimeSupported = currentOSSupportsBundledLdid();
#endif
	BOOL bundledLdidUsable = isLdidInstalled() && ldidRuntimeSupported;
	// Never mutate the process-wide configuration from a worker thread. In particular,
	// a fallback on one executable must not change the signing mode of another task.
	NSDictionary *activeSigningConfiguration = gSigningConfiguration;
	if (activeSigningConfiguration && [activeSigningConfiguration[@"mode"] isEqualToString:@"troll"] && !bundledLdidUsable) {
		NSLog(@"[signAdhoc] bundled ldid is missing or requires iOS 14.0+; using the native TrollStore ad-hoc signer where available. The selected ldid template applies only when the bundled binary is compatible.");
		activeSigningConfiguration = nil;
	}
	if (activeSigningConfiguration) {
		if (!isLdidInstalled()) return 173;
		if (!ldidRuntimeSupported) return 195;
		NSString *entitlementsPath = nil;
		NSString *entitlementsDirectory = nil;
		NSMutableArray *arguments = [NSMutableArray new];
		if (entitlements.count || replaceEntitlements) {
			NSError *serializationError = nil;
			NSData *xml = [NSPropertyListSerialization dataWithPropertyList:entitlements format:NSPropertyListXMLFormat_v1_0 options:0 error:&serializationError];
			if (!xml) { NSLog(@"[signAdhoc] entitlement serialization failed: %@", serializationError); return 175; }
			entitlementsPath = createPrivateTemporaryFile(@"TrollStore-entitlements", @"entitlements.plist", xml, &entitlementsDirectory);
			if (!entitlementsPath) return 175;
			[arguments addObject:[@"-S" stringByAppendingString:entitlementsPath]];
			if (!replaceEntitlements) {
				[arguments addObjectsFromArray:@[@"--merge-deep", @"-M"]];
			}
		} else if (![activeSigningConfiguration[@"mode"] isEqualToString:@"real"] && ![activeSigningConfiguration[@"mode"] isEqualToString:@"certificate-only"]) {
			[arguments addObjectsFromArray:@[@"-s", @"-M"]];
		} else {
			// CMS mode is selected by the profile's P12 or PEM identity. Never add -s here.
			// This also applies to profile-free Pure Certificate Signing.
			[arguments addObject:@"-M"];
		}
		// When independent files are already being signed in parallel, reserve ldid's
		// internal worker pool for the outer queue to avoid jobs × jobs oversubscription.
		if (limitLdidJobs) [arguments addObjectsFromArray:@[@"--jobs", @"1"]];
		[arguments addObject:filePath];
		NSString *output = nil;
		NSString *exactEntitlementsConfigPath = nil;
		if (replaceEntitlements) {
			exactEntitlementsConfigPath = createExactEntitlementsSigningConfig(&output);
			if (!exactEntitlementsConfigPath) {
				if (entitlementsDirectory) [[NSFileManager defaultManager] removeItemAtPath:entitlementsDirectory error:nil];
				NSLog(@"[signAdhoc] unable to build exact-Entitlements signing profile for %@: %@", filePath, output ?: @"");
				return 190;
			}
		}
		int status = runLdidWithSigningConfiguration(arguments, &output, exactEntitlementsConfigPath);
		if (exactEntitlementsConfigPath) [[NSFileManager defaultManager] removeItemAtPath:exactEntitlementsConfigPath.stringByDeletingLastPathComponent error:nil];
		if (entitlementsDirectory) [[NSFileManager defaultManager] removeItemAtPath:entitlementsDirectory error:nil];
		if (status != 0) { NSLog(@"[signAdhoc] configured ldid failed (%d) for %@: %@", status, filePath, output ?: @""); return 175; }
		return 0;
	}
#ifndef TROLLSTORE_LITE
	// On iOS 15+, try the in-process SecCodeSigner path first. It avoids spawning
	// a separate ldid process for every nested executable. iOS 14 keeps using the
	// supplied ldid. Any native signer error falls back to ldid for compatibility.
	if (@available(iOS 15.0, *)) {
		int nativeRet = codesign_sign_adhoc(filePath.fileSystemRepresentation, true, entitlements);
		if (nativeRet == 0) return 0;
		NSLog(@"[signAdhoc] in-process signer returned %d for %@; falling back to bundled ldid", nativeRet, filePath);
	}
#endif
	if (!ldidRuntimeSupported) return 195;
	if(!isLdidInstalled()) return 173;

	NSString *entitlementsPath = nil;
	NSString *entitlementsDirectory = nil;
	NSString *signArg = @"-s";
	NSString* errorOutput = nil;
	if(entitlements)
	{
		NSError *serializationError = nil;
		NSData *entitlementsXML = [NSPropertyListSerialization dataWithPropertyList:entitlements format:NSPropertyListXMLFormat_v1_0 options:0 error:&serializationError];
		if (!entitlementsXML) {
			NSLog(@"[signAdhoc] failed to serialize entitlements for %@: %@", filePath, serializationError);
			return 175;
		}
		entitlementsPath = createPrivateTemporaryFile(@"TrollStore-entitlements", @"entitlements.plist", entitlementsXML, &entitlementsDirectory);
		if (!entitlementsPath) {
			NSLog(@"[signAdhoc] failed to write private temporary entitlements for %@", filePath);
			return 175;
		}
		signArg = [@"-S" stringByAppendingString:entitlementsPath];
	}

	int ldidRet = runLdid(@[signArg, filePath], &errorOutput);
	if(entitlementsDirectory) [[NSFileManager defaultManager] removeItemAtPath:entitlementsDirectory error:nil];
	if(ldidRet == 0) return 0;
	NSLog(@"[signAdhoc] bundled ldid exited with status %d for %@", ldidRet, filePath);
	if(errorOutput.length > 0) printMultilineNSString(errorOutput);
	return 175;
}

int signAdhoc(NSString *filePath, NSDictionary *entitlements)
{
	return signAdhocInternal(filePath, entitlements, NO, NO);
}

static NSUInteger signWorkerCount(void)
{
	// Only configured ldid runs are known to be safe to fan out. The native
	// Security.framework fallback remains serial unless it gains explicit proof
	// of re-entrancy on the supported iOS releases.
	if (!gSigningConfiguration) return 1;
	if ([gSigningConfiguration[@"mode"] isEqualToString:@"troll"] && (!isLdidInstalled() || !currentOSSupportsBundledLdid())) return 1;
	NSUInteger configured = [gSigningConfiguration[@"jobs"] unsignedIntegerValue];
	if (configured == 0) configured = 1;
	NSUInteger processors = NSProcessInfo.processInfo.activeProcessorCount;
	if (processors == 0) processors = 1;
	return MIN(4, MIN(configured, processors));
}

static int signIndependentMachOJobs(NSArray<NSDictionary *> *jobs)
{
	if (jobs.count == 0) return 0;
	NSUInteger workers = signWorkerCount();
	if (workers <= 1) {
		for (NSDictionary *job in jobs) {
			int status = signAdhocInternal(job[@"path"], job[@"entitlements"], NO, [job[@"replaceEntitlements"] boolValue]);
			if (status != 0) return status;
		}
		return 0;
	}
	NSOperationQueue *queue = [NSOperationQueue new];
	queue.name = @"com.opa334.TrollStore.independent-signing";
	queue.maxConcurrentOperationCount = (NSInteger)workers;
	NSLock *statusLock = [NSLock new];
	__block int firstStatus = 0;
	for (NSDictionary *job in jobs) {
		[queue addOperationWithBlock:^{
			[statusLock lock]; BOOL stopped = firstStatus != 0; [statusLock unlock];
			if (stopped) return;
			int status = signAdhocInternal(job[@"path"], job[@"entitlements"], YES, [job[@"replaceEntitlements"] boolValue]);
			if (status != 0) {
				[statusLock lock];
				if (firstStatus == 0) { firstStatus = status; [queue cancelAllOperations]; }
				[statusLock unlock];
			}
		}];
	}
	[queue waitUntilAllOperationsAreFinished];
	return firstStatus;
}

static BOOL removeEmbeddedProvisioningProfiles(NSString *appPath)
{
	NSString *canonicalRoot = canonicalExistingPath(appPath);
	if (!canonicalRoot.length) return NO;
	NSDirectoryEnumerator *enumerator = [[NSFileManager defaultManager] enumeratorAtURL:[NSURL fileURLWithPath:canonicalRoot] includingPropertiesForKeys:nil options:0 errorHandler:nil];
	NSMutableArray<NSString *> *profilePaths = [NSMutableArray array];
	NSURL *url = nil;
	while ((url = [enumerator nextObject])) {
		struct stat profileStat;
		if (lstat(url.path.fileSystemRepresentation, &profileStat) != 0) continue;
		if (S_ISLNK(profileStat.st_mode)) { [enumerator skipDescendants]; continue; }
		if (![url.lastPathComponent isEqualToString:@"embedded.mobileprovision"] || !S_ISREG(profileStat.st_mode)) continue;
		NSString *resolved = canonicalExistingPath(url.path);
		if (!resolved.length || !pathIsWithinDirectory(resolved, canonicalRoot)) continue;
		[profilePaths addObject:url.path];
	}
	for (NSString *path in profilePaths) {
		NSError *removeError = nil;
		if (![[NSFileManager defaultManager] removeItemAtPath:path error:&removeError]) {
			NSLog(@"[signApp] cannot remove embedded provisioning profile %@: %@", path, removeError);
			return NO;
		}
	}
	return YES;
}

int signApp(NSString* appPath)
{
	NSString *signingMode = [gSigningConfiguration[@"mode"] isKindOfClass:NSString.class] ? gSigningConfiguration[@"mode"] : @"";
	BOOL certificateOnlyMode = [signingMode isEqualToString:@"certificate-only"];
	BOOL realSigningMode = [signingMode isEqualToString:@"real"] || certificateOnlyMode;
	if ([signingMode isEqualToString:@"real"]) {
		NSString *existingProfile = [appPath stringByAppendingPathComponent:@"embedded.mobileprovision"];
		gRealSigningMissingProfile = ![gSigningConfiguration[@"hasProvisioningProfile"] boolValue] && ![[NSFileManager defaultManager] fileExistsAtPath:existingProfile];
	} else if (certificateOnlyMode) {
		// This mode is deliberately profile-free. Remove any profile shipped inside
		// the source IPA, including extension profiles, before computing CMS seals.
		if (!removeEmbeddedProvisioningProfiles(appPath)) return 175;
		gRealSigningMissingProfile = NO;
	}
	NSString *canonicalAppPath = canonicalExistingPath(appPath);
	if (!canonicalAppPath.length) return 172;
	struct stat appRootStat;
	if (lstat(canonicalAppPath.fileSystemRepresentation, &appRootStat) != 0 || !S_ISDIR(appRootStat.st_mode) || S_ISLNK(appRootStat.st_mode)) return 172;
	NSDictionary* appInfoDict = infoDictionaryForAppPath(canonicalAppPath);
	if(![appInfoDict isKindOfClass:NSDictionary.class]) return 172;

	NSString *mainExecutablePath = safeExecutablePathForBundle(canonicalAppPath, appInfoDict[@"CFBundleExecutable"], canonicalAppPath);
	if(!mainExecutablePath.length) {
		NSLog(@"[signApp] main CFBundleExecutable is missing, unsafe, or outside the staged app bundle %@", canonicalAppPath);
		return 176;
	}
	if (realSigningMode && !certificateOnlyMode) {
		NSString *profilePath = gSigningConfiguration[@"provisioningProfilePath"];
		if ([profilePath isKindOfClass:NSString.class] && profilePath.length) {
			NSString *embeddedProfile = [appPath stringByAppendingPathComponent:@"embedded.mobileprovision"];
			NSData *profileData = [NSData dataWithContentsOfFile:profilePath];
			if (!profileData.length || ![profileData writeToFile:embeddedProfile options:NSDataWritingAtomic error:nil]) { NSLog(@"[signApp] could not attach the selected provisioning profile"); return 175; }
			gRealSigningMissingProfile = NO;
		}
	}

	// An IPA can opt into the pre-signed fast path by setting TSBundlePreSigned=YES.
	// Never use it when a complete edited Entitlements document is active: the main executable
	// must be re-signed with that exact dictionary before CoreTrust processing.
	BOOL skipAdhocSigning = !gSigningConfiguration && [appInfoDict[@"TSBundlePreSigned"] boolValue] && !gEditedMainEntitlementsProvided;
	if(skipAdhocSigning) NSLog(@"[signApp] TSBundlePreSigned enabled; skipping adhoc signing but retaining CoreTrust processing");

#ifndef TROLLSTORE_LITE
	// Check if the bundle has had a supported exploit pre-applied
	EXPLOIT_TYPE declaredPreAppliedExploitType = getDeclaredExploitTypeFromInfoDictionary(appInfoDict);
	if(!realSigningMode && !skipAdhocSigning && !gEditedMainEntitlementsProvided && isPlatformVulnerableToExploitType(declaredPreAppliedExploitType))
	{
		NSLog(@"[signApp] taking fast path for app which declares use of a supported pre-applied exploit (%@)", mainExecutablePath);
		return 0;
	}
	else if (declaredPreAppliedExploitType != 0 && !skipAdhocSigning)
	{
		NSLog(@"[signApp] app (%@) declares use of a pre-applied exploit that is not supported on this device. Proceeding to re-sign...", mainExecutablePath);
	}

	// If the app doesn't declare a pre-applied exploit, and the host supports fake custom root certs,
	// we can also skip doing any work here when that app is signed with fake roots
	// If not, with the new bypass, a previously modified binary should failed to be adhoc signed, and
	// reapplying the bypass should produce an identical binary
	if(!realSigningMode && !skipAdhocSigning && !gEditedMainEntitlementsProvided && isPlatformVulnerableToExploitType(EXPLOIT_TYPE_CUSTOM_ROOT_CERTIFICATE_V1))
	{
		SecStaticCodeRef codeRef = getStaticCodeRef(mainExecutablePath);
		if(codeRef != NULL)
		{
			if(codeCertChainContainsFakeAppStoreExtensions(codeRef))
			{
				NSLog(@"[signApp] taking fast path for app signed using a custom root certificate (%@)", mainExecutablePath);
				CFRelease(codeRef);
				return 0;
			}

			CFRelease(codeRef);
		}
	}

	// On iOS 16+, binaries with certain entitlements requires developer mode to be enabled, so we'll check
	// while we're fixing entitlements
	BOOL requiresDevMode = NO;
#endif

	// The majority of IPA decryption utilities only decrypt the main executable of the app bundle
	// As a result, we cannot bail on the entire app if an additional binary is encrypted (e.g. app extensions)
	// Instead, we will display a warning to the user, and warn them that the app may not work properly
	BOOL hasAdditionalEncryptedBinaries = NO;

	NSURL *fileURL;
	NSDirectoryEnumerator *enumerator;
	NSMutableArray<NSString *> *bundleFilePaths = [NSMutableArray array];
	NSMutableArray<NSString *> *bundleInfoPlistPaths = [NSMutableArray array];
	NSMutableSet<NSString *> *signedMachOPaths = [NSMutableSet set];
	NSMutableSet<NSString *> *codeBundlePaths = [NSMutableSet set];

	// Build one metadata index: retain nested Info.plists and likely Mach-O files only.
	// The CoreTrust pass can then skip every ordinary asset and avoid a second tree walk.
	enumerator = [[NSFileManager defaultManager] enumeratorAtURL:[NSURL fileURLWithPath:canonicalAppPath]
		includingPropertiesForKeys:@[NSURLIsDirectoryKey] options:0 errorHandler:nil];
	while((fileURL = [enumerator nextObject]))
	{
		NSString *path = fileURL.path;
		struct stat candidateStat;
		if (lstat(path.fileSystemRepresentation, &candidateStat) != 0) continue;
		// Do not allow the enumerator to descend through a symlinked directory.
		if (S_ISLNK(candidateStat.st_mode)) { [enumerator skipDescendants]; continue; }
		if (!S_ISREG(candidateStat.st_mode)) continue;
		NSString *resolvedPath = canonicalExistingPath(path);
		if (!resolvedPath.length || !pathIsWithinDirectory(resolvedPath, canonicalAppPath)) continue;
		if([path.lastPathComponent isEqualToString:@"Info.plist"])
			[bundleInfoPlistPaths addObject:path];
		if(fileMayContainMachOAtPath(path))
			[bundleFilePaths addObject:resolvedPath];
	}

	BOOL appleInternalProfileTemplate = [gSigningConfiguration[@"templateName"] isEqualToString:@"apple-internal-profile"];
	if (appleInternalProfileTemplate && gEditedMainEntitlementsProvided) {
		NSLog(@"[signApp] Apple Internal profile policy cannot be combined with an independent exact-Entitlements override; the profile's own entitlement allowlist must be evaluated as one policy.");
		return 190;
	}
	BOOL useWholeBundleCMSPass = realSigningMode && gSigningConfiguration && !gEditedMainEntitlementsProvided;
	if (useWholeBundleCMSPass) {
		// The 2026-10-30 ldid recursively signs nested bundles in dependency order and
		// parallelizes independent Mach-O/Fat work using the selected template's jobs value.
		// This is the production fast path for normal real-signing installs.
		NSString *signOutput = nil;
		NSMutableArray *recursiveArguments = [NSMutableArray arrayWithObjects:@"-M", @"--deep", nil];
		if (![gSigningConfiguration[@"superDeep"] isKindOfClass:NSNumber.class] || [gSigningConfiguration[@"superDeep"] boolValue])
			[recursiveArguments addObject:@"--super-deep"];
		[recursiveArguments addObject:appPath];
		int status = appleInternalProfileTemplate
			? runAppleInternalProfileSignature(appPath, &signOutput)
			: runLdidWithSigningConfiguration(recursiveArguments, &signOutput, nil);
		if (status != 0) { NSLog(@"[signApp] %@ bundle CMS signing failed (%d): %@", appleInternalProfileTemplate ? @"Apple Internal policy" : @"recursive", status, signOutput ?: @""); return 175; }
#ifndef TROLLSTORE_LITE
		if (@available(iOS 16, *)) {
			for (NSString *candidate in bundleFilePaths) {
				NSDictionary *candidateEntitlements = dumpEntitlementsFromBinaryAtPath(candidate);
				for (NSString *restrictedKey in @[@"get-task-allow", @"task_for_pid-allow", @"com.apple.system-task-ports", @"com.apple.system-task-ports.control", @"com.apple.system-task-ports.token.control", @"com.apple.private.cs.debugger"]) {
					id value = candidateEntitlements[restrictedKey];
					if ([value isKindOfClass:NSNumber.class] && [value boolValue]) { requiresDevMode = YES; break; }
				}
				if (requiresDevMode) break;
			}
		}
#endif
	} else {
	// Prepare all independent executable signatures before sealing any Bundle resources.
	NSMutableArray<NSDictionary *> *pendingMachOSigns = [NSMutableArray array];
	// Entitlements must be prepared for each nested bundle executable before the recursive bundle sign.
	for(NSString *filePath in bundleInfoPlistPaths)
	{
		NSDictionary *infoDict = [NSDictionary dictionaryWithContentsOfFile:filePath];
		if (!infoDict) continue;
		NSString *bundleId = infoDict[@"CFBundleIdentifier"];
		NSString *bundleExecutable = infoDict[@"CFBundleExecutable"];
		if (![bundleId isKindOfClass:NSString.class] || !bundleId.length ||
			![bundleExecutable isKindOfClass:NSString.class] || !bundleExecutable.length) continue;
		NSString *bundlePath = [filePath stringByDeletingLastPathComponent];
		NSString *canonicalBundlePath = canonicalExistingPath(bundlePath);
		NSString *bundleMainExecutablePath = safeExecutablePathForBundle(bundlePath, bundleExecutable, canonicalAppPath);
		if (!canonicalBundlePath.length || !pathIsWithinDirectory(canonicalBundlePath, canonicalAppPath) || !bundleMainExecutablePath.length) {
			NSLog(@"[signApp] refusing unsafe nested bundle executable %@ in %@", bundleExecutable, bundlePath);
			return 176;
		}

		NSString *packageType = infoDict[@"CFBundlePackageType"];
		[codeBundlePaths addObject:canonicalBundlePath];

		// Framework binaries keep their own entitlement set, but their code bundle
		// still needs a resource seal. They are signed in the bottom-up bundle pass.
		if ([packageType isEqualToString:@"FMWK"]) continue;

		NSMutableDictionary *entitlementsToUse = dumpEntitlementsFromBinaryAtPath(bundleMainExecutablePath).mutableCopy;
		if (isSameFile(bundleMainExecutablePath, mainExecutablePath)) {
			// In the case where the main executable of the app currently has no entitlements at all
			// We want to ensure it gets signed with fallback entitlements
			// These mimic the entitlements that Xcodes gives every app it signs
			if (!entitlementsToUse && !realSigningMode) {
				entitlementsToUse = @{
					@"application-identifier" : @"TROLLTROLL.*",
					@"com.apple.developer.team-identifier" : @"TROLLTROLL",
					@"get-task-allow" : (__bridge id)kCFBooleanTrue,
					@"keychain-access-groups" : @[
						@"TROLLTROLL.*",
						@"com.apple.token"
					],
				}.mutableCopy;
			}
		}

		if (!entitlementsToUse) entitlementsToUse = [NSMutableDictionary new];

		// The editor supplies a complete Entitlements document, initialized from the
		// target IPA's main executable. Replace the main executable's entire dictionary
		// so deleting a key in the editor really removes it from the signed binary.
		// Other app/extension executables continue to use their own extracted values.
		if (gEditedMainEntitlementsProvided && isSameFile(bundleMainExecutablePath, mainExecutablePath)) {
			entitlementsToUse = [gEditedMainEntitlements mutableCopy] ?: [NSMutableDictionary new];
		}

#ifndef TROLLSTORE_LITE
		// Developer mode does not exist before iOS 16
		if (@available(iOS 16, *)){
			if (!requiresDevMode) {
				for (NSString* restrictedEntitlementKey in @[
					@"get-task-allow", 
					@"task_for_pid-allow", 
					@"com.apple.system-task-ports",
					@"com.apple.system-task-ports.control",
					@"com.apple.system-task-ports.token.control",
					@"com.apple.private.cs.debugger"
				]) {
					NSObject *restrictedEntitlement = entitlementsToUse[restrictedEntitlementKey];
					if (restrictedEntitlement && [restrictedEntitlement isKindOfClass:[NSNumber class]] && [(NSNumber *)restrictedEntitlement boolValue]) {
						requiresDevMode = YES;
					}
				}
			}
		}

		NSObject *containerRequiredO = entitlementsToUse[@"com.apple.private.security.container-required"];
		BOOL containerRequired = YES;
		if (containerRequiredO && [containerRequiredO isKindOfClass:[NSNumber class]]) {
			containerRequired = [(NSNumber *)containerRequiredO boolValue];
		}
		else if (containerRequiredO && [containerRequiredO isKindOfClass:[NSString class]]) {
			// Keep whatever is in it if it's a string...
			containerRequired = NO;
		}

		if (!gEditedMainEntitlementsProvided && !realSigningMode && containerRequired) {
			NSObject *noContainerO = entitlementsToUse[@"com.apple.private.security.no-container"];
			BOOL noContainer = NO;
			if (noContainerO && [noContainerO isKindOfClass:[NSNumber class]]) {
				noContainer = [(NSNumber *)noContainerO boolValue];
			}
			NSObject *noSandboxO = entitlementsToUse[@"com.apple.private.security.no-sandbox"];
			BOOL noSandbox = NO;
			if (noSandboxO && [noSandboxO isKindOfClass:[NSNumber class]]) {
				noSandbox = [(NSNumber *)noSandboxO boolValue];
			}
			if (!noContainer && !noSandbox) {
				entitlementsToUse[@"com.apple.private.security.container-required"] = bundleId;
			}
		}
#else
		// Since TrollStore Lite adhoc signs stuff, this means that on PMAP_CS devices, it will run with "PMAP_CS_IN_LOADED_TRUST_CACHE" trust level.
		// Preserve the editor's complete main-app document exactly; automatic compatibility
		// entitlements may only be added when the user did not explicitly provide one.
		if (!gEditedMainEntitlementsProvided || !isSameFile(bundleMainExecutablePath, mainExecutablePath)) {
			entitlementsToUse[@"jb.pmap_cs.custom_trust"] = @"PMAP_CS_APP_STORE";
		}
#endif

		if(!skipAdhocSigning)
		{
			BOOL replaceMainEntitlements = gEditedMainEntitlementsProvided && isSameFile(bundleMainExecutablePath, mainExecutablePath);
			NSDictionary *task = nil;
			if (replaceMainEntitlements) {
				// Keep an explicit empty dictionary too: it means remove all original main-app
				// Entitlements, not preserve the old signature's dictionary.
				task = @{@"path":bundleMainExecutablePath, @"entitlements":entitlementsToUse ?: @{}, @"replaceEntitlements":@YES};
			} else if (realSigningMode && entitlementsToUse.count == 0) {
				task = @{@"path":bundleMainExecutablePath};
			} else {
				task = @{@"path":bundleMainExecutablePath, @"entitlements":entitlementsToUse};
			}
			[pendingMachOSigns addObject:task];
			[signedMachOPaths addObject:bundleMainExecutablePath.stringByStandardizingPath];
		}
	}

	// Sign any additional Mach-O files that are not named by a nested bundle's
	// CFBundleExecutable (framework binaries, helper tools, and embedded libraries).
	// This prevents a successful non-recursive Security.framework call on the outer
	// app from leaving an auxiliary executable unsigned.
	if(!skipAdhocSigning)
	{
		for(NSString *filePath in bundleFilePaths)
		{
			NSString *normalizedPath = filePath.stringByStandardizingPath;
			if([signedMachOPaths containsObject:normalizedPath]) continue;
			NSDictionary *existingEntitlements = dumpEntitlementsFromBinaryAtPath(filePath);
			NSDictionary *task = existingEntitlements.count
				? @{@"path":filePath, @"entitlements":existingEntitlements}
				: @{@"path":filePath};
			[pendingMachOSigns addObject:task];
			[signedMachOPaths addObject:normalizedPath];
		}
		int independentSignStatus = signIndependentMachOJobs(pendingMachOSigns);
		if (independentSignStatus != 0) return independentSignStatus;

		// Seal nested code bundles bottom-up: extensions/frameworks first, then
		// their parents, and the main .app last. SecCodeSigner doesn't provide the
		// same recursive guarantee as ldid -s <bundle>, so relying on one outer
		// bundle call would leave embedded frameworks with stale/missing CodeResources.
		NSArray<NSString *> *bundlesDeepestFirst = [[codeBundlePaths allObjects] sortedArrayUsingComparator:^NSComparisonResult(NSString *left, NSString *right) {
			NSUInteger leftDepth = left.pathComponents.count;
			NSUInteger rightDepth = right.pathComponents.count;
			if (leftDepth > rightDepth) return NSOrderedAscending;
			if (leftDepth < rightDepth) return NSOrderedDescending;
			return [left localizedStandardCompare:right];
		}];
		NSString *normalizedAppPath = appPath.stringByStandardizingPath;
		for(NSString *bundlePath in bundlesDeepestFirst)
		{
			int r = signAdhoc(bundlePath, nil);
			if (r != 0) return r;
		}
		// Be defensive if the app's Info.plist could not be included in the bundle
		// path set for some malformed package edge case.
		if (![codeBundlePaths containsObject:normalizedAppPath]) {
			int r = signAdhoc(appPath, nil);
			if (r != 0) return r;
		}
	}
	} // useWholeBundleCMSPass / per-binary signing paths

	if (realSigningMode) {
		// Validate both the normal recursive CMS path and the complete per-binary Entitlements-edit path.
		// Profile absence is a policy warning surfaced after installation; malformed CMS/code hashes fail here.
		NSString *validationOutput = nil;
		int validationStatus = runLdid(@[@"--signature-validate", appPath], &validationOutput);
		if (validationStatus != 0) { NSLog(@"[signApp] post-signature validation failed (%d): %@", validationStatus, validationOutput ?: @""); return 175; }
	}

#ifndef TROLLSTORE_LITE
	if (realSigningMode) {
		// Genuine CMS signatures must never be rewritten by TrollStore's CoreTrust bypass.
		// Check FairPlay encryption separately so the UI can still distinguish primary and extension failures.
		for (NSString *candidate in bundleFilePaths) {
			FAT *fat = fat_init_from_path(candidate.fileSystemRepresentation);
			if (!fat) continue;
			MachO *macho = fat_find_preferred_slice(fat);
			BOOL encrypted = macho && macho_is_encrypted(macho);
			fat_free(fat);
			if (encrypted) { if (isSameFile(candidate, mainExecutablePath)) return 180; hasAdditionalEncryptedBinaries = YES; }
		}
		if (requiresDevMode) return 182;
		if (hasAdditionalEncryptedBinaries) return 184;
		if (gRealSigningMissingProfile) return 193;
		return 0;
	}
	// Apply CoreTrust bypass to the cached paths without walking the bundle tree a second time.
	for(NSString *filePath in bundleFilePaths)
	{
		FAT *fat = fat_init_from_path(filePath.fileSystemRepresentation);
		if (fat) {
			#if DEBUG
			NSLog(@"[signApp] Mach-O candidate: %@", filePath);
			#endif
			MachO *machoForExtraction = fat_find_preferred_slice(fat);
			if (machoForExtraction) {
				// Extract best slice
				NSString *tmpPath = [filePath stringByAppendingFormat:@".trollstore-bypass-%@", NSUUID.UUID.UUIDString];
				MemoryStream *sliceStream = macho_get_stream(machoForExtraction);
				MemoryStream *sliceOutStream = file_stream_init_from_path(tmpPath.fileSystemRepresentation, 0, 0, FILE_STREAM_FLAG_WRITABLE | FILE_STREAM_FLAG_AUTO_EXPAND);
				if (sliceOutStream) {
					memory_stream_copy_data(sliceStream, 0, sliceOutStream, 0, memory_stream_get_size(sliceStream));
					memory_stream_free(sliceOutStream);

					// Use a sibling temp file so the final replacement can be an atomic same-volume rename.
					// As in the original code, this intentionally keeps only the preferred architecture slice.
					int r = apply_coretrust_bypass(tmpPath.fileSystemRepresentation);
					if(r == 0)
					{
						#if DEBUG
						NSLog(@"[signApp] bypass applied to %@", filePath);
						#endif
					}
					else if (r == 2) {
						NSLog(@"[%@] Cannot apply CoreTrust bypass on an encrypted binary!", filePath);
						if (isSameFile(filePath, mainExecutablePath)) {
							// If this is the main binary, this error is fatal
							NSLog(@"[%@] Main binary is encrypted, cannot continue!", filePath);
							[[NSFileManager defaultManager] removeItemAtPath:tmpPath error:nil];
							fat_free(fat);
							return 180;
						}
						else {
							// If not, we can continue but want to show a warning after the app is installed
							hasAdditionalEncryptedBinaries = YES;
						}
					} else if (r == 3) { // Non-fatal - unsupported MachO type
						NSLog(@"[%@] Cannot apply CoreTrust bypass on an unsupported MachO type!", filePath);
					}
					else {
						NSLog(@"[%@] CoreTrust bypass failed!!! :(", filePath);
						[[NSFileManager defaultManager] removeItemAtPath:tmpPath error:nil];
						fat_free(fat);
						return 185;
					}

					// Same-directory rename avoids an extra file copy and never deletes the original first.
					if(rename(tmpPath.fileSystemRepresentation, filePath.fileSystemRepresentation) != 0)
					{
						int renameError = errno;
						NSLog(@"[signApp] atomic replacement failed for %@: %s", filePath, strerror(renameError));
						[[NSFileManager defaultManager] removeItemAtPath:tmpPath error:nil];
						fat_free(fat);
						return 185;
					}
				}
				else
				{
					[[NSFileManager defaultManager] removeItemAtPath:tmpPath error:nil];
				}
			}
			fat_free(fat);
		}
	}

	if (requiresDevMode) {
		// Postpone trying to enable dev mode until after the app is (successfully) installed
		return 182;
	}
#else // TROLLSTORE_LITE
	// Just check for whether anything is fairplay encrypted, reusing the cached file list.
	for(NSString *filePath in bundleFilePaths)
	{
		FAT *fat = fat_init_from_path(filePath.fileSystemRepresentation);
		if (fat) {
			#if DEBUG
			NSLog(@"[signApp] Mach-O candidate: %@", filePath);
			#endif
			MachO *macho = fat_find_preferred_slice(fat);
			if (macho) {
				if (macho_is_encrypted(macho)) {
					NSLog(@"[%@] Cannot apply CoreTrust bypass on an encrypted binary!", filePath);
					if (isSameFile(filePath, mainExecutablePath)) {
						// If this is the main binary, this error is fatal
						NSLog(@"[%@] Main binary is encrypted, cannot continue!", filePath);
						fat_free(fat);
						return 180;
					}
					else {
						// If not, we can continue but want to show a warning after the app is installed
						hasAdditionalEncryptedBinaries = YES;
					}
				}
			}
			fat_free(fat);
		}
	}
#endif

	if (hasAdditionalEncryptedBinaries) {
		return 184;
	}

	return 0;
}
#endif

static NSString* randomStealthBundleIdentifierSuffix(void)
{
	uint64_t randomValue = ((uint64_t)arc4random() << 32) | arc4random();
	return [NSString stringWithFormat:@"TS%016llX", (unsigned long long)randomValue];
}

BOOL applyPatchesToInfoDictionary(NSString* appPath, BOOL stealthInstall)
{
	NSURL* appURL = [NSURL fileURLWithPath:appPath];
	NSURL* infoPlistURL = [appURL URLByAppendingPathComponent:@"Info.plist"];
	NSMutableDictionary* infoDictM = [[NSDictionary dictionaryWithContentsOfURL:infoPlistURL error:nil] mutableCopy];
	if(!infoDictM) return NO;

	// Enable Notifications.
	infoDictM[@"SBAppUsesLocalNotifications"] = @1;

	if(stealthInstall)
	{
		NSString* originalAppId = infoDictM[@"TSOriginalBundleIdentifier"];
		if(![originalAppId isKindOfClass:NSString.class] || originalAppId.length == 0)
		{
			originalAppId = infoDictM[@"CFBundleIdentifier"];
		}
		if([originalAppId isKindOfClass:NSString.class] && originalAppId.length > 0)
		{
			NSString* stealthAppId = installedStealthAppIdForOriginalAppId(originalAppId);
			NSString* currentAppId = infoDictM[@"CFBundleIdentifier"];
			NSString* previousOriginalAppId = infoDictM[@"TSOriginalBundleIdentifier"];
			BOOL hasExistingStealthId = [currentAppId isKindOfClass:NSString.class] && currentAppId.length > 0 &&
				![currentAppId isEqualToString:originalAppId] &&
				[previousOriginalAppId isKindOfClass:NSString.class] &&
				[previousOriginalAppId isEqualToString:originalAppId];
			if(!stealthAppId && hasExistingStealthId)
			{
				stealthAppId = currentAppId;
			}
			if(!stealthAppId)
			{
				NSString* suffix = randomStealthBundleIdentifierSuffix();
				// Keep the final identifier within the conventional 255-character limit.
				NSUInteger maxPrefixLength = 255 - suffix.length - 1;
				NSString* baseIdentifier = originalAppId;
				if(baseIdentifier.length > maxPrefixLength)
				{
					// Extremely long identifiers are rare; use a valid short prefix rather than cutting a component.
					baseIdentifier = @"com.trollstore.stealth";
				}
				stealthAppId = [baseIdentifier stringByAppendingFormat:@".%@", suffix];
			}
			infoDictM[@"TSOriginalBundleIdentifier"] = originalAppId;
			infoDictM[@"CFBundleIdentifier"] = stealthAppId;
		}

		// This can break app-to-app callbacks and deep links; the Settings UI warns users.
		[infoDictM removeObjectForKey:@"CFBundleURLTypes"];
	}
	else
	{
		// Normal mode only removes URL schemes claimed by system apps.
		NSSet* appleSchemes = systemURLSchemes();
		NSArray* CFBundleURLTypes = infoDictM[@"CFBundleURLTypes"];
		if([CFBundleURLTypes isKindOfClass:[NSArray class]])
		{
			NSMutableArray* CFBundleURLTypesM = [NSMutableArray new];
			for(NSDictionary* URLType in CFBundleURLTypes)
			{
				if(![URLType isKindOfClass:[NSDictionary class]]) continue;
				NSMutableDictionary* modifiedURLType = URLType.mutableCopy;
				NSArray* URLSchemes = URLType[@"CFBundleURLSchemes"];
				if([URLSchemes isKindOfClass:[NSArray class]])
				{
					NSMutableSet* URLSchemesSet = [NSMutableSet setWithArray:URLSchemes];
					for(NSString* existingURLScheme in [URLSchemesSet copy])
					{
						if(![existingURLScheme isKindOfClass:[NSString class]] || [appleSchemes containsObject:existingURLScheme.lowercaseString])
						{
							[URLSchemesSet removeObject:existingURLScheme];
						}
					}
					modifiedURLType[@"CFBundleURLSchemes"] = URLSchemesSet.allObjects;
				}
				[CFBundleURLTypesM addObject:modifiedURLType.copy];
			}
			infoDictM[@"CFBundleURLTypes"] = CFBundleURLTypesM.copy;
		}
	}

	return [infoDictM writeToURL:infoPlistURL error:nil];
}

// 170: failed to create container for app bundle
// 171: a non trollstore app with the same identifier is already installled
// 172: no info.plist found in app
// 173: app is not signed and cannot be signed because ldid not installed or didn't work
// 174: 
// 180: tried to sign app where the main binary is encrypted
// 184: tried to sign app where an additional binary is encrypted

int installApp(NSString* appPackagePath, BOOL sign, BOOL force, BOOL isTSUpdate, BOOL useInstalldMethod, BOOL skipUICache, BOOL stealthInstall, BOOL protectFromHomeScreenDeletion, NSArray<NSString *> *pluginPaths)
{
	NSLog(@"[installApp force = %d]", force);

	NSString* appPayloadPath = [appPackagePath stringByAppendingPathComponent:@"Payload"];

	NSString* appBundleToInstallPath = findAppPathInBundlePath(appPayloadPath);
	if(!appBundleToInstallPath) return 167;

	NSDictionary* initialInfoDict = infoDictionaryForAppPath(appBundleToInstallPath);
	if(!initialInfoDict) return 172;
	NSString* appId = initialInfoDict[@"CFBundleIdentifier"];
	if(![appId isKindOfClass:NSString.class] || appId.length == 0) return 176;
	NSString* originalAppId = initialInfoDict[@"TSOriginalBundleIdentifier"];
	if(![originalAppId isKindOfClass:NSString.class] || originalAppId.length == 0) originalAppId = appId;
	NSSet* immutableBundleIds = immutableAppBundleIdentifiers();

	if(([originalAppId.lowercaseString isEqualToString:@"com.opa334.trollstore"] && !isTSUpdate) || [immutableBundleIds containsObject:originalAppId.lowercaseString])
	{
		return 179;
	}

	if(!isTSUpdate)
	{
		NSString* existingStealthAppId = installedStealthAppIdForOriginalAppId(originalAppId);
		BOOL hasStealthInstall = [existingStealthAppId isKindOfClass:NSString.class] && existingStealthAppId.length > 0;
		LSApplicationProxy* normalAppProxy = [LSApplicationProxy applicationProxyForIdentifier:originalAppId];
		BOOL hasNormalInstall = normalAppProxy.installed;
		if((stealthInstall && hasNormalInstall) || (!stealthInstall && hasStealthInstall))
		{
			return 187;
		}
		if(!applyPatchesToInfoDictionary(appBundleToInstallPath, stealthInstall)) return 188;
		appId = appIdForAppPath(appBundleToInstallPath);
		if(!appId) return 176;
		if([immutableBundleIds containsObject:appId.lowercaseString]) return 179;
	}

	BOOL requiresDevMode = NO;
	BOOL hasAdditionalEncryptedBinaries = NO;
	BOOL realSigningMissingProfile = NO;
	NSString *updateOriginalBundlePath = nil;
	NSString *updateBackupPath = nil;
	NSString *updateNewBundlePath = nil;
	BOOL hadActiveMarkerBeforeInstall = NO;
	BOOL hadNonDeletableMarkerBeforeInstall = NO;
	// Function-scope URL: rollback branches below all use this marker path.
	// Keep it outside the update/fresh-install branches to avoid block-scope
	// visibility differences when the RootHelper is compiled with Theos.
	NSURL *nonDeletableMarkerURL = nil;

	if(sign && pluginPaths.count > 0)
	{
		for(NSString *pluginPath in pluginPaths)
		{
			NSString *injectionDetail = nil;
			int injectionRet = TSAppMaintenanceInjectDylibIntoStagedBundle(appBundleToInstallPath, appPackagePath, pluginPath, NO, &injectionDetail);
			NSLog(@"[installApp] plugin injection %@ => %d: %@", pluginPath.lastPathComponent, injectionRet, injectionDetail ?: @"");
			if(injectionRet != 0) return injectionRet;
		}
	}

	if(sign)
	{
		CFAbsoluteTime signingStart = CFAbsoluteTimeGetCurrent();
		int signRet = signApp(appBundleToInstallPath);
		NSLog(@"[install-perf] stage=sign seconds=%.3f result=%d", CFAbsoluteTimeGetCurrent() - signingStart, signRet);
		// 182: app requires developer mode; non-fatal
		// 184: app has additional encrypted binaries; non-fatal
		if(signRet != 0) {
			if (signRet == 182) {
				requiresDevMode = YES;
			} else if (signRet == 184) {
				hasAdditionalEncryptedBinaries = YES;
			} else if (signRet == 193) {
				realSigningMissingProfile = YES;
			} else {
				return signRet;
			}
		};
	}

	MCMAppContainer* appContainer = [MCMAppContainer containerWithIdentifier:appId createIfNecessary:NO existed:nil error:nil];
	BOOL hadExistingContainer = (appContainer != nil);
	if(appContainer)
	{
		// App update. Keep the previous bundle in the same MCM container until
		// the replacement has been copied and registered successfully.
		NSURL *bundleContainerURL = appContainer.url;
		NSURL *appBundleURL = findAppURLInBundleURL(bundleContainerURL);
		NSString *containerPath = canonicalExistingPath(bundleContainerURL.path);
		if (!containerPath.length) return 170;

		NSURL *trollStoreMarkURL = [bundleContainerURL URLByAppendingPathComponent:TS_ACTIVE_MARKER];
		NSURL *existingNonDeletableMarkerURL = [bundleContainerURL URLByAppendingPathComponent:TS_NON_DELETABLE_MARKER];
		hadActiveMarkerBeforeInstall = [[NSFileManager defaultManager] fileExistsAtPath:trollStoreMarkURL.path];
		hadNonDeletableMarkerBeforeInstall = [[NSFileManager defaultManager] fileExistsAtPath:existingNonDeletableMarkerURL.path];
		if(appBundleURL && !hadActiveMarkerBeforeInstall && !force)
		{
			NSLog(@"[installApp] already installed and not a TrollStore app... bailing out");
			return 171;
		}

		if(!isTSUpdate) BKSTerminateApplicationForReasonAndReportWithDescription(appId, 5, false, @"TrollStore - App updated");
		if (appBundleURL) {
			updateOriginalBundlePath = canonicalExistingPath(appBundleURL.path);
			if (!updateOriginalBundlePath.length || ![updateOriginalBundlePath.stringByDeletingLastPathComponent isEqualToString:containerPath]) {
				NSLog(@"[installApp] refusing to replace a bundle outside the app's MCM container: %@", appBundleURL.path);
				return 178;
			}
			updateBackupPath = [containerPath stringByAppendingPathComponent:[NSString stringWithFormat:@".TrollStore.UpdateBackup.%@", NSUUID.UUID.UUIDString]];
			NSError *backupError = nil;
			if (![[NSFileManager defaultManager] moveItemAtPath:updateOriginalBundlePath toPath:updateBackupPath error:&backupError]) {
				NSLog(@"[installApp] could not stage previous app bundle %@: %@", updateOriginalBundlePath, backupError);
				return 178;
			}
		}

		updateNewBundlePath = [containerPath stringByAppendingPathComponent:appBundleToInstallPath.lastPathComponent];
		NSError *transferError = nil;
		if (!moveItemWithCopyFallback(appBundleToInstallPath, updateNewBundlePath, &transferError)) {
			NSLog(@"[installApp] failed to stage the new app bundle %@: %@", updateNewBundlePath, transferError);
			rollbackAppBundleUpdate(nil, updateOriginalBundlePath, updateBackupPath);
			return 178;
		}
	}

	else
	{
		// Initial app install
		BOOL systemMethodSuccessful = NO;
		if(useInstalldMethod)
		{
			// System method
			// Do initial placeholder installation using LSApplicationWorkspace
			NSLog(@"[installApp] doing placeholder installation using LSApplicationWorkspace");

			// The installApplication API (re)moves the app bundle, so in order to be able to later 
			// fall back to the custom method, we need to make a temporary copy just for using it on this API once
			// Yeah this sucks, but there is no better solution unfortunately
			NSError* tmpCopyError;
			NSString* lsAppPackageTmpCopy = createPrivateTemporaryDirectory(@"TrollStore-placeholder");
			NSString *lsAppPackageStagedPath = lsAppPackageTmpCopy ? [lsAppPackageTmpCopy stringByAppendingPathComponent:appPackagePath.lastPathComponent] : nil;
			if(!lsAppPackageTmpCopy || ![[NSFileManager defaultManager] copyItemAtPath:appPackagePath toPath:lsAppPackageStagedPath error:&tmpCopyError])
			{
				NSLog(@"failed to make temporary copy of app package: %@", tmpCopyError);
				if (lsAppPackageTmpCopy) [[NSFileManager defaultManager] removeItemAtPath:lsAppPackageTmpCopy error:nil];
				return 170;
			}

			NSError* installError;
			@try
			{
				systemMethodSuccessful = [[LSApplicationWorkspace defaultWorkspace] installApplication:[NSURL fileURLWithPath:lsAppPackageStagedPath] withOptions:@{
					LSInstallTypeKey : @1,
					@"PackageType" : @"Placeholder"
				} error:&installError];
			}
			@catch(NSException* e)
			{
				NSLog(@"[installApp] encountered expection %@ while trying to do placeholder install", e);
				systemMethodSuccessful = NO;
			}

			if(!systemMethodSuccessful)
			{
				NSLog(@"[installApp] encountered error %@ while trying to do placeholder install", installError);
			}

			[[NSFileManager defaultManager] removeItemAtPath:lsAppPackageTmpCopy error:nil];

			if(!systemMethodSuccessful)
			{
				// The caller owns the decision to switch methods. Do not silently change
				// the user's selected installation method after an installd failure.
				@try
				{
					[[LSApplicationWorkspace defaultWorkspace] uninstallApplication:appId withOptions:nil];
				}
				@catch(NSException *cleanupException)
				{
					NSLog(@"[installApp] placeholder cleanup exception for %@: %@", appId, cleanupException);
				}

				LSApplicationProxy *remainingProxy = [LSApplicationProxy applicationProxyForIdentifier:appId];
				MCMAppContainer *residualContainer = [MCMAppContainer containerWithIdentifier:appId createIfNecessary:NO existed:nil error:nil];
				if(residualContainer && !(remainingProxy && remainingProxy.installed))
				{
					NSString *activeMarker = [residualContainer.url.path stringByAppendingPathComponent:TS_ACTIVE_MARKER];
					NSString *inactiveMarker = [residualContainer.url.path stringByAppendingPathComponent:TS_INACTIVE_MARKER];
					// The container was absent before this fresh-install branch. Still refuse to
					// touch any container carrying either TrollStore flavor's marker.
					if(![[NSFileManager defaultManager] fileExistsAtPath:activeMarker] && ![[NSFileManager defaultManager] fileExistsAtPath:inactiveMarker])
					{
						NSURL *residualAppURL = findAppURLInBundleURL(residualContainer.url);
						if(residualAppURL && [appIdForAppPath(residualAppURL.path) isEqualToString:appId])
							[[NSFileManager defaultManager] removeItemAtURL:residualAppURL error:nil];
						NSArray *remainingItems = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:residualContainer.url.path error:nil];
						if(remainingItems.count == 0)
							[[NSFileManager defaultManager] removeItemAtURL:residualContainer.url error:nil];
					}
				}
				return 189; // installd failed; ask the user whether to retry with Custom.
			}
		}

		if(!systemMethodSuccessful)
		{
			// Custom method (only when explicitly selected by the user)
			// Manually create app bundle via MCM apis and move app there
			NSLog(@"[installApp] doing custom installation using MCMAppContainer");

			NSError* mcmError;
			appContainer = [MCMAppContainer containerWithIdentifier:appId createIfNecessary:YES existed:nil error:&mcmError];

			if(!appContainer || mcmError)
			{
				NSLog(@"[installApp] failed to create app container for %@: %@", appId, mcmError);
				return 170;
			}
			else
			{
				NSLog(@"[installApp] created app container: %@", appContainer);
			}

			NSString* newAppBundlePath = [appContainer.url.path stringByAppendingPathComponent:appBundleToInstallPath.lastPathComponent];
			NSLog(@"[installApp] new app path: %@", newAppBundlePath);
			
			NSError *transferError = nil;
			BOOL suc = moveItemWithCopyFallback(appBundleToInstallPath, newAppBundlePath, &transferError);
			if(!suc)
			{
				NSLog(@"[installApp] Failed to move/copy app bundle for app %@, error: %@", appId, transferError);
				// This branch started with no MCM container, so this is installation residue
				// created by this attempt, not the user's pre-existing app data.
				[[NSFileManager defaultManager] removeItemAtURL:appContainer.url error:nil];
				return 178;
			}
		}
	}

	appContainer = [MCMAppContainer containerWithIdentifier:appId createIfNecessary:NO existed:nil error:nil];
	if(!appContainer)
	{
		NSLog(@"[installApp] the app container disappeared before registration for %@", appId);
		if (updateNewBundlePath) rollbackAppBundleUpdate(updateNewBundlePath, updateOriginalBundlePath, updateBackupPath);
		return 170;
	}

	// Marker URLs must remain in scope for every rollback path below. The
	// non-deletable marker is container-scoped and may be created by this install.
	NSURL* trollStoreMarkURL = [appContainer.url URLByAppendingPathComponent:TS_ACTIVE_MARKER];
	nonDeletableMarkerURL = [appContainer.url URLByAppendingPathComponent:TS_NON_DELETABLE_MARKER];
	if(![[NSFileManager defaultManager] fileExistsAtPath:trollStoreMarkURL.path])
	{
		NSError* creationError;
		NSData* emptyData = [NSData data];
		BOOL marked = [emptyData writeToURL:trollStoreMarkURL options:0 error:&creationError];
		if(!marked)
		{
			NSLog(@"[installApp] failed to mark %@ as TrollStore app by creating %@, error: %@", appId, trollStoreMarkURL.path, creationError);
			if (updateNewBundlePath) {
				rollbackAppBundleUpdate(updateNewBundlePath, updateOriginalBundlePath, updateBackupPath);
				if (!hadActiveMarkerBeforeInstall) [[NSFileManager defaultManager] removeItemAtURL:trollStoreMarkURL error:nil];
				if (!hadNonDeletableMarkerBeforeInstall) [[NSFileManager defaultManager] removeItemAtURL:nonDeletableMarkerURL error:nil];
			} else if(!hadExistingContainer) [[NSFileManager defaultManager] removeItemAtURL:appContainer.url error:nil];
			return 177;
		}
	}

	// When enabled, persist non-deletability next to the app-container marker rather than
	// inside the replaceable .app directory. Existing protection is retained on updates.
	if(protectFromHomeScreenDeletion)
	{
		if(![[NSFileManager defaultManager] fileExistsAtPath:nonDeletableMarkerURL.path])
		{
			NSError *markerError = nil;
			if(![[NSData data] writeToURL:nonDeletableMarkerURL options:NSDataWritingAtomic error:&markerError])
			{
				NSLog(@"[installApp] failed to persist Home Screen non-deletable marker for %@: %@", appId, markerError);
				if (updateNewBundlePath) {
					rollbackAppBundleUpdate(updateNewBundlePath, updateOriginalBundlePath, updateBackupPath);
					if (!hadActiveMarkerBeforeInstall) [[NSFileManager defaultManager] removeItemAtURL:trollStoreMarkURL error:nil];
					if (!hadNonDeletableMarkerBeforeInstall) [[NSFileManager defaultManager] removeItemAtURL:nonDeletableMarkerURL error:nil];
				} else if(!hadExistingContainer) [[NSFileManager defaultManager] removeItemAtURL:appContainer.url error:nil];
				return 231;
			}
		}
	}

	// At this point the (new version of the) app is installed but still needs to be registered
	// Also permissions need to be fixed
	NSURL* updatedAppURL = findAppURLInBundleURL(appContainer.url);
	NSString *updatedCanonicalPath = canonicalExistingPath(updatedAppURL.path);
	if (!updatedCanonicalPath.length || ![updatedCanonicalPath.stringByDeletingLastPathComponent isEqualToString:canonicalExistingPath(appContainer.url.path)]) {
		NSLog(@"[installApp] installed app bundle could not be verified inside its MCM container");
		if (updateNewBundlePath) {
			rollbackAppBundleUpdate(updateNewBundlePath, updateOriginalBundlePath, updateBackupPath);
			if (!hadActiveMarkerBeforeInstall) [[NSFileManager defaultManager] removeItemAtURL:trollStoreMarkURL error:nil];
			if (!hadNonDeletableMarkerBeforeInstall) [[NSFileManager defaultManager] removeItemAtURL:nonDeletableMarkerURL error:nil];
		} else if (!hadExistingContainer) [[NSFileManager defaultManager] removeItemAtURL:appContainer.url error:nil];
		return 170;
	}
	CFAbsoluteTime permissionStart = CFAbsoluteTimeGetCurrent();
	BOOL permissionsFixed = fixPermissionsOfAppBundle(updatedCanonicalPath);
	NSLog(@"[install-perf] stage=permissions seconds=%.3f success=%d", CFAbsoluteTimeGetCurrent() - permissionStart, permissionsFixed);
	if (!permissionsFixed) {
		NSLog(@"[installApp] permission normalization failed for %@", updatedCanonicalPath);
		if (updateNewBundlePath) {
			rollbackAppBundleUpdate(updateNewBundlePath, updateOriginalBundlePath, updateBackupPath);
			if (!hadActiveMarkerBeforeInstall) [[NSFileManager defaultManager] removeItemAtURL:trollStoreMarkURL error:nil];
			if (!hadNonDeletableMarkerBeforeInstall) [[NSFileManager defaultManager] removeItemAtURL:nonDeletableMarkerURL error:nil];
		} else if (!hadExistingContainer) {
			[[NSFileManager defaultManager] removeItemAtURL:appContainer.url error:nil];
		} else {
			NSURL *failedBundleURL = findAppURLInBundleURL(appContainer.url);
			if (failedBundleURL) [[NSFileManager defaultManager] removeItemAtURL:failedBundleURL error:nil];
		}
		return 232;
	}
	if (!skipUICache) {
		CFAbsoluteTime registrationStart = CFAbsoluteTimeGetCurrent();
		cleanRestrictions();
		if (!registerPath(updatedAppURL.path, 0, !shouldRegisterAsUserByDefault())) {
			if (updateNewBundlePath) {
				rollbackAppBundleUpdate(updateNewBundlePath, updateOriginalBundlePath, updateBackupPath);
				if (!hadActiveMarkerBeforeInstall) [[NSFileManager defaultManager] removeItemAtURL:trollStoreMarkURL error:nil];
				if (!hadNonDeletableMarkerBeforeInstall) [[NSFileManager defaultManager] removeItemAtURL:nonDeletableMarkerURL error:nil];
				NSLog(@"[installApp] registration failed during update; restored previous app bundle and preserved data for %@", appId);
			} else if(!hadExistingContainer) {
				// Fresh install: no pre-existing user data was present in this container.
				[[NSFileManager defaultManager] removeItemAtURL:appContainer.url error:nil];
			} else {
				// There was no previous app bundle to roll back; keep the data container intact.
				NSURL *failedBundleURL = findAppURLInBundleURL(appContainer.url);
				if(failedBundleURL) [[NSFileManager defaultManager] removeItemAtURL:failedBundleURL error:nil];
				NSLog(@"[installApp] registration failed; preserved existing data container for %@", appId);
			}
			return 181;
		}
		NSLog(@"[install-perf] stage=registration seconds=%.3f", CFAbsoluteTimeGetCurrent() - registrationStart);
	}
	if (appContainer) {
		NSURL *inactiveMarkerURL = [appContainer.url URLByAppendingPathComponent:TS_INACTIVE_MARKER];
		if ([[NSFileManager defaultManager] fileExistsAtPath:inactiveMarkerURL.path])
			[[NSFileManager defaultManager] removeItemAtURL:inactiveMarkerURL error:nil];
	}
	if (updateBackupPath && [[NSFileManager defaultManager] fileExistsAtPath:updateBackupPath]) {
		NSError *backupCleanupError = nil;
		if (![[NSFileManager defaultManager] removeItemAtPath:updateBackupPath error:&backupCleanupError])
			NSLog(@"[installApp] app update committed but previous bundle backup could not be removed: %@", backupCleanupError);
	}

	// Handle developer mode after installing and registering the app, to ensure that we
	// don't arm developer mode but then fail to install the app
	if (requiresDevMode) {
		BOOL alreadyEnabled = NO;
		if (armDeveloperMode(&alreadyEnabled)) {
			if (!alreadyEnabled) {
				NSLog(@"[installApp] app requires developer mode and we have successfully armed it");
				// non-fatal
				return 182;
			}
		} else {
			NSLog(@"[installApp] failed to arm developer mode");
			// fatal
			return 183;
		}
	}

	if (hasAdditionalEncryptedBinaries) {
		NSLog(@"[installApp] app has additional encrypted binaries");
		// non-fatal
		return 184;
	}
	if (realSigningMissingProfile) {
		NSLog(@"[installApp] real CMS signing completed without a provisioning profile");
		return 193;
	}

	return 0;
}

int uninstallApp(NSString* appPath, NSString* appId, BOOL useCustomMethod)
{
	if (!appPath.length || !isManagedAppBundlePath(appPath)) return 1;
	NSString *canonicalAppPath = canonicalExistingPath(appPath);
	if (!canonicalAppPath.length) return 1;
	NSString *appContainerPath = canonicalAppPath.stringByDeletingLastPathComponent;
	NSFileManager *fm = NSFileManager.defaultManager;
	__block BOOL cleanupFailed = NO;

	if (!appId.length) {
		// Broken app bundle (usually a missing/malformed Info.plist). Still only
		// remove a verified app container directly under Bundle/Application.
		registerPath(canonicalAppPath, YES, YES);
		NSError *removeError = nil;
		BOOL removed = ![fm fileExistsAtPath:appContainerPath] || [fm removeItemAtPath:appContainerPath error:&removeError];
		if (!removed) NSLog(@"[uninstallApp] failed to remove broken app container %@: %@", appContainerPath, removeError);
		return removed ? 0 : 1;
	}

	LSApplicationProxy *appProxy = [LSApplicationProxy applicationProxyForIdentifier:appId];
	NSURL *dataContainerURL = appProxy.dataContainerURL;
	if (!dataContainerURL) {
		// LaunchServices may already have dropped the proxy while the MCM data
		// container remains. Query MCM directly so a registration-only uninstall
		// cannot leave the app's private files behind.
		MCMAppDataContainer *dataContainer = [MCMAppDataContainer containerWithIdentifier:appId createIfNecessary:NO existed:nil error:nil];
		dataContainerURL = dataContainer.url;
	}
	if (dataContainerURL) {
		NSError *dataError = nil;
		if (![fm removeItemAtURL:dataContainerURL error:&dataError] && dataError.code != NSFileNoSuchFileError) {
			NSLog(@"[uninstallApp] failed to remove data container %@: %@", dataContainerURL.path, dataError);
			cleanupFailed = YES;
		}
	}
	[appProxy.groupContainerURLs enumerateKeysAndObjectsUsingBlock:^(NSString *groupId, NSURL *groupURL, BOOL *stop) {
		NSArray<LSApplicationProxy *> *appsWithGroup = applicationsWithGroupId(groupId);
		if (appsWithGroup.count > 1) return;
		NSError *groupError = nil;
		if (![fm removeItemAtURL:groupURL error:&groupError] && groupError.code != NSFileNoSuchFileError) {
			NSLog(@"[uninstallApp] failed to remove group container %@: %@", groupURL.path, groupError);
			cleanupFailed = YES;
		}
	}];
	for (LSPlugInKitProxy *pluginProxy in appProxy.plugInKitPlugins) {
		NSURL *pluginURL = pluginProxy.dataContainerURL;
		if (!pluginURL) continue;
		NSError *pluginError = nil;
		if (![fm removeItemAtURL:pluginURL error:&pluginError] && pluginError.code != NSFileNoSuchFileError) {
			NSLog(@"[uninstallApp] failed to remove extension data %@: %@", pluginURL.path, pluginError);
			cleanupFailed = YES;
		}
	}

	if (!useCustomMethod) {
		BOOL systemResult = [[LSApplicationWorkspace defaultWorkspace] uninstallApplication:appId withOptions:nil];
		NSLog(@"[uninstallApp] LaunchServices uninstall %@ => %@", appId, systemResult ? @"YES" : @"NO");
	}
	// LaunchServices can unregister an app while leaving its physical bundle
	// container behind. Always unregister and remove the verified bundle path.
	registerPath(canonicalAppPath, YES, YES);
	NSError *removeError = nil;
	BOOL removed = ![fm fileExistsAtPath:appContainerPath] || [fm removeItemAtPath:appContainerPath error:&removeError];
	if (!removed) NSLog(@"[uninstallApp] failed to remove bundle container %@: %@", appContainerPath, removeError);
	BOOL bundleGone = ![fm fileExistsAtPath:appContainerPath];
	if (bundleGone) cleanRestrictions();
	return bundleGone && !cleanupFailed ? 0 : 1;
}

int uninstallAppByPath(NSString* appPath, BOOL useCustomMethod)
{
	if (!appPath.length || !isManagedAppBundlePath(appPath)) return 1;
	NSString *canonicalAppPath = canonicalExistingPath(appPath);
	if (!canonicalAppPath.length) return 1;
	NSString *appId = appIdForAppPath(canonicalAppPath);
	return uninstallApp(canonicalAppPath, appId, useCustomMethod);
}

int uninstallAppById(NSString* appId, BOOL useCustomMethod)
{
	if (!appId.length) return 1;
	NSString *appPath = appPathForAppId(appId);
	if (!appPath.length) return 1;
	return uninstallApp(appPath, appId, useCustomMethod);
}

// 166: IPA does not exist or is not accessible
// 167: IPA does not appear to contain an app
// 180: IPA's main binary is encrypted
// 184: IPA contains additional encrypted binaries
int installIpa(NSString* ipaPath, BOOL force, BOOL useInstalldMethod, BOOL skipUICache, BOOL stealthInstall, BOOL protectFromHomeScreenDeletion, NSArray<NSString *> *pluginPaths)
{
	if(![[NSFileManager defaultManager] fileExistsAtPath:ipaPath]) return 166;

	CFAbsoluteTime installStart = CFAbsoluteTimeGetCurrent();
	NSString* tmpPackagePath = createPrivateTemporaryDirectory(@"TrollStore-install");
	if (!tmpPackagePath) return 1;

	CFAbsoluteTime extractStart = CFAbsoluteTimeGetCurrent();
	int extractRet = extract(ipaPath, tmpPackagePath);
	NSLog(@"[install-perf] stage=extract seconds=%.3f", CFAbsoluteTimeGetCurrent() - extractStart);
	if(extractRet != 0)
	{
		[[NSFileManager defaultManager] removeItemAtPath:tmpPackagePath error:nil];
		return 168;
	}

	int ret = installApp(tmpPackagePath, YES, force, NO, useInstalldMethod, skipUICache, stealthInstall, protectFromHomeScreenDeletion, pluginPaths ?: @[]);
	
	[[NSFileManager defaultManager] removeItemAtPath:tmpPackagePath error:nil];
	NSLog(@"[install-perf] stage=total seconds=%.3f result=%d", CFAbsoluteTimeGetCurrent() - installStart, ret);

	return ret;
}

int cleanupInstallResidueForIPA(NSString *ipaPath)
{
	if(!ipaPath.length || ![[NSFileManager defaultManager] fileExistsAtPath:ipaPath]) return 0;
	NSString *tmpPackagePath = createPrivateTemporaryDirectory(@"TrollStore-cleanup");
	if (!tmpPackagePath) return 1;
	int extractRet = extract(ipaPath, tmpPackagePath);
	NSString *appBundlePath = extractRet == 0 ? findAppPathInBundlePath([tmpPackagePath stringByAppendingPathComponent:@"Payload"]) : nil;
	NSString *appId = appBundlePath ? appIdForAppPath(appBundlePath) : nil;
	[[NSFileManager defaultManager] removeItemAtPath:tmpPackagePath error:nil];
	if(!appId.length) return 0;

	LSApplicationProxy *registeredProxy = [LSApplicationProxy applicationProxyForIdentifier:appId];
	if(registeredProxy && registeredProxy.installed)
	{
		NSLog(@"[cleanup-install] %@ is registered; leaving its app and data untouched", appId);
		return 0;
	}
	MCMAppContainer *container = [MCMAppContainer containerWithIdentifier:appId createIfNecessary:NO existed:nil error:nil];
	if(!container) return 0;
	NSString *activeMarker = [container.url.path stringByAppendingPathComponent:TS_ACTIVE_MARKER];
	NSString *inactiveMarker = [container.url.path stringByAppendingPathComponent:TS_INACTIVE_MARKER];
	if([[NSFileManager defaultManager] fileExistsAtPath:activeMarker] || [[NSFileManager defaultManager] fileExistsAtPath:inactiveMarker])
	{
		NSLog(@"[cleanup-install] %@ has a TrollStore marker; refusing to delete it", appId);
		return 0;
	}

	NSURL *partialAppURL = findAppURLInBundleURL(container.url);
	if(partialAppURL)
	{
		NSString *partialBundleId = appIdForAppPath(partialAppURL.path);
		if(![partialBundleId isEqualToString:appId])
		{
			NSLog(@"[cleanup-install] bundle id mismatch inside %@; refusing to remove it", container.url.path);
			return 0;
		}
		NSError *removeError = nil;
		if(![[NSFileManager defaultManager] removeItemAtURL:partialAppURL error:&removeError])
			NSLog(@"[cleanup-install] couldn't remove partial app %@: %@", partialAppURL.path, removeError);
	}
	NSArray *remainingItems = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:container.url.path error:nil];
	if(remainingItems && remainingItems.count == 0)
	{
		NSError *removeError = nil;
		if(![[NSFileManager defaultManager] removeItemAtURL:container.url error:&removeError])
			NSLog(@"[cleanup-install] couldn't remove empty residue container %@: %@", container.url.path, removeError);
	}
	return 0;
}

int uninstallAllApps(BOOL useCustomMethod)
{
	int result = 0;
	for (NSString *appPath in trollStoreInstalledAppBundlePaths()) {
		NSString *appId = appIdForAppPath(appPath);
		if (uninstallApp(appPath, appId, useCustomMethod) != 0) {
			NSLog(@"[uninstallAllApps] failed to completely remove %@", appId ?: appPath);
			result = 1;
		}
	}
	return result;
}

int uninstallTrollStore(BOOL unregister)
{
	NSString *containerPath = trollStorePath();
	NSString *appPath = trollStoreAppPath();
	if (!containerPath.length || !appPath.length || ![[NSFileManager defaultManager] fileExistsAtPath:containerPath]) return 1;

	// Restore the original system-app executable before deleting TrollStore's
	// own app container. This prevents a helper host from being left unlaunchable.
	if (!uninstallPersistenceHelper()) {
		NSLog(@"[uninstallTrollStore] persistence helper restore is incomplete; preserving TrollStore data for recovery");
		return 1;
	}
	if (unregister) registerPath(appPath, YES, YES);

    NSFileManager *fm = NSFileManager.defaultManager;
    // Bundle and app-data containers are distinct MCM objects. Removing only the
    // bundle container unregisters the app but can leave its preferences/caches.
    MCMAppDataContainer *dataContainer = [MCMAppDataContainer containerWithIdentifier:APP_ID createIfNecessary:NO existed:nil error:nil];
    NSString *dataContainerPath = dataContainer.url.path;
    if (dataContainerPath.length && [fm fileExistsAtPath:dataContainerPath]) {
        NSError *dataError = nil;
        if (![fm removeItemAtPath:dataContainerPath error:&dataError]) {
            NSLog(@"[uninstallTrollStore] failed to remove its MCM app-data container %@: %@", dataContainerPath, dataError);
            return 1;
        }
    }

    NSError *removeError = nil;
    BOOL removed = ![fm fileExistsAtPath:containerPath] || [fm removeItemAtPath:containerPath error:&removeError];
    if (!removed) NSLog(@"[uninstallTrollStore] failed to remove its MCM bundle container %@: %@", containerPath, removeError);
    BOOL bundleGone = ![fm fileExistsAtPath:containerPath];
    BOOL dataGone = !dataContainerPath.length || ![fm fileExistsAtPath:dataContainerPath];
    return bundleGone && dataGone ? 0 : 1;
}

int installTrollStore(NSString* pathToTar)
{
	_CFPreferencesSetValueWithContainerType _CFPreferencesSetValueWithContainer = (_CFPreferencesSetValueWithContainerType)dlsym(RTLD_DEFAULT, "_CFPreferencesSetValueWithContainer");
	_CFPreferencesSynchronizeWithContainerType _CFPreferencesSynchronizeWithContainer = (_CFPreferencesSynchronizeWithContainerType)dlsym(RTLD_DEFAULT, "_CFPreferencesSynchronizeWithContainer");
	if (_CFPreferencesSetValueWithContainer && _CFPreferencesSynchronizeWithContainer) {
		_CFPreferencesSetValueWithContainer(CFSTR("SBShowNonDefaultSystemApps"), kCFBooleanTrue, CFSTR("com.apple.springboard"), CFSTR("mobile"), kCFPreferencesAnyHost, kCFPreferencesNoContainer);
		_CFPreferencesSynchronizeWithContainer(CFSTR("com.apple.springboard"), CFSTR("mobile"), kCFPreferencesAnyHost, kCFPreferencesNoContainer);
	}

	if(![[NSFileManager defaultManager] fileExistsAtPath:pathToTar] || ![pathToTar.pathExtension.lowercaseString isEqualToString:@"tar"]) return 1;

	NSString *tmpPackagePath = createPrivateTemporaryDirectory(@"TrollStore-upgrade");
	if (!tmpPackagePath) return 1;
	NSString *tmpPayloadPath = [tmpPackagePath stringByAppendingPathComponent:@"Payload"];
	if (![[NSFileManager defaultManager] createDirectoryAtPath:tmpPayloadPath withIntermediateDirectories:NO attributes:@{NSFilePosixPermissions:@0700} error:nil]) {
		[[NSFileManager defaultManager] removeItemAtPath:tmpPackagePath error:nil];
		return 1;
	}

	int ret = 1;
	int extractRet = 0;
	NSString *tmpTrollStorePath = nil;
	BOOL isDirectory = NO;
	NSString *toInstallInfoPlistPath = nil;
	NSDictionary *toInstallInfoDict = nil;
	NSString *toInstallVersion = nil;
	NSComparisonResult versionResult = NSOrderedSame;
	LSApplicationProxy *persistenceHelperApp = nil;
	NSString *persistenceHelper = nil;
	NSString *rootHelper = nil;
	extractRet = extract(pathToTar, tmpPayloadPath);
	if(extractRet != 0) {
		ret = 169;
		goto cleanup;
	}

	tmpTrollStorePath = [tmpPayloadPath stringByAppendingPathComponent:@"TrollStore.app"];
	if(![[NSFileManager defaultManager] fileExistsAtPath:tmpTrollStorePath isDirectory:&isDirectory] || !isDirectory) goto cleanup;

	toInstallInfoPlistPath = [tmpTrollStorePath stringByAppendingPathComponent:@"Info.plist"];
	toInstallInfoDict = [NSDictionary dictionaryWithContentsOfFile:toInstallInfoPlistPath];
	toInstallVersion = [toInstallInfoDict[@"CFBundleVersion"] isKindOfClass:NSString.class] ? toInstallInfoDict[@"CFBundleVersion"] : nil;
	if (!toInstallVersion.length) goto cleanup;

	// Preserve the already-installed ldid executable only for old upgrade payloads
	// that predate bundling it. Never copy ldid source trees into the app bundle.
	versionResult = [@"1.5.0" compare:toInstallVersion options:NSNumericSearch];
	if(versionResult != NSOrderedDescending) {
		NSString *existingLdidPath = [trollStoreAppPath() stringByAppendingPathComponent:@"ldid"];
		NSString *tmpLdidPath = [tmpTrollStorePath stringByAppendingPathComponent:@"ldid"];
		if([[NSFileManager defaultManager] isExecutableFileAtPath:existingLdidPath] && ![[NSFileManager defaultManager] fileExistsAtPath:tmpLdidPath]) {
			NSError *copyError = nil;
			if (![[NSFileManager defaultManager] copyItemAtPath:existingLdidPath toPath:tmpLdidPath error:&copyError]) {
				NSLog(@"[installTrollStore] could not preserve the bundled ldid executable: %@", copyError);
				goto cleanup;
			}
		}
	}

	// Merge existing URL scheme settings value.
	if(!getTSURLSchemeState(nil)) setTSURLSchemeState(NO, tmpTrollStorePath);

    // Keep the current helper untouched until the new TrollStore.app is committed.
    // If the archive install fails, an existing persistence host must continue to
    // run the old helper instead of being partially upgraded to staged binaries.
    persistenceHelperApp = findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_SYSTEM);

    ret = installApp(tmpPackagePath, NO, YES, YES, YES, NO, NO, NO, @[]);
    NSLog(@"[installTrollStore] installApp => %d", ret);
    if (ret == 0 && persistenceHelperApp) {
        NSString *installedTrollStorePath = trollStoreAppPath();
        persistenceHelper = [installedTrollStorePath stringByAppendingPathComponent:@"PersistenceHelper"];
        rootHelper = [installedTrollStorePath stringByAppendingPathComponent:@"trollstorehelper"];
        if (!_installPersistenceHelper(persistenceHelperApp, persistenceHelper, rootHelper)) {
            // TrollStore itself is upgraded; the previous Persistence Helper is
            // deliberately retained so the system host remains launchable.
            NSLog(@"[installTrollStore] TrollStore.app was upgraded, but the existing Persistence Helper could not be updated");
            ret = 1;
        }
    }

cleanup:
	[[NSFileManager defaultManager] removeItemAtPath:tmpPackagePath error:nil];
	return ret;
}

void refreshAppRegistrations(BOOL system)
{
	registerPath(trollStoreAppPath(), NO, system);

	// the reason why there is even an option to register everything as user
	// is because it fixes an issue where app permissions would reset during an icon cache reload
	for(NSString* appPath in trollStoreInstalledAppBundlePaths())
	{
		registerPath(appPath, NO, system);
	}
}

BOOL _installPersistenceHelper(LSApplicationProxy* appProxy, NSString* sourcePersistenceHelper, NSString* sourceRootHelper)
{
	NSLog(@"_installPersistenceHelper(%@, %@, %@)", appProxy, sourcePersistenceHelper, sourceRootHelper);
	if (!appProxy || !sourcePersistenceHelper.length || !sourceRootHelper.length ||
	    ![[NSFileManager defaultManager] isExecutableFileAtPath:sourcePersistenceHelper] ||
	    ![[NSFileManager defaultManager] isExecutableFileAtPath:sourceRootHelper]) return NO;

	NSString *bundlePath = appProxy.bundleURL.path;
	NSString *executablePath = appProxy.canonicalExecutablePath;
	if (!executablePath.length) {
		NSBundle *appBundle = [NSBundle bundleWithPath:bundlePath];
		NSString *executableName = [appBundle objectForInfoDictionaryKey:@"CFBundleExecutable"];
		if (!executableName.length || [executableName containsString:@"/"]) return NO;
		executablePath = [bundlePath stringByAppendingPathComponent:executableName];
	}
	if (!bundlePath.length || ![executablePath hasPrefix:[bundlePath stringByAppendingString:@"/"]]) return NO;

	NSFileManager *fm = NSFileManager.defaultManager;
	NSString *markPath = [bundlePath stringByAppendingPathComponent:@".TrollStorePersistenceHelper"];
	NSString *rootHelperPath = [bundlePath stringByAppendingPathComponent:@"trollstorehelper"];
	NSString *token = NSUUID.UUID.UUIDString;
	NSString *stagedExecutable = [bundlePath stringByAppendingPathComponent:[NSString stringWithFormat:@".TSPersistenceHelper.%@", token]];
	NSString *stagedRootHelper = [bundlePath stringByAppendingPathComponent:[NSString stringWithFormat:@".TSRootHelper.%@", token]];
	NSString *oldExecutable = [bundlePath stringByAppendingPathComponent:[NSString stringWithFormat:@".TSPersistenceHelper.old.%@", token]];
	NSString *oldRootHelper = [bundlePath stringByAppendingPathComponent:[NSString stringWithFormat:@".TSRootHelper.old.%@", token]];
	NSError *error = nil;

	if (![fm copyItemAtPath:sourcePersistenceHelper toPath:stagedExecutable error:&error] ||
	    ![fm copyItemAtPath:sourceRootHelper toPath:stagedRootHelper error:&error]) {
		NSLog(@"[persistence-helper] staging copy failed: %@", error);
		[fm removeItemAtPath:stagedExecutable error:nil]; [fm removeItemAtPath:stagedRootHelper error:nil];
		return NO;
	}
    if (chmod(stagedExecutable.fileSystemRepresentation, 0755) != 0 ||
        chown(stagedExecutable.fileSystemRepresentation, 33, 33) != 0 ||
        chmod(stagedRootHelper.fileSystemRepresentation, 0755) != 0 ||
        chown(stagedRootHelper.fileSystemRepresentation, 0, 0) != 0) {
        NSLog(@"[persistence-helper] could not set staged helper ownership/mode: %s", strerror(errno));
        [fm removeItemAtPath:stagedExecutable error:nil];
        [fm removeItemAtPath:stagedRootHelper error:nil];
        return NO;
    }

    BOOL hadMarker = [fm fileExistsAtPath:markPath];
    if ([fm fileExistsAtPath:rootHelperPath] && !hadMarker) {
        NSLog(@"[persistence-helper] refusing to replace an existing unmarked trollstorehelper at %@", rootHelperPath);
        [fm removeItemAtPath:stagedExecutable error:nil];
        [fm removeItemAtPath:stagedRootHelper error:nil];
        return NO;
    }
    BOOL movedExecutable = NO, movedRootHelper = NO, installedExecutable = NO, installedRootHelper = NO;
	if ([fm fileExistsAtPath:executablePath]) {
		if (!hadMarker || ![fm moveItemAtPath:executablePath toPath:oldExecutable error:&error]) goto rollback;
		movedExecutable = YES;
	}
	if ([fm fileExistsAtPath:rootHelperPath]) {
		if (![fm moveItemAtPath:rootHelperPath toPath:oldRootHelper error:&error]) goto rollback;
		movedRootHelper = YES;
	}
	if (![fm moveItemAtPath:stagedExecutable toPath:executablePath error:&error]) goto rollback;
	installedExecutable = YES;
	if (![fm moveItemAtPath:stagedRootHelper toPath:rootHelperPath error:&error]) goto rollback;
	installedRootHelper = YES;
	if (![fm fileExistsAtPath:markPath] && ![fm createFileAtPath:markPath contents:[NSData data] attributes:nil]) {
		error = [NSError errorWithDomain:NSPOSIXErrorDomain code:EIO userInfo:@{NSLocalizedDescriptionKey:@"Could not create the persistence-helper marker."}];
		goto rollback;
	}
	[fm removeItemAtPath:oldExecutable error:nil]; [fm removeItemAtPath:oldRootHelper error:nil];
	return YES;

rollback:
	NSLog(@"[persistence-helper] atomic replacement failed: %@", error);
	if (installedExecutable) [fm removeItemAtPath:executablePath error:nil];
	if (installedRootHelper) [fm removeItemAtPath:rootHelperPath error:nil];
	if (movedExecutable) [fm moveItemAtPath:oldExecutable toPath:executablePath error:nil];
	if (movedRootHelper) [fm moveItemAtPath:oldRootHelper toPath:rootHelperPath error:nil];
	if (!hadMarker) [fm removeItemAtPath:markPath error:nil];
	[fm removeItemAtPath:stagedExecutable error:nil]; [fm removeItemAtPath:stagedRootHelper error:nil];
	return NO;
}

int installPersistenceHelper(NSString* systemAppId, NSString *persistenceHelperBinary, NSString *rootHelperBinary)
{
    if (findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_ALL)) return 0;

	if (persistenceHelperBinary == nil) {
		persistenceHelperBinary = [trollStoreAppPath() stringByAppendingPathComponent:@"PersistenceHelper"];
	}
	if (rootHelperBinary == nil) {
		rootHelperBinary = [trollStoreAppPath() stringByAppendingPathComponent:@"trollstorehelper"];
	}
    LSApplicationProxy *appProxy = [LSApplicationProxy applicationProxyForIdentifier:systemAppId];
    if (!appProxy || ![appProxy.bundleType isEqualToString:@"System"]) return ENOENT;

    NSString *executablePath = appProxy.canonicalExecutablePath;
    NSString *bundlePath = appProxy.bundleURL.path;
    if (!bundlePath.length || !executablePath.length ||
        ![executablePath hasPrefix:[bundlePath stringByAppendingString:@"/"]]) return EINVAL;
    NSString *backupPath = [bundlePath stringByAppendingPathComponent:
        [[executablePath lastPathComponent] stringByAppendingString:@"_TROLLSTORE_BACKUP"]];
    NSFileManager *fm = NSFileManager.defaultManager;
    if ([fm fileExistsAtPath:backupPath]) {
        NSLog(@"[installPersistenceHelper] refusing to overwrite an existing original-executable backup: %@", backupPath);
        return EEXIST;
    }

    NSError *moveError = nil;
    if (![fm moveItemAtPath:executablePath toPath:backupPath error:&moveError]) {
        NSLog(@"[installPersistenceHelper] could not stage the original system executable: %@", moveError);
        return moveError.code ?: EIO;
    }

    if (!_installPersistenceHelper(appProxy, persistenceHelperBinary, rootHelperBinary)) {
        NSError *restoreError = nil;
        if (![fm moveItemAtPath:backupPath toPath:executablePath error:&restoreError]) {
            NSLog(@"[installPersistenceHelper] helper installation failed and the original executable remains recoverable at %@: %@", backupPath, restoreError);
            return restoreError.code ?: EIO;
        }
        return EIO;
    }

    BKSTerminateApplicationForReasonAndReportWithDescription(systemAppId, 5, false, @"TrollStore - Reload persistence helper");
    return 0;
}

static int registerUserPersistenceHelper(NSString *userAppId)
{
	if (![userAppId isKindOfClass:NSString.class] || !userAppId.length) return EINVAL;
	LSApplicationProxy *appProxy = [LSApplicationProxy applicationProxyForIdentifier:userAppId];
	if (!appProxy || !appProxy.installed || ![appProxy.bundleType isEqualToString:@"User"]) return ENOENT;

	NSString *bundlePath = canonicalExistingPath(appProxy.bundleURL.path);
	if (!bundlePath.length || !isManagedAppBundlePath(bundlePath) ||
		![appIdForAppPath(bundlePath) isEqualToString:userAppId]) return EPERM;

	NSString *markerPath = [bundlePath stringByAppendingPathComponent:@".TrollStorePersistenceHelper"];
	struct stat markerStat;
	if (lstat(markerPath.fileSystemRepresentation, &markerStat) == 0) {
		// Idempotent registration is safe only when the marker is a regular file.
		return S_ISREG(markerStat.st_mode) && !S_ISLNK(markerStat.st_mode) ? 0 : EEXIST;
	}
	if (errno != ENOENT) return errno ?: EIO;

	if (findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_ALL)) return EBUSY;

	int fd = open(markerPath.fileSystemRepresentation, O_WRONLY | O_CREAT | O_EXCL | O_CLOEXEC | O_NOFOLLOW, 0600);
	if (fd < 0) {
		if (errno == EEXIST) {
			if (lstat(markerPath.fileSystemRepresentation, &markerStat) == 0 && S_ISREG(markerStat.st_mode) && !S_ISLNK(markerStat.st_mode)) return 0;
		}
		NSLog(@"[registerUserPersistenceHelper] could not create marker %@: %s", markerPath, strerror(errno));
		return errno ?: EIO;
	}
	int syncResult = fsync(fd);
	int closeResult = close(fd);
	if (syncResult != 0 || closeResult != 0) {
		int savedErrno = errno ?: EIO;
		unlink(markerPath.fileSystemRepresentation);
		NSLog(@"[registerUserPersistenceHelper] marker commit failed for %@: %s", markerPath, strerror(savedErrno));
		return savedErrno;
	}
	return 0;
}

void unregisterUserPersistenceHelper()
{
	LSApplicationProxy* userAppProxy = findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_USER);
	if(userAppProxy)
	{
		NSString* markPath = [userAppProxy.bundleURL.path stringByAppendingPathComponent:@".TrollStorePersistenceHelper"];
		[[NSFileManager defaultManager] removeItemAtPath:markPath error:nil];
	}
}

BOOL uninstallPersistenceHelper(void)
{
    NSFileManager *fm = NSFileManager.defaultManager;
    LSApplicationProxy *systemAppProxy = findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_SYSTEM);
    if (systemAppProxy) {
        NSString *bundlePath = systemAppProxy.bundleURL.path;
        NSString *executablePath = systemAppProxy.canonicalExecutablePath;
        if (!executablePath.length) {
            NSBundle *bundle = bundlePath.length ? [NSBundle bundleWithPath:bundlePath] : nil;
            NSString *executableName = [bundle objectForInfoDictionaryKey:@"CFBundleExecutable"];
            if (executableName.length && ![executableName containsString:@"/"])
                executablePath = [bundlePath stringByAppendingPathComponent:executableName];
        }
        if (!bundlePath.length || !executablePath.length ||
            ![executablePath hasPrefix:[bundlePath stringByAppendingString:@"/"]]) {
            NSLog(@"[uninstallPersistenceHelper] invalid host bundle/executable path");
            return NO;
        }

        NSString *backupPath = [bundlePath stringByAppendingPathComponent:
            [[executablePath lastPathComponent] stringByAppendingString:@"_TROLLSTORE_BACKUP"]];
        NSString *helperPath = [bundlePath stringByAppendingPathComponent:@"trollstorehelper"];
        NSString *markPath = [bundlePath stringByAppendingPathComponent:@".TrollStorePersistenceHelper"];
        NSString *restoredMarkPath = [bundlePath stringByAppendingPathComponent:@".TrollStorePersistenceHelperRestored"];

        if ([fm fileExistsAtPath:backupPath]) {
            // Record the restore phase before moving files. If any later cleanup
            // fails, findPersistenceHelperApp can still find this host and a retry
            // will clean residue without ever replacing the restored executable.
            if (![fm fileExistsAtPath:restoredMarkPath] && ![fm createFileAtPath:restoredMarkPath contents:[NSData data] attributes:nil]) {
                NSLog(@"[uninstallPersistenceHelper] could not create restore transaction marker");
                return NO;
            }

            NSString *stagedCurrent = [bundlePath stringByAppendingPathComponent:
                [NSString stringWithFormat:@".TSPersistenceCurrent.%@", NSUUID.UUID.UUIDString]];
            NSError *error = nil;
            BOOL movedCurrent = NO;
            if ([fm fileExistsAtPath:executablePath]) {
                if (![fm moveItemAtPath:executablePath toPath:stagedCurrent error:&error]) {
                    NSLog(@"[uninstallPersistenceHelper] could not stage active persistence executable: %@", error);
                    [fm removeItemAtPath:restoredMarkPath error:nil];
                    return NO;
                }
                movedCurrent = YES;
            }
            if (![fm moveItemAtPath:backupPath toPath:executablePath error:&error]) {
                NSLog(@"[uninstallPersistenceHelper] failed to restore original executable %@: %@", executablePath, error);
                if (movedCurrent) [fm moveItemAtPath:stagedCurrent toPath:executablePath error:nil];
                [fm removeItemAtPath:restoredMarkPath error:nil];
                return NO;
            }
            if (movedCurrent) [fm removeItemAtPath:stagedCurrent error:nil];
            BKSTerminateApplicationForReasonAndReportWithDescription(systemAppProxy.bundleIdentifier, 5, false, @"TrollStore - Reload persistence helper");
        } else if (![fm fileExistsAtPath:restoredMarkPath] && [fm fileExistsAtPath:markPath]) {
            // There is no proof that the currently installed executable is the
            // original one. Do not delete markers or the TrollStore recovery data.
            NSLog(@"[uninstallPersistenceHelper] marker exists without backup or completed-restore marker: %@", backupPath);
            return NO;
        }

        if ([fm fileExistsAtPath:restoredMarkPath]) {
            NSError *helperError = nil;
            if ([fm fileExistsAtPath:helperPath] && ![fm removeItemAtPath:helperPath error:&helperError]) {
                NSLog(@"[uninstallPersistenceHelper] original executable restored, but helper binary cleanup failed: %@", helperError);
                return NO;
            }
            NSError *markError = nil;
            if ([fm fileExistsAtPath:markPath] && ![fm removeItemAtPath:markPath error:&markError]) {
                NSLog(@"[uninstallPersistenceHelper] original executable restored, but helper marker cleanup failed: %@", markError);
                return NO;
            }
            NSError *restoredError = nil;
            if (![fm removeItemAtPath:restoredMarkPath error:&restoredError]) {
                NSLog(@"[uninstallPersistenceHelper] could not remove restore transaction marker: %@", restoredError);
                return NO;
            }
        }
    }

    LSApplicationProxy *userAppProxy = findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_USER);
    if (userAppProxy) {
        NSString *markPath = [userAppProxy.bundleURL.path stringByAppendingPathComponent:@".TrollStorePersistenceHelper"];
        NSError *markerError = nil;
        if ([fm fileExistsAtPath:markPath] && ![fm removeItemAtPath:markPath error:&markerError]) {
            NSLog(@"[uninstallPersistenceHelper] failed to remove user helper marker: %@", markerError);
            return NO;
        }
    }
    return YES;
}

// Apparently there is some odd behaviour where TrollStore installed apps sometimes get restricted
// This works around that issue at least and is triggered when rebuilding icon cache
void cleanRestrictions(void)
{
	NSString* clientTruthPath = @"/private/var/containers/Shared/SystemGroup/systemgroup.com.apple.configurationprofiles/Library/ConfigurationProfiles/ClientTruth.plist";
	NSURL* clientTruthURL = [NSURL fileURLWithPath:clientTruthPath];
	NSDictionary* clientTruthDictionary = [NSDictionary dictionaryWithContentsOfURL:clientTruthURL];

	if(!clientTruthDictionary) return;

	NSArray* valuesArr;

	NSDictionary* lsdAppRemoval = clientTruthDictionary[@"com.apple.lsd.appremoval"];
	if(lsdAppRemoval && [lsdAppRemoval isKindOfClass:NSDictionary.class])
	{
		NSDictionary* clientRestrictions = lsdAppRemoval[@"clientRestrictions"];
		if(clientRestrictions && [clientRestrictions isKindOfClass:NSDictionary.class])
		{
			NSDictionary* unionDict = clientRestrictions[@"union"];
			if(unionDict && [unionDict isKindOfClass:NSDictionary.class])
			{
				NSDictionary* removedSystemAppBundleIDs = unionDict[@"removedSystemAppBundleIDs"];
				if(removedSystemAppBundleIDs && [removedSystemAppBundleIDs isKindOfClass:NSDictionary.class])
				{
					valuesArr = removedSystemAppBundleIDs[@"values"];
				}
			}
		}
	}

	if(!valuesArr || !valuesArr.count) return;

	NSMutableArray* valuesArrM = valuesArr.mutableCopy;
	__block BOOL changed = NO;

	[valuesArrM enumerateObjectsWithOptions:NSEnumerationReverse usingBlock:^(NSString* value, NSUInteger idx, BOOL *stop)
	{
		if(!isRemovableSystemApp(value))
		{
			[valuesArrM removeObjectAtIndex:idx];
			changed = YES;
		}
	}];

	if(!changed) return;

	NSMutableDictionary* clientTruthDictionaryM = (__bridge_transfer NSMutableDictionary*)CFPropertyListCreateDeepCopy(kCFAllocatorDefault, (__bridge CFDictionaryRef)clientTruthDictionary, kCFPropertyListMutableContainersAndLeaves);
	
	clientTruthDictionaryM[@"com.apple.lsd.appremoval"][@"clientRestrictions"][@"union"][@"removedSystemAppBundleIDs"][@"values"] = valuesArrM;

	[clientTruthDictionaryM writeToURL:clientTruthURL error:nil];

	killall(@"profiled", NO); // profiled needs to restart for the changes to apply
}

int MAIN_NAME(int argc, char *argv[], char *envp[])
{
	@autoreleasepool {
		if(argc <= 1) return -1;

		if(getuid() != 0)
		{
			NSLog(@"ERROR: trollstorehelper has to be run as root.");
			return -1;
		}

		NSMutableArray* args = [NSMutableArray new];
		for (int i = 1; i < argc; i++)
		{
			[args addObject:[NSString stringWithUTF8String:argv[i]]];
		}

		NSLog(@"trollstorehelper invoked with arguments: %@", args);

		int ret = 0;
		NSString* cmd = args.firstObject;
		if([cmd isEqualToString:@"install"])
		{
			if(args.count < 2) return -3;
			// use system method when specified, otherwise use custom method
			BOOL useInstalldMethod = [args containsObject:@"installd"];
			BOOL force = [args containsObject:@"force"];
			BOOL skipUICache = [args containsObject:@"skip-uicache"];
			BOOL stealthInstall = [args containsObject:@"stealth"];
			BOOL protectFromHomeScreenDeletion = [args containsObject:@"protect-home-screen-deletion"];
			gEditedMainEntitlements = nil;
			gEditedMainEntitlementsProvided = NO;
			gSigningConfiguration = nil;
			gRealSigningMissingProfile = NO;
			NSUInteger signingConfigIndex = [args indexOfObject:@"--signing-config"];
			if (signingConfigIndex != NSNotFound) {
				if (signingConfigIndex + 1 >= args.count) return 190;
				id parsedConfig = [NSDictionary dictionaryWithContentsOfFile:args[signingConfigIndex + 1]];
				if (![parsedConfig isKindOfClass:NSDictionary.class] || ![parsedConfig[@"ldidConfigPath"] isKindOfClass:NSString.class]) return 190;
				gSigningConfiguration = parsedConfig;
			}
			NSUInteger entitlementsIndex = [args indexOfObject:@"--entitlements"];
			if (entitlementsIndex != NSNotFound) {
				if (entitlementsIndex + 1 >= args.count) return 186;
				id parsedEntitlements = [NSDictionary dictionaryWithContentsOfFile:args[entitlementsIndex + 1]];
				if (![parsedEntitlements isKindOfClass:NSDictionary.class]) return 186;
				gEditedMainEntitlements = parsedEntitlements;
				gEditedMainEntitlementsProvided = YES;
			}
			NSMutableArray<NSString *> *pluginPaths = [NSMutableArray array];
			for(NSUInteger i = 1; i + 1 < args.count; i++)
			{
				if([args[i] isEqualToString:@"--inject-dylib"])
				{
					if(i + 1 >= args.count - 1 || ![args[i + 1] isKindOfClass:NSString.class] || ![args[i + 1] length]) return -3;
					[pluginPaths addObject:args[++i]];
				}
			}
			NSString* ipaPath = args.lastObject;
			ret = installIpa(ipaPath, force, useInstalldMethod, skipUICache, stealthInstall, protectFromHomeScreenDeletion, pluginPaths.copy);
			gEditedMainEntitlements = nil;
			gEditedMainEntitlementsProvided = NO;
			gSigningConfiguration = nil;
			gRealSigningMissingProfile = NO;
		}
		else if([cmd isEqualToString:@"clear-cache"])
		{
			if(args.count < 2) return -3;
			NSString *detail = nil;
			ret = TSAppMaintenanceClearCache(args[1], &detail);
			if(detail.length) NSLog(@"[clear-cache] %@", detail);
		}
		else if([cmd isEqualToString:@"clear-data"])
		{
			if(args.count < 2) return -3;
			NSString *detail = nil;
			ret = TSAppMaintenanceClearData(args[1], &detail);
			if(detail.length) NSLog(@"[clear-data] %@", detail);
		}
		else if([cmd isEqualToString:@"clear-cache-all"])
		{
			NSString *detail = nil;
			ret = TSAppMaintenanceClearAllCaches(&detail);
			if(detail.length) NSLog(@"[clear-cache-all] %@", detail);
		}
		else if([cmd isEqualToString:@"block-app-update"] || [cmd isEqualToString:@"unblock-app-update"])
		{
			if(args.count < 2) return -3;
			NSString *detail = nil;
			BOOL blocked = [cmd isEqualToString:@"block-app-update"];
			ret = TSAppUpdateControlSetBlocked(args[1], blocked, &detail);
			if(detail.length) NSLog(@"[%@] %@", cmd, detail);
		}
		else if([cmd isEqualToString:@"list-blocked-app-updates"])
		{
			NSArray<NSString *> *blocked = TSAppUpdateControlCopyBlockedBundleIdentifiers();
			NSError *jsonError = nil;
			NSData *json = [NSJSONSerialization dataWithJSONObject:@{@"blockedBundleIdentifiers":blocked ?: @[]} options:0 error:&jsonError];
			if(!json || jsonError) return 308;
			fwrite(json.bytes, 1, json.length, stdout);
			fputc('\n', stdout);
			fflush(stdout);
		}
		else if([cmd isEqualToString:@"inject-dylib"])
		{
			if(args.count < 3) return -3;
			NSString *bundleID = args[1];
			NSString *dylibPath = args[2];
			BOOL weak = [args containsObject:@"weak"];
			NSString *detail = nil;
			ret = TSAppMaintenanceInjectDylib(bundleID, dylibPath, weak, &detail);
			if(detail.length) NSLog(@"[inject-dylib] %@", detail);
		}
		else if([cmd isEqualToString:@"decrypt"])
		{
			if(args.count < 3) return -3;
			NSString *detail = nil;
			ret = TSAppDecryptorDecryptBundleToIPA(args[1], args[2], &detail);
			if(detail.length) NSLog(@"[decrypt] %@", detail);
		}
		else if([cmd isEqualToString:@"cleanup-install"])
		{
			// Error 189 is only returned from the fresh installd placeholder path.
			// In particular, never run this cleanup for error 171 (existing app conflict).
			if(args.count < 3 || [args[2] intValue] != 189)
			{
				NSLog(@"[cleanup-install] skipped: cleanup is only allowed after error 189");
				ret = 0;
			}
			else ret = cleanupInstallResidueForIPA(args[1]);
		}
		else if([cmd isEqualToString:@"uninstall"])
		{
			if(args.count < 2) return -3;
			// use custom method when specified, otherwise use system method
			BOOL useCustomMethod = [args containsObject:@"custom"];
			NSString* appId = args.lastObject;
			ret = uninstallAppById(appId, useCustomMethod);
		}
		else if([cmd isEqualToString:@"uninstall-path"])
		{
			if(args.count < 2) return -3;
			// use custom method when specified, otherwise use system method
			BOOL useCustomMethod = [args containsObject:@"custom"];
			NSString* appPath = args.lastObject;
			ret = uninstallAppByPath(appPath, useCustomMethod);
		}
		else if([cmd isEqualToString:@"refresh"])
		{
			refreshAppRegistrations(!shouldRegisterAsUserByDefault());
		}
		else if([cmd isEqualToString:@"refresh-all"])
		{
			cleanRestrictions();
			//refreshAppRegistrations(NO); // <- fixes app permissions resetting, causes apps to move around on home screen, so I had to disable it
			[[NSFileManager defaultManager] removeItemAtPath:@"/var/containers/Shared/SystemGroup/systemgroup.com.apple.lsd.iconscache/Library/Caches/com.apple.IconsCache" error:nil];
			[[LSApplicationWorkspace defaultWorkspace] _LSPrivateRebuildApplicationDatabasesForSystemApps:YES internal:YES user:YES];
			if (!shouldRegisterAsUserByDefault()) refreshAppRegistrations(YES);
			killall(@"backboardd", YES);
		}
		else if([cmd isEqualToString:@"url-scheme"])
		{
			if(args.count < 2) return -3;
			NSString* modifyArg = args.lastObject;
			BOOL newState = [modifyArg isEqualToString:@"enable"];
			if(newState == YES || [modifyArg isEqualToString:@"disable"])
			{
				setTSURLSchemeState(newState, nil);
			}
		}
		else if([cmd isEqualToString:@"reboot"])
		{
			[[FBSSystemService sharedService] reboot];
			// Give the system some time to reboot
			sleep(1);
		}
		else if([cmd isEqualToString:@"enable-jit"])
		{
			if(args.count < 2) return -3;
			NSString* userAppId = args.lastObject;
			ret = enableJIT(userAppId);
		}
		else if([cmd isEqualToString:@"modify-registration"])
		{
			if(args.count < 3) return -3;
			NSString* appPath = args[1];
			NSString* newRegistration = args[2];

			NSString* trollStoreMark = [[appPath stringByDeletingLastPathComponent] stringByAppendingPathComponent:TS_ACTIVE_MARKER];
			if([[NSFileManager defaultManager] fileExistsAtPath:trollStoreMark])
			{
				registerPath(appPath, NO, [newRegistration isEqualToString:@"System"]);
			}
		}
		else if ([cmd isEqualToString:@"transfer-apps"])
		{
			bool oneFailed = false;
			for (NSString *candidatePath in trollStoreInactiveInstalledAppBundlePaths()) {
				NSLog(@"[transfer-apps] preparing %@", candidatePath);
				NSString *appBundlePath = canonicalExistingPath(candidatePath);
				struct stat appStat;
				NSString *transferBundleID = appBundlePath.length ? appIdForAppPath(appBundlePath) : nil;
				if (!appBundlePath.length || !transferBundleID.length || ![appBundlePath.pathExtension.lowercaseString isEqualToString:@"app"] ||
					!isManagedAppBundlePath(appBundlePath) || lstat(appBundlePath.fileSystemRepresentation, &appStat) != 0 ||
					!S_ISDIR(appStat.st_mode) || S_ISLNK(appStat.st_mode) ||
					![appBundlePath.stringByDeletingLastPathComponent isEqualToString:canonicalExistingPath(candidatePath.stringByDeletingLastPathComponent)]) {
					NSLog(@"[transfer-apps] refusing unsafe or non-managed app bundle path %@", candidatePath);
					oneFailed = true;
					continue;
				}

				NSString *containerPath = appBundlePath.stringByDeletingLastPathComponent;
				NSString *activeMarkerPath = [containerPath stringByAppendingPathComponent:TS_ACTIVE_MARKER];
				NSString *inactiveMarkerPath = [containerPath stringByAppendingPathComponent:TS_INACTIVE_MARKER];
				struct stat inactiveMarkerStat;
				if (lstat(inactiveMarkerPath.fileSystemRepresentation, &inactiveMarkerStat) != 0 ||
					!S_ISREG(inactiveMarkerStat.st_mode) || S_ISLNK(inactiveMarkerStat.st_mode)) {
					NSLog(@"[transfer-apps] missing or invalid inactive marker for %@", appBundlePath);
					oneFailed = true;
					continue;
				}

				NSString *tmpPath = createPrivateSiblingTemporaryDirectory(containerPath, @"TrollStore-transfer");
				if (!tmpPath) { oneFailed = true; continue; }
				NSString *tmpAppPath = [tmpPath stringByAppendingPathComponent:appBundlePath.lastPathComponent];
				NSError *copyError = nil;
				if (![[NSFileManager defaultManager] copyItemAtPath:appBundlePath toPath:tmpAppPath error:&copyError]) {
					NSLog(@"[transfer-apps] failed to stage %@: %@", appBundlePath, copyError);
					[[NSFileManager defaultManager] removeItemAtPath:tmpPath error:nil];
					oneFailed = true;
					continue;
				}

				int signRet = signApp(tmpAppPath);
				if (signRet != 0 && signRet != 182 && signRet != 184) {
					NSLog(@"[transfer-apps] signing %@ failed with %d; original bundle preserved", appBundlePath, signRet);
					[[NSFileManager defaultManager] removeItemAtPath:tmpPath error:nil];
					oneFailed = true;
					continue;
				}

				struct stat currentOriginalStat;
				if (lstat(appBundlePath.fileSystemRepresentation, &currentOriginalStat) != 0 || !S_ISDIR(currentOriginalStat.st_mode) ||
					S_ISLNK(currentOriginalStat.st_mode) || currentOriginalStat.st_dev != appStat.st_dev || currentOriginalStat.st_ino != appStat.st_ino) {
					NSLog(@"[transfer-apps] original bundle changed while it was being signed: %@", appBundlePath);
					[[NSFileManager defaultManager] removeItemAtPath:tmpPath error:nil];
					oneFailed = true;
					continue;
				}
				NSString *backupPath = [containerPath stringByAppendingPathComponent:[NSString stringWithFormat:@".%@.TrollStoreBackup.%@", appBundlePath.lastPathComponent, NSUUID.UUID.UUIDString]];
				if (rename(appBundlePath.fileSystemRepresentation, backupPath.fileSystemRepresentation) != 0) {
					NSLog(@"[transfer-apps] cannot preserve original bundle %@: %s", appBundlePath, strerror(errno));
					[[NSFileManager defaultManager] removeItemAtPath:tmpPath error:nil];
					oneFailed = true;
					continue;
				}
				if (rename(tmpAppPath.fileSystemRepresentation, appBundlePath.fileSystemRepresentation) != 0) {
					int commitError = errno;
					if (rename(backupPath.fileSystemRepresentation, appBundlePath.fileSystemRepresentation) != 0)
						NSLog(@"[transfer-apps] CRITICAL: could not restore %@ from %@: %s", appBundlePath, backupPath, strerror(errno));
					NSLog(@"[transfer-apps] atomic replacement failed: %s", strerror(commitError));
					[[NSFileManager defaultManager] removeItemAtPath:tmpPath error:nil];
					oneFailed = true;
					continue;
				}

				if (!fixPermissionsOfAppBundle(appBundlePath)) {
					NSLog(@"[transfer-apps] permission normalization failed for %@; restoring original bundle", appBundlePath);
					[[NSFileManager defaultManager] removeItemAtPath:appBundlePath error:nil];
					if (rename(backupPath.fileSystemRepresentation, appBundlePath.fileSystemRepresentation) != 0)
						NSLog(@"[transfer-apps] CRITICAL: rollback failed; original bundle remains at %@: %s", backupPath, strerror(errno));
					[[NSFileManager defaultManager] removeItemAtPath:tmpPath error:nil];
					oneFailed = true;
					continue;
				}
				struct stat activeMarkerStat;
				int activeMarkerResult = lstat(activeMarkerPath.fileSystemRepresentation, &activeMarkerStat);
				BOOL hadActiveMarker = (activeMarkerResult == 0 && S_ISREG(activeMarkerStat.st_mode) && !S_ISLNK(activeMarkerStat.st_mode));
				BOOL activeMarkerSafe = hadActiveMarker || (activeMarkerResult != 0 && errno == ENOENT);
				BOOL markerReady = activeMarkerSafe && (hadActiveMarker || [[NSData data] writeToFile:activeMarkerPath options:NSDataWritingAtomic error:&copyError]);
				BOOL registered = markerReady && registerPath(appBundlePath, NO, !shouldRegisterAsUserByDefault());
				if (!registered) {
					NSLog(@"[transfer-apps] registration failed for %@; restoring previous bundle", appBundlePath);
					registerPath(appBundlePath, YES, !shouldRegisterAsUserByDefault());
					if (!hadActiveMarker) [[NSFileManager defaultManager] removeItemAtPath:activeMarkerPath error:nil];
					[[NSFileManager defaultManager] removeItemAtPath:appBundlePath error:nil];
					if (rename(backupPath.fileSystemRepresentation, appBundlePath.fileSystemRepresentation) != 0)
						NSLog(@"[transfer-apps] CRITICAL: rollback failed; original bundle remains at %@: %s", backupPath, strerror(errno));
					[[NSFileManager defaultManager] removeItemAtPath:tmpPath error:nil];
					oneFailed = true;
					continue;
				}

				if (![[NSFileManager defaultManager] removeItemAtPath:inactiveMarkerPath error:&copyError]) {
					NSLog(@"[transfer-apps] could not finalize active marker for %@: %@; attempting rollback", appBundlePath, copyError);
					registerPath(appBundlePath, YES, !shouldRegisterAsUserByDefault());
					if (!hadActiveMarker) [[NSFileManager defaultManager] removeItemAtPath:activeMarkerPath error:nil];
					[[NSFileManager defaultManager] removeItemAtPath:appBundlePath error:nil];
					if (rename(backupPath.fileSystemRepresentation, appBundlePath.fileSystemRepresentation) != 0)
						NSLog(@"[transfer-apps] CRITICAL: rollback failed; original bundle remains at %@: %s", backupPath, strerror(errno));
					[[NSFileManager defaultManager] removeItemAtPath:tmpPath error:nil];
					oneFailed = true;
					continue;
				}

				NSError *backupCleanupError = nil;
				if (![[NSFileManager defaultManager] removeItemAtPath:backupPath error:&backupCleanupError])
					NSLog(@"[transfer-apps] transfer committed; backup cleanup is pending at %@: %@", backupPath, backupCleanupError);
				[[NSFileManager defaultManager] removeItemAtPath:tmpPath error:nil];
				NSLog(@"[transfer-apps] transferred %@", appBundlePath);
			}
			if (oneFailed) ret = -1;
		}

		else if([cmd isEqualToString:@"install-trollstore"])
		{
			if(args.count < 2) return -3;
			NSString* tsTar = args.lastObject;
			ret = installTrollStore(tsTar);
			NSLog(@"installed troll store? %d", ret==0);
		}
        else if([cmd isEqualToString:@"uninstall-trollstore"])
        {
            int appsResult = 0;
            if (![args containsObject:@"preserve-apps"]) appsResult = uninstallAllApps([args containsObject:@"custom"]);
            if (appsResult != 0) {
                // Keep TrollStore installed so the user can retry cleanup; do not
                // remove the only UI that can report which managed app failed.
                ret = appsResult;
            } else {
                ret = uninstallTrollStore(YES);
            }
        }
		else if([cmd isEqualToString:@"install-ldid"])
		{
			if(args.count < 2) return -3;
			NSString* ldidPath = args[1];
			ret = installLdid(ldidPath);
		}
		else if([cmd isEqualToString:@"install-persistence-helper"])
		{
			if(args.count < 2) return -3;
			NSString* systemAppId = args[1];
			NSString* persistenceHelperBinary;
			NSString* rootHelperBinary;
			if (args.count == 4) {
				persistenceHelperBinary = args[2];
				rootHelperBinary = args[3];
			}

			// Hard stop even if a caller bypasses the UI candidate filter.
			// Apple Shortcuts must never be converted into a Persistence Helper host.
			if ([systemAppId isEqualToString:@"com.apple.shortcuts"]) {
				NSLog(@"Refusing Persistence Helper installation into Apple Shortcuts.");
				ret = EPERM;
            } else {
                ret = installPersistenceHelper(systemAppId, persistenceHelperBinary, rootHelperBinary);
            }
		}
		else if([cmd isEqualToString:@"uninstall-persistence-helper"])
		{
			ret = uninstallPersistenceHelper() ? 0 : 1;
		}
		else if([cmd isEqualToString:@"register-user-persistence-helper"])
		{
			if(args.count != 2) return -3;
			NSString* userAppId = args[1];
			ret = registerUserPersistenceHelper(userAppId);
		}
		else if([cmd isEqualToString:@"check-dev-mode"])
		{
			// switch the result, so 0 is enabled, and 1 is disabled/error
			ret = !checkDeveloperMode();
		}
		else if([cmd isEqualToString:@"arm-dev-mode"])
		{
			// assumes that checkDeveloperMode() has already been called
			ret = !armDeveloperMode(NULL);
		}

		NSLog(@"trollstorehelper returning %d", ret);
		return ret;
	}
}
