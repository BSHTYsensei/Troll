#import "TSMachODependencyResolver.h"
#import <mach-o/loader.h>
#import <mach-o/fat.h>
#import <mach/machine.h>
#import <sys/stat.h>
#import <string.h>

static uint32_t TSDRReadBE32(const uint8_t *p) {
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) | ((uint32_t)p[2] << 8) | (uint32_t)p[3];
}
static uint64_t TSDRReadBE64(const uint8_t *p) {
    return ((uint64_t)TSDRReadBE32(p) << 32) | TSDRReadBE32(p + 4);
}
static uint32_t TSDRReadLE32(const uint8_t *p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) | ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}
static NSString *TSDRDependencyComponentName(NSString *loadName);
static BOOL TSDRIsHookDependency(NSString *name) {
    NSString *lower = name.lowercaseString;
    return [lower containsString:@"substrate"] || [lower containsString:@"ellekit"] ||
           [lower containsString:@"libhooker"] || [lower containsString:@"tweakloader"];
}
static BOOL TSDRIsSystemDependency(NSString *name) {
    NSString *lower = name.lowercaseString;
    NSString *component = TSDRDependencyComponentName(name);
    NSString *lowerComponent = component.lowercaseString;
    // Hook runtimes are deliberately excluded before the generic /usr/lib
    // and framework checks. They are not supplied by iOS itself.
    if (TSDRIsHookDependency(name)) return NO;
    if ([lower hasPrefix:@"/system/"] || [lower hasPrefix:@"/usr/lib/system/"] ||
        [lower hasPrefix:@"/usr/lib/libsystem"] || [lower hasPrefix:@"/system/library/frameworks/"] ||
        [lower hasPrefix:@"/usr/lib/swift/"] || [lower hasPrefix:@"/system/library/privateframeworks/"] ||
        [lowerComponent hasPrefix:@"libswift"]) return YES;

    // A large number of tweak binaries use @rpath names for Apple frameworks,
    // and absolute /usr/lib names for the system C/ObjC runtimes. These should
    // never be copied into the host app as third-party dependencies.
    static NSSet<NSString *> *systemFrameworks;
    static NSSet<NSString *> *systemDylibs;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        systemFrameworks = [NSSet setWithArray:@[
            @"foundation.framework", @"uikit.framework", @"uikitcore.framework", @"corefoundation.framework",
            @"coregraphics.framework", @"quartzcore.framework", @"security.framework", @"coretelephony.framework",
            @"coreservices.framework", @"cfnetwork.framework", @"systemconfiguration.framework", @"avfoundation.framework",
            @"audiotoolbox.framework", @"coreaudio.framework", @"mediaplayer.framework", @"mediatoolbox.framework",
            @"webkit.framework", @"storekit.framework", @"safariservices.framework", @"photos.framework", @"photosui.framework",
            @"mapkit.framework", @"corelocation.framework", @"contacts.framework", @"contactskit.framework", @"contactsui.framework",
            @"eventkit.framework", @"eventkitui.framework", @"usernotifications.framework", @"localauthentication.framework",
            @"authenticationservices.framework", @"network.framework", @"corebluetooth.framework", @"coremotion.framework",
            @"coreimage.framework", @"vision.framework", @"accelerate.framework", @"metal.framework", @"metalkit.framework",
            @"coredata.framework", @"cloudkit.framework", @"gamecontroller.framework", @"gamekit.framework", @"messageui.framework",
            @"social.framework", @"accounts.framework", @"intents.framework", @"intentsui.framework", @"passkit.framework",
            @"pushkit.framework", @"replaykit.framework", @"quicklook.framework", @"quicklookthumbnailing.framework",
            @"pdfkit.framework", @"widgetkit.framework", @"backgroundtasks.framework", @"apptrackingtransparency.framework",
            @"devicecheck.framework", @"adsupport.framework", @"corenfc.framework", @"imageio.framework", @"coretext.framework",
            @"mobilecoreservices.framework", @"uniformtypeidentifiers.framework"
        ]];
        systemDylibs = [NSSet setWithArray:@[
            @"libobjc.a.dylib", @"libsystem.b.dylib", @"libc++.1.dylib", @"libc++abi.dylib", @"libz.1.dylib",
            @"libsqlite3.dylib", @"libcompression.dylib", @"libiconv.2.dylib", @"libxml2.2.dylib", @"libresolv.9.dylib",
            @"libdyld.dylib", @"libdispatch.dylib", @"libcommoncrypto.dylib", @"libmacho.dylib", @"libnetwork.dylib",
            @"libarchive.2.dylib", @"libbz2.1.0.dylib", @"libcharset.1.0.0.dylib", @"libncurses.5.4.dylib", @"libedit.3.dylib",
            @"libpam.2.dylib", @"libutil.dylib", @"libpcap.a.dylib", @"libdns_services.dylib", @"libsystem_platform.dylib",
            @"libsystem_pthread.dylib", @"libsystem_kernel.dylib", @"libsystem_malloc.dylib", @"libsystem_c.dylib"
        ]];
    });
    if ([lowerComponent hasSuffix:@".framework"] && [systemFrameworks containsObject:lowerComponent]) return YES;
    if ([systemDylibs containsObject:lowerComponent]) return YES;
    return NO;
}
static NSString *TSDRFrameworkExecutable(NSString *frameworkPath) {
    NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:[frameworkPath stringByAppendingPathComponent:@"Info.plist"]];
    NSString *executable = [info[@"CFBundleExecutable"] isKindOfClass:NSString.class] ? info[@"CFBundleExecutable"] : frameworkPath.lastPathComponent.stringByDeletingPathExtension;
    if (!executable.length || [executable containsString:@"/"] || [executable containsString:@"\\"]) return nil;
    NSString *path = [frameworkPath stringByAppendingPathComponent:executable];
    return [[NSFileManager defaultManager] fileExistsAtPath:path] ? path : nil;
}
static NSString *TSDRBinaryForPayload(NSString *payload) {
    if ([payload.pathExtension.lowercaseString isEqualToString:@"framework"]) return TSDRFrameworkExecutable(payload);
    return payload;
}

// Parses the arm64/arm64e Mach-O slice only. All offsets and load-command sizes
// are bounded before reading so malformed third-party binaries cannot overrun.
static NSArray<NSDictionary *> *TSDRDependenciesForMachO(NSString *path) {
    NSData *data = [NSData dataWithContentsOfFile:path options:NSDataReadingMappedIfSafe error:nil];
    if (data.length < sizeof(struct mach_header_64)) return @[];
    const uint8_t *bytes = data.bytes;
    uint64_t sliceOffset = 0, sliceSize = data.length;
    uint32_t magicBE = TSDRReadBE32(bytes);
    if (magicBE == FAT_MAGIC || magicBE == FAT_MAGIC_64) {
        if (data.length < sizeof(struct fat_header)) return @[];
        uint32_t count = TSDRReadBE32(bytes + 4);
        if (count > 64) return @[];
        BOOL found = NO;
        size_t stride = magicBE == FAT_MAGIC_64 ? sizeof(struct fat_arch_64) : sizeof(struct fat_arch);
        if (sizeof(struct fat_header) + (uint64_t)count * stride > data.length) return @[];
        for (uint32_t i = 0; i < count; i++) {
            const uint8_t *arch = bytes + sizeof(struct fat_header) + (size_t)i * stride;
            int32_t cpu = (int32_t)TSDRReadBE32(arch);
            if (cpu != CPU_TYPE_ARM64) continue;
            uint64_t offset = magicBE == FAT_MAGIC_64 ? TSDRReadBE64(arch + 8) : TSDRReadBE32(arch + 8);
            uint64_t size = magicBE == FAT_MAGIC_64 ? TSDRReadBE64(arch + 16) : TSDRReadBE32(arch + 12);
            if (offset > data.length || size > data.length - offset || size < sizeof(struct mach_header_64)) continue;
            sliceOffset = offset; sliceSize = size; found = YES; break;
        }
        if (!found) return @[];
    } else if (magicBE == FAT_CIGAM || magicBE == FAT_CIGAM_64) {
        // Byte-swapped FAT containers are uncommon for iOS payloads. Reject
        // rather than guessing at their offsets.
        return @[];
    }
    if (sliceOffset > data.length || sliceSize > data.length - sliceOffset || sliceSize < sizeof(struct mach_header_64)) return @[];
    const uint8_t *slice = bytes + sliceOffset;
    uint32_t magic = TSDRReadLE32(slice);
    if (magic != MH_MAGIC_64) return @[];
    int32_t cpuType = (int32_t)TSDRReadLE32(slice + 4);
    if (cpuType != CPU_TYPE_ARM64) return @[];
    uint32_t commandCount = TSDRReadLE32(slice + 16);
    uint32_t commandBytes = TSDRReadLE32(slice + 20);
    if (commandCount > 8192 || commandBytes > sliceSize - sizeof(struct mach_header_64)) return @[];
    size_t cursor = sizeof(struct mach_header_64);
    size_t commandsEnd = cursor + commandBytes;
    NSMutableArray<NSDictionary *> *dependencies = [NSMutableArray array];
    for (uint32_t i = 0; i < commandCount; i++) {
        if (cursor > commandsEnd || commandsEnd - cursor < sizeof(struct load_command)) break;
        uint32_t command = TSDRReadLE32(slice + cursor);
        uint32_t commandSize = TSDRReadLE32(slice + cursor + 4);
        if (commandSize < sizeof(struct load_command) || commandSize > commandsEnd - cursor) break;
        uint32_t baseCommand = command & ~LC_REQ_DYLD;
        BOOL isWeak = baseCommand == (LC_LOAD_WEAK_DYLIB & ~LC_REQ_DYLD);
        BOOL isDylib = baseCommand == (LC_LOAD_DYLIB & ~LC_REQ_DYLD) || isWeak ||
                       baseCommand == (LC_REEXPORT_DYLIB & ~LC_REQ_DYLD) ||
                       baseCommand == (LC_LOAD_UPWARD_DYLIB & ~LC_REQ_DYLD);
        if (isDylib && commandSize >= sizeof(struct dylib_command)) {
            uint32_t nameOffset = TSDRReadLE32(slice + cursor + 8);
            if (nameOffset < sizeof(struct dylib_command) && nameOffset < commandSize) {
                const char *raw = (const char *)(slice + cursor + nameOffset);
                size_t remaining = commandSize - nameOffset;
                const char *end = memchr(raw, '\0', remaining);
                if (end && end > raw) {
                    NSString *name = [[NSString alloc] initWithBytes:raw length:(NSUInteger)(end - raw) encoding:NSUTF8StringEncoding];
                    if (name.length) [dependencies addObject:@{@"name":name, @"weak":@(isWeak)}];
                }
            }
        }
        cursor += commandSize;
    }
    return dependencies.copy;
}

static NSString *TSDRDependencyComponentName(NSString *loadName) {
    NSArray<NSString *> *parts = [loadName componentsSeparatedByString:@"/"];
    for (NSString *part in parts) if ([part.lowercaseString hasSuffix:@".framework"]) return part;
    return loadName.lastPathComponent;
}

static NSString *TSDRPackageSearchRoot(NSString *pluginPath) {
    NSString *parent = pluginPath.stringByDeletingLastPathComponent;
    NSString *cursor = parent;
    for (NSUInteger depth = 0; depth < 12 && cursor.length; depth++) {
        NSString *name = cursor.lastPathComponent.lowercaseString;
        if ([name hasSuffix:@".contents"] || [name hasPrefix:@"extracted-"]) return cursor;
        // A standalone .dylib in the top-level store is not a package. Do not
        // borrow another unrelated plugin's files as dependencies.
        if ([name isEqualToString:@"plugins"] || [name isEqualToString:@"packages"]) return nil;
        if ([name isEqualToString:@"tweakpresets"]) return [parent isEqualToString:cursor] ? nil : parent;
        NSString *next = cursor.stringByDeletingLastPathComponent;
        if ([next isEqualToString:cursor]) break;
        cursor = next;
    }
    return parent;
}

static BOOL TSDRHasArm64MachO(NSString *path) {
    NSData *data = [NSData dataWithContentsOfFile:path options:NSDataReadingMappedIfSafe error:nil];
    if (data.length < sizeof(struct mach_header_64)) return NO;
    const uint8_t *bytes = data.bytes;
    uint32_t magicBE = TSDRReadBE32(bytes);
    if (magicBE == FAT_MAGIC || magicBE == FAT_MAGIC_64) {
        if (data.length < sizeof(struct fat_header)) return NO;
        uint32_t count = TSDRReadBE32(bytes + 4);
        size_t stride = magicBE == FAT_MAGIC_64 ? sizeof(struct fat_arch_64) : sizeof(struct fat_arch);
        if (count > 64 || sizeof(struct fat_header) + (uint64_t)count * stride > data.length) return NO;
        for (uint32_t i = 0; i < count; i++) {
            const uint8_t *arch = bytes + sizeof(struct fat_header) + (size_t)i * stride;
            if ((int32_t)TSDRReadBE32(arch) != CPU_TYPE_ARM64) continue;
            uint64_t offset = magicBE == FAT_MAGIC_64 ? TSDRReadBE64(arch + 8) : TSDRReadBE32(arch + 8);
            uint64_t size = magicBE == FAT_MAGIC_64 ? TSDRReadBE64(arch + 16) : TSDRReadBE32(arch + 12);
            if (offset > data.length || size > data.length - offset || size < sizeof(struct mach_header_64)) continue;
            const uint8_t *slice = bytes + offset;
            return TSDRReadLE32(slice) == MH_MAGIC_64 && (int32_t)TSDRReadLE32(slice + 4) == CPU_TYPE_ARM64;
        }
        return NO;
    }
    return magicBE == 0xCFFAEDFEU && (int32_t)TSDRReadLE32(bytes + 4) == CPU_TYPE_ARM64;
}

static void TSDRCollectPayloads(NSString *directory, NSUInteger depth, NSMutableArray<NSString *> *result) {
    if (!directory.length || depth > 8) return;
    NSFileManager *fm = NSFileManager.defaultManager;
    NSArray<NSString *> *children = [fm contentsOfDirectoryAtPath:directory error:nil];
    for (NSString *child in children) {
        if ([child hasPrefix:@"."]) continue;
        NSString *path = [directory stringByAppendingPathComponent:child];
        struct stat linkStat, targetStat;
        if (lstat(path.fileSystemRepresentation, &linkStat) != 0) continue;
        BOOL isSymlink = S_ISLNK(linkStat.st_mode);
        if (stat(path.fileSystemRepresentation, &targetStat) != 0) continue;
        if (S_ISDIR(targetStat.st_mode)) {
            if ([child.pathExtension.lowercaseString isEqualToString:@"framework"] && !isSymlink) {
                NSString *binary = TSDRFrameworkExecutable(path);
                NSString *resolvedRoot = path.stringByResolvingSymlinksInPath.stringByStandardizingPath;
                NSString *resolvedBinary = binary.stringByResolvingSymlinksInPath.stringByStandardizingPath;
                BOOL contained = [resolvedBinary isEqualToString:resolvedRoot] || [resolvedBinary hasPrefix:[resolvedRoot stringByAppendingString:@"/"]];
                if (binary && contained && TSDRHasArm64MachO(binary) && [result indexOfObject:path] == NSNotFound) [result addObject:path];
            } else if (!isSymlink) {
                TSDRCollectPayloads(path, depth + 1, result);
            }
        } else if (S_ISREG(targetStat.st_mode) && [child.pathExtension.lowercaseString isEqualToString:@"dylib"]) {
            if (TSDRHasArm64MachO(path) && [result indexOfObject:path] == NSNotFound) [result addObject:path];
        }
    }
}

static BOOL TSDRDependencyAlreadyInTarget(NSString *loadName, NSString *appPath, NSString *sourceBinary) {
    if ([loadName hasPrefix:@"/"] && [[NSFileManager defaultManager] fileExistsAtPath:loadName]) return YES;
    if ([loadName hasPrefix:@"@loader_path/"]) {
        NSString *relative = [loadName substringFromIndex:@"@loader_path/".length];
        NSString *candidate = [[sourceBinary stringByDeletingLastPathComponent] stringByAppendingPathComponent:relative];
        if ([[NSFileManager defaultManager] fileExistsAtPath:candidate]) return YES;
    }
    if ([loadName hasPrefix:@"@executable_path/"]) {
        NSString *relative = [loadName substringFromIndex:@"@executable_path/".length];
        NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:[appPath stringByAppendingPathComponent:@"Info.plist"]];
        NSString *executable = [info[@"CFBundleExecutable"] isKindOfClass:NSString.class] ? info[@"CFBundleExecutable"] : nil;
        if (executable.length) {
            NSString *candidate = [[[appPath stringByAppendingPathComponent:executable] stringByDeletingLastPathComponent] stringByAppendingPathComponent:relative];
            if ([[NSFileManager defaultManager] fileExistsAtPath:candidate]) return YES;
        }
    }
    NSString *component = TSDRDependencyComponentName(loadName);
    NSString *existing = [[appPath stringByAppendingPathComponent:@"Frameworks"] stringByAppendingPathComponent:component];
    return component.length && [[NSFileManager defaultManager] fileExistsAtPath:existing];
}

@implementation TSMachODependencyResolver
+ (NSArray<NSString *> *)additionalPayloadsForPluginAtPath:(NSString *)pluginPath targetApp:(NSString *)appPath runtimeRoot:(NSString *)runtimeRoot unresolvedDependencies:(NSArray<NSString *> **)unresolved {
    if (unresolved) *unresolved = @[];
    NSString *pluginBinary = TSDRBinaryForPayload(pluginPath);
    if (!pluginBinary.length || !TSDRHasArm64MachO(pluginBinary)) {
        if (unresolved) *unresolved = @[@"plugin payload is not a valid arm64 Mach-O image"];
        return @[];
    }
    NSArray<NSDictionary *> *initial = TSDRDependenciesForMachO(pluginBinary);
    if (!initial.count) return @[];

    NSMutableArray<NSString *> *packageCandidates = [NSMutableArray array];
    NSString *packageRoot = TSDRPackageSearchRoot(pluginPath);
    TSDRCollectPayloads(packageRoot, 0, packageCandidates);
    NSMutableArray<NSString *> *runtimeCandidates = [NSMutableArray array];
    TSDRCollectPayloads(runtimeRoot, 0, runtimeCandidates);

    NSMutableArray<NSString *> *additional = [NSMutableArray array];
    NSMutableArray<NSString *> *missing = [NSMutableArray array];
    NSMutableSet<NSString *> *visitedPaths = [NSMutableSet setWithObject:pluginBinary.stringByResolvingSymlinksInPath.stringByStandardizingPath];
    NSMutableSet<NSString *> *processedLoads = [NSMutableSet set];
    NSMutableArray<NSDictionary *> *queue = [NSMutableArray array];
    for (NSDictionary *dependency in initial) {
        if ([dependency[@"weak"] boolValue]) continue;
        NSString *name = dependency[@"name"];
        if (name.length && !TSDRIsSystemDependency(name)) [queue addObject:@{@"name":name, @"source":pluginBinary}];
    }

    NSUInteger cursor = 0;
    while (cursor < queue.count && additional.count < 24) {
        NSDictionary *item = queue[cursor++];
        NSString *loadName = item[@"name"];
        NSString *sourceBinary = item[@"source"];
        NSString *normalizedLoad = loadName.lowercaseString;
        if (!loadName.length || [processedLoads containsObject:normalizedLoad]) continue;
        [processedLoads addObject:normalizedLoad];
        if (TSDRIsSystemDependency(loadName) || TSDRDependencyAlreadyInTarget(loadName, appPath, sourceBinary)) continue;

        NSString *component = TSDRDependencyComponentName(loadName);
        NSString *lowerComponent = component.lowercaseString;
        if (!component.length) continue;

        NSMutableArray<NSString *> *matches = [NSMutableArray array];
        for (NSString *candidate in packageCandidates) {
            NSString *resolved = candidate.stringByResolvingSymlinksInPath.stringByStandardizingPath;
            if ([visitedPaths containsObject:resolved]) continue;
            if ([candidate.lastPathComponent.lowercaseString isEqualToString:lowerComponent]) [matches addObject:candidate];
        }
        // App-bundled runtime payloads are a fallback only. A package-local
        // dependency always wins over a bundled compatibility copy.
        if (!matches.count) {
            for (NSString *candidate in runtimeCandidates) {
                NSString *resolved = candidate.stringByResolvingSymlinksInPath.stringByStandardizingPath;
                if ([visitedPaths containsObject:resolved]) continue;
                if ([candidate.lastPathComponent.lowercaseString isEqualToString:lowerComponent]) [matches addObject:candidate];
            }
        }

        if (matches.count == 1) {
            NSString *candidate = matches.firstObject;
            NSString *resolved = candidate.stringByResolvingSymlinksInPath.stringByStandardizingPath;
            if (![visitedPaths containsObject:resolved]) {
                [visitedPaths addObject:resolved];
                [additional addObject:candidate];
                NSString *binary = TSDRBinaryForPayload(candidate);
                for (NSDictionary *nested in TSDRDependenciesForMachO(binary)) {
                    if ([nested[@"weak"] boolValue]) continue;
                    NSString *nestedName = nested[@"name"];
                    if (nestedName.length && !TSDRIsSystemDependency(nestedName)) [queue addObject:@{@"name":nestedName, @"source":binary ?: candidate}];
                }
            }
        } else {
            // A missing or ambiguous strong dependency must not produce an app
            // that appears injected but will fail at dyld load time.
            if (![missing containsObject:loadName]) [missing addObject:loadName];
        }
    }
    while (cursor < queue.count) {
        NSString *name = queue[cursor++][@"name"];
        if (name.length && ![missing containsObject:name] && !TSDRIsSystemDependency(name)) [missing addObject:name];
    }
    if (unresolved) *unresolved = missing.copy;
    return additional.copy;
}
@end
