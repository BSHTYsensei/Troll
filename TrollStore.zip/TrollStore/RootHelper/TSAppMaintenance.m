#import "TSAppMaintenance.h"
#import "TSMachODependencyResolver.h"
#import <TSUtil.h>
#import <CoreServices.h>
#import <sys/stat.h>
#import <unistd.h>
#import <errno.h>

extern NSString *getLdidPath(void);
extern int runLdid(NSArray *args, NSString **errorOutput);
extern int signApp(NSString *appPath);
extern NSDictionary *dumpEntitlementsFromBinaryAtPath(NSString *binaryPath);
extern BOOL constructContainerizationForEntitlements(NSDictionary *entitlements, NSString **customContainerOut);

static NSString *TSMAPath(NSURL *url) { return url.isFileURL ? url.path.stringByStandardizingPath : nil; }
static BOOL TSMAPathIsWithin(NSString *path, NSString *root) {
    if (!path.length || !root.length) return NO;
    // Standardization alone does not stop a symlink inside an allowed directory from
    // redirecting a destructive operation outside that directory. Resolve both paths
    // before applying a path-component-aware prefix test.
    NSString *p = path.stringByResolvingSymlinksInPath.stringByStandardizingPath;
    NSString *r = root.stringByResolvingSymlinksInPath.stringByStandardizingPath;
    return [p isEqualToString:r] || [p hasPrefix:[r stringByAppendingString:@"/"]];
}
static LSApplicationProxy *TSMAProxy(NSString *bundleIdentifier, NSString **detail) {
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-"];
    if (!bundleIdentifier.length || [bundleIdentifier rangeOfCharacterFromSet:allowed.invertedSet].location != NSNotFound || ![bundleIdentifier containsString:@"."]) {
        if (detail) *detail = @"Invalid bundle identifier.";
        return nil;
    }
    LSApplicationProxy *proxy = [LSApplicationProxy applicationProxyForIdentifier:bundleIdentifier];
    if (!proxy || !proxy.installed || !proxy.bundleURL.path.length) {
        if (detail) *detail = [NSString stringWithFormat:@"The application %@ is not installed.", bundleIdentifier];
        return nil;
    }
    NSString *dataPath = TSMAPath(proxy.dataContainerURL);
    if (!TSMAPathIsWithin(dataPath, @"/private/var/mobile/Containers/Data/Application") && !TSMAPathIsWithin(dataPath, @"/var/mobile/Containers/Data/Application")) {
        if (detail) *detail = @"Refusing to modify a protected or non-standard application data container.";
        return nil;
    }
    NSString *bundlePath = TSMAPath(proxy.bundleURL).stringByResolvingSymlinksInPath.stringByStandardizingPath;
    NSString *ourBundlePath = trollStoreAppPath().stringByResolvingSymlinksInPath.stringByStandardizingPath;
    if (ourBundlePath.length && [bundlePath isEqualToString:ourBundlePath]) {
        if (detail) *detail = @"For safety, maintenance commands cannot clear TrollStore's own cache/data container.";
        return nil;
    }
    BOOL inUserBundleContainer = TSMAPathIsWithin(bundlePath, @"/private/var/containers/Bundle/Application") || TSMAPathIsWithin(bundlePath, @"/var/containers/Bundle/Application");
    if (!inUserBundleContainer || [bundlePath hasPrefix:@"/Applications/"] || [bundlePath hasPrefix:@"/System/"] || [bundlePath hasPrefix:@"/private/var/stash/"]) {
        if (detail) *detail = @"Cache/data cleanup is restricted to user application containers; protected system applications are refused.";
        return nil;
    }
    return proxy;
}
static BOOL TSMARemoveChildren(NSString *directory, BOOL preserveContainerMetadata, NSString **detail) {
    NSFileManager *fm = NSFileManager.defaultManager;
    BOOL isDirectory = NO;
    if (![fm fileExistsAtPath:directory isDirectory:&isDirectory] || !isDirectory) {
        if (![fm createDirectoryAtPath:directory withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0755} error:nil]) {
            if (detail) *detail = [NSString stringWithFormat:@"Could not create %@.", directory];
            return NO;
        }
        chown(directory.fileSystemRepresentation, 501, 501);
        return YES;
    }
    NSError *enumerationError = nil;
    NSArray<NSString *> *items = [fm contentsOfDirectoryAtPath:directory error:&enumerationError];
    if (!items) {
        if (detail) *detail = enumerationError.localizedDescription ?: @"Could not list application data.";
        return NO;
    }
    for (NSString *name in items) {
        if (preserveContainerMetadata && [name isEqualToString:@".com.apple.mobile_container_manager.metadata.plist"]) continue;
        NSString *target = [directory stringByAppendingPathComponent:name];
        NSError *removeError = nil;
        if (![fm removeItemAtPath:target error:&removeError]) {
            if (detail) *detail = [NSString stringWithFormat:@"Could not remove %@: %@", name, removeError.localizedDescription ?: @"unknown error"];
            return NO;
        }
    }
    chmod(directory.fileSystemRepresentation, 0755);
    chown(directory.fileSystemRepresentation, 501, 501);
    return YES;
}
int TSAppMaintenanceClearCache(NSString *bundleIdentifier, NSString **detail) {
    LSApplicationProxy *proxy = TSMAProxy(bundleIdentifier, detail);
    if (!proxy) return 201;
    NSString *dataPath = TSMAPath(proxy.dataContainerURL);
    NSString *cachePath = [dataPath stringByAppendingPathComponent:@"Library/Caches"];
    if (!TSMAPathIsWithin(cachePath, dataPath)) { if (detail) *detail = @"Invalid cache path."; return 202; }
    if (!TSMARemoveChildren(cachePath, NO, detail)) return 203;
    if (detail) *detail = [NSString stringWithFormat:@"Cleared cache for %@.", bundleIdentifier];
    return 0;
}
int TSAppMaintenanceClearData(NSString *bundleIdentifier, NSString **detail) {
    LSApplicationProxy *proxy = TSMAProxy(bundleIdentifier, detail);
    if (!proxy) return 211;
    NSString *dataPath = TSMAPath(proxy.dataContainerURL);
    NSString *dataRoot = @"/private/var/mobile/Containers/Data/Application";
    if (!TSMAPathIsWithin(dataPath, dataRoot) && !TSMAPathIsWithin(dataPath, @"/var/mobile/Containers/Data/Application")) {
        if (detail) *detail = @"Refusing to remove a data container outside the user application container root.";
        return 212;
    }
    // Inspect entitlements before deleting anything. Some applications explicitly opt
    // out of a standard data container; deleting their current path and then trying to
    // recreate a normal container would be destructive and semantically incorrect.
    NSString *containerIdentifier = bundleIdentifier;
    NSDictionary *appInfo = [NSDictionary dictionaryWithContentsOfFile:[proxy.bundleURL.path stringByAppendingPathComponent:@"Info.plist"]];
    NSString *executableName = [appInfo[@"CFBundleExecutable"] isKindOfClass:NSString.class] ? appInfo[@"CFBundleExecutable"] : nil;
    if (!executableName.length || [executableName containsString:@"/"] || [executableName containsString:@"\\"]) {
        if (detail) *detail = @"Could not safely determine the application's main executable; data cleanup was not performed.";
        return 212;
    }
    NSString *executablePath = [proxy.bundleURL.path stringByAppendingPathComponent:executableName];
    if (!TSMAPathIsWithin(executablePath, proxy.bundleURL.path)) {
        if (detail) *detail = @"The application executable resolves outside its bundle; data cleanup was refused.";
        return 212;
    }
    NSDictionary *entitlements = dumpEntitlementsFromBinaryAtPath(executablePath) ?: @{};
    // Keep the app's custom container identifier, if any, and refuse no-container apps.
    if (!constructContainerizationForEntitlements(entitlements, &containerIdentifier)) {
        if (detail) *detail = @"This application declares that it does not use a standard data container. Data cleanup was refused.";
        return 212;
    }
    NSCharacterSet *containerCharacters = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-"];
    if (!containerIdentifier.length || containerIdentifier.length > 255 || [containerIdentifier rangeOfCharacterFromSet:containerCharacters.invertedSet].location != NSNotFound) {
        if (detail) *detail = @"The application's data-container identifier is not safe to recreate; no data was removed.";
        return 212;
    }

    // Clear-data means deleting the whole container, not merely unlinking files while
    // leaving stale container metadata. Recreate the same MCM container immediately.
    NSError *removeError = nil;
    if (![[NSFileManager defaultManager] removeItemAtPath:dataPath error:&removeError]) {
        if (detail) *detail = [NSString stringWithFormat:@"Could not remove the application data container: %@", removeError.localizedDescription ?: @"unknown error"];
        return 213;
    }
    BOOL existed = NO;
    NSError *createError = nil;
    MCMAppDataContainer *freshContainer = [MCMAppDataContainer containerWithIdentifier:containerIdentifier createIfNecessary:YES existed:&existed error:(id *)&createError];
    NSString *freshPath = TSMAPath(freshContainer.url);
    BOOL safeFreshPath = TSMAPathIsWithin(freshPath, dataRoot) || TSMAPathIsWithin(freshPath, @"/var/mobile/Containers/Data/Application");
    BOOL isDirectory = NO;
    if (!safeFreshPath || ![[NSFileManager defaultManager] fileExistsAtPath:freshPath isDirectory:&isDirectory] || !isDirectory) {
        if (detail) *detail = [NSString stringWithFormat:@"The old data container was removed, but iOS could not immediately recreate it (%@). Relaunch the app or reboot to let the system recreate its container.", createError.localizedDescription ?: @"container manager returned no valid path"];
        return 214;
    }
    chmod(freshPath.fileSystemRepresentation, 0755);
    chown(freshPath.fileSystemRepresentation, 501, 501);
    if (detail) *detail = [NSString stringWithFormat:@"Removed and recreated the data container for %@. All local documents, preferences, databases and caches were deleted.", bundleIdentifier];
    return 0;
}
int TSAppMaintenanceClearAllCaches(NSString **detail) {
    NSMutableArray *failed = [NSMutableArray array];
    __block NSUInteger cleared = 0;
    LSEnumerator *enumerator = [LSEnumerator enumeratorForApplicationProxiesWithOptions:0];
    LSApplicationProxy *proxy = nil;
    while ((proxy = [enumerator nextObject])) {
        if (!proxy.installed || !proxy.bundleIdentifier.length) continue;
        NSString *path = proxy.bundleURL.path ?: @"";
        NSString *ownBundlePath = trollStoreAppPath().stringByResolvingSymlinksInPath.stringByStandardizingPath;
        if ((ownBundlePath.length && [path.stringByResolvingSymlinksInPath.stringByStandardizingPath isEqualToString:ownBundlePath]) || [path hasPrefix:@"/Applications/"] || [path hasPrefix:@"/System/"]) continue;
        NSString *oneDetail = nil;
        if (TSAppMaintenanceClearCache(proxy.bundleIdentifier, &oneDetail) == 0) cleared++;
        else if (failed.count < 8) [failed addObject:[NSString stringWithFormat:@"%@ (%@)", proxy.bundleIdentifier, oneDetail ?: @"failed"]];
    }
    if (detail) *detail = failed.count ? [NSString stringWithFormat:@"Cleared cache for %lu applications. Some were skipped: %@", (unsigned long)cleared, [failed componentsJoinedByString:@"; "]] : [NSString stringWithFormat:@"Cleared cache for %lu applications.", (unsigned long)cleared];
    return failed.count ? 1 : 0;
}
int TSAppMaintenanceInjectDylibIntoStagedBundle(NSString *appBundlePath, NSString *stagingRootPath, NSString *dylibPath, BOOL weak, NSString **detail) {
#ifndef TROLLSTORE_LITE
    if (!appBundlePath.length || !stagingRootPath.length || !dylibPath.length) { if (detail) *detail = @"A staged app path, staging root and plugin payload are required."; return 220; }
    NSString *stagingRoot = stagingRootPath.stringByResolvingSymlinksInPath.stringByStandardizingPath;
    NSString *appPath = appBundlePath.stringByResolvingSymlinksInPath.stringByStandardizingPath;
    BOOL appIsDirectory = NO;
    if (!TSMAPathIsWithin(appPath, stagingRoot) || ![appPath.pathExtension.lowercaseString isEqualToString:@"app"] || ![[NSFileManager defaultManager] fileExistsAtPath:appPath isDirectory:&appIsDirectory] || !appIsDirectory) {
        if (detail) *detail = @"The injection target must be an .app directory inside the current IPA staging directory.";
        return 221;
    }
    NSString *infoPath = [appPath stringByAppendingPathComponent:@"Info.plist"];
    NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:infoPath];
    NSString *executable = [info[@"CFBundleExecutable"] isKindOfClass:NSString.class] ? info[@"CFBundleExecutable"] : nil;
    if (!executable.length || [executable containsString:@"/"] || [executable containsString:@"\\"] || [executable isEqualToString:@"."] || [executable isEqualToString:@".."]) {
        if (detail) *detail = @"The staged app has no safe CFBundleExecutable in Info.plist.";
        return 222;
    }
    NSString *mainBinary = [appPath stringByAppendingPathComponent:executable];
    if (!TSMAPathIsWithin(mainBinary, appPath) || ![[NSFileManager defaultManager] fileExistsAtPath:mainBinary]) {
        if (detail) *detail = @"The staged app's main executable is missing or resolves outside the app bundle.";
        return 222;
    }

    NSString *trollStoreRoot = trollStoreAppPath().stringByResolvingSymlinksInPath.stringByStandardizingPath;
    NSDictionary *ownInfo = [NSDictionary dictionaryWithContentsOfFile:[trollStoreRoot stringByAppendingPathComponent:@"Info.plist"]];
    NSString *ownBundleIdentifier = [ownInfo[@"CFBundleIdentifier"] isKindOfClass:NSString.class] ? ownInfo[@"CFBundleIdentifier"] : nil;
    LSApplicationProxy *ownProxy = ownBundleIdentifier.length ? [LSApplicationProxy applicationProxyForIdentifier:ownBundleIdentifier] : nil;
    NSString *ownDataPath = TSMAPath(ownProxy.dataContainerURL);
    NSString *pluginRoot = ownDataPath.length ? [ownDataPath stringByAppendingPathComponent:@"Documents/Plugins"] : nil;
    NSString *packageRoot = ownDataPath.length ? [ownDataPath stringByAppendingPathComponent:@"Documents/Packages"] : nil;
    NSString *presetRoot = [trollStoreRoot stringByAppendingPathComponent:@"TweakPresets"];
    if (!TSMAPathIsWithin(dylibPath, pluginRoot) && !TSMAPathIsWithin(dylibPath, packageRoot) && !TSMAPathIsWithin(dylibPath, presetRoot)) {
        if (detail) *detail = @"The plugin payload must be stored in TrollStore's private Plugins/Packages directory or bundled TweakPresets directory.";
        return 224;
    }
    NSString *payloadPath = dylibPath.stringByResolvingSymlinksInPath.stringByStandardizingPath;
    BOOL payloadIsDirectory = NO;
    if (![[NSFileManager defaultManager] fileExistsAtPath:payloadPath isDirectory:&payloadIsDirectory]) { if (detail) *detail = @"The selected plugin library no longer exists."; return 224; }
    NSString *extension = payloadPath.pathExtension.lowercaseString;
    BOOL validDylib = [extension isEqualToString:@"dylib"] && !payloadIsDirectory;
    BOOL validFramework = [extension isEqualToString:@"framework"] && payloadIsDirectory;
    if (!validDylib && !validFramework) { if (detail) *detail = @"Only a .dylib or .framework payload can be injected. A DEB/ZIP must first be unpacked in the plugin store."; return 225; }
    if (validFramework) {
        NSDictionary *frameworkInfo = [NSDictionary dictionaryWithContentsOfFile:[payloadPath stringByAppendingPathComponent:@"Info.plist"]];
        NSString *frameworkExecutable = [frameworkInfo[@"CFBundleExecutable"] isKindOfClass:NSString.class] ? frameworkInfo[@"CFBundleExecutable"] : payloadPath.lastPathComponent.stringByDeletingPathExtension;
        NSString *frameworkBinary = [payloadPath stringByAppendingPathComponent:frameworkExecutable];
        if (!frameworkExecutable.length || [frameworkExecutable containsString:@"/"] || [frameworkExecutable containsString:@"\\"] || !TSMAPathIsWithin(frameworkBinary, payloadPath) || ![[NSFileManager defaultManager] fileExistsAtPath:frameworkBinary]) {
            if (detail) *detail = @"The selected framework has no safe executable Mach-O.";
            return 226;
        }
    }
    if (![[NSFileManager defaultManager] fileExistsAtPath:getLdidPath()]) { if (detail) *detail = @"The bundled ldid has not been initialized. Initialize it in Settings first."; return 227; }
    NSString *runtimeRoot = [trollStoreRoot stringByAppendingPathComponent:@"TweakRuntime"];
    NSArray<NSString *> *missingRuntime = nil;
    NSArray<NSString *> *extraPayloads = [TSMachODependencyResolver additionalPayloadsForPluginAtPath:payloadPath targetApp:appPath runtimeRoot:runtimeRoot unresolvedDependencies:&missingRuntime];
    for (NSString *dependencyPayload in extraPayloads) {
        if (!TSMAPathIsWithin(dependencyPayload, pluginRoot) && !TSMAPathIsWithin(dependencyPayload, packageRoot) && !TSMAPathIsWithin(dependencyPayload, presetRoot) && !TSMAPathIsWithin(dependencyPayload, runtimeRoot)) {
            if (detail) *detail = @"A resolved dependency escaped the trusted plugin/runtime directories. Injection was refused.";
            return 228;
        }
    }
    if (missingRuntime.count) {
        BOOL needsHooker = NO;
        for (NSString *name in missingRuntime) { NSString *lower = name.lowercaseString; if ([lower containsString:@"substrate"] || [lower containsString:@"ellekit"] || [lower containsString:@"libhooker"] || [lower containsString:@"tweakloader"]) { needsHooker = YES; break; } }
        NSString *reason = needsHooker ? @"The required Substrate/ElleKit/libhooker runtime was not found as a compatible arm64 payload in this package or TrollStore's bundled TweakRuntime. A runtime's installer/daemon cannot be replaced by copying a single library." : @"One or more strong non-system dependencies were not found in this plugin package, the target app, or TrollStore's bundled TweakRuntime.";
        if (detail) *detail = [NSString stringWithFormat:@"%@ Missing: %@. Injection was stopped to avoid a broken app.", reason, [missingRuntime componentsJoinedByString:@", "]];
        return 228;
    }
    NSMutableArray *arguments = [NSMutableArray arrayWithObjects:@"--iosinject", @"--inplace", @"--sign", @"--verify", nil];
    if (weak) [arguments addObject:@"--weak"];
    [arguments addObject:appPath]; [arguments addObject:payloadPath]; [arguments addObjectsFromArray:extraPayloads];
    NSString *ldidLog = nil;
    int result = runLdid(arguments, &ldidLog);
    if (result != 0) { if (detail) *detail = [NSString stringWithFormat:@"ldid injection failed (%d): %@", result, ldidLog ?: @""]; return 228; }
    if (detail) *detail = extraPayloads.count ? [NSString stringWithFormat:@"Prepared %@ and auto-added %lu dependency payload(s) into the staged IPA.", payloadPath.lastPathComponent, (unsigned long)extraPayloads.count] : [NSString stringWithFormat:@"Prepared %@ for injection into the staged IPA.", payloadPath.lastPathComponent];
    return 0;
#else
    if (detail) *detail = @"Dynamic-library injection is unavailable in this TrollStore Lite build.";
    return 230;
#endif
}

int TSAppMaintenanceInjectDylib(NSString *bundleIdentifier, NSString *dylibPath, BOOL weak, NSString **detail) {
#ifndef TROLLSTORE_LITE
    if (!bundleIdentifier.length || !dylibPath.length) { if (detail) *detail = @"A target bundle ID and a payload path are required."; return 220; }
    NSString *appPath = nil;
    BOOL managedByTrollStore = NO;
    for (NSString *candidate in trollStoreInstalledAppBundlePaths()) {
        NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:[candidate stringByAppendingPathComponent:@"Info.plist"]];
        if ([info[@"CFBundleIdentifier"] isEqualToString:bundleIdentifier]) { appPath = candidate; managedByTrollStore = YES; break; }
    }
    if (!appPath.length) {
        // Permit removable/user App Store apps, but never patch system apps or arbitrary filesystem paths.
        LSApplicationProxy *proxy = [LSApplicationProxy applicationProxyForIdentifier:bundleIdentifier];
        NSString *candidate = proxy.bundleURL.path.stringByStandardizingPath;
        BOOL safeContainer = TSMAPathIsWithin(candidate, @"/private/var/containers/Bundle/Application") || TSMAPathIsWithin(candidate, @"/var/containers/Bundle/Application");
        BOOL appBundle = [candidate.pathExtension.lowercaseString isEqualToString:@"app"];
        if (!proxy.installed || !safeContainer || !appBundle || ![[NSFileManager defaultManager] fileExistsAtPath:candidate]) {
            if (detail) *detail = @"Injection is limited to TrollStore-installed applications and ordinary user application bundles. System applications are refused.";
            return 221;
        }
        appPath = candidate;
    }
    if (![[NSFileManager defaultManager] fileExistsAtPath:appPath]) { if (detail) *detail = @"The target application bundle is missing."; return 222; }
    if (managedByTrollStore) {
        NSString *container = appPath.stringByDeletingLastPathComponent;
        if (![[NSFileManager defaultManager] fileExistsAtPath:[container stringByAppendingPathComponent:TS_ACTIVE_MARKER]] && ![[NSFileManager defaultManager] fileExistsAtPath:[container stringByAppendingPathComponent:TS_LITE_MARKER]]) {
            if (detail) *detail = @"The target bundle is missing the TrollStore ownership marker."; return 223;
        }
    }
    // RootHelper is privileged: accept payloads only from TrollStore's private package
    // store (including staged Tweaks/ and extracted archives) or its bundled presets.
    // This prevents an untrusted caller from asking the helper to inject an arbitrary
    // root-owned filesystem path. Resolve symlinks before authorization.
    NSString *trollStoreRoot = trollStoreAppPath().stringByResolvingSymlinksInPath.stringByStandardizingPath;
    NSDictionary *ownInfo = [NSDictionary dictionaryWithContentsOfFile:[trollStoreRoot stringByAppendingPathComponent:@"Info.plist"]];
    NSString *ownBundleIdentifier = [ownInfo[@"CFBundleIdentifier"] isKindOfClass:NSString.class] ? ownInfo[@"CFBundleIdentifier"] : nil;
    LSApplicationProxy *ownProxy = ownBundleIdentifier.length ? [LSApplicationProxy applicationProxyForIdentifier:ownBundleIdentifier] : nil;
    NSString *ownDataPath = TSMAPath(ownProxy.dataContainerURL);
    NSString *packageRoot = ownDataPath.length ? [ownDataPath stringByAppendingPathComponent:@"Documents/Packages"] : nil;
    NSString *pluginRoot = ownDataPath.length ? [ownDataPath stringByAppendingPathComponent:@"Documents/Plugins"] : nil;
    NSString *presetRoot = [trollStoreRoot stringByAppendingPathComponent:@"TweakPresets"];
    if (!TSMAPathIsWithin(dylibPath, packageRoot) && !TSMAPathIsWithin(dylibPath, pluginRoot) && !TSMAPathIsWithin(dylibPath, presetRoot)) {
        if (detail) *detail = @"The payload must be staged in TrollStore's Documents/Packages directory or bundled TweakPresets directory.";
        return 224;
    }
    dylibPath = dylibPath.stringByResolvingSymlinksInPath.stringByStandardizingPath;
    BOOL payloadIsDirectory = NO;
    if (![[NSFileManager defaultManager] fileExistsAtPath:dylibPath isDirectory:&payloadIsDirectory]) { if (detail) *detail = @"The selected dynamic library does not exist."; return 224; }
    NSString *extension = dylibPath.pathExtension.lowercaseString;
    BOOL validDylib = [extension isEqualToString:@"dylib"] && !payloadIsDirectory;
    BOOL validFramework = [extension isEqualToString:@"framework"] && payloadIsDirectory;
    if (!validDylib && !validFramework) {
        if (detail) *detail = @"Select a Mach-O .dylib file or a valid .framework directory. Extract a .deb/.zip before injecting."; return 225;
    }
    NSString *payloadExecutable = dylibPath;
    if (validFramework) {
        NSDictionary *frameworkInfo = [NSDictionary dictionaryWithContentsOfFile:[dylibPath stringByAppendingPathComponent:@"Info.plist"]];
        NSString *executable = [frameworkInfo[@"CFBundleExecutable"] isKindOfClass:NSString.class] ? frameworkInfo[@"CFBundleExecutable"] : dylibPath.lastPathComponent.stringByDeletingPathExtension;
        payloadExecutable = [dylibPath stringByAppendingPathComponent:executable];
        if (![[NSFileManager defaultManager] fileExistsAtPath:payloadExecutable]) { if (detail) *detail = @"The selected framework has no executable Mach-O."; return 226; }
    }
    if (![[NSFileManager defaultManager] fileExistsAtPath:getLdidPath()]) { if (detail) *detail = @"The bundled ldid has not been initialized. Initialize it in Settings first."; return 227; }
    NSString *runtimeRoot = [trollStoreRoot stringByAppendingPathComponent:@"TweakRuntime"];
    NSArray<NSString *> *missingRuntime = nil;
    NSArray<NSString *> *extraPayloads = [TSMachODependencyResolver additionalPayloadsForPluginAtPath:dylibPath targetApp:appPath runtimeRoot:runtimeRoot unresolvedDependencies:&missingRuntime];
    for (NSString *dependencyPayload in extraPayloads) {
        if (!TSMAPathIsWithin(dependencyPayload, pluginRoot) && !TSMAPathIsWithin(dependencyPayload, packageRoot) && !TSMAPathIsWithin(dependencyPayload, presetRoot) && !TSMAPathIsWithin(dependencyPayload, runtimeRoot)) {
            if (detail) *detail = @"A resolved dependency escaped the trusted plugin/runtime directories. Injection was refused.";
            return 228;
        }
    }
    if (missingRuntime.count) {
        BOOL needsHooker = NO;
        for (NSString *name in missingRuntime) { NSString *lower = name.lowercaseString; if ([lower containsString:@"substrate"] || [lower containsString:@"ellekit"] || [lower containsString:@"libhooker"] || [lower containsString:@"tweakloader"]) { needsHooker = YES; break; } }
        NSString *reason = needsHooker ? @"The required Substrate/ElleKit/libhooker runtime was not found as a compatible arm64 payload in this package or TrollStore's bundled TweakRuntime. A runtime's installer/daemon cannot be replaced by copying a single library." : @"One or more strong non-system dependencies were not found in this plugin package, the target app, or TrollStore's bundled TweakRuntime.";
        if (detail) *detail = [NSString stringWithFormat:@"%@ Missing: %@. Injection was stopped to avoid a broken app.", reason, [missingRuntime componentsJoinedByString:@", "]];
        return 228;
    }
    NSMutableArray *arguments = [NSMutableArray arrayWithObjects:@"--iosinject", @"--inplace", @"--sign", @"--verify", nil];
    if (weak) [arguments addObject:@"--weak"];
    [arguments addObject:appPath]; [arguments addObject:dylibPath]; [arguments addObjectsFromArray:extraPayloads];
    NSString *ldidLog = nil;
    int result = runLdid(arguments, &ldidLog);
    if (result != 0) { if (detail) *detail = [NSString stringWithFormat:@"ldid in-process injection failed (%d): %@", result, ldidLog ?: @""]; return 228; }
    // The precompiled ldid binary inserts the load command and verifies its ad-hoc signature.
    // TrollStore must still regenerate its CoreTrust-compatible envelope; ordinary App Store
    // apps may be resigned too, so callers are warned that restoring the original IPA is safest.
    int signResult = signApp(appPath);
    if (signResult != 0) { if (detail) *detail = [NSString stringWithFormat:@"The load command was inserted, but final signing/CoreTrust processing failed (%d). Restore the original IPA before retrying.", signResult]; return 229; }
    if (detail) {
        NSString *dependencyNote = extraPayloads.count ? [NSString stringWithFormat:@" Automatically added %lu package/runtime dependency payload(s).", (unsigned long)extraPayloads.count] : @" No extra package dependencies were needed.";
        *detail = [NSString stringWithFormat:@"Injected %@ into %@ and completed ldid verification plus TrollStore signing.%@", dylibPath.lastPathComponent, bundleIdentifier, dependencyNote];
    }
    return 0;
#else
    if (detail) *detail = @"Dynamic-library injection is unavailable in this TrollStore Lite build.";
    return 230;
#endif
}
