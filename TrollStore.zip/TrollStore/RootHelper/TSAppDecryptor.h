#import <Foundation/Foundation.h>

// Dumps encrypted Mach-O regions from a running App Store app and writes a standard Payload/*.app IPA.
// This requires task_for_pid permission on the current OS; failure is reported cleanly rather than
// producing an IPA that falsely appears decrypted.
int TSAppDecryptorDecryptBundleToIPA(NSString *bundleIdentifier, NSString *outputIPAPath, NSString **detail);
