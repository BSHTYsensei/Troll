#import "TSAppUpdateControl.h"
#import <CoreServices.h>
#import <TSUtil.h>
#import <objc/message.h>
#import <sys/stat.h>
#import <unistd.h>
#import <errno.h>
#import <string.h>

static NSString *TSUACanonicalPath(NSString *path) {
    if (!path.length) return nil;
    return path.stringByResolvingSymlinksInPath.stringByStandardizingPath;
}

static BOOL TSUAPathIsWithin(NSString *path, NSString *root) {
    NSString *p = TSUACanonicalPath(path);
    NSString *r = TSUACanonicalPath(root);
    return p.length && r.length && ([p isEqualToString:r] || [p hasPrefix:[r stringByAppendingString:@"/"]]);
}

static BOOL TSUAIsRegularNonSymlinkFile(NSString *path) {
    struct stat st;
    if (!path.length || lstat(path.fileSystemRepresentation, &st) != 0) return NO;
    return S_ISREG(st.st_mode) && !S_ISLNK(st.st_mode);
}

static BOOL TSUABundleIdentifierIsValid(NSString *bundleIdentifier) {
    if (!bundleIdentifier.length || bundleIdentifier.length > 255 || ![bundleIdentifier containsString:@"."]) return NO;
    NSCharacterSet *allowed = [NSCharacterSet characterSetWithCharactersInString:@"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.-"];
    return [bundleIdentifier rangeOfCharacterFromSet:allowed.invertedSet].location == NSNotFound;
}

static LSApplicationProxy *TSUAProxy(NSString *bundleIdentifier, NSString **bundlePathOut, NSString **metadataPathOut, NSString **blockedPathOut, NSString **detail) {
    if (!TSUABundleIdentifierIsValid(bundleIdentifier)) {
        if (detail) *detail = @"Invalid application bundle identifier.";
        return nil;
    }
    LSApplicationProxy *proxy = [LSApplicationProxy applicationProxyForIdentifier:bundleIdentifier];
    if (!proxy || !proxy.installed || !proxy.bundleURL.path.length) {
        if (detail) *detail = @"This application is not installed.";
        return nil;
    }
    NSString *bundlePath = TSUACanonicalPath(proxy.bundleURL.path);
    BOOL inUserBundleRoot = TSUAPathIsWithin(bundlePath, @"/private/var/containers/Bundle/Application") || TSUAPathIsWithin(bundlePath, @"/var/containers/Bundle/Application");
    if (!inUserBundleRoot || ![bundlePath.pathExtension.lowercaseString isEqualToString:@"app"]) {
        if (detail) *detail = @"Only normal App Store applications in the user application container can be managed.";
        return nil;
    }
    NSString *containerPath = bundlePath.stringByDeletingLastPathComponent;
    NSFileManager *fm = NSFileManager.defaultManager;
    if ([fm fileExistsAtPath:[containerPath stringByAppendingPathComponent:TS_MARKER]] ||
        [fm fileExistsAtPath:[containerPath stringByAppendingPathComponent:TS_LITE_MARKER]] ||
        [fm fileExistsAtPath:[bundlePath stringByAppendingPathComponent:TS_MARKER]] ||
        [fm fileExistsAtPath:[bundlePath stringByAppendingPathComponent:TS_LITE_MARKER]]) {
        if (detail) *detail = @"TrollStore-managed applications are excluded from update blocking.";
        return nil;
    }
    NSString *ownBundlePath = TSUACanonicalPath(trollStoreAppPath());
    if (ownBundlePath.length && [bundlePath isEqualToString:ownBundlePath]) {
        if (detail) *detail = @"TrollStore itself cannot be update-locked.";
        return nil;
    }
    NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:[bundlePath stringByAppendingPathComponent:@"Info.plist"]];
    if (![info[@"CFBundleIdentifier"] isKindOfClass:NSString.class] || ![info[@"CFBundleIdentifier"] isEqualToString:bundleIdentifier]) {
        if (detail) *detail = @"The installed bundle identity does not match the requested application.";
        return nil;
    }
    NSString *metadata = [bundlePath stringByAppendingPathComponent:@"iTunesMetadata.plist"];
    NSString *blocked = [bundlePath stringByAppendingPathComponent:@"iTunesMetadata_blocked.plist"];
    if (bundlePathOut) *bundlePathOut = bundlePath;
    if (metadataPathOut) *metadataPathOut = metadata;
    if (blockedPathOut) *blockedPathOut = blocked;
    return proxy;
}

static BOOL TSUAWaitForLaunchServicesToSettle(NSString **detail) {
    Class workspaceClass = NSClassFromString(@"LSApplicationWorkspace");
    SEL defaultSelector = NSSelectorFromString(@"defaultWorkspace");
    SEL knowledgeSelector = NSSelectorFromString(@"getKnowledgeUUID:andSequenceNumber:");
    id workspace = nil;
    if (workspaceClass && [workspaceClass respondsToSelector:defaultSelector]) {
        workspace = ((id (*)(id, SEL))objc_msgSend)(workspaceClass, defaultSelector);
    }
    BOOL canObserveToken = workspace && [workspace respondsToSelector:knowledgeSelector];
    NSTimeInterval start = NSProcessInfo.processInfo.systemUptime;
    NSString *lastToken = nil;
    BOOL sawToken = NO;
    NSUInteger stableSamples = 0;
    while (NSProcessInfo.processInfo.systemUptime - start < 120.0) {
        sleep(2);
        NSString *token = nil;
        if (canObserveToken) {
            __autoreleasing id knowledgeUUID = nil;
            uint64_t sequenceNumber = 0;
            ((void (*)(id, SEL, id *, uint64_t *))objc_msgSend)(workspace, knowledgeSelector, &knowledgeUUID, &sequenceNumber);
            if (knowledgeUUID) token = [NSString stringWithFormat:@"%@-%llu", knowledgeUUID, sequenceNumber];
        }
        if (token.length) sawToken = YES;
        if (token.length && [token isEqualToString:lastToken]) stableSamples++;
        else if (token.length) { lastToken = token; stableSamples = 0; }
        NSTimeInterval elapsed = NSProcessInfo.processInfo.systemUptime - start;
        // The LS rebuild SPI merely queues work. Keep the user-visible activity alive for
        // at least a minute and require three stable knowledge-token samples before success.
        if (elapsed >= 60.0 && stableSamples >= 3) return YES;
        if (elapsed >= 90.0 && !sawToken) return YES;
    }
    if (detail) *detail = @"LaunchServices did not report a stable database within two minutes. The metadata change was rolled back; retry after the device is idle.";
    return NO;
}

static BOOL TSUARefreshLaunchServices(NSString **detail) {
    LSApplicationWorkspace *workspace = [LSApplicationWorkspace defaultWorkspace];
    SEL selector = @selector(_LSPrivateRebuildApplicationDatabasesForSystemApps:internal:user:);
    if (![workspace respondsToSelector:selector]) {
        if (detail) *detail = @"This iOS version does not expose the required LaunchServices rebuild operation. The metadata change was rolled back.";
        return NO;
    }
    // The private SPI is treated as a fire-and-queue operation. Some iOS builds do not
    // provide a meaningful BOOL return even though older local declarations did.
    ((void (*)(id, SEL, BOOL, BOOL, BOOL))objc_msgSend)(workspace, selector, YES, YES, YES);
    if (!TSUAWaitForLaunchServicesToSettle(detail)) return NO;
    CFNotificationCenterPostNotification(CFNotificationCenterGetDarwinNotifyCenter(), CFSTR("com.apple.mobile.application_installed"), NULL, NULL, true);
    // Force the App Store to reload its cached installed-app metadata. No SpringBoard respring is needed.
    killall(@"AppStore", YES);
    return YES;
}

int TSAppUpdateControlSetBlocked(NSString *bundleIdentifier, BOOL blocked, NSString **detail) {
    NSString *bundlePath = nil, *metadata = nil, *blockedMetadata = nil;
    if (!TSUAProxy(bundleIdentifier, &bundlePath, &metadata, &blockedMetadata, detail)) return 301;
    BOOL originalExists = TSUAIsRegularNonSymlinkFile(metadata);
    BOOL blockedExists = TSUAIsRegularNonSymlinkFile(blockedMetadata);
    NSFileManager *fileManager = NSFileManager.defaultManager;
    if (([fileManager fileExistsAtPath:metadata] && !originalExists) ||
        ([fileManager fileExistsAtPath:blockedMetadata] && !blockedExists)) {
        if (detail) *detail = @"Refusing to rename non-regular or symbolic-link metadata.";
        return 302;
    }
    // If both names exist, the app was most likely reinstalled while an old lock
    // marker remained in the reused container. The normal metadata file is the
    // authoritative new-install state; remove only our own stale regular marker.
    if (originalExists && blockedExists) {
        if (unlink(blockedMetadata.fileSystemRepresentation) != 0) {
            if (detail) *detail = [NSString stringWithFormat:@"The app appears to have been reinstalled, but its stale update-lock marker could not be removed: %s", strerror(errno)];
            return 303;
        }
        blockedExists = NO;
        if (!blocked) {
            if (detail) *detail = @"The app was reinstalled. Its stale update-lock marker was cleared and updates are allowed.";
            return 0;
        }
    }
    if (blocked && blockedExists) {
        if (detail) *detail = @"Updates are already blocked for this application.";
        return 0;
    }
    if (!blocked && originalExists) {
        if (detail) *detail = @"Updates are already allowed for this application.";
        return 0;
    }
    if (blocked && !originalExists) {
        if (detail) *detail = @"This app does not contain iTunesMetadata.plist, so its App Store update state cannot be safely changed.";
        return 304;
    }
    if (!blocked && !blockedExists) {
        if (detail) *detail = @"The blocked metadata file is missing. Nothing can be restored.";
        return 305;
    }
    NSString *source = blocked ? metadata : blockedMetadata;
    NSString *destination = blocked ? blockedMetadata : metadata;
    if (rename(source.fileSystemRepresentation, destination.fileSystemRepresentation) != 0) {
        if (detail) *detail = [NSString stringWithFormat:@"Could not update metadata filename: %s", strerror(errno)];
        return 306;
    }
    if (!TSUARefreshLaunchServices(detail)) {
        int savedErrno = errno;
        if (rename(destination.fileSystemRepresentation, source.fileSystemRepresentation) != 0 && detail) {
            *detail = [NSString stringWithFormat:@"LaunchServices refresh failed and metadata rollback also failed (%s). Check the app bundle before retrying.", strerror(errno)];
        }
        errno = savedErrno;
        return 307;
    }
    if (detail) *detail = blocked ? @"Updates are now blocked for this app. LaunchServices and App Store metadata were refreshed." : @"Updates are allowed again for this app. The original metadata filename was restored.";
    return 0;
}

NSArray<NSString *> *TSAppUpdateControlCopyBlockedBundleIdentifiers(void) {
    NSMutableOrderedSet<NSString *> *blocked = [NSMutableOrderedSet orderedSet];
    LSEnumerator *enumerator = [LSEnumerator enumeratorForApplicationProxiesWithOptions:0];
    LSApplicationProxy *proxy = nil;
    while ((proxy = [enumerator nextObject])) {
        if (!proxy.installed || !proxy.bundleIdentifier.length) continue;
        NSString *bundlePath = nil, *metadata = nil, *blockedMetadata = nil;
        if (!TSUAProxy(proxy.bundleIdentifier, &bundlePath, &metadata, &blockedMetadata, NULL)) continue;
        BOOL normalExists = TSUAIsRegularNonSymlinkFile(metadata);
        BOOL blockedExists = TSUAIsRegularNonSymlinkFile(blockedMetadata);
        if (normalExists && blockedExists) {
            // Reinstallation recovery; the new normal metadata restores update eligibility.
            unlink(blockedMetadata.fileSystemRepresentation);
            continue;
        }
        if (blockedExists && !normalExists) [blocked addObject:proxy.bundleIdentifier];
    }
    return [[blocked.array sortedArrayUsingSelector:@selector(localizedStandardCompare:)] copy];
}
