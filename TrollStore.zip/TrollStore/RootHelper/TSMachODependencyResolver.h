#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@interface TSMachODependencyResolver : NSObject
// Resolves non-system LC_LOAD_DYLIB dependencies from the same imported package,
// the app's existing Frameworks directory, or TrollStore's bundled TweakRuntime.
// Returns extra .dylib/.framework payloads that can be passed to ldid --iosinject.
+ (NSArray<NSString *> *)additionalPayloadsForPluginAtPath:(NSString *)pluginPath
                                                 targetApp:(NSString *)appPath
                                             runtimeRoot:(NSString *)runtimeRoot
                               unresolvedDependencies:(NSArray<NSString *> * _Nullable * _Nullable)unresolved;
@end
NS_ASSUME_NONNULL_END
