#import <Foundation/Foundation.h>

int TSAppMaintenanceClearCache(NSString *bundleIdentifier, NSString **detail);
int TSAppMaintenanceClearData(NSString *bundleIdentifier, NSString **detail);
int TSAppMaintenanceClearAllCaches(NSString **detail);
int TSAppMaintenanceInjectDylib(NSString *bundleIdentifier, NSString *dylibPath, BOOL weak, NSString **detail);

int TSAppMaintenanceInjectDylibIntoStagedBundle(NSString *appBundlePath, NSString *stagingRootPath, NSString *dylibPath, BOOL weak, NSString **detail);
