#import <Foundation/Foundation.h>

int TSAppUpdateControlSetBlocked(NSString *bundleIdentifier, BOOL blocked, NSString **detail);
NSArray<NSString *> *TSAppUpdateControlCopyBlockedBundleIdentifiers(void);
