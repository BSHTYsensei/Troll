#import "unarchive.h"

#include <archive.h>
#include <archive_entry.h>
#include <limits.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <unistd.h>

static int copy_data(struct archive *reader, struct archive *writer, uint64_t *totalBytes, la_int64_t declaredEntrySize)
{
    const uint64_t maximumExpandedBytes = 32ULL * 1024ULL * 1024ULL * 1024ULL;
    for (;;) {
        const void *buffer = NULL;
        size_t size = 0;
        la_int64_t offset = 0;
        int status = archive_read_data_block(reader, &buffer, &size, &offset);
        if (status == ARCHIVE_EOF) return ARCHIVE_OK;
        if (status < ARCHIVE_OK) return status;
        if (offset < 0 || (uint64_t)offset > maximumExpandedBytes ||
            size > maximumExpandedBytes - (uint64_t)offset ||
            (declaredEntrySize < 0 || (uint64_t)offset + (uint64_t)size > (uint64_t)declaredEntrySize) ||
            size > maximumExpandedBytes || *totalBytes > maximumExpandedBytes - (uint64_t)size) {
            fprintf(stderr, "Archive block exceeds its declared file extent or the maximum expanded size limit\n");
            return ARCHIVE_FATAL;
        }
        *totalBytes += (uint64_t)size;
        status = archive_write_data_block(writer, buffer, size, offset);
        if (status != ARCHIVE_OK) {
            const char *message = archive_error_string(writer);
            fprintf(stderr, "%s\n", message ? message : "archive_write_data_block failed");
            return status;
        }
    }
}

static BOOL isSafeArchiveSymlinkTarget(NSString *relativePath, const char *rawTarget)
{
    if (!relativePath.length || !rawTarget) return NO;
    NSString *target = [NSString stringWithUTF8String:rawTarget];
    if (!target.length) return NO;
    target = [target stringByReplacingOccurrencesOfString:@"\\" withString:@"/"];
    if ([target hasPrefix:@"/"] || [target hasPrefix:@"~"] ||
        (target.length >= 2 && [[NSCharacterSet letterCharacterSet] characterIsMember:[target characterAtIndex:0]] && [target characterAtIndex:1] == ':')) return NO;
    NSMutableArray<NSString *> *components = [[relativePath.stringByDeletingLastPathComponent componentsSeparatedByString:@"/"] mutableCopy];
    if (components.count == 1 && !components.firstObject.length) [components removeAllObjects];
    for (NSString *component in [target componentsSeparatedByString:@"/"]) {
        if (!component.length || [component isEqualToString:@"."]) continue;
        if ([component isEqualToString:@".."]) {
            if (components.count == 0) return NO;
            [components removeLastObject];
        } else {
            [components addObject:component];
        }
    }
    return components.count != 0;
}

static BOOL isSafeRelativeArchivePath(NSString *path)
{
    if (![path isKindOfClass:NSString.class] || path.length == 0) return NO;
    // ZIP tools on different platforms may store either slash style. Normalize
    // before checking traversal so a Windows-style `..\` cannot bypass it.
    path = [path stringByReplacingOccurrencesOfString:@"\\" withString:@"/"];
    // Archive directory entries conventionally end in '/'. Remove trailing
    // separators before validating, while still rejecting an empty/root path.
    while ([path hasSuffix:@"/"]) path = [path substringToIndex:path.length - 1];
    if (!path.length || [path hasPrefix:@"/"] || [path hasPrefix:@"~"] ||
        (path.length >= 2 && [[NSCharacterSet letterCharacterSet] characterIsMember:[path characterAtIndex:0]] && [path characterAtIndex:1] == ':')) return NO;
    NSArray<NSString *> *components = [path componentsSeparatedByString:@"/"];
    if (components.count == 0) return NO;
    for (NSString *component in components) {
        if (component.length == 0 || [component isEqualToString:@"."] || [component isEqualToString:@".."])
            return NO;
    }
    return YES;
}

int extract(NSString *fileToExtract, NSString *extractionPath)
{
    if (![fileToExtract isKindOfClass:NSString.class] || !fileToExtract.length ||
        ![extractionPath isKindOfClass:NSString.class] || !extractionPath.length) return 1;

    // Resolve the selected input once. File-provider aliases and /var -> /private/var
    // symlinks must not be passed as extraction roots to libarchive.
    char resolvedArchive[PATH_MAX] = {0};
    if (!realpath(fileToExtract.fileSystemRepresentation, resolvedArchive)) {
        fprintf(stderr, "Archive input cannot be resolved: %s\n", strerror(errno));
        return 1;
    }
    struct stat archiveStat;
    if (stat(resolvedArchive, &archiveStat) != 0 || !S_ISREG(archiveStat.st_mode) || archiveStat.st_size <= 0) {
        fprintf(stderr, "Archive input is not a non-empty regular file\n");
        return 1;
    }

    struct archive *reader = archive_read_new();
    struct archive *writer = archive_write_disk_new();
    if (!reader || !writer) {
        if (reader) archive_read_free(reader);
        if (writer) archive_write_free(writer);
        return 1;
    }

    int result = 0;

    // Keep the extraction body in a single-exit scope. In Objective-C ARC,
    // jumping forward with goto across initialization of a __strong local is
    // ill-formed. A do/while scope lets every early validation failure leave
    // through break, so ARC can run normal scope cleanup without bypassing
    // object initialization.
    do {
        char resolvedRoot[PATH_MAX] = {0};
        NSString *canonicalExtractionPath = nil;
        if (!realpath(extractionPath.fileSystemRepresentation, resolvedRoot)) {
            fprintf(stderr, "Extraction destination is missing or cannot be resolved: %s\n", strerror(errno));
            result = 1;
            break;
        }
        canonicalExtractionPath = [NSString stringWithUTF8String:resolvedRoot];
        struct stat rootStat;
        if (!canonicalExtractionPath.length || lstat(resolvedRoot, &rootStat) != 0 || !S_ISDIR(rootStat.st_mode) || S_ISLNK(rootStat.st_mode)) {
            fprintf(stderr, "Extraction destination is not a real directory\n");
            result = 1;
            break;
        }

        // Do not restore archive-provided owners, ACLs, flags, or setuid bits.
        // TrollStore normalizes app-bundle ownership and executable permissions after
        // installation, so preserving these metadata is unnecessary and riskier.
        int flags = ARCHIVE_EXTRACT_TIME | ARCHIVE_EXTRACT_SECURE_NODOTDOT | ARCHIVE_EXTRACT_SECURE_SYMLINKS;
        archive_read_support_format_zip(reader);
        archive_read_support_format_tar(reader);
        archive_read_support_filter_all(reader);
        archive_write_disk_set_options(writer, flags);

        if (archive_read_open_filename(reader, resolvedArchive, 1048576) != ARCHIVE_OK) {
            const char *message = archive_error_string(reader);
            fprintf(stderr, "Could not open archive: %s\n", message ? message : "unknown libarchive error");
            result = 1;
            break;
        }

        const uint64_t maximumExpandedBytes = 32ULL * 1024ULL * 1024ULL * 1024ULL;
        const NSUInteger maximumEntries = 500000;
        uint64_t totalExpandedBytes = 0;
        NSUInteger entryCount = 0;
        NSMutableSet<NSString *> *seenPaths = [NSMutableSet set];

        for (;;) {
            struct archive_entry *entry = NULL;
            int status = archive_read_next_header(reader, &entry);
            if (status == ARCHIVE_EOF) break;
            if (status != ARCHIVE_OK) {
                const char *message = archive_error_string(reader);
                fprintf(stderr, "Could not read archive header: %s\n", message ? message : "unknown libarchive error");
                result = 1;
                break;
            }
            if (++entryCount > maximumEntries) {
                fprintf(stderr, "Archive contains too many entries\n");
                result = 1;
                break;
            }

            const char *entryName = archive_entry_pathname(entry);
            NSString *relativePath = entryName ? [NSString stringWithUTF8String:entryName] : nil;
            if ([relativePath isKindOfClass:NSString.class]) {
                relativePath = [relativePath stringByReplacingOccurrencesOfString:@"\\" withString:@"/"];
                // Tar packages commonly prefix entries with ./; strip only this harmless
                // prefix. Parent-relative components remain visible and are rejected.
                while ([relativePath hasPrefix:@"./"]) relativePath = [relativePath substringFromIndex:2];
                while ([relativePath hasSuffix:@"/"]) relativePath = [relativePath substringToIndex:relativePath.length - 1];
            }
            if ((!relativePath.length || [relativePath isEqualToString:@"."]) && archive_entry_filetype(entry) == AE_IFDIR) {
                if (archive_read_data_skip(reader) < ARCHIVE_OK) {
                    fprintf(stderr, "Could not skip archive root directory entry\n");
                    result = 1;
                    break;
                }
                continue;
            }
            if (!isSafeRelativeArchivePath(relativePath)) {
                fprintf(stderr, "Rejected unsafe archive entry path\n");
                result = 1;
                break;
            }
            NSString *pathKey = relativePath.precomposedStringWithCanonicalMapping.lowercaseString;
            if ([seenPaths containsObject:pathKey]) {
                fprintf(stderr, "Rejected duplicate/case-colliding archive entry: %s\n", relativePath.UTF8String);
                result = 1;
                break;
            }
            [seenPaths addObject:pathKey];

            const mode_t entryType = archive_entry_filetype(entry);
            if ((entryType != AE_IFDIR && entryType != AE_IFREG && entryType != AE_IFLNK) || archive_entry_hardlink(entry)) {
                fprintf(stderr, "Rejected unsupported special-file or hard-link archive entry: %s\n", relativePath.UTF8String);
                result = 1;
                break;
            }
            if (entryType == AE_IFREG) {
                la_int64_t entrySize = archive_entry_size(entry);
                if (entrySize < 0 || (uint64_t)entrySize > maximumExpandedBytes || totalExpandedBytes > maximumExpandedBytes - (uint64_t)entrySize) {
                    fprintf(stderr, "Rejected archive entry with invalid or excessive size: %s\n", relativePath.UTF8String);
                    result = 1;
                    break;
                }
            }
            if (entryType == AE_IFLNK && !isSafeArchiveSymlinkTarget(relativePath, archive_entry_symlink(entry))) {
                fprintf(stderr, "Rejected archive symlink that escapes its extraction root: %s\n", relativePath.UTF8String);
                result = 1;
                break;
            }

            NSString *fullOutputPath = [[canonicalExtractionPath stringByAppendingPathComponent:relativePath] stringByStandardizingPath];
            NSString *rootPrefix = [canonicalExtractionPath stringByAppendingString:@"/"];
            if (![fullOutputPath hasPrefix:rootPrefix] ||
                strlen(fullOutputPath.fileSystemRepresentation) >= PATH_MAX) {
                fprintf(stderr, "Rejected archive entry outside extraction root or with an overlong path\n");
                result = 1;
                break;
            }
            archive_entry_set_pathname(entry, fullOutputPath.fileSystemRepresentation);

            status = archive_write_header(writer, entry);
            // ARCHIVE_WARN is not accepted: libarchive uses it for blocked writes such
            // as traversing a symlink. A partial Payload must never be installed.
            if (status != ARCHIVE_OK) {
                const char *message = archive_error_string(writer);
                fprintf(stderr, "Could not create archive entry %s: %s\n", relativePath.UTF8String, message ? message : "unknown libarchive error");
                result = 1;
                break;
            }
            if (entryType == AE_IFREG && archive_entry_size(entry) > 0) {
                status = copy_data(reader, writer, &totalExpandedBytes, archive_entry_size(entry));
                if (status != ARCHIVE_OK) {
                    const char *message = archive_error_string(writer);
                    fprintf(stderr, "Could not extract archive entry %s: %s\n", relativePath.UTF8String, message ? message : "archive size or data error");
                    result = 1;
                    break;
                }
            } else if (archive_read_data_skip(reader) < ARCHIVE_OK) {
                fprintf(stderr, "Could not skip empty archive entry %s\n", relativePath.UTF8String);
                result = 1;
                break;
            }

            status = archive_write_finish_entry(writer);
            if (status != ARCHIVE_OK) {
                const char *message = archive_error_string(writer);
                fprintf(stderr, "Could not finish archive entry %s: %s\n", relativePath.UTF8String, message ? message : "unknown libarchive error");
                result = 1;
                break;
            }
        }
    } while (0);

    archive_read_close(reader);
    archive_read_free(reader);
    if (archive_write_close(writer) != ARCHIVE_OK) {
        const char *message = archive_error_string(writer);
        fprintf(stderr, "Could not finalize extracted archive: %s\n", message ? message : "unknown libarchive error");
        result = 1;
    }
    archive_write_free(writer);
    return result;
}
