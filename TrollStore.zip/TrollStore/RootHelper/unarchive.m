#import "unarchive.h"

#include <archive.h>
#include <archive_entry.h>

static int copy_data(struct archive *reader, struct archive *writer)
{
    for (;;) {
        const void *buffer = NULL;
        size_t size = 0;
        la_int64_t offset = 0;
        int status = archive_read_data_block(reader, &buffer, &size, &offset);
        if (status == ARCHIVE_EOF) return ARCHIVE_OK;
        if (status < ARCHIVE_OK) return status;
        status = archive_write_data_block(writer, buffer, size, offset);
        if (status < ARCHIVE_OK) {
            fprintf(stderr, "%s\n", archive_error_string(writer));
            return status;
        }
    }
}

static BOOL isSafeRelativeArchivePath(NSString *path)
{
    if (path.length == 0 || path.isAbsolutePath) return NO;
    NSArray<NSString *> *components = path.pathComponents;
    if (components.count == 0) return NO;
    for (NSString *component in components) {
        if ([component isEqualToString:@".."] || [component isEqualToString:@""]) return NO;
    }
    return YES;
}

int extract(NSString *fileToExtract, NSString *extractionPath)
{
    struct archive *reader = archive_read_new();
    struct archive *writer = archive_write_disk_new();
    if (!reader || !writer) {
        if (reader) archive_read_free(reader);
        if (writer) archive_write_free(writer);
        return 1;
    }

    int result = 0;
    int flags = ARCHIVE_EXTRACT_TIME | ARCHIVE_EXTRACT_PERM |
                ARCHIVE_EXTRACT_ACL | ARCHIVE_EXTRACT_FFLAGS |
                ARCHIVE_EXTRACT_SECURE_NODOTDOT | ARCHIVE_EXTRACT_SECURE_SYMLINKS;
    archive_read_support_format_zip(reader);
    archive_read_support_filter_all(reader);
    archive_write_disk_set_options(writer, flags);
    archive_write_disk_set_standard_lookup(writer);

    // IPA is ZIP; a 1 MiB input block reduces read-call overhead for large assets.
    if (archive_read_open_filename(reader, fileToExtract.fileSystemRepresentation, 1048576) != ARCHIVE_OK) {
        fprintf(stderr, "%s\n", archive_error_string(reader));
        result = 1;
        goto cleanup;
    }

    for (;;) {
        struct archive_entry *entry = NULL;
        int status = archive_read_next_header(reader, &entry);
        if (status == ARCHIVE_EOF) break;
        if (status < ARCHIVE_WARN) {
            fprintf(stderr, "%s\n", archive_error_string(reader));
            result = 1;
            break;
        }
        if (status < ARCHIVE_OK) fprintf(stderr, "%s\n", archive_error_string(reader));

        const char *entryName = archive_entry_pathname(entry);
        NSString *relativePath = entryName ? [NSString stringWithUTF8String:entryName] : nil;
        if (!isSafeRelativeArchivePath(relativePath)) {
            fprintf(stderr, "Rejected unsafe IPA archive entry path\n");
            result = 1;
            break;
        }

        NSString *fullOutputPath = [extractionPath stringByAppendingPathComponent:relativePath];
        archive_entry_set_pathname(entry, fullOutputPath.fileSystemRepresentation);

        status = archive_write_header(writer, entry);
        if (status < ARCHIVE_OK) {
            fprintf(stderr, "%s\n", archive_error_string(writer));
        } else if (archive_entry_size(entry) > 0) {
            status = copy_data(reader, writer);
            if (status < ARCHIVE_WARN) {
                fprintf(stderr, "%s\n", archive_error_string(writer));
                result = 1;
                break;
            }
        }

        status = archive_write_finish_entry(writer);
        if (status < ARCHIVE_WARN) {
            fprintf(stderr, "%s\n", archive_error_string(writer));
            result = 1;
            break;
        }
    }

cleanup:
    archive_read_close(reader);
    archive_read_free(reader);
    archive_write_close(writer);
    archive_write_free(writer);
    return result;
}
