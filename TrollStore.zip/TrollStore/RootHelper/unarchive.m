#import "unarchive.h"

#include <archive.h>
#include <archive_entry.h>
#include <limits.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/stat.h>
#include <unistd.h>

static int copy_data(struct archive *reader, struct archive *writer)
{
    for (;;) {
        const void *buffer = NULL;
        size_t size = 0;
        la_int64_t offset = 0;
        int status = archive_read_data_block(reader, &buffer, &size, &offset);
        if (status == ARCHIVE_EOF) return ARCHIVE_OK;
        if (status < ARCHIVE_OK) return status;
        status = archive_write_data_block(writer, buffer, size, offset);
        if (status != ARCHIVE_OK) {
            const char *message = archive_error_string(writer);
            fprintf(stderr, "%s\n", message ? message : "archive_write_data_block failed");
            return status;
        }
    }
}

static BOOL isSafeArchiveSymlinkTarget(NSString *relativePath, const char *rawTarget)
{
    if (!relativePath.length || !rawTarget) return NO;
    NSString *target = [NSString stringWithUTF8String:rawTarget];
    if (!target.length) return NO;
    target = [target stringByReplacingOccurrencesOfString:@"\\" withString:@"/"];
    if ([target hasPrefix:@"/"] || [target hasPrefix:@"~"] ||
        (target.length >= 2 && [[NSCharacterSet letterCharacterSet] characterIsMember:[target characterAtIndex:0]] && [target characterAtIndex:1] == ':')) return NO;
    NSMutableArray<NSString *> *components = [[relativePath.stringByDeletingLastPathComponent componentsSeparatedByString:@"/"] mutableCopy];
    if (components.count == 1 && !components.firstObject.length) [components removeAllObjects];
    for (NSString *component in [target componentsSeparatedByString:@"/"]) {
        if (!component.length || [component isEqualToString:@"."]) continue;
        if ([component isEqualToString:@".."]) {
            if (components.count == 0) return NO;
            [components removeLastObject];
        } else {
            [components addObject:component];
        }
    }
    return components.count != 0;
}

static BOOL isSafeRelativeArchivePath(NSString *path)
{
    if (![path isKindOfClass:NSString.class] || path.length == 0) return NO;
    // ZIP tools on different platforms may store either slash style. Normalize
    // before checking traversal so a Windows-style `..\` cannot bypass it.
    path = [path stringByReplacingOccurrencesOfString:@"\\" withString:@"/"];
    // Archive directory entries conventionally end in '/'. Remove trailing
    // separators before validating, while still rejecting an empty/root path.
    while ([path hasSuffix:@"/"]) path = [path substringToIndex:path.length - 1];
    if (!path.length || [path hasPrefix:@"/"] || [path hasPrefix:@"~"]) return NO;
    NSArray<NSString *> *components = [path componentsSeparatedByString:@"/"];
    if (components.count == 0) return NO;
    for (NSString *component in components) {
        if (component.length == 0 || [component isEqualToString:@"."] || [component isEqualToString:@".."])
            return NO;
    }
    return YES;
}

int extract(NSString *fileToExtract, NSString *extractionPath)
{
    struct archive *reader = archive_read_new();
    struct archive *writer = archive_write_disk_new();
    if (!reader || !writer) {
        if (reader) archive_read_free(reader);
        if (writer) archive_write_free(writer);
        return 1;
    }

    int result = 0;
    char resolvedRoot[PATH_MAX] = {0};
    NSString *canonicalExtractionPath = nil;
    if (!realpath(extractionPath.fileSystemRepresentation, resolvedRoot)) {
        fprintf(stderr, "Extraction destination is missing or cannot be resolved: %s\n", strerror(errno));
        result = 1;
        goto cleanup;
    }
    canonicalExtractionPath = [NSString stringWithUTF8String:resolvedRoot];
    struct stat rootStat;
    if (!canonicalExtractionPath.length || lstat(resolvedRoot, &rootStat) != 0 || !S_ISDIR(rootStat.st_mode) || S_ISLNK(rootStat.st_mode)) {
        fprintf(stderr, "Extraction destination is not a real directory\n");
        result = 1;
        goto cleanup;
    }

    int flags = ARCHIVE_EXTRACT_TIME | ARCHIVE_EXTRACT_PERM |
                ARCHIVE_EXTRACT_ACL | ARCHIVE_EXTRACT_FFLAGS |
                ARCHIVE_EXTRACT_SECURE_NODOTDOT | ARCHIVE_EXTRACT_SECURE_SYMLINKS;
    // User app installs are IPA/ZIP; TrollStore upgrades are tar archives.
    // Supporting both here avoids a separate, less-hardened extraction path.
    archive_read_support_format_zip(reader);
    archive_read_support_format_tar(reader);
    archive_read_support_filter_all(reader);
    archive_write_disk_set_options(writer, flags);
    archive_write_disk_set_standard_lookup(writer);

    // IPA is ZIP; a 1 MiB input block reduces read-call overhead for large assets.
    if (archive_read_open_filename(reader, fileToExtract.fileSystemRepresentation, 1048576) != ARCHIVE_OK) {
        fprintf(stderr, "%s\n", archive_error_string(reader));
        result = 1;
        goto cleanup;
    }

    for (;;) {
        struct archive_entry *entry = NULL;
        int status = archive_read_next_header(reader, &entry);
        if (status == ARCHIVE_EOF) break;
        if (status != ARCHIVE_OK) {
            fprintf(stderr, "Could not read archive header: %s\n", archive_error_string(reader));
            result = 1;
            break;
        }

        const char *entryName = archive_entry_pathname(entry);
        NSString *relativePath = entryName ? [NSString stringWithUTF8String:entryName] : nil;
        if ([relativePath isKindOfClass:NSString.class]) {
            relativePath = [relativePath stringByReplacingOccurrencesOfString:@"\\" withString:@"/"];
            // Tar packages commonly prefix every entry with ./; strip only this
            // harmless prefix before validating components. A later ../ remains
            // visible and is rejected by isSafeRelativeArchivePath.
            while ([relativePath hasPrefix:@"./"]) relativePath = [relativePath substringFromIndex:2];
            while ([relativePath hasSuffix:@"/"]) relativePath = [relativePath substringToIndex:relativePath.length - 1];
        }
        // A root directory entry (./ or ./) has no payload and is safe to skip.
        if ((!relativePath.length || [relativePath isEqualToString:@"."]) && archive_entry_filetype(entry) == AE_IFDIR) {
            if (archive_read_data_skip(reader) < ARCHIVE_OK) {
                fprintf(stderr, "Could not skip archive root directory entry\n");
                result = 1;
                break;
            }
            continue;
        }
        if (!isSafeRelativeArchivePath(relativePath)) {
            fprintf(stderr, "Rejected unsafe IPA archive entry path\n");
            result = 1;
            break;
        }
        const mode_t entryType = archive_entry_filetype(entry);
        if ((entryType != AE_IFDIR && entryType != AE_IFREG && entryType != AE_IFLNK) || archive_entry_hardlink(entry)) {
            fprintf(stderr, "Rejected unsupported special-file or hard-link archive entry: %s\n", relativePath.UTF8String);
            result = 1;
            break;
        }
        if (entryType == AE_IFLNK && !isSafeArchiveSymlinkTarget(relativePath, archive_entry_symlink(entry))) {
            fprintf(stderr, "Rejected archive symlink that escapes its extraction root: %s\n", relativePath.UTF8String);
            result = 1;
            break;
        }

        NSString *fullOutputPath = [canonicalExtractionPath stringByAppendingPathComponent:relativePath];
        fullOutputPath = fullOutputPath.stringByStandardizingPath;
        NSString *rootPrefix = [canonicalExtractionPath stringByAppendingString:@"/"];
        if (![fullOutputPath hasPrefix:rootPrefix]) {
            fprintf(stderr, "Rejected archive entry outside extraction root\n");
            result = 1;
            break;
        }
        archive_entry_set_pathname(entry, fullOutputPath.fileSystemRepresentation);

        status = archive_write_header(writer, entry);
        // libarchive may return ARCHIVE_WARN after refusing an entry (for
        // example when a parent path traverses a symlink). Do not report a
        // successful install with a partially empty Payload directory.
        if (status != ARCHIVE_OK) {
            fprintf(stderr, "Could not create archive entry %s: %s\n", relativePath.UTF8String, archive_error_string(writer));
            result = 1;
            break;
        }
        if (archive_entry_size(entry) > 0) {
            status = copy_data(reader, writer);
            if (status != ARCHIVE_OK) {
                fprintf(stderr, "Could not extract archive entry %s: %s\n", relativePath.UTF8String, archive_error_string(writer));
                result = 1;
                break;
            }
        }

        status = archive_write_finish_entry(writer);
        if (status != ARCHIVE_OK) {
            fprintf(stderr, "%s\n", archive_error_string(writer));
            result = 1;
            break;
        }
    }

cleanup:
    archive_read_close(reader);
    archive_read_free(reader);
    if (archive_write_close(writer) != ARCHIVE_OK) {
        fprintf(stderr, "Could not finalize extracted archive: %s\n", archive_error_string(writer));
        result = 1;
    }
    archive_write_free(writer);
    return result;
}
