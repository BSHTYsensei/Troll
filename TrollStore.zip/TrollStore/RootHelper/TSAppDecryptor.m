#import "TSAppDecryptor.h"
#import <TSUtil.h>
#import <CoreServices.h>
#import <sys/sysctl.h>
#import <mach/mach.h>
#import <mach/mach_vm.h>
#import <mach-o/loader.h>
#import <mach-o/dyld_images.h>
#import <mach-o/fat.h>
#import <archive.h>
#import <archive_entry.h>
#import <sys/stat.h>
#import <fcntl.h>
#import <unistd.h>
#import <errno.h>
#import <limits.h>
#import <stdlib.h>
#import <string.h>
#import <CoreFoundation/CoreFoundation.h>

extern int signApp(NSString *appPath);

static NSString *TSDecryptCanonicalPath(NSString *path) {
    return path.length ? path.stringByResolvingSymlinksInPath.stringByStandardizingPath : @"";
}
static BOOL TSDecryptPathIsWithin(NSString *path, NSString *root) {
    NSString *p = TSDecryptCanonicalPath(path), *r = TSDecryptCanonicalPath(root);
    return p.length && r.length && ([p isEqualToString:r] || [p hasPrefix:[r stringByAppendingString:@"/"]]);
}
static NSString *TSDecryptRemoteCString(task_t task, mach_vm_address_t address) {
    if (!address) return nil;
    NSMutableData *data = [NSMutableData dataWithLength:PATH_MAX];
    mach_vm_size_t outSize = 0;
    kern_return_t kr = mach_vm_read_overwrite(task, address, data.length, (mach_vm_address_t)data.mutableBytes, &outSize);
    if (kr != KERN_SUCCESS || outSize == 0) return nil;
    const char *bytes = data.bytes;
    const char *end = memchr(bytes, '\0', (size_t)outSize);
    if (!end) return nil;
    return [[NSString alloc] initWithBytes:bytes length:(NSUInteger)(end - bytes) encoding:NSUTF8StringEncoding];
}
// Enumerate processes using Darwin sysctl APIs available in the iOS SDK.
// KERN_PROCARGS2 returns the executable path together with the process arguments.
static NSString *TSDecryptExecutablePathForPID(pid_t pid) {
    static int maxArgumentSize = 0;
    if (maxArgumentSize <= 0) {
        size_t size = sizeof(maxArgumentSize);
        int mib[2] = { CTL_KERN, KERN_ARGMAX };
        if (sysctl(mib, 2, &maxArgumentSize, &size, NULL, 0) != 0 || maxArgumentSize <= (int)sizeof(int)) {
            maxArgumentSize = 262144; // Conservative fallback for restricted sysctl environments.
        }
    }

    // KERN_PROCARGS2 returns argc followed by the executable path and argv data.
    // Bound the allocation even if the kernel reports an unexpected argument limit.
    size_t capacity = (size_t)MIN(maxArgumentSize, 4 * 1024 * 1024);
    char *arguments = calloc(1, capacity);
    if (!arguments) return nil;

    int mib[3] = { CTL_KERN, KERN_PROCARGS2, pid };
    size_t actualSize = capacity;
    if (sysctl(mib, 3, arguments, &actualSize, NULL, 0) != 0 || actualSize <= sizeof(int) || actualSize > capacity) {
        free(arguments);
        return nil;
    }

    const char *pathBytes = arguments + sizeof(int);
    size_t remaining = actualSize - sizeof(int);
    size_t pathLength = strnlen(pathBytes, remaining);
    NSString *path = nil;
    if (pathLength > 0 && pathLength < remaining) {
        path = [[NSString alloc] initWithBytes:pathBytes length:pathLength encoding:NSUTF8StringEncoding];
    }
    free(arguments);
    return path;
}

static BOOL TSDecryptFindProcess(LSApplicationProxy *proxy, pid_t *pidOut, NSString **errorOut) {
    NSString *bundle = TSDecryptCanonicalPath(proxy.bundleURL.path);
    NSString *expectedExecutable = proxy.canonicalExecutablePath;
    if (!expectedExecutable.length) {
        NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:[bundle stringByAppendingPathComponent:@"Info.plist"]];
        NSString *name = [info[@"CFBundleExecutable"] isKindOfClass:NSString.class] ? info[@"CFBundleExecutable"] : nil;
        if (name.length) expectedExecutable = [bundle stringByAppendingPathComponent:name];
    }
    if (!expectedExecutable.length) { if (errorOut) *errorOut = @"Could not determine the application's executable path."; return NO; }
    if (!pidOut) { if (errorOut) *errorOut = @"Missing process ID output parameter."; return NO; }

    int processMIB[3] = { CTL_KERN, KERN_PROC, KERN_PROC_ALL };
    struct kinfo_proc *processes = NULL;
    size_t processBytes = 0;
    // The process list can grow between the size query and the read. Retry once
    // on a size race rather than using a truncated or uninitialized process table.
    for (NSUInteger attempt = 0; attempt < 2; attempt++) {
        processBytes = 0;
        if (sysctl(processMIB, 3, NULL, &processBytes, NULL, 0) != 0 || processBytes < sizeof(struct kinfo_proc)) break;
        processes = calloc(1, processBytes);
        if (!processes) { if (errorOut) *errorOut = @"Out of memory while enumerating processes."; return NO; }
        size_t returnedBytes = processBytes;
        if (sysctl(processMIB, 3, processes, &returnedBytes, NULL, 0) == 0) {
            processBytes = returnedBytes;
            break;
        }
        free(processes);
        processes = NULL;
    }
    if (!processes || processBytes < sizeof(struct kinfo_proc)) {
        free(processes);
        if (errorOut) *errorOut = [NSString stringWithFormat:@"Could not enumerate running processes (sysctl: %s).", strerror(errno)];
        return NO;
    }

    NSString *expectedCanonical = TSDecryptCanonicalPath(expectedExecutable);
    BOOL found = NO;
    size_t processCount = processBytes / sizeof(struct kinfo_proc);
    for (size_t i = 0; i < processCount; i++) {
        pid_t pid = processes[i].kp_proc.p_pid;
        if (pid <= 0) continue;
        NSString *processPath = TSDecryptExecutablePathForPID(pid);
        if (!processPath.length) continue;
        NSString *candidate = TSDecryptCanonicalPath(processPath);
        if ([candidate isEqualToString:expectedCanonical] ||
            (TSDecryptPathIsWithin(candidate, bundle) && [candidate.lastPathComponent isEqualToString:expectedExecutable.lastPathComponent])) {
            *pidOut = pid;
            found = YES;
            break;
        }
    }
    free(processes);
    if (!found && errorOut) *errorOut = [NSString stringWithFormat:@"%@ is not running. Open the application, leave it in the foreground, then retry.", proxy.localizedName ?: proxy.bundleIdentifier];
    return found;
}
static BOOL TSDecryptRemoteRead(task_t task, mach_vm_address_t address, void *buffer, size_t length, NSString **errorOut) {
    mach_vm_size_t readLength = 0;
    kern_return_t kr = mach_vm_read_overwrite(task, address, (mach_vm_size_t)length, (mach_vm_address_t)buffer, &readLength);
    if (kr != KERN_SUCCESS || readLength != length) {
        if (errorOut) *errorOut = [NSString stringWithFormat:@"Could not read decrypted memory at 0x%llx (Mach error %d; %llu/%zu bytes).", (unsigned long long)address, kr, (unsigned long long)readLength, length];
        return NO;
    }
    return YES;
}
static BOOL TSDecryptSliceInfo(NSString *path, uint64_t *sliceOffset, uint64_t *sliceSize, NSString **errorOut) {
    int fd = open(path.fileSystemRepresentation, O_RDONLY | O_CLOEXEC);
    if (fd < 0) { if (errorOut) *errorOut = [NSString stringWithFormat:@"Could not open %@: %s", path.lastPathComponent, strerror(errno)]; return NO; }
    uint8_t header[sizeof(struct fat_header)] = {0};
    ssize_t got = pread(fd, header, sizeof(header), 0);
    if (got < (ssize_t)sizeof(uint32_t)) { close(fd); if (errorOut) *errorOut = @"Mach-O file is truncated."; return NO; }
    uint32_t magic = 0; memcpy(&magic, header, sizeof(magic));
    uint64_t fileSize = 0; struct stat st; if (fstat(fd, &st) == 0 && st.st_size >= 0) fileSize = (uint64_t)st.st_size;
    // FAT headers may use either byte order. On a little-endian device, a canonical
    // big-endian FAT_MAGIC header is read as FAT_CIGAM; swap the fields only in that case.
    BOOL isFat = NO, swapFields = NO, is64 = NO;
    if (magic == FAT_CIGAM || magic == FAT_CIGAM_64) { isFat = YES; swapFields = YES; is64 = (magic == FAT_CIGAM_64); }
    else if (magic == FAT_MAGIC || magic == FAT_MAGIC_64) { isFat = YES; swapFields = NO; is64 = (magic == FAT_MAGIC_64); }
    if (isFat) {
        if (got < (ssize_t)sizeof(struct fat_header)) { close(fd); if (errorOut) *errorOut = @"Universal Mach-O header is truncated."; return NO; }
        struct fat_header fh; memcpy(&fh, header, sizeof(fh));
        uint32_t n = swapFields ? CFSwapInt32(fh.nfat_arch) : fh.nfat_arch;
        if (n > 128) { close(fd); if (errorOut) *errorOut = @"Universal Mach-O contains an unreasonable number of architectures."; return NO; }
        uint64_t archSize = is64 ? sizeof(struct fat_arch_64) : sizeof(struct fat_arch);
        if ((uint64_t)sizeof(struct fat_header) + (uint64_t)n * archSize > fileSize) { close(fd); if (errorOut) *errorOut = @"Universal Mach-O architecture table exceeds the file size."; return NO; }
        for (uint32_t i = 0; i < n; i++) {
            uint64_t pos = sizeof(struct fat_header) + (uint64_t)i * archSize;
            uint32_t cpuType = 0; uint64_t candidateOffset = 0, candidateSize = 0;
            if (is64) {
                struct fat_arch_64 a; if (pread(fd, &a, sizeof(a), (off_t)pos) != sizeof(a)) continue;
                cpuType = swapFields ? CFSwapInt32(a.cputype) : a.cputype;
                candidateOffset = swapFields ? CFSwapInt64(a.offset) : a.offset;
                candidateSize = swapFields ? CFSwapInt64(a.size) : a.size;
            } else {
                struct fat_arch a; if (pread(fd, &a, sizeof(a), (off_t)pos) != sizeof(a)) continue;
                cpuType = swapFields ? CFSwapInt32(a.cputype) : a.cputype;
                candidateOffset = swapFields ? CFSwapInt32(a.offset) : a.offset;
                candidateSize = swapFields ? CFSwapInt32(a.size) : a.size;
            }
            if (cpuType == CPU_TYPE_ARM64) {
                if (candidateOffset > fileSize || candidateSize > fileSize - candidateOffset || candidateSize <= sizeof(struct mach_header_64)) { close(fd); if (errorOut) *errorOut = @"The arm64 slice has invalid bounds."; return NO; }
                *sliceOffset = candidateOffset; *sliceSize = candidateSize; close(fd); return YES;
            }
        }
        close(fd); if (errorOut) *errorOut = @"The Mach-O file has no arm64 slice."; return NO;
    }
    close(fd); *sliceOffset = 0; *sliceSize = fileSize; return fileSize > sizeof(struct mach_header_64);
}
static BOOL TSDecryptRuntimeOffsetForFileRange(const uint8_t *commands, const struct mach_header_64 *header, uint64_t fileOffset, uint64_t fileLength, uint64_t *runtimeOffset) {
    if (!commands || !header || !runtimeOffset || !fileLength || fileOffset > UINT64_MAX - fileLength) return NO;
    uint64_t baseVMAddress = UINT64_MAX;
    uint32_t offset = 0;
    for (uint32_t i = 0; i < header->ncmds; i++) {
        if (offset + sizeof(struct load_command) > header->sizeofcmds) return NO;
        const struct load_command *lc = (const struct load_command *)(commands + offset);
        if (lc->cmdsize < sizeof(struct load_command) || offset + lc->cmdsize > header->sizeofcmds) return NO;
        if (lc->cmd == LC_SEGMENT_64 && lc->cmdsize >= sizeof(struct segment_command_64)) {
            const struct segment_command_64 *segment = (const struct segment_command_64 *)lc;
            if (segment->fileoff == 0 && segment->filesize >= sizeof(struct mach_header_64)) baseVMAddress = MIN(baseVMAddress, segment->vmaddr);
        }
        offset += lc->cmdsize;
    }
    if (baseVMAddress == UINT64_MAX) return NO;
    offset = 0;
    for (uint32_t i = 0; i < header->ncmds; i++) {
        const struct load_command *lc = (const struct load_command *)(commands + offset);
        if (lc->cmd == LC_SEGMENT_64 && lc->cmdsize >= sizeof(struct segment_command_64)) {
            const struct segment_command_64 *segment = (const struct segment_command_64 *)lc;
            if (fileOffset >= segment->fileoff && fileOffset + fileLength <= segment->fileoff + segment->filesize && segment->vmaddr >= baseVMAddress) {
                uint64_t segmentDelta = segment->vmaddr - baseVMAddress;
                if (segmentDelta > UINT64_MAX - (fileOffset - segment->fileoff)) return NO;
                *runtimeOffset = segmentDelta + fileOffset - segment->fileoff;
                return YES;
            }
        }
        offset += lc->cmdsize;
    }
    return NO;
}

static BOOL TSDecryptPatchImage(task_t task, mach_vm_address_t imageAddress, NSString *sourceImagePath, NSString *destinationImagePath, NSUInteger *decryptedRegions, NSString **warning) {
    struct mach_header_64 header;
    NSString *readError = nil;
    if (!TSDecryptRemoteRead(task, imageAddress, &header, sizeof(header), &readError)) { if (warning) *warning = readError; return NO; }
    if (header.magic != MH_MAGIC_64 || header.ncmds > 8192 || header.sizeofcmds > 16 * 1024 * 1024) return NO;
    size_t commandBytes = header.sizeofcmds;
    uint8_t *commands = calloc(1, commandBytes ?: 1);
    if (!commands) { if (warning) *warning = @"Out of memory reading Mach-O load commands."; return NO; }
    BOOL ok = TSDecryptRemoteRead(task, imageAddress + sizeof(header), commands, commandBytes, &readError);
    if (!ok) { free(commands); if (warning) *warning = readError; return NO; }
    uint64_t sliceOffset = 0, sliceSize = 0;
    if (!TSDecryptSliceInfo(sourceImagePath, &sliceOffset, &sliceSize, &readError)) { free(commands); if (warning) *warning = readError; return NO; }
    int fd = open(destinationImagePath.fileSystemRepresentation, O_RDWR | O_CLOEXEC);
    if (fd < 0) { free(commands); if (warning) *warning = [NSString stringWithFormat:@"Cannot modify %@: %s", destinationImagePath.lastPathComponent, strerror(errno)]; return NO; }
    uint32_t offset = 0; BOOL touched = NO;
    for (uint32_t i = 0; i < header.ncmds; i++) {
        if (offset + sizeof(struct load_command) > commandBytes) break;
        struct load_command *lc = (struct load_command *)(commands + offset);
        if (lc->cmdsize < sizeof(struct load_command) || offset + lc->cmdsize > commandBytes) break;
        if (lc->cmd == LC_ENCRYPTION_INFO_64 && lc->cmdsize >= sizeof(struct encryption_info_command_64)) {
            struct encryption_info_command_64 *crypt = (struct encryption_info_command_64 *)lc;
            if (crypt->cryptid != 0 && crypt->cryptsize > 0 && (uint64_t)crypt->cryptoff + crypt->cryptsize <= sliceSize) {
                uint64_t runtimeOffset = 0;
                if (!TSDecryptRuntimeOffsetForFileRange(commands, &header, crypt->cryptoff, crypt->cryptsize, &runtimeOffset)) { if (warning) *warning = @"The encrypted file range could not be mapped to a loaded Mach-O segment."; close(fd); free(commands); return NO; }
                uint64_t cursor = 0; size_t chunkSize = 1024 * 1024; uint8_t *buffer = malloc(chunkSize);
                if (!buffer) { if (warning) *warning = @"Out of memory while dumping decrypted memory."; close(fd); free(commands); return NO; }
                while (cursor < crypt->cryptsize) {
                    size_t current = (size_t)MIN((uint64_t)chunkSize, (uint64_t)crypt->cryptsize - cursor);
                    if (!TSDecryptRemoteRead(task, imageAddress + runtimeOffset + cursor, buffer, current, &readError)) { free(buffer); close(fd); free(commands); if (warning) *warning = readError; return NO; }
                    size_t written = 0;
                    while (written < current) {
                        ssize_t n = pwrite(fd, buffer + written, current - written, (off_t)(sliceOffset + crypt->cryptoff + cursor + written));
                        if (n < 0 && errno == EINTR) continue;
                        if (n <= 0) { free(buffer); close(fd); free(commands); if (warning) *warning = [NSString stringWithFormat:@"Could not write decrypted bytes: %s", strerror(errno)]; return NO; }
                        written += (size_t)n;
                    }
                    cursor += current;
                }
                free(buffer);
                uint32_t zero = 0;
                off_t cryptidOffset = (off_t)(sliceOffset + sizeof(struct mach_header_64) + (uint64_t)offset + offsetof(struct encryption_info_command_64, cryptid));
                if (pwrite(fd, &zero, sizeof(zero), cryptidOffset) != sizeof(zero)) { close(fd); free(commands); if (warning) *warning = @"Could not clear the Mach-O cryptid field."; return NO; }
                (*decryptedRegions)++; touched = YES;
            }
        } else if (lc->cmd == LC_ENCRYPTION_INFO && lc->cmdsize >= sizeof(struct encryption_info_command)) {
            struct encryption_info_command *crypt = (struct encryption_info_command *)lc;
            if (crypt->cryptid != 0 && crypt->cryptsize > 0 && (uint64_t)crypt->cryptoff + crypt->cryptsize <= sliceSize) {
                uint64_t runtimeOffset = 0;
                if (!TSDecryptRuntimeOffsetForFileRange(commands, &header, crypt->cryptoff, crypt->cryptsize, &runtimeOffset)) { if (warning) *warning = @"The encrypted file range could not be mapped to a loaded Mach-O segment."; close(fd); free(commands); return NO; }
                uint64_t cursor = 0; uint8_t *buffer = malloc(1024 * 1024);
                if (!buffer) { close(fd); free(commands); if (warning) *warning = @"Out of memory while dumping decrypted memory."; return NO; }
                while (cursor < crypt->cryptsize) {
                    size_t current = (size_t)MIN((uint64_t)(1024 * 1024), (uint64_t)crypt->cryptsize - cursor);
                    if (!TSDecryptRemoteRead(task, imageAddress + runtimeOffset + cursor, buffer, current, &readError)) { free(buffer); close(fd); free(commands); if (warning) *warning = readError; return NO; }
                    size_t written = 0; while (written < current) { ssize_t n = pwrite(fd, buffer + written, current - written, (off_t)(sliceOffset + crypt->cryptoff + cursor + written)); if (n < 0 && errno == EINTR) continue; if (n <= 0) { free(buffer); close(fd); free(commands); if (warning) *warning = @"Could not write decrypted bytes."; return NO; } written += (size_t)n; }
                    cursor += current;
                }
                free(buffer); uint32_t zero = 0;
                off_t cryptidOffset = (off_t)(sliceOffset + sizeof(struct mach_header_64) + (uint64_t)offset + offsetof(struct encryption_info_command, cryptid));
                if (pwrite(fd, &zero, sizeof(zero), cryptidOffset) != sizeof(zero)) { close(fd); free(commands); if (warning) *warning = @"Could not clear the Mach-O cryptid field."; return NO; }
                (*decryptedRegions)++; touched = YES;
            }
        }
        offset += lc->cmdsize;
    }
    fsync(fd); close(fd); free(commands);
    return touched;
}
static BOOL TSDecryptArchiveDirectory(NSString *root, NSString *outputPath, NSString **errorOut) {
    struct archive *writer = archive_write_new(); archive_write_set_format_zip(writer); archive_write_set_options(writer, "zip:compression=deflate");
    NSString *temporary = [outputPath stringByAppendingFormat:@".partial.%@", NSUUID.UUID.UUIDString];
    int rc = archive_write_open_filename(writer, temporary.fileSystemRepresentation);
    if (rc != ARCHIVE_OK) { if (errorOut) *errorOut = [NSString stringWithUTF8String:archive_error_string(writer) ?: "Could not create output IPA."]; archive_write_free(writer); return NO; }
    NSString *standardRoot = root.stringByStandardizingPath; NSFileManager *fm = NSFileManager.defaultManager;
    NSDirectoryEnumerator *enumerator = [fm enumeratorAtURL:[NSURL fileURLWithPath:standardRoot] includingPropertiesForKeys:nil options:0 errorHandler:^BOOL(NSURL *url, NSError *error) { return NO; }];
    BOOL success = YES; NSURL *url = nil;
    while ((url = [enumerator nextObject])) {
        NSString *abs = url.path.stringByStandardizingPath;
        if (![abs hasPrefix:[standardRoot stringByAppendingString:@"/"]]) continue;
        NSString *rel = [abs substringFromIndex:standardRoot.length + 1]; struct stat st; if (lstat(abs.fileSystemRepresentation, &st) != 0) continue;
        struct archive_entry *entry = archive_entry_new(); archive_entry_set_pathname(entry, rel.fileSystemRepresentation); archive_entry_set_perm(entry, st.st_mode & 07777); archive_entry_set_mtime(entry, st.st_mtime, 0);
        if (S_ISDIR(st.st_mode)) { archive_entry_set_filetype(entry, AE_IFDIR); archive_entry_set_size(entry, 0); }
        else if (S_ISREG(st.st_mode)) { archive_entry_set_filetype(entry, AE_IFREG); archive_entry_set_size(entry, st.st_size); }
        else if (S_ISLNK(st.st_mode)) { char linkBuffer[PATH_MAX + 1] = {0}; ssize_t linkLength = readlink(abs.fileSystemRepresentation, linkBuffer, PATH_MAX); if (linkLength < 0) { archive_entry_free(entry); success = NO; break; } linkBuffer[linkLength] = 0; archive_entry_set_filetype(entry, AE_IFLNK); archive_entry_set_symlink(entry, linkBuffer); archive_entry_set_size(entry, 0); }
        else { archive_entry_free(entry); continue; }
        if (archive_write_header(writer, entry) < ARCHIVE_OK) { archive_entry_free(entry); success = NO; break; }
        if (S_ISREG(st.st_mode)) {
            int fd = open(abs.fileSystemRepresentation, O_RDONLY | O_CLOEXEC); if (fd < 0) { archive_entry_free(entry); success = NO; break; }
            uint8_t buffer[256 * 1024]; ssize_t n = 0;
            while ((n = read(fd, buffer, sizeof(buffer))) > 0) { size_t offset = 0; while (offset < (size_t)n) { la_ssize_t w = archive_write_data(writer, buffer + offset, (size_t)n - offset); if (w <= 0) { success = NO; break; } offset += (size_t)w; } if (!success) break; }
            if (n < 0) success = NO; close(fd);
        }
        archive_entry_free(entry); if (!success || archive_write_finish_entry(writer) < ARCHIVE_OK) { success = NO; break; }
    }
    if (archive_write_close(writer) != ARCHIVE_OK) success = NO; archive_write_free(writer);
    if (!success) { [fm removeItemAtPath:temporary error:nil]; if (errorOut) *errorOut = @"Could not package decrypted IPA."; return NO; }
    [fm removeItemAtPath:outputPath error:nil]; NSError *moveError = nil;
    if (![fm moveItemAtPath:temporary toPath:outputPath error:&moveError]) { [fm removeItemAtPath:temporary error:nil]; if (errorOut) *errorOut = moveError.localizedDescription; return NO; }
    return YES;
}
int TSAppDecryptorDecryptBundleToIPA(NSString *bundleIdentifier, NSString *outputIPAPath, NSString **detail) {
    LSApplicationProxy *proxy = [LSApplicationProxy applicationProxyForIdentifier:bundleIdentifier];
    if (!proxy || !proxy.installed || !proxy.bundleURL.path.length) { if (detail) *detail = @"The selected application is not installed."; return 301; }
    LSApplicationProxy *selfProxy = [LSApplicationProxy applicationProxyForIdentifier:APP_ID];
    NSString *packagesRoot = [selfProxy.dataContainerURL.path stringByAppendingPathComponent:@"Documents/Packages"].stringByStandardizingPath;
    NSString *outputStandard = outputIPAPath.stringByStandardizingPath;
    if (!packagesRoot.length || !TSDecryptPathIsWithin(outputStandard, packagesRoot) || ![outputStandard.pathExtension.lowercaseString isEqualToString:@"ipa"]) { if (detail) *detail = @"Output must be an .ipa inside TrollStore's Documents/Packages directory."; return 302; }
    NSString *processError = nil; pid_t pid = 0;
    if (!TSDecryptFindProcess(proxy, &pid, &processError)) { if (detail) *detail = processError ?: @"The app is not running."; return 303; }
    mach_port_t task = MACH_PORT_NULL;
    kern_return_t kr = task_for_pid(mach_task_self(), pid, &task);
    if (kr != KERN_SUCCESS) { if (detail) *detail = [NSString stringWithFormat:@"Could not attach to PID %d (Mach error %d). Keep the app running and confirm this TrollStore build has task_for_pid permission on this iOS version.", pid, kr]; return 304; }
    struct task_dyld_info dyldInfo; mach_msg_type_number_t count = TASK_DYLD_INFO_COUNT;
    kr = task_info(task, TASK_DYLD_INFO, (task_info_t)&dyldInfo, &count);
    if (kr != KERN_SUCCESS || !dyldInfo.all_image_info_addr) { mach_port_deallocate(mach_task_self(), task); if (detail) *detail = @"Could not read the target process's dyld image list."; return 305; }
    struct dyld_all_image_infos allInfos;
    if (!TSDecryptRemoteRead(task, (mach_vm_address_t)dyldInfo.all_image_info_addr, &allInfos, sizeof(allInfos), &processError)) { mach_port_deallocate(mach_task_self(), task); if (detail) *detail = processError; return 306; }
    if (allInfos.infoArrayCount > 100000) { mach_port_deallocate(mach_task_self(), task); if (detail) *detail = @"The target process returned an invalid dyld image count."; return 307; }
    NSString *sourceBundle = TSDecryptCanonicalPath(proxy.bundleURL.path);
    NSString *staging = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"TS-decrypt-%@", NSUUID.UUID.UUIDString]];
    NSString *payload = [staging stringByAppendingPathComponent:@"Payload"];
    NSString *copiedBundle = [payload stringByAppendingPathComponent:sourceBundle.lastPathComponent];
    NSFileManager *fm = NSFileManager.defaultManager; NSError *copyError = nil;
    if (![fm createDirectoryAtPath:payload withIntermediateDirectories:YES attributes:nil error:&copyError] || ![fm copyItemAtPath:sourceBundle toPath:copiedBundle error:&copyError]) { mach_port_deallocate(mach_task_self(), task); [fm removeItemAtPath:staging error:nil]; if (detail) *detail = copyError.localizedDescription ?: @"Could not stage the app bundle."; return 308; }
    NSUInteger decryptedCount = 0; NSMutableArray *warnings = [NSMutableArray array]; uint64_t imageListAddress = (uint64_t)allInfos.infoArray;
    for (uint32_t i = 0; i < allInfos.infoArrayCount; i++) {
        struct dyld_image_info imageInfo;
        if (!TSDecryptRemoteRead(task, imageListAddress + (uint64_t)i * sizeof(imageInfo), &imageInfo, sizeof(imageInfo), &processError)) { if (warnings.count < 8) [warnings addObject:processError ?: @"Skipped an unreadable dyld image."]; continue; }
        NSString *imagePath = TSDecryptRemoteCString(task, (mach_vm_address_t)imageInfo.imageFilePath);
        if (!imagePath.length) continue;
        NSString *normalizedSource = TSDecryptCanonicalPath(imagePath);
        if (!TSDecryptPathIsWithin(normalizedSource, sourceBundle)) continue;
        NSString *relative = [normalizedSource substringFromIndex:sourceBundle.length];
        NSString *copySourcePath = [sourceBundle stringByAppendingString:relative];
        NSString *copyDestinationPath = [copiedBundle stringByAppendingString:relative];
        if (![fm fileExistsAtPath:copySourcePath] || ![fm fileExistsAtPath:copyDestinationPath]) continue;
        NSUInteger before = decryptedCount; NSString *warning = nil;
        TSDecryptPatchImage(task, (mach_vm_address_t)imageInfo.imageLoadAddress, copySourcePath, copyDestinationPath, &decryptedCount, &warning);
        if (warning.length && warnings.count < 8) [warnings addObject:[NSString stringWithFormat:@"%@ — %@", relative.lastPathComponent, warning]];
        (void)before;
    }
    mach_port_deallocate(mach_task_self(), task);
    if (decryptedCount == 0) { [fm removeItemAtPath:staging error:nil]; if (detail) *detail = warnings.count ? [NSString stringWithFormat:@"No encrypted Mach-O region was decrypted. %@", [warnings componentsJoinedByString:@"; "]] : @"No loaded encrypted Mach-O region was found. The app may already be decrypted or its encryption information is not readable."; return 309; }
    // Re-sign the decrypted copy and regenerate nested resource envelopes before packaging.
    // Error 184 means at least one additional binary remains encrypted; that is a warning,
    // not a reason to discard successfully decrypted main/other images.
    int signResult = signApp(copiedBundle);
    if (signResult != 0 && signResult != 184) { [fm removeItemAtPath:staging error:nil]; if (detail) *detail = [NSString stringWithFormat:@"The decrypted memory was copied, but signing the output bundle failed (%d). No IPA was written.", signResult]; return 311; }
    if (signResult == 184 && warnings.count < 8) [warnings addObject:@"One or more extension/plugin binaries remain encrypted (error 184); the main executable was decrypted, but those features may not work."];
    NSString *zipError = nil;
    if (![fm createDirectoryAtPath:packagesRoot withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0755} error:nil] || !TSDecryptArchiveDirectory(staging, outputStandard, &zipError)) { [fm removeItemAtPath:staging error:nil]; if (detail) *detail = zipError ?: @"Could not write the IPA."; return 310; }
    [fm removeItemAtPath:staging error:nil];
    if (detail) *detail = warnings.count ? [NSString stringWithFormat:@"Decrypted %lu memory region(s) from the running process. IPA saved to %@. Some images were skipped: %@", (unsigned long)decryptedCount, outputStandard.lastPathComponent, [warnings componentsJoinedByString:@"; "]] : [NSString stringWithFormat:@"Decrypted %lu memory region(s) from the running process. IPA saved to %@.", (unsigned long)decryptedCount, outputStandard.lastPathComponent];
    return 0;
}
