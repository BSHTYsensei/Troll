#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

#define TROLLSTORE_ROOT_PATH @"/var/containers/Bundle/TrollStore"
#define TROLLSTORE_MAIN_PATH [TROLLSTORE_ROOT_PATH stringByAppendingPathComponent:@"Main"]
#define TROLLSTORE_APPLICATIONS_PATH [TROLLSTORE_ROOT_PATH stringByAppendingPathComponent:@"Applications"]

@interface TSApplicationsManager : NSObject

+ (instancetype)sharedInstance;

- (NSArray*)installedAppPaths;

- (NSError*)errorForCode:(int)code;
- (int)installIpa:(NSString*)pathToIpa force:(BOOL)force log:(NSString * _Nullable * _Nullable)logOut;
- (int)installIpa:(NSString*)pathToIpa
            force:(BOOL)force
 installationMethod:(int)method // 0 = installd, 1 = custom
preserveEntitlementsOverride:(BOOL)preserve
              log:(NSString * _Nullable * _Nullable)logOut;
- (int)installIpa:(NSString*)pathToIpa
            force:(BOOL)force
 installationMethod:(int)method
preserveEntitlementsOverride:(BOOL)preserve
customEntitlementsPath:(NSString * _Nullable)entitlementsPath
      stealthInstall:(BOOL)stealthInstall
              log:(NSString * _Nullable * _Nullable)logOut;
- (int)installIpa:(NSString*)pathToIpa;
- (int)uninstallApp:(NSString * _Nullable)appId;
- (int)uninstallAppByPath:(NSString * _Nullable)path;
- (BOOL)openApplicationWithBundleID:(NSString *)appID;
- (int)enableJITForBundleID:(NSString *)appID;
- (int)changeAppRegistration:(NSString * _Nullable)appPath toState:(NSString * _Nullable)newState;

@end

NS_ASSUME_NONNULL_END