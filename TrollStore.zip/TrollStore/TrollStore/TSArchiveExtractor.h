#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@interface TSArchiveExtractor : NSObject
+ (BOOL)archiveContainsInstallableIPAAtPath:(NSString *)archivePath;
+ (BOOL)extractArchiveAtPath:(NSString *)archivePath toDirectory:(NSString *)destinationPath error:(NSError * _Nullable * _Nullable)error;
+ (BOOL)createZipFromDirectory:(NSString *)sourceDirectory outputPath:(NSString *)outputPath error:(NSError * _Nullable * _Nullable)error;
+ (NSArray<NSString *> *)dynamicLibrariesUnderDirectory:(NSString *)directory;
@end
NS_ASSUME_NONNULL_END
