#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@interface TSAppUpdateManager : NSObject
+ (void)copyBlockedBundleIdentifiersWithCompletion:(void (^)(NSSet<NSString *> *identifiers, NSError * _Nullable error))completion;
+ (void)setUpdatesBlocked:(BOOL)blocked forBundleIdentifier:(NSString *)bundleIdentifier completion:(void (^)(BOOL success, NSString *message))completion;
@end
NS_ASSUME_NONNULL_END
