#import "TSPluginStore.h"
#import "TSArchiveExtractor.h"

static NSString * const TSPluginStoreErrorDomain = @"com.opa334.TrollStore.PluginStore";
static NSSet<NSString *> *TSPluginStoreExtensions(void) {
    return [NSSet setWithArray:@[@"dylib", @"framework", @"deb", @"zip"]];
}
static NSString *TSPluginStoreUniquePath(NSString *directory, NSString *filename) {
    NSString *candidate = [directory stringByAppendingPathComponent:filename];
    if (![NSFileManager.defaultManager fileExistsAtPath:candidate]) return candidate;
    NSString *stem = filename.stringByDeletingPathExtension;
    NSString *extension = filename.pathExtension;
    for (NSUInteger index = 1; index < 10000; index++) {
        NSString *name = extension.length ? [NSString stringWithFormat:@"%@-%lu.%@", stem, (unsigned long)index, extension] : [NSString stringWithFormat:@"%@-%lu", stem, (unsigned long)index];
        candidate = [directory stringByAppendingPathComponent:name];
        if (![NSFileManager.defaultManager fileExistsAtPath:candidate]) return candidate;
    }
    return [directory stringByAppendingPathComponent:[NSString stringWithFormat:@"%@-%@", NSUUID.UUID.UUIDString, filename]];
}

@implementation TSPluginStore
+ (NSString *)pluginDirectoryPath {
    NSString *documents = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject ?: NSTemporaryDirectory();
    return [documents stringByAppendingPathComponent:@"Plugins"];
}
+ (void)ensurePluginDirectory {
    [NSFileManager.defaultManager createDirectoryAtPath:self.pluginDirectoryPath withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0755} error:nil];
}
+ (NSArray<NSURL *> *)availablePluginItems {
    [self ensurePluginDirectory];
    NSArray<NSURL *> *items = [NSFileManager.defaultManager contentsOfDirectoryAtURL:[NSURL fileURLWithPath:self.pluginDirectoryPath isDirectory:YES] includingPropertiesForKeys:@[NSURLIsDirectoryKey, NSURLFileSizeKey, NSURLContentModificationDateKey] options:NSDirectoryEnumerationSkipsHiddenFiles error:nil] ?: @[];
    NSMutableArray<NSURL *> *plugins = [NSMutableArray array];
    for (NSURL *item in items) {
        NSString *extension = item.pathExtension.lowercaseString;
        if (![TSPluginStoreExtensions() containsObject:extension]) continue;
        NSString *resolved = item.path.stringByResolvingSymlinksInPath.stringByStandardizingPath;
        NSString *root = self.pluginDirectoryPath.stringByResolvingSymlinksInPath.stringByStandardizingPath;
        if (![resolved isEqualToString:root] && ![resolved hasPrefix:[root stringByAppendingString:@"/"]]) continue;
        [plugins addObject:item];
    }
    [plugins sortUsingComparator:^NSComparisonResult(NSURL *a, NSURL *b) {
        return [a.lastPathComponent localizedStandardCompare:b.lastPathComponent];
    }];
    return plugins.copy;
}
+ (BOOL)isInjectableLibraryPath:(NSString *)path {
    if (!path.length) return NO;
    NSString *root = self.pluginDirectoryPath.stringByResolvingSymlinksInPath.stringByStandardizingPath;
    NSString *resolved = path.stringByResolvingSymlinksInPath.stringByStandardizingPath;
    if (![resolved isEqualToString:root] && ![resolved hasPrefix:[root stringByAppendingString:@"/"]]) return NO;
    NSString *extension = resolved.pathExtension.lowercaseString;
    if (![extension isEqualToString:@"dylib"] && ![extension isEqualToString:@"framework"]) return NO;
    BOOL isDirectory = NO;
    if (![NSFileManager.defaultManager fileExistsAtPath:resolved isDirectory:&isDirectory]) return NO;
    return [extension isEqualToString:@"framework"] ? isDirectory : !isDirectory;
}
+ (NSArray<NSString *> *)injectableLibraryPathsForPluginItem:(NSURL *)item {
    if (!item.isFileURL) return @[];
    NSString *extension = item.pathExtension.lowercaseString;
    if ([extension isEqualToString:@"dylib"] || [extension isEqualToString:@"framework"]) {
        return [self isInjectableLibraryPath:item.path] ? @[item.path] : @[];
    }
    if (![extension isEqualToString:@"deb"] && ![extension isEqualToString:@"zip"]) return @[];
    NSString *contents = [item.path stringByAppendingString:@".contents"];
    NSArray<NSString *> *libraries = [TSArchiveExtractor dynamicLibrariesUnderDirectory:contents];
    NSMutableArray *safe = [NSMutableArray array];
    for (NSString *path in libraries) if ([self isInjectableLibraryPath:path]) [safe addObject:path];
    return [safe sortedArrayUsingSelector:@selector(localizedStandardCompare:)];
}
+ (NSArray<NSString *> *)availableInjectableLibraryPaths {
    NSMutableArray<NSString *> *paths = [NSMutableArray array];
    for (NSURL *item in [self availablePluginItems]) [paths addObjectsFromArray:[self injectableLibraryPathsForPluginItem:item]];
    return [paths sortedArrayUsingSelector:@selector(localizedStandardCompare:)];
}
+ (NSUInteger)injectableLibraryCountForPluginItem:(NSURL *)item {
    return [self injectableLibraryPathsForPluginItem:item].count;
}
+ (NSURL *)importPluginAtURL:(NSURL *)sourceURL error:(NSError **)error {
    if (!sourceURL.isFileURL || ![TSPluginStoreExtensions() containsObject:sourceURL.pathExtension.lowercaseString]) {
        if (error) *error = [NSError errorWithDomain:TSPluginStoreErrorDomain code:1 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"Choose a .dylib, .framework, .deb or .zip plugin.", nil)}];
        return nil;
    }
    BOOL scoped = [sourceURL startAccessingSecurityScopedResource];
    [self ensurePluginDirectory];
    NSString *extension = sourceURL.pathExtension.lowercaseString;
    BOOL isDirectory = NO;
    BOOL exists = [NSFileManager.defaultManager fileExistsAtPath:sourceURL.path isDirectory:&isDirectory];
    if (!exists || ( [extension isEqualToString:@"framework"] != isDirectory )) {
        if (scoped) [sourceURL stopAccessingSecurityScopedResource];
        if (error) *error = [NSError errorWithDomain:TSPluginStoreErrorDomain code:2 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"The selected plugin file or framework is unavailable or has the wrong type.", nil)}];
        return nil;
    }
    NSString *destination = TSPluginStoreUniquePath(self.pluginDirectoryPath, sourceURL.lastPathComponent.lastPathComponent);
    NSError *copyError = nil;
    BOOL copied = [NSFileManager.defaultManager copyItemAtPath:sourceURL.path toPath:destination error:&copyError];
    if (scoped) [sourceURL stopAccessingSecurityScopedResource];
    if (!copied) {
        if (error) *error = copyError ?: [NSError errorWithDomain:TSPluginStoreErrorDomain code:3 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"Could not copy the plugin into the local plugin store.", nil)}];
        return nil;
    }
    if ([extension isEqualToString:@"deb"] || [extension isEqualToString:@"zip"]) {
        NSString *contents = [destination stringByAppendingString:@".contents"];
        NSError *extractError = nil;
        if (![TSArchiveExtractor extractArchiveAtPath:destination toDirectory:contents error:&extractError]) {
            // Keep the original package for inspection even when it has no supported archive payload.
            NSLog(@"[PluginStore] saved %@ but could not extract payload: %@", destination.lastPathComponent, extractError.localizedDescription);
        }
    }
    return [NSURL fileURLWithPath:destination];
}
+ (BOOL)removePluginItemAtURL:(NSURL *)item error:(NSError **)error {
    if (!item.isFileURL) return NO;
    NSString *root = self.pluginDirectoryPath.stringByResolvingSymlinksInPath.stringByStandardizingPath;
    NSString *resolved = item.path.stringByResolvingSymlinksInPath.stringByStandardizingPath;
    if (![resolved hasPrefix:[root stringByAppendingString:@"/"]] || ![TSPluginStoreExtensions() containsObject:item.pathExtension.lowercaseString]) {
        if (error) *error = [NSError errorWithDomain:TSPluginStoreErrorDomain code:4 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"Refusing to remove a file outside the plugin store.", nil)}];
        return NO;
    }
    NSError *removeError = nil;
    if (![NSFileManager.defaultManager removeItemAtPath:item.path error:&removeError]) {
        if (error) *error = removeError;
        return NO;
    }
    NSString *contents = [item.path stringByAppendingString:@".contents"];
    [NSFileManager.defaultManager removeItemAtPath:contents error:nil];
    return YES;
}
@end
