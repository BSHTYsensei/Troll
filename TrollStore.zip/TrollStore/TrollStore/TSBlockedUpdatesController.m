#import "TSBlockedUpdatesController.h"
#import "TSAppUpdateManager.h"
#import <CoreServices.h>
#import <TSPresentationDelegate.h>

@interface TSBlockedUpdatesController ()
@property(nonatomic, copy) NSArray<NSDictionary *> *items;
@property(nonatomic, assign) BOOL loading;
@property(nonatomic, strong) UILabel *footerLabel;
@end
@implementation TSBlockedUpdatesController
- (void)viewDidLoad {
    [super viewDidLoad]; self.title = NSLocalizedString(@"Blocked App Updates", nil);
    self.tableView.tableFooterView = [UIView new]; self.items = @[];
    self.footerLabel = [UILabel new];
    self.footerLabel.text = [NSString stringWithFormat:@"%@ %@", NSLocalizedString(@"Tap a blocked app to restore its original App Store metadata and allow updates again.", nil), NSLocalizedString(@"App Store app updates only. iOS and system software updates are not affected.", nil)];
    self.footerLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    self.footerLabel.textColor = UIColor.secondaryLabelColor; self.footerLabel.numberOfLines = 0;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh target:self action:@selector(reloadBlockedApps)];
}
- (void)viewWillAppear:(BOOL)animated { [super viewWillAppear:animated]; [self reloadBlockedApps]; }
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGFloat tableWidth = CGRectGetWidth(self.tableView.bounds);
    CGFloat labelWidth = MAX(0, tableWidth - 36);
    CGSize size = [self.footerLabel sizeThatFits:CGSizeMake(labelWidth, CGFLOAT_MAX)];
    UIView *container = self.tableView.tableFooterView;
    BOOL shouldAssignFooter = NO;
    if ([container viewWithTag:7416] != self.footerLabel) {
        container = [[UIView alloc] initWithFrame:CGRectZero];
        self.footerLabel.tag = 7416;
        [container addSubview:self.footerLabel];
        shouldAssignFooter = YES;
    }
    self.footerLabel.frame = CGRectMake(18, 10, labelWidth, size.height);
    CGRect desiredFrame = CGRectMake(0, 0, tableWidth, size.height + 20);
    if (!CGRectEqualToRect(container.frame, desiredFrame)) { container.frame = desiredFrame; shouldAssignFooter = YES; }
    if (shouldAssignFooter) self.tableView.tableFooterView = container;
}
- (void)reloadBlockedApps {
    if (self.loading) return; self.loading = YES;
    [TSAppUpdateManager copyBlockedBundleIdentifiersWithCompletion:^(NSSet<NSString *> *ids, NSError *error) {
        self.loading = NO;
        if (error) { [self showMessage:error.localizedDescription title:NSLocalizedString(@"Unable to Load", nil)]; return; }
        NSMutableArray *rows = [NSMutableArray array];
        for (NSString *bundleID in ids) {
            LSApplicationProxy *proxy = [LSApplicationProxy applicationProxyForIdentifier:bundleID];
            [rows addObject:@{@"bundleID":bundleID, @"name":proxy.localizedName ?: bundleID}];
        }
        [rows sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) { return [a[@"name"] localizedStandardCompare:b[@"name"]]; }];
        self.items = rows.copy; [self.tableView reloadData];
    }];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return self.items.count; }
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"BlockedUpdateCell"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"BlockedUpdateCell"];
    NSDictionary *item = self.items[indexPath.row]; cell.textLabel.text = item[@"name"]; cell.detailTextLabel.text = item[@"bundleID"];
    cell.imageView.image = [UIImage systemImageNamed:@"arrow.down.circle.fill"]; cell.imageView.tintColor = UIColor.systemOrangeColor;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator; return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES]; NSDictionary *item = self.items[indexPath.row];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Allow App Updates?", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Restore update metadata for %@ (%@)?", nil), item[@"name"], item[@"bundleID"]] preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Allow Updates", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        [TSPresentationDelegate startActivity:NSLocalizedString(@"Refreshing App Store Metadata", nil)];
        [TSAppUpdateManager setUpdatesBlocked:NO forBundleIdentifier:item[@"bundleID"] completion:^(BOOL success, NSString *message) {
            [TSPresentationDelegate stopActivityWithCompletion:^{ [self showMessage:message title:success ? NSLocalizedString(@"Completed", nil) : NSLocalizedString(@"Operation Failed", nil)]; if (success) [self reloadBlockedApps]; }];
        }];
    }]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}
- (void)showMessage:(NSString *)message title:(NSString *)title { UIAlertController *alert=[UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert]; [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]]; [TSPresentationDelegate presentViewController:alert animated:YES completion:nil]; }
@end
