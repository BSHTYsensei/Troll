#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@interface TSIPAPackageStore : UITableViewController <UIDocumentPickerDelegate>
+ (NSString *)packageDirectoryPath;
+ (NSArray<NSURL *> *)availablePackages;
+ (NSURL * _Nullable)importPackageAtURL:(NSURL *)sourceURL error:(NSError * _Nullable * _Nullable)error;
+ (NSURL * _Nullable)exportInstalledAppAtPath:(NSString *)appBundlePath error:(NSError * _Nullable * _Nullable)error;
@end
NS_ASSUME_NONNULL_END
