# Optional tweak runtime payloads

This directory is copied into TrollStore.app by the existing `TrollStore_RESOURCE_DIRS = Resources` rule. The RootHelper dependency resolver searches here after checking the selected plugin's own extracted package.

## Supported layout

Place only redistributable, device-compatible `.dylib` and `.framework` payloads here, retaining their exact dependency load names and package layout. The resolver verifies an arm64 Mach-O slice, follows strong `LC_LOAD_DYLIB` dependencies recursively, and asks the bundled `ldid --iosinject` implementation to copy those dependencies into the target app's `Frameworks` directory. Ambiguous, weak, missing, and non-arm64 dependencies are not silently substituted.

A standalone plugin imported directly into `Documents/Plugins` is not allowed to borrow files from unrelated plugins. Dependencies should travel together in the same `.deb` or `.zip` package so they are kept under that package's `.contents` directory.

## Upstream runtime references

- ElleKit source: https://github.com/tealbathingsuit/ellekit
- ElleKit package builder: https://github.com/dhinakg/ellekit-builder

ElleKit is a hook runtime and Substrate/libhooker API reimplementation, not a standalone compatibility shim. Its upstream project documents a startup LaunchDaemon and package-level components; copying only `libellekit.dylib` or renaming it to `libsubstrate.dylib` does not make a functioning runtime. The rootful/rootless package variants also differ.

No unverified hook runtime binary is shipped in this source archive. If a tweak requires ElleKit, Substrate, or libhooker and the selected package does not include a compatible app-loadable runtime, TrollStore reports the missing dependency and stops injection instead of producing a likely-crashing app.
