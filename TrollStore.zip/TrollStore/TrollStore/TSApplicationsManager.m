#import "TSApplicationsManager.h"
#import <TSUtil.h>
#import "TSSigningManager.h"
#import "TSPluginStore.h"
extern NSUserDefaults* trollStoreUserDefaults();

@implementation TSApplicationsManager

+ (instancetype)sharedInstance
{
    static TSApplicationsManager *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[TSApplicationsManager alloc] init];
    });
    return sharedInstance;
}

- (NSArray*)installedAppPaths
{
    return trollStoreInstalledAppBundlePaths();
}

- (NSError*)errorForCode:(int)code
{
    NSString* errorDescription = NSLocalizedString(@"Unknown Error", nil);
    switch(code)
    {
        // IPA install errors
        case 166:
        errorDescription = NSLocalizedString(@"The IPA file does not exist or is not accessible.", nil);
        break;
        case 167:
        errorDescription = NSLocalizedString(@"The IPA file does not appear to contain an app.", nil);
        break;
        case 168:
        errorDescription = NSLocalizedString(@"Failed to extract IPA file.", nil);
        break;
        case 169:
        errorDescription = NSLocalizedString(@"Failed to extract update tar file.", nil);
        break;
        // App install errors
        case 170:
        errorDescription = NSLocalizedString(@"Failed to create container for app bundle.", nil);
        break;
        case 171:
        errorDescription = [NSString stringWithFormat:NSLocalizedString(@"A non %@ or a %@ app with the same identifier is already installed. If you are absolutely sure it is not, you can force install it.", nil), APP_NAME, OTHER_APP_NAME];
        break;
        case 172:
        errorDescription = NSLocalizedString(@"The app does not contain an Info.plist file.", nil);
        break;
        case 173:
        errorDescription = NSLocalizedString(@"The bundled ldid is unavailable or not initialized. Enable Auto-initialize bundled ldid or choose Initialize bundled ldid in Settings, then try again.", nil);
        break;
        case 174:
        errorDescription = NSLocalizedString(@"The app's main executable does not exist.", nil);
        break;
        case 175: {
            //if (@available(iOS 16, *)) {
            //    errorDescription = @"Failed to sign the app.";
            //}
            //else {
                errorDescription = NSLocalizedString(@"Failed to sign the app. ldid returned a non zero status code.", nil);
            //}
        }
        break;
        case 176:
        errorDescription = NSLocalizedString(@"The app's Info.plist is missing required values.", nil);
        break;
        case 177:
        errorDescription = NSLocalizedString(@"Failed to mark app as TrollStore app.", nil);
        break;
        case 178:
        errorDescription = NSLocalizedString(@"Failed to copy app bundle.", nil);
        break;
        case 179:
        errorDescription = NSLocalizedString(@"The app you tried to install has the same identifier as a system app already installed on the device. The installation has been prevented to protect you from possible bootloops or other issues.", nil);
        break;
        case 180:
        errorDescription = NSLocalizedString(@"The app you tried to install has an encrypted main binary, which cannot have the CoreTrust bypass applied to it. Please ensure you install decrypted apps.", nil);
        break;
        case 181:
        errorDescription = NSLocalizedString(@"Failed to add app to icon cache.", nil);
        break;
        case 182:
        errorDescription = NSLocalizedString(@"The app was installed successfully, but requires developer mode to be enabled to run. After rebooting, select \"Turn On\" to enable developer mode.", nil);
        break;
        case 183:
        errorDescription = NSLocalizedString(@"Failed to enable developer mode.", nil);
        break;
        case 184:
        errorDescription = NSLocalizedString(@"The app was installed successfully, but has additional binaries that are encrypted (e.g. extensions, plugins). The app itself should work, but you may experience broken functionality as a result.", nil);
        break;
        case 185:
        errorDescription = NSLocalizedString(@"Failed to sign the app. The CoreTrust bypass returned a non zero status code.", nil);
        break;
        case 186:
        errorDescription = NSLocalizedString(@"The edited Entitlements plist is invalid or unavailable. Cancel the installation and retry the editor.", nil);
        break;
        case 187:
        errorDescription = NSLocalizedString(@"Stealth and normal installs cannot be mixed for the same app. Uninstall the existing copy first, then install again with the desired mode.", nil);
        break;
        case 188:
        errorDescription = NSLocalizedString(@"Failed to update the app's Info.plist while preparing installation.", nil);
        break;
        case 189:
        errorDescription = NSLocalizedString(@"The installd placeholder install failed. You can retry with the Custom installation method.", nil);
        break;
        case 190:
        errorDescription = NSLocalizedString(@"Real signing requires a valid imported P12 identity or a matching PEM certificate/private-key pair. Add one in Settings → Signing Method & Certificates.", nil);
        break;
        case 193:
        errorDescription = NSLocalizedString(@"The app was signed and installed, but no provisioning profile was attached. A valid CMS signature alone does not grant this app permission to install or launch on this device.", nil);
        break;
        case 195:
        errorDescription = NSLocalizedString(@"This TrollStore build requires iOS 16.0 or later. The bundled ldid is an iOS 16+ arm64 device binary and cannot run on earlier system versions.", nil);
        break;
        case 220:
        errorDescription = NSLocalizedString(@"Plugin injection could not start because the target or library path is missing.", nil);
        break;
        case 221:
        errorDescription = NSLocalizedString(@"Plugin injection target is outside the temporary app bundle or is not a valid app.", nil);
        break;
        case 222:
        errorDescription = NSLocalizedString(@"The staged app executable or Info.plist is invalid.", nil);
        break;
        case 224:
        errorDescription = NSLocalizedString(@"The selected plugin is missing or is not stored in TrollStore's local Plugins directory.", nil);
        break;
        case 225:
        errorDescription = NSLocalizedString(@"Only a dynamic library or framework can be injected. Import a DEB/ZIP and select one of its extracted libraries.", nil);
        break;
        case 226:
        errorDescription = NSLocalizedString(@"The selected framework does not contain a valid executable.", nil);
        break;
        case 227:
        errorDescription = NSLocalizedString(@"The bundled ldid is not initialized. Initialize it in Settings before injecting plugins.", nil);
        break;
        case 228:
        errorDescription = NSLocalizedString(@"ldid failed to inject the selected plugin. Check the installation debug log and the library's architecture.", nil);
        break;
        case 230:
        errorDescription = NSLocalizedString(@"Plugin injection is unavailable in this TrollStore Lite build.", nil);
        break;
        case 231:
        errorDescription = NSLocalizedString(@"Could not save the per-app Home Screen deletion protection marker. The app was not registered as protected.", nil);
        break;
    }

    NSError* error = [NSError errorWithDomain:TrollStoreErrorDomain code:code userInfo:@{NSLocalizedDescriptionKey : errorDescription}];
    return error;
}

- (int)installIpa:(NSString*)pathToIpa force:(BOOL)force log:(NSString * _Nullable * _Nullable)logOut
{
    NSUserDefaults *defaults = trollStoreUserDefaults();
    NSNumber *methodNumber = [defaults objectForKey:@"installationMethod"];
    int method = methodNumber ? methodNumber.intValue : 1;
    if (method != 0 && method != 1) method = 1;
    BOOL stealth = [defaults boolForKey:@"TSStealthInstallEnabled"];
    return [self installIpa:pathToIpa force:force installationMethod:method
        replaceMainEntitlements:NO customEntitlementsPath:nil stealthInstall:stealth
        protectFromHomeScreenDeletion:[defaults boolForKey:@"TSProtectHomeScreenDeletionEnabled"] pluginPaths:@[] log:logOut];
}

- (int)installIpa:(NSString*)pathToIpa
            force:(BOOL)force
 installationMethod:(int)method
replaceMainEntitlements:(BOOL)replaceMainEntitlements
              log:(NSString * _Nullable * _Nullable)logOut
{
    NSUserDefaults *defaults = trollStoreUserDefaults();
    return [self installIpa:pathToIpa
                      force:force
         installationMethod:method
replaceMainEntitlements:replaceMainEntitlements
     customEntitlementsPath:nil
             stealthInstall:[defaults boolForKey:@"TSStealthInstallEnabled"]
                       log:logOut];
}

- (int)installIpa:(NSString*)pathToIpa
            force:(BOOL)force
 installationMethod:(int)method
replaceMainEntitlements:(BOOL)replaceMainEntitlements
customEntitlementsPath:(NSString * _Nullable)entitlementsPath
      stealthInstall:(BOOL)stealthInstall
              log:(NSString * _Nullable * _Nullable)logOut
{
    return [self installIpa:pathToIpa force:force installationMethod:method replaceMainEntitlements:replaceMainEntitlements customEntitlementsPath:entitlementsPath stealthInstall:stealthInstall pluginPaths:@[] log:logOut];
}

- (int)installIpa:(NSString*)pathToIpa
            force:(BOOL)force
 installationMethod:(int)method
replaceMainEntitlements:(BOOL)replaceMainEntitlements
customEntitlementsPath:(NSString * _Nullable)entitlementsPath
      stealthInstall:(BOOL)stealthInstall
         pluginPaths:(NSArray<NSString *> *)pluginPaths
              log:(NSString * _Nullable * _Nullable)logOut
{
    return [self installIpa:pathToIpa force:force installationMethod:method replaceMainEntitlements:replaceMainEntitlements customEntitlementsPath:entitlementsPath stealthInstall:stealthInstall protectFromHomeScreenDeletion:NO pluginPaths:pluginPaths log:logOut];
}

- (int)installIpa:(NSString*)pathToIpa
            force:(BOOL)force
 installationMethod:(int)method
replaceMainEntitlements:(BOOL)replaceMainEntitlements
customEntitlementsPath:(NSString * _Nullable)entitlementsPath
      stealthInstall:(BOOL)stealthInstall
protectFromHomeScreenDeletion:(BOOL)protectFromHomeScreenDeletion
         pluginPaths:(NSArray<NSString *> *)pluginPaths
              log:(NSString * _Nullable * _Nullable)logOut
{
    NSMutableArray *args = [NSMutableArray new];
    [args addObject:@"install"];
    if (force) [args addObject:@"force"];

    // Never re-read installationMethod during a retry. The controller owns the
    // attempt snapshot and explicitly passes 0 (installd) or 1 (custom).
    if (method == 0) [args addObject:@"installd"];
    else [args addObject:@"custom"];

    // The temporary edited document is intentionally not consumed here. A retry
    // must reuse the exact same plist until the install session finishes.
    if (replaceMainEntitlements) {
        if (!entitlementsPath.length || ![[NSFileManager defaultManager] isReadableFileAtPath:entitlementsPath]) {
            if (logOut) *logOut = @"An edited Entitlements document was requested, but its temporary plist is missing or unreadable.";
            return 186;
        }
        [args addObject:@"--entitlements"];
        [args addObject:entitlementsPath]; // Exact complete plist; RootHelper validates it again.
    }
    if (stealthInstall) [args addObject:@"stealth"];
    if (protectFromHomeScreenDeletion) [args addObject:@"protect-home-screen-deletion"];

    // RootHelper accepts only libraries staged in the app's private Plugins store.
    // The helper independently revalidates every path after resolving symlinks.
    NSMutableSet<NSString *> *uniquePluginPaths = [NSMutableSet set];
    for (NSString *pluginPath in pluginPaths ?: @[]) {
        if (![TSPluginStore isInjectableLibraryPath:pluginPath]) {
            if (logOut) *logOut = [NSString stringWithFormat:@"Refusing plugin path outside the local plugin store or with an unsupported type: %@", pluginPath ?: @"(null)"];
            return 224;
        }
        NSString *resolved = pluginPath.stringByResolvingSymlinksInPath.stringByStandardizingPath;
        if (![uniquePluginPaths containsObject:resolved]) {
            [uniquePluginPaths addObject:resolved];
            [args addObject:@"--inject-dylib"];
            [args addObject:resolved];
        }
    }

    NSError *signingConfigurationError = nil;
    NSString *signingConfigurationPath = [TSSigningManager prepareRootHelperSigningConfiguration:&signingConfigurationError];
    if (!signingConfigurationPath) {
        if (logOut) *logOut = signingConfigurationError.localizedDescription ?: NSLocalizedString(@"Unable to prepare signing configuration.", nil);
        return (int)(signingConfigurationError.code ?: 190);
    }
    [args addObject:@"--signing-config"];
    [args addObject:signingConfigurationPath];
    [args addObject:pathToIpa];

    int ret = spawnRoot(rootHelperPath(), args, nil, logOut);
    [TSSigningManager cleanupRootHelperSigningConfiguration:signingConfigurationPath];
    // One-shot Entitlements cleanup is owned by TSInstallationController so
    // every retry retains the original state and arguments.
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ApplicationsChanged" object:nil];
    return ret;
}

- (int)installIpa:(NSString*)pathToIpa
{
    return [self installIpa:pathToIpa force:NO log:nil];
}

- (int)uninstallApp:(NSString * _Nullable)appId
{
    if(!appId) return -200;

    NSMutableArray* args = [NSMutableArray new];
    [args addObject:@"uninstall"];

    NSNumber* uninstallationMethodToUseNum = [trollStoreUserDefaults() objectForKey:@"uninstallationMethod"];
    int uninstallationMethodToUse = uninstallationMethodToUseNum ? uninstallationMethodToUseNum.intValue : 0;
    if(uninstallationMethodToUse == 1)
    {
        [args addObject:@"custom"];
    }
    else
    {
        [args addObject:@"installd"];
    }

    [args addObject:appId];

    int ret = spawnRoot(rootHelperPath(), args, nil, nil);
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ApplicationsChanged" object:nil];
    return ret;
}

- (int)uninstallAppByPath:(NSString * _Nullable)path
{
    if(!path) return -200;

    NSMutableArray* args = [NSMutableArray new];
    [args addObject:@"uninstall-path"];

    NSNumber* uninstallationMethodToUseNum = [trollStoreUserDefaults() objectForKey:@"uninstallationMethod"];
    int uninstallationMethodToUse = uninstallationMethodToUseNum ? uninstallationMethodToUseNum.intValue : 0;
    if(uninstallationMethodToUse == 1)
    {
        [args addObject:@"custom"];
    }
    else
    {
        [args addObject:@"installd"];
    }

    [args addObject:path];

    int ret = spawnRoot(rootHelperPath(), args, nil, nil);
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ApplicationsChanged" object:nil];
    return ret;
}

- (BOOL)openApplicationWithBundleID:(NSString *)appId
{
    return [[LSApplicationWorkspace defaultWorkspace] openApplicationWithBundleID:appId];
}

- (int)enableJITForBundleID:(NSString *)appId
{
    return spawnRoot(rootHelperPath(), @[@"enable-jit", appId], nil, nil);
}

- (int)changeAppRegistration:(NSString * _Nullable)appPath toState:(NSString * _Nullable)newState
{
    if(!appPath || !newState) return -200;
    int ret = spawnRoot(rootHelperPath(), @[@"modify-registration", appPath, newState], nil, nil);
    if(ret == 0) [[NSNotificationCenter defaultCenter] postNotificationName:@"ApplicationsChanged" object:nil];
    return ret;
}

@end