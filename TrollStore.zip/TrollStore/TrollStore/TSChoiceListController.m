#import "TSChoiceListController.h"
#import "TSThemeManager.h"

@interface TSChoiceListController ()
@property(nonatomic, copy) NSArray<NSString *> *options;
@property(nonatomic, assign) NSInteger selectedIndex;
@property(nonatomic, copy) void (^selectionHandler)(NSInteger selectedIndex);
@end

@implementation TSChoiceListController

- (instancetype)initWithTitle:(NSString *)title
                      options:(NSArray<NSString *> *)options
                selectedIndex:(NSInteger)selectedIndex
            selectionHandler:(void (^)(NSInteger))selectionHandler {
    if ((self = [super initWithStyle:UITableViewStylePlain])) {
        self.title = title;
        self.options = [options copy] ?: @[];
        self.selectedIndex = options.count ? MAX(0, MIN((NSInteger)options.count - 1, selectedIndex)) : NSNotFound;
        self.selectionHandler = [selectionHandler copy];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeAlways;
    self.tableView.backgroundColor = UIColor.systemBackgroundColor;
    self.tableView.separatorColor = [UIColor.separatorColor colorWithAlphaComponent:0.45];
    self.tableView.rowHeight = 60.0;
    self.tableView.tableFooterView = [UIView new];
    self.tableView.tintColor = [TSThemeManager accentColor];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.options.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString * const reuseIdentifier = @"TSChoiceCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseIdentifier];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier];
    cell.backgroundColor = UIColor.clearColor;
    cell.contentView.backgroundColor = UIColor.clearColor;
    cell.textLabel.text = self.options[indexPath.row];
    cell.textLabel.textColor = UIColor.labelColor;
    cell.textLabel.font = [UIFont systemFontOfSize:17.0 weight:UIFontWeightRegular];
    cell.accessoryType = indexPath.row == self.selectedIndex ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
    cell.tintColor = [TSThemeManager accentColor];
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.row >= self.options.count) return;
    self.selectedIndex = indexPath.row;
    [tableView reloadData];
    if (self.selectionHandler) self.selectionHandler(indexPath.row);
    [self.navigationController popViewControllerAnimated:YES];
}

@end
