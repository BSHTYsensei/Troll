#import <UIKit/UIKit.h>
@interface TSPluginStoreController : UITableViewController
@end
