#import <UIKit/UIKit.h>

@interface TSThemeManager : NSObject
+ (void)applyToViewController:(UIViewController *)viewController;
+ (void)applyAppearance;
+ (UIColor *)accentColor;
+ (CGFloat)floatingBarHeight;
+ (CGFloat)floatingBarSpacing;
+ (CGFloat)floatingBarHorizontalMargin;
+ (CGFloat)floatingBarBottomOffset;
+ (BOOL)floatingBarHidden;
+ (BOOL)floatingBarEnabled;
@end
