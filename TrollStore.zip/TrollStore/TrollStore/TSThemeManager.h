#import <UIKit/UIKit.h>

@interface TSThemeManager : NSObject
+ (void)applyToViewController:(UIViewController *)viewController;
+ (void)applyAppearance;
+ (void)prepareWindowForLaunch:(UIWindow *)window;
+ (void)applyNavigationAppearanceToController:(UINavigationController *)navigationController;
+ (UIColor *)accentColor;
+ (CGFloat)floatingBarHeight;
+ (CGFloat)floatingBarSpacing;
+ (CGFloat)floatingBarHorizontalMargin;
+ (CGFloat)floatingBarBottomOffset;
+ (BOOL)floatingBarHidden;
+ (BOOL)floatingBarEnabled;
@end
