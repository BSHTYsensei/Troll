#import "TSAppearanceController.h"
#import "TSThemeManager.h"
#import "TSChoiceListController.h"
#import <TSUtil.h>
#import <TSPresentationDelegate.h>
@import UniformTypeIdentifiers;

static NSString *TSAppearanceSymbolForTitle(NSString *title) {
    NSString *value = title.lowercaseString ?: @"";
    if ([value containsString:@"theme"] || [value containsString:@"accent"] || [value containsString:@"主题"] || [value containsString:@"颜色"]) return @"paintbrush.pointed.fill";
    if ([value containsString:@"bar"] || [value containsString:@"底栏"]) return @"rectangle.bottomthird.inset.filled";
    if ([value containsString:@"layout"] || [value containsString:@"布局"]) return @"square.grid.2x2.fill";
    if ([value containsString:@"animation"] || [value containsString:@"动画"]) return @"viewfinder";
    if ([value containsString:@"icon"] || [value containsString:@"图标"]) return @"app.badge";
    if ([value containsString:@"background"] || [value containsString:@"背景"]) return @"photo.fill";
    if ([value containsString:@"blur"] || [value containsString:@"模糊"]) return @"drop.halffull";
    if ([value containsString:@"opacity"] || [value containsString:@"透明"]) return @"circle.lefthalf.filled";
    if ([value containsString:@"spacing"] || [value containsString:@"间距"]) return @"arrow.left.and.right";
    if ([value containsString:@"height"] || [value containsString:@"高度"]) return @"arrow.up.and.down";
    return @"slider.horizontal.3";
}

@interface TSAppearanceController ()
@property(nonatomic,strong) UIScrollView *scrollView;
@property(nonatomic,strong) UIStackView *stack;
@property(nonatomic,strong) UISlider *opacitySlider;
@property(nonatomic,strong) UISlider *blurSlider;
@property(nonatomic,strong) UISwitch *hideDockSwitch;
@property(nonatomic,strong) UISlider *heightSlider;
@property(nonatomic,strong) UISlider *spacingSlider;
@property(nonatomic,strong) UISlider *marginSlider;
@property(nonatomic,strong) UISlider *bottomSlider;
@end
@implementation TSAppearanceController
- (void)viewDidLoad {
    [super viewDidLoad]; self.title=NSLocalizedString(@"Appearance & Floating Bar",nil); self.view.backgroundColor=UIColor.systemBackgroundColor;
    _scrollView=[UIScrollView new]; _scrollView.translatesAutoresizingMaskIntoConstraints=NO; [self.view addSubview:_scrollView];
    _stack=[[UIStackView alloc] initWithFrame:CGRectZero]; _stack.axis=UILayoutConstraintAxisVertical; _stack.spacing=10; _stack.translatesAutoresizingMaskIntoConstraints=NO; [_scrollView addSubview:_stack];
    [NSLayoutConstraint activateConstraints:@[[_scrollView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],[_scrollView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],[_scrollView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],[_scrollView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],[_stack.topAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.topAnchor constant:16],[_stack.bottomAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.bottomAnchor constant:-24],[_stack.leadingAnchor constraintEqualToAnchor:_scrollView.frameLayoutGuide.leadingAnchor constant:16],[_stack.trailingAnchor constraintEqualToAnchor:_scrollView.frameLayoutGuide.trailingAnchor constant:-16]]];
    [self addSection:NSLocalizedString(@"Theme",nil)];
    [self addButtonRow:NSLocalizedString(@"Change Theme Color",nil) action:@selector(chooseAccentColor)];
    [self addButtonRow:NSLocalizedString(@"Choose Background Image",nil) action:@selector(chooseBackground)]; [self addButtonRow:NSLocalizedString(@"Remove Background Image",nil) action:@selector(removeBackground)];
    _opacitySlider=[self sliderMin:0 max:0.6 value:[trollStoreUserDefaults() objectForKey:@"TSThemeBackgroundOpacity"]?[trollStoreUserDefaults() doubleForKey:@"TSThemeBackgroundOpacity"]:0.22 action:@selector(opacityChanged)]; [self addControlRow:NSLocalizedString(@"Background Opacity",nil) control:_opacitySlider];
    _blurSlider=[self sliderMin:0 max:30 value:[trollStoreUserDefaults() doubleForKey:@"TSThemeBackgroundBlur"] action:@selector(blurChanged)]; [self addControlRow:NSLocalizedString(@"Background Blur",nil) control:_blurSlider];
    [self addSection:NSLocalizedString(@"Personalization",nil)];
    [self addButtonRow:NSLocalizedString(@"App List Layout",nil) action:@selector(chooseAppListLayout)];
    [self addButtonRow:NSLocalizedString(@"App Bottom Bar Style",nil) action:@selector(chooseBottomBarStyle)];
    [self addButtonRow:NSLocalizedString(@"Change Theme Color",nil) action:@selector(chooseAccentColor)];
    [self addButtonRow:NSLocalizedString(@"Change App Icon",nil) action:@selector(chooseAppIcon)];
    [self addButtonRow:NSLocalizedString(@"Animation Effect",nil) action:@selector(chooseAnimationEffect)];
    [self addSection:NSLocalizedString(@"Background",nil)];
    [self addButtonRow:NSLocalizedString(@"Choose Background Image",nil) action:@selector(chooseBackground)]; [self addButtonRow:NSLocalizedString(@"Remove Background Image",nil) action:@selector(removeBackground)];
    _opacitySlider=[self sliderMin:0 max:0.6 value:[trollStoreUserDefaults() objectForKey:@"TSThemeBackgroundOpacity"]?[trollStoreUserDefaults() doubleForKey:@"TSThemeBackgroundOpacity"]:0.22 action:@selector(opacityChanged)]; [self addControlRow:NSLocalizedString(@"Background Opacity",nil) control:_opacitySlider];
    _blurSlider=[self sliderMin:0 max:30 value:[trollStoreUserDefaults() doubleForKey:@"TSThemeBackgroundBlur"] action:@selector(blurChanged)]; [self addControlRow:NSLocalizedString(@"Background Blur",nil) control:_blurSlider];
    [self addSection:NSLocalizedString(@"Floating Bar Fine Tuning",nil)];
    _hideDockSwitch=[UISwitch new]; _hideDockSwitch.on=[trollStoreUserDefaults() boolForKey:@"TSHideFloatingTabBar"]; [_hideDockSwitch addTarget:self action:@selector(hideDockChanged) forControlEvents:UIControlEventValueChanged]; [self addControlRow:NSLocalizedString(@"Hide Tab Bar",nil) control:_hideDockSwitch];
    _heightSlider=[self sliderMin:48 max:82 value:[TSThemeManager floatingBarHeight] action:@selector(dockValuesChanged)]; [self addControlRow:NSLocalizedString(@"Bar Height",nil) control:_heightSlider];
    _spacingSlider=[self sliderMin:0 max:24 value:[TSThemeManager floatingBarSpacing] action:@selector(dockValuesChanged)]; [self addControlRow:NSLocalizedString(@"Button Spacing",nil) control:_spacingSlider];
    _marginSlider=[self sliderMin:12 max:64 value:[TSThemeManager floatingBarHorizontalMargin] action:@selector(dockValuesChanged)]; [self addControlRow:NSLocalizedString(@"Horizontal Margins",nil) control:_marginSlider];
    _bottomSlider=[self sliderMin:0 max:28 value:[TSThemeManager floatingBarBottomOffset] action:@selector(dockValuesChanged)]; [self addControlRow:NSLocalizedString(@"Bottom Offset",nil) control:_bottomSlider];
    [TSThemeManager applyToViewController:self];
}
- (void)addSection:(NSString *)title { UILabel *label=[UILabel new]; label.text=title; label.font=[UIFont systemFontOfSize:14 weight:UIFontWeightSemibold]; label.textColor=UIColor.secondaryLabelColor; [_stack addArrangedSubview:label]; }
- (UIView *)row:(NSString *)title control:(UIView *)control {
    UIView *box=[UIView new]; box.backgroundColor=UIColor.secondarySystemBackgroundColor; box.layer.cornerRadius=19; box.layer.cornerCurve=kCACornerCurveContinuous;
    UIImageSymbolConfiguration *symbolConfiguration=[UIImageSymbolConfiguration configurationWithPointSize:18 weight:UIImageSymbolWeightSemibold];
    UIImageView *icon=[[UIImageView alloc] initWithImage:[UIImage systemImageNamed:TSAppearanceSymbolForTitle(title) withConfiguration:symbolConfiguration]];
    icon.tintColor=([control isKindOfClass:UISwitch.class] || [control isKindOfClass:UISlider.class] || [control isKindOfClass:UISegmentedControl.class]) ? UIColor.secondaryLabelColor : [TSThemeManager accentColor];
    icon.translatesAutoresizingMaskIntoConstraints=NO;
    UILabel *label=[UILabel new]; label.text=title; label.font=[UIFont systemFontOfSize:15.5 weight:UIFontWeightMedium]; label.textColor=([control isKindOfClass:UISwitch.class] || [control isKindOfClass:UISlider.class] || [control isKindOfClass:UISegmentedControl.class]) ? UIColor.labelColor : [TSThemeManager accentColor]; label.translatesAutoresizingMaskIntoConstraints=NO;
    control.translatesAutoresizingMaskIntoConstraints=NO;
    [box addSubview:icon]; [box addSubview:label]; [box addSubview:control];
    [NSLayoutConstraint activateConstraints:@[[icon.leadingAnchor constraintEqualToAnchor:box.leadingAnchor constant:16],[icon.centerYAnchor constraintEqualToAnchor:box.centerYAnchor],[icon.widthAnchor constraintEqualToConstant:22],[label.leadingAnchor constraintEqualToAnchor:icon.trailingAnchor constant:16],[label.centerYAnchor constraintEqualToAnchor:box.centerYAnchor],[control.trailingAnchor constraintEqualToAnchor:box.trailingAnchor constant:-14],[control.centerYAnchor constraintEqualToAnchor:box.centerYAnchor],[control.leadingAnchor constraintGreaterThanOrEqualToAnchor:label.trailingAnchor constant:10]]];
    if([control isKindOfClass:UISlider.class]) { [box.heightAnchor constraintEqualToConstant:68].active=YES; [control.widthAnchor constraintEqualToConstant:142].active=YES; }
    else { [box.heightAnchor constraintEqualToConstant:54].active=YES; if([control isKindOfClass:UISegmentedControl.class]) [control.widthAnchor constraintLessThanOrEqualToConstant:190].active=YES; }
    return box;
}
- (void)addControlRow:(NSString *)title control:(UIView *)control { [_stack addArrangedSubview:[self row:title control:control]]; }
- (void)addButtonRow:(NSString *)title action:(SEL)action {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    UIButtonConfiguration *configuration = [UIButtonConfiguration plainButtonConfiguration];
    configuration.title = title;
    UIImageSymbolConfiguration *symbolConfiguration = [UIImageSymbolConfiguration configurationWithPointSize:18.0 weight:UIImageSymbolWeightSemibold];
    configuration.image = [UIImage systemImageNamed:TSAppearanceSymbolForTitle(title) withConfiguration:symbolConfiguration];
    configuration.imagePadding = 14.0;
    configuration.baseForegroundColor = [TSThemeManager accentColor];
    configuration.contentInsets = NSDirectionalEdgeInsetsMake(0, 14, 0, 14);
    configuration.titleTextAttributesTransformer = ^NSDictionary *(NSDictionary *attributes) {
        NSMutableDictionary *updated = [attributes mutableCopy];
        updated[NSFontAttributeName] = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
        return updated;
    };
    UIBackgroundConfiguration *background = [UIBackgroundConfiguration clearConfiguration];
    background.backgroundColor = UIColor.secondarySystemBackgroundColor;
    background.cornerRadius = 19;
    configuration.background = background;
    button.configuration = configuration;
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [button.heightAnchor constraintEqualToConstant:54].active = YES;
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [_stack addArrangedSubview:button];
}
- (UISlider *)sliderMin:(float)min max:(float)max value:(float)value action:(SEL)action { UISlider *s=[UISlider new]; s.minimumValue=min;s.maximumValue=max;s.value=value;[s addTarget:self action:action forControlEvents:UIControlEventValueChanged];return s; }
- (void)pushChoiceScreenWithTitle:(NSString *)title options:(NSArray<NSString *> *)options selectedIndex:(NSInteger)selectedIndex handler:(void (^)(NSInteger))handler {
    TSChoiceListController *controller = [[TSChoiceListController alloc] initWithTitle:title options:options selectedIndex:selectedIndex selectionHandler:handler];
    [self.navigationController pushViewController:controller animated:YES];
}
- (void)chooseAppListLayout {
    NSInteger selected = [trollStoreUserDefaults() integerForKey:@"TSAppListLayout"] == 1 ? 1 : 0;
    [self pushChoiceScreenWithTitle:NSLocalizedString(@"App List Layout", nil)
                            options:@[NSLocalizedString(@"List", nil), NSLocalizedString(@"Grid", nil)]
                      selectedIndex:selected
                             handler:^(NSInteger index) {
        [trollStoreUserDefaults() setInteger:index forKey:@"TSAppListLayout"];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"TSAppListLayoutChanged" object:nil];
    }];
}
- (void)chooseBottomBarStyle {
    NSInteger selected = [TSThemeManager floatingBarStyle];
    [self pushChoiceScreenWithTitle:NSLocalizedString(@"Choose Bottom Bar Style", nil)
                            options:@[NSLocalizedString(@"Floating", nil), NSLocalizedString(@"Standard", nil), NSLocalizedString(@"Floating 2", nil)]
                      selectedIndex:selected
                             handler:^(NSInteger index) {
        [trollStoreUserDefaults() setInteger:index forKey:@"TSFloatingBarStyle"];
        [trollStoreUserDefaults() setBool:(index != 1) forKey:@"TSFloatingTabBarEnabled"];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"TSAppearanceChanged" object:nil];
    }];
}
- (void)chooseAnimationEffect {
    NSInteger selected = [trollStoreUserDefaults() integerForKey:@"TSNavigationTransitionStyle"] == 1 ? 1 : 0;
    [self pushChoiceScreenWithTitle:NSLocalizedString(@"Choose Animation Effect", nil)
                            options:@[NSLocalizedString(@"Fade In/Out (Default)", nil), NSLocalizedString(@"Standard", nil)]
                      selectedIndex:selected
                             handler:^(NSInteger index) {
        [trollStoreUserDefaults() setInteger:index forKey:@"TSNavigationTransitionStyle"];
    }];
}
- (void)chooseAppIcon {
    NSDictionary *info = NSBundle.mainBundle.infoDictionary;
    NSDictionary *icons = info[@"CFBundleIcons"] ?: info[@"CFBundleIcons~ipad"];
    NSDictionary *alternateIcons = icons[@"CFBundleAlternateIcons"];
    if (!UIApplication.sharedApplication.supportsAlternateIcons || alternateIcons.count == 0) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Change App Icon", nil) message:NSLocalizedString(@"This build does not include alternate app icons.", nil) preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    UIAlertController *menu = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Change App Icon", nil) message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    NSMutableArray<NSString *> *names = [NSMutableArray arrayWithObject:NSLocalizedString(@"Default", nil)];
    [names addObjectsFromArray:[[alternateIcons allKeys] sortedArrayUsingSelector:@selector(localizedStandardCompare:)]];
    for (NSUInteger index = 0; index < names.count; index++) {
        NSString *iconName = index == 0 ? nil : names[index];
        NSString *title = names[index];
        [menu addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            [UIApplication.sharedApplication setAlternateIconName:iconName completionHandler:^(NSError *error) {
                if (error) NSLog(@"[Appearance] Could not change app icon: %@", error.localizedDescription);
            }];
        }]];
    }
    [menu addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    menu.popoverPresentationController.barButtonItem = self.navigationItem.rightBarButtonItem;
    [self presentViewController:menu animated:YES completion:nil];
}
- (void)chooseAccentColor {
    UIColorPickerViewController *picker = [UIColorPickerViewController new];
    picker.delegate = self;
    picker.supportsAlpha = YES;
    picker.selectedColor = [TSThemeManager accentColor];
    picker.title = NSLocalizedString(@"Change Theme Color", nil);
    [self presentViewController:picker animated:YES completion:nil];
}
- (void)colorPickerViewControllerDidSelectColor:(UIColorPickerViewController *)viewController {
    UIColor *color = [viewController.selectedColor resolvedColorWithTraitCollection:self.traitCollection];
    CGFloat red = 0, green = 0, blue = 0, alpha = 1;
    if (![color getRed:&red green:&green blue:&blue alpha:&alpha]) {
        CGColorRef cgColor = color.CGColor;
        size_t componentCount = CGColorGetNumberOfComponents(cgColor);
        const CGFloat *components = CGColorGetComponents(cgColor);
        if (!components || (componentCount != 2 && componentCount < 4)) return;
        if (componentCount == 2) red = green = blue = components[0], alpha = components[1];
        else red = components[0], green = components[1], blue = components[2], alpha = components[3];
    }
    NSDictionary *components = @{@"red":@(red), @"green":@(green), @"blue":@(blue), @"alpha":@(alpha)};
    [trollStoreUserDefaults() setObject:components forKey:@"TSThemeAccentCustomColor"];
    [trollStoreUserDefaults() removeObjectForKey:@"TSThemeAccent"];
    [TSThemeManager applyAppearance];
}
- (void)opacityChanged { [trollStoreUserDefaults() setDouble:_opacitySlider.value forKey:@"TSThemeBackgroundOpacity"]; [TSThemeManager applyAppearance]; }
- (void)blurChanged { [trollStoreUserDefaults() setDouble:_blurSlider.value forKey:@"TSThemeBackgroundBlur"]; [TSThemeManager applyAppearance]; }
- (void)hideDockChanged { [trollStoreUserDefaults() setBool:_hideDockSwitch.on forKey:@"TSHideFloatingTabBar"]; [TSThemeManager applyAppearance]; }
- (void)dockValuesChanged { [trollStoreUserDefaults() setDouble:_heightSlider.value forKey:@"TSFloatingBarHeight"]; [trollStoreUserDefaults() setDouble:_spacingSlider.value forKey:@"TSFloatingBarSpacing"]; [trollStoreUserDefaults() setDouble:_marginSlider.value forKey:@"TSFloatingBarMargin"]; [trollStoreUserDefaults() setDouble:_bottomSlider.value forKey:@"TSFloatingBarBottomOffset"]; [TSThemeManager applyAppearance]; }
- (void)chooseBackground {
    UTType *imageType = [UTType typeWithIdentifier:@"public.image"];
    if (!imageType) imageType = [UTType typeWithIdentifier:@"public.data"];
    if (!imageType) return;
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:@[imageType] asCopy:YES];
    picker.delegate = self;
    [TSPresentationDelegate presentViewController:picker animated:YES completion:nil];
}
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls { NSURL *url=urls.firstObject; if(!url)return; BOOL scoped=[url startAccessingSecurityScopedResource]; NSString *support=[NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory,NSUserDomainMask,YES) firstObject]; [[NSFileManager defaultManager] createDirectoryAtPath:support withIntermediateDirectories:YES attributes:nil error:nil]; NSString *dest=[support stringByAppendingPathComponent:@"TSThemeBackground.png"]; NSError *error=nil; UIImage *image=[UIImage imageWithContentsOfFile:url.path]; NSData *data=UIImagePNGRepresentation(image); BOOL success=data && [data writeToFile:dest options:NSDataWritingAtomic error:&error]; if(scoped)[url stopAccessingSecurityScopedResource]; if(success){[trollStoreUserDefaults() setObject:dest forKey:@"TSThemeBackgroundPath"];[TSThemeManager applyAppearance];} else {UIAlertController *alert=[UIAlertController alertControllerWithTitle:NSLocalizedString(@"Background Image Failed",nil) message:error.localizedDescription?:NSLocalizedString(@"The selected file is not a supported image.",nil) preferredStyle:UIAlertControllerStyleAlert];[alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK",nil) style:UIAlertActionStyleCancel handler:nil]];[TSPresentationDelegate presentViewController:alert animated:YES completion:nil];} }
- (void)removeBackground { NSString *path=[trollStoreUserDefaults() stringForKey:@"TSThemeBackgroundPath"]; if(path.length)[[NSFileManager defaultManager] removeItemAtPath:path error:nil]; [trollStoreUserDefaults() removeObjectForKey:@"TSThemeBackgroundPath"]; [TSThemeManager applyAppearance]; }
@end
