#import "TSAppearanceController.h"
#import "TSThemeManager.h"
#import <TSUtil.h>
#import <TSPresentationDelegate.h>
@import UniformTypeIdentifiers;

@interface TSAppearanceController ()
@property(nonatomic,strong) UIScrollView *scrollView;
@property(nonatomic,strong) UIStackView *stack;
@property(nonatomic,strong) UISegmentedControl *modeControl;
@property(nonatomic,strong) UISegmentedControl *accentControl;
@property(nonatomic,strong) UISlider *opacitySlider;
@property(nonatomic,strong) UISlider *blurSlider;
@property(nonatomic,strong) UISwitch *dockSwitch;
@property(nonatomic,strong) UISwitch *hideDockSwitch;
@property(nonatomic,strong) UISlider *heightSlider;
@property(nonatomic,strong) UISlider *spacingSlider;
@property(nonatomic,strong) UISlider *marginSlider;
@property(nonatomic,strong) UISlider *bottomSlider;
@end
@implementation TSAppearanceController
- (void)viewDidLoad {
    [super viewDidLoad]; self.title=NSLocalizedString(@"Appearance & Floating Bar",nil); self.view.backgroundColor=UIColor.systemGroupedBackgroundColor;
    _scrollView=[UIScrollView new]; _scrollView.translatesAutoresizingMaskIntoConstraints=NO; [self.view addSubview:_scrollView];
    _stack=[[UIStackView alloc] initWithFrame:CGRectZero]; _stack.axis=UILayoutConstraintAxisVertical; _stack.spacing=16; _stack.translatesAutoresizingMaskIntoConstraints=NO; [_scrollView addSubview:_stack];
    [NSLayoutConstraint activateConstraints:@[[_scrollView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],[_scrollView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],[_scrollView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],[_scrollView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],[_stack.topAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.topAnchor constant:16],[_stack.bottomAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.bottomAnchor constant:-24],[_stack.leadingAnchor constraintEqualToAnchor:_scrollView.frameLayoutGuide.leadingAnchor constant:16],[_stack.trailingAnchor constraintEqualToAnchor:_scrollView.frameLayoutGuide.trailingAnchor constant:-16]]];
    [self addSection:NSLocalizedString(@"Theme",nil)];
    _modeControl=[[UISegmentedControl alloc] initWithItems:@[NSLocalizedString(@"System",nil),NSLocalizedString(@"Light",nil),NSLocalizedString(@"Dark",nil)]]; _modeControl.selectedSegmentIndex=[trollStoreUserDefaults() integerForKey:@"TSThemeMode"]; if(_modeControl.selectedSegmentIndex<0 || _modeControl.selectedSegmentIndex>2) _modeControl.selectedSegmentIndex=0; [_modeControl addTarget:self action:@selector(modeChanged) forControlEvents:UIControlEventValueChanged]; [self addControlRow:NSLocalizedString(@"Appearance",nil) control:_modeControl];
    _accentControl=[[UISegmentedControl alloc] initWithItems:@[@"Blue",@"Purple",@"Teal",@"Orange",@"Pink"]]; NSArray *accents=@[@"Blue",@"Purple",@"Teal",@"Orange",@"Pink"]; NSInteger accent=[accents indexOfObject:([trollStoreUserDefaults() stringForKey:@"TSThemeAccent"] ?: @"Blue")]; _accentControl.selectedSegmentIndex=accent==NSNotFound?0:accent; [_accentControl addTarget:self action:@selector(accentChanged) forControlEvents:UIControlEventValueChanged]; [self addControlRow:NSLocalizedString(@"Accent Color",nil) control:_accentControl];
    [self addButtonRow:NSLocalizedString(@"Choose Background Image",nil) action:@selector(chooseBackground)]; [self addButtonRow:NSLocalizedString(@"Remove Background Image",nil) action:@selector(removeBackground)];
    _opacitySlider=[self sliderMin:0 max:0.6 value:[trollStoreUserDefaults() objectForKey:@"TSThemeBackgroundOpacity"]?[trollStoreUserDefaults() doubleForKey:@"TSThemeBackgroundOpacity"]:0.22 action:@selector(opacityChanged)]; [self addControlRow:NSLocalizedString(@"Background Opacity",nil) control:_opacitySlider];
    _blurSlider=[self sliderMin:0 max:30 value:[trollStoreUserDefaults() doubleForKey:@"TSThemeBackgroundBlur"] action:@selector(blurChanged)]; [self addControlRow:NSLocalizedString(@"Background Blur",nil) control:_blurSlider];
    [self addSection:NSLocalizedString(@"Floating Bottom Bar",nil)];
    _dockSwitch=[UISwitch new]; id enabled=[trollStoreUserDefaults() objectForKey:@"TSFloatingTabBarEnabled"]; _dockSwitch.on=enabled? [enabled boolValue]:YES; [_dockSwitch addTarget:self action:@selector(dockChanged) forControlEvents:UIControlEventValueChanged]; [self addControlRow:NSLocalizedString(@"Enable Floating Bar",nil) control:_dockSwitch];
    _hideDockSwitch=[UISwitch new]; _hideDockSwitch.on=[trollStoreUserDefaults() boolForKey:@"TSHideFloatingTabBar"]; [_hideDockSwitch addTarget:self action:@selector(hideDockChanged) forControlEvents:UIControlEventValueChanged]; [self addControlRow:NSLocalizedString(@"Hide Tab Bar",nil) control:_hideDockSwitch];
    _heightSlider=[self sliderMin:48 max:82 value:[TSThemeManager floatingBarHeight] action:@selector(dockValuesChanged)]; [self addControlRow:NSLocalizedString(@"Bar Height",nil) control:_heightSlider];
    _spacingSlider=[self sliderMin:4 max:30 value:[TSThemeManager floatingBarSpacing] action:@selector(dockValuesChanged)]; [self addControlRow:NSLocalizedString(@"Button Spacing",nil) control:_spacingSlider];
    _marginSlider=[self sliderMin:6 max:40 value:[TSThemeManager floatingBarHorizontalMargin] action:@selector(dockValuesChanged)]; [self addControlRow:NSLocalizedString(@"Horizontal Margins",nil) control:_marginSlider];
    _bottomSlider=[self sliderMin:0 max:28 value:[TSThemeManager floatingBarBottomOffset] action:@selector(dockValuesChanged)]; [self addControlRow:NSLocalizedString(@"Bottom Offset",nil) control:_bottomSlider];
    [TSThemeManager applyToViewController:self];
}
- (void)addSection:(NSString *)title { UILabel *label=[UILabel new]; label.text=title; label.font=[UIFont systemFontOfSize:20 weight:UIFontWeightBold]; label.textColor=UIColor.labelColor; [_stack addArrangedSubview:label]; UIView *line=[UIView new]; line.backgroundColor=UIColor.separatorColor; [line.heightAnchor constraintEqualToConstant:1].active=YES; [_stack addArrangedSubview:line]; }
- (UIView *)row:(NSString *)title control:(UIView *)control { UIView *box=[UIView new]; box.backgroundColor=[UIColor.secondarySystemGroupedBackgroundColor colorWithAlphaComponent:0.96]; box.layer.cornerRadius=13; UILabel *label=[UILabel new]; label.text=title; label.font=[UIFont systemFontOfSize:15 weight:UIFontWeightMedium]; label.translatesAutoresizingMaskIntoConstraints=NO; control.translatesAutoresizingMaskIntoConstraints=NO; [box addSubview:label]; [box addSubview:control]; [NSLayoutConstraint activateConstraints:@[[label.leadingAnchor constraintEqualToAnchor:box.leadingAnchor constant:14],[label.centerYAnchor constraintEqualToAnchor:box.centerYAnchor],[control.trailingAnchor constraintEqualToAnchor:box.trailingAnchor constant:-14],[control.centerYAnchor constraintEqualToAnchor:box.centerYAnchor],[control.leadingAnchor constraintGreaterThanOrEqualToAnchor:label.trailingAnchor constant:12]]]; if([control isKindOfClass:UISlider.class]) { [box.heightAnchor constraintEqualToConstant:70].active=YES; [control.widthAnchor constraintEqualToConstant:150].active=YES; } else { [box.heightAnchor constraintEqualToConstant:62].active=YES; [control.widthAnchor constraintLessThanOrEqualToConstant:260].active=YES; } return box; }
- (void)addControlRow:(NSString *)title control:(UIView *)control { [_stack addArrangedSubview:[self row:title control:control]]; }
- (void)addButtonRow:(NSString *)title action:(SEL)action {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    UIButtonConfiguration *configuration = [UIButtonConfiguration plainButtonConfiguration];
    configuration.title = title;
    configuration.contentInsets = NSDirectionalEdgeInsetsMake(0, 14, 0, 14);
    configuration.titleTextAttributesTransformer = ^NSDictionary *(NSDictionary *attributes) {
        NSMutableDictionary *updated = [attributes mutableCopy];
        updated[NSFontAttributeName] = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
        return updated;
    };
    UIBackgroundConfiguration *background = [UIBackgroundConfiguration clearConfiguration];
    background.backgroundColor = UIColor.secondarySystemGroupedBackgroundColor;
    background.cornerRadius = 13;
    configuration.background = background;
    button.configuration = configuration;
    button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [button.heightAnchor constraintEqualToConstant:54].active = YES;
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    [_stack addArrangedSubview:button];
}
- (UISlider *)sliderMin:(float)min max:(float)max value:(float)value action:(SEL)action { UISlider *s=[UISlider new]; s.minimumValue=min;s.maximumValue=max;s.value=value;[s addTarget:self action:action forControlEvents:UIControlEventValueChanged];return s; }
- (void)modeChanged { [trollStoreUserDefaults() setInteger:_modeControl.selectedSegmentIndex forKey:@"TSThemeMode"]; [TSThemeManager applyAppearance]; }
- (void)accentChanged { NSArray *names=@[@"Blue",@"Purple",@"Teal",@"Orange",@"Pink"]; [trollStoreUserDefaults() setObject:names[MAX(0,_accentControl.selectedSegmentIndex)] forKey:@"TSThemeAccent"]; [TSThemeManager applyAppearance]; }
- (void)opacityChanged { [trollStoreUserDefaults() setDouble:_opacitySlider.value forKey:@"TSThemeBackgroundOpacity"]; [TSThemeManager applyAppearance]; }
- (void)blurChanged { [trollStoreUserDefaults() setDouble:_blurSlider.value forKey:@"TSThemeBackgroundBlur"]; [TSThemeManager applyAppearance]; }
- (void)dockChanged { [trollStoreUserDefaults() setBool:_dockSwitch.on forKey:@"TSFloatingTabBarEnabled"]; [TSThemeManager applyAppearance]; }
- (void)hideDockChanged { [trollStoreUserDefaults() setBool:_hideDockSwitch.on forKey:@"TSHideFloatingTabBar"]; [TSThemeManager applyAppearance]; }
- (void)dockValuesChanged { [trollStoreUserDefaults() setDouble:_heightSlider.value forKey:@"TSFloatingBarHeight"]; [trollStoreUserDefaults() setDouble:_spacingSlider.value forKey:@"TSFloatingBarSpacing"]; [trollStoreUserDefaults() setDouble:_marginSlider.value forKey:@"TSFloatingBarMargin"]; [trollStoreUserDefaults() setDouble:_bottomSlider.value forKey:@"TSFloatingBarBottomOffset"]; [TSThemeManager applyAppearance]; }
- (void)chooseBackground {
    UTType *imageType = [UTType typeWithIdentifier:@"public.image"];
    if (!imageType) imageType = [UTType typeWithIdentifier:@"public.data"];
    if (!imageType) return;
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:@[imageType] asCopy:YES];
    picker.delegate = self;
    [TSPresentationDelegate presentViewController:picker animated:YES completion:nil];
}
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls { NSURL *url=urls.firstObject; if(!url)return; BOOL scoped=[url startAccessingSecurityScopedResource]; NSString *support=[NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory,NSUserDomainMask,YES) firstObject]; [[NSFileManager defaultManager] createDirectoryAtPath:support withIntermediateDirectories:YES attributes:nil error:nil]; NSString *dest=[support stringByAppendingPathComponent:@"TSThemeBackground.png"]; NSError *error=nil; UIImage *image=[UIImage imageWithContentsOfFile:url.path]; NSData *data=UIImagePNGRepresentation(image); BOOL success=data && [data writeToFile:dest options:NSDataWritingAtomic error:&error]; if(scoped)[url stopAccessingSecurityScopedResource]; if(success){[trollStoreUserDefaults() setObject:dest forKey:@"TSThemeBackgroundPath"];[TSThemeManager applyAppearance];} else {UIAlertController *alert=[UIAlertController alertControllerWithTitle:NSLocalizedString(@"Background Image Failed",nil) message:error.localizedDescription?:NSLocalizedString(@"The selected file is not a supported image.",nil) preferredStyle:UIAlertControllerStyleAlert];[alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK",nil) style:UIAlertActionStyleCancel handler:nil]];[TSPresentationDelegate presentViewController:alert animated:YES completion:nil];} }
- (void)removeBackground { NSString *path=[trollStoreUserDefaults() stringForKey:@"TSThemeBackgroundPath"]; if(path.length)[[NSFileManager defaultManager] removeItemAtPath:path error:nil]; [trollStoreUserDefaults() removeObjectForKey:@"TSThemeBackgroundPath"]; [TSThemeManager applyAppearance]; }
@end
