#import "TSAppRepackager.h"
#import "TSArchiveExtractor.h"
#import "TSIPAPackageStore.h"
#import "TSAppInfo.h"
#import <TSPresentationDelegate.h>

static NSString *TSRepackErrorDomain = @"com.opa334.TrollStore.Repackager";
static NSError *TSRepackError(NSInteger code, NSString *message) { return [NSError errorWithDomain:TSRepackErrorDomain code:code userInfo:@{NSLocalizedDescriptionKey:message ?: NSLocalizedString(@"Could not repackage the application.", nil)}]; }

@interface TSRepackageEditorController : UIViewController
@property(nonatomic, copy) NSString *sourceIPA;
@property(nonatomic, copy) void (^completion)(NSString * _Nullable, NSError * _Nullable);
@property(nonatomic, strong) UITextField *bundleIDField;
@property(nonatomic, strong) UITextField *displayNameField;
@property(nonatomic, strong) UITextField *versionField;
@property(nonatomic, strong) UISwitch *removeURLSwitch;
@property(nonatomic, strong) UISwitch *removeWidgetsSwitch;
@property(nonatomic, strong) UISwitch *removeWatchSwitch;
@end

@implementation TSAppRepackager
+ (void)presentFromViewController:(UIViewController *)viewController sourceIPA:(NSString *)sourceIPA completion:(void (^)(NSString *, NSError *))completion {
    if (!sourceIPA.length || ![[NSFileManager defaultManager] fileExistsAtPath:sourceIPA]) {
        NSError *error = TSRepackError(1, NSLocalizedString(@"The source IPA is unavailable.", nil));
        if (completion) completion(nil, error); return;
    }
    TSRepackageEditorController *editor = [TSRepackageEditorController new];
    editor.sourceIPA = sourceIPA; editor.completion = completion;
    UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:editor];
    navigation.modalPresentationStyle = UIModalPresentationFormSheet;
    [viewController presentViewController:navigation animated:YES completion:nil];
}

+ (BOOL)repackageIPAAtPath:(NSString *)sourceIPA bundleIdentifier:(NSString *)bundleIdentifier displayName:(NSString *)displayName version:(NSString *)version removeURLSchemes:(BOOL)removeURLSchemes removeWidgets:(BOOL)removeWidgets removeWatch:(BOOL)removeWatch outputPath:(NSString **)outputPath error:(NSError **)error {
    NSRegularExpression *bundlePattern = [NSRegularExpression regularExpressionWithPattern:@"^[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)+$" options:0 error:nil];
    NSTextCheckingResult *bundleMatch = [bundlePattern firstMatchInString:bundleIdentifier ?: @"" options:0 range:NSMakeRange(0, (bundleIdentifier ?: @"").length)];
    if (!bundleIdentifier.length || !bundleMatch || bundleMatch.range.length != bundleIdentifier.length) {
        if (error) *error = TSRepackError(2, NSLocalizedString(@"Bundle ID must contain dots and only letters, digits, dots or hyphens.", nil)); return NO;
    }
    BOOL sourceExists = [[NSFileManager defaultManager] fileExistsAtPath:sourceIPA];
    if (!sourceExists || ![@[@"ipa", @"tipa"] containsObject:sourceIPA.pathExtension.lowercaseString]) {
        if (error) *error = TSRepackError(3, NSLocalizedString(@"Select a valid IPA or TIPA package.", nil)); return NO;
    }
    NSString *staging = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"TS-repack-%@", NSUUID.UUID.UUIDString]];
    NSError *extractError = nil;
    if (![TSArchiveExtractor extractArchiveAtPath:sourceIPA toDirectory:staging error:&extractError]) { if (error) *error = extractError; return NO; }
    NSFileManager *fm = NSFileManager.defaultManager;
    NSString *payload = [staging stringByAppendingPathComponent:@"Payload"];
    NSArray<NSString *> *payloadItems = [fm contentsOfDirectoryAtPath:payload error:nil] ?: @[];
    NSString *appName = nil;
    for (NSString *item in payloadItems) if ([item.pathExtension.lowercaseString isEqualToString:@"app"] && [fm fileExistsAtPath:[payload stringByAppendingPathComponent:item]]) { appName = item; break; }
    if (!appName) { [fm removeItemAtPath:staging error:nil]; if (error) *error = TSRepackError(4, NSLocalizedString(@"The package does not contain Payload/*.app.", nil)); return NO; }
    NSString *appPath = [payload stringByAppendingPathComponent:appName];
    NSString *mainInfoPath = [appPath stringByAppendingPathComponent:@"Info.plist"];
    NSDictionary *originalMain = [NSDictionary dictionaryWithContentsOfFile:mainInfoPath];
    NSString *oldBundleID = [originalMain[@"CFBundleIdentifier"] isKindOfClass:NSString.class] ? originalMain[@"CFBundleIdentifier"] : @"";
    if (!oldBundleID.length) { [fm removeItemAtPath:staging error:nil]; if (error) *error = TSRepackError(5, NSLocalizedString(@"The main Info.plist does not contain a bundle identifier.", nil)); return NO; }

    NSMutableSet<NSString *> *removePaths = [NSMutableSet set];
    if (removeWatch) {
        // Some vendors package Watch targets as sibling apps directly under Payload,
        // not under App.app/Watch. Detect these from WatchKit metadata and companion ID.
        for (NSString *item in payloadItems) {
            if (![item.pathExtension.lowercaseString isEqualToString:@"app"] || [item isEqualToString:appName]) continue;
            NSString *siblingPath = [payload stringByAppendingPathComponent:item];
            NSDictionary *watchInfo = [NSDictionary dictionaryWithContentsOfFile:[siblingPath stringByAppendingPathComponent:@"Info.plist"]];
            NSString *companionID = [watchInfo[@"WKCompanionAppBundleIdentifier"] isKindOfClass:NSString.class] ? watchInfo[@"WKCompanionAppBundleIdentifier"] : @"";
            NSString *extensionPoint = @"";
            NSDictionary *extension = [watchInfo[@"NSExtension"] isKindOfClass:NSDictionary.class] ? watchInfo[@"NSExtension"] : @{};
            if ([extension[@"NSExtensionPointIdentifier"] isKindOfClass:NSString.class]) extensionPoint = extension[@"NSExtensionPointIdentifier"];
            BOOL isWatchTarget = [watchInfo[@"WKWatchKitApp"] respondsToSelector:@selector(boolValue)] && [watchInfo[@"WKWatchKitApp"] boolValue];
            isWatchTarget = isWatchTarget || (companionID.length && [companionID isEqualToString:oldBundleID]);
            isWatchTarget = isWatchTarget || [extensionPoint.lowercaseString containsString:@"watchkit"] || [item.lowercaseString isEqualToString:@"watch.app"];
            if (isWatchTarget) [removePaths addObject:siblingPath];
        }
    }
    NSDirectoryEnumerator *enumerator = [fm enumeratorAtPath:appPath];
    NSString *relative = nil;
    NSMutableDictionary<NSString *, NSDictionary *> *plistCache = [NSMutableDictionary dictionary];
    while ((relative = [enumerator nextObject])) {
        NSString *fullPath = [appPath stringByAppendingPathComponent:relative];
        BOOL isDir = NO; [fm fileExistsAtPath:fullPath isDirectory:&isDir];
        NSString *last = relative.lastPathComponent;
        NSArray *components = relative.pathComponents;
        if (removeWatch && ([last isEqualToString:@"WatchKitSupport2"] || [last isEqualToString:@"Watch"] || ([components containsObject:@"Watch"] && [last.pathExtension.lowercaseString isEqualToString:@"app"]))) {
            NSString *target = fullPath;
            if ([last isEqualToString:@"WatchKitSupport2"]) target = fullPath;
            else if ([last isEqualToString:@"Watch"]) target = fullPath;
            else {
                NSUInteger watchIndex = [components indexOfObject:@"Watch"];
                if (watchIndex != NSNotFound) {
                    NSArray *prefix = [components subarrayWithRange:NSMakeRange(0, watchIndex + 1)];
                    target = [appPath stringByAppendingPathComponent:[NSString pathWithComponents:prefix]];
                }
            }
            [removePaths addObject:target];
            if (isDir) [enumerator skipDescendants];
            continue;
        }
        if (isDir && [last.pathExtension.lowercaseString isEqualToString:@"appex"] && removeWidgets) {
            NSDictionary *extensionInfo = [NSDictionary dictionaryWithContentsOfFile:[fullPath stringByAppendingPathComponent:@"Info.plist"]];
            NSDictionary *extension = [extensionInfo[@"NSExtension"] isKindOfClass:NSDictionary.class] ? extensionInfo[@"NSExtension"] : @{};
            NSString *point = [extension[@"NSExtensionPointIdentifier"] isKindOfClass:NSString.class] ? extension[@"NSExtensionPointIdentifier"] : @"";
            NSString *principal = [extensionInfo[@"WKAppBundleIdentifier"] isKindOfClass:NSString.class] ? extensionInfo[@"WKAppBundleIdentifier"] : @"";
            BOOL isWidget = [point.lowercaseString containsString:@"widget"] || [last.lowercaseString containsString:@"widget"] || [principal.lowercaseString containsString:@"watchkit"];
            if (isWidget) { [removePaths addObject:fullPath]; [enumerator skipDescendants]; continue; }
        }
        if (!isDir && [last isEqualToString:@"Info.plist"]) {
            NSDictionary *dict = [NSDictionary dictionaryWithContentsOfFile:fullPath];
            if (dict) plistCache[fullPath] = dict;
        }
    }
    // Remove nested paths only once: a parent removal makes child removals redundant.
    NSArray<NSString *> *candidates = [[removePaths allObjects] sortedArrayUsingComparator:^NSComparisonResult(NSString *a, NSString *b) { return a.pathComponents.count < b.pathComponents.count ? NSOrderedAscending : NSOrderedDescending; }];
    NSMutableArray<NSString *> *minimalRemovePaths = [NSMutableArray array];
    for (NSString *candidate in candidates) {
        BOOL covered = NO;
        for (NSString *parent in minimalRemovePaths) if ([candidate hasPrefix:[parent stringByAppendingString:@"/"]] || [candidate isEqualToString:parent]) { covered = YES; break; }
        if (!covered) [minimalRemovePaths addObject:candidate];
    }
    for (NSString *path in minimalRemovePaths) {
        NSString *standard = path.stringByStandardizingPath;
        NSString *payloadRoot = payload.stringByStandardizingPath;
        // Permit only paths strictly inside Payload. This covers both embedded files
        // inside the main app and standalone Watch .app siblings, never the Payload root.
        if (![standard hasPrefix:[payloadRoot stringByAppendingString:@"/"]] || [standard isEqualToString:appPath.stringByStandardizingPath]) continue;
        [fm removeItemAtPath:standard error:nil];
    }
    if (removeWatch) {
        for (NSString *supportName in @[@"WatchKitSupport", @"WatchKitSupport2"]) {
            NSString *support = [payload stringByAppendingPathComponent:supportName];
            if ([fm fileExistsAtPath:support]) [fm removeItemAtPath:support error:nil];
        }
    }

    // Update identifiers consistently for the main app and nested app/extension bundles.
    NSEnumerator *plistEnumerator = [fm enumeratorAtPath:appPath];
    while ((relative = [plistEnumerator nextObject])) {
        if (![relative.lastPathComponent isEqualToString:@"Info.plist"]) continue;
        NSString *path = [appPath stringByAppendingPathComponent:relative];
        NSMutableDictionary *dict = [[NSDictionary dictionaryWithContentsOfFile:path] mutableCopy];
        if (!dict) continue;
        NSString *existingID = [dict[@"CFBundleIdentifier"] isKindOfClass:NSString.class] ? dict[@"CFBundleIdentifier"] : @"";
        if (existingID.length && [existingID isEqualToString:oldBundleID]) dict[@"CFBundleIdentifier"] = bundleIdentifier;
        else if (existingID.length && [existingID hasPrefix:[oldBundleID stringByAppendingString:@"."]]) dict[@"CFBundleIdentifier"] = [bundleIdentifier stringByAppendingString:[existingID substringFromIndex:oldBundleID.length]];
        if ([path isEqualToString:mainInfoPath]) {
            dict[@"CFBundleIdentifier"] = bundleIdentifier;
            if (displayName.length) { dict[@"CFBundleDisplayName"] = displayName; dict[@"CFBundleName"] = displayName; }
            if (version.length) { dict[@"CFBundleShortVersionString"] = version; dict[@"CFBundleVersion"] = version; }
        }
        if (removeURLSchemes) [dict removeObjectForKey:@"CFBundleURLTypes"];
        if (removeWatch) {
            [dict removeObjectForKey:@"WKWatchKitApp"];
            [dict removeObjectForKey:@"WKCompanionAppBundleIdentifier"];
            [dict removeObjectForKey:@"WKAppBundleIdentifier"];
            [dict removeObjectForKey:@"WKWatchKitVersion"];
        }
        NSError *writeError = nil;
        NSData *serialized = [NSPropertyListSerialization dataWithPropertyList:dict format:NSPropertyListXMLFormat_v1_0 options:0 error:&writeError];
        if (!serialized || ![serialized writeToFile:path options:NSDataWritingAtomic error:&writeError]) {
            [fm removeItemAtPath:staging error:nil]; if (error) *error = writeError ?: TSRepackError(6, NSLocalizedString(@"Could not update an Info.plist file.", nil)); return NO;
        }
    }
    // A changed Bundle ID must not retain the source provisioning profile or stale signature resources.
    NSDirectoryEnumerator *profileEnumerator = [fm enumeratorAtPath:appPath];
    NSMutableArray<NSString *> *profiles = [NSMutableArray array];
    NSString *profileRel = nil;
    while ((profileRel = [profileEnumerator nextObject])) if ([profileRel.lastPathComponent isEqualToString:@"embedded.mobileprovision"]) [profiles addObject:[appPath stringByAppendingPathComponent:profileRel]];
    for (NSString *profile in profiles) [fm removeItemAtPath:profile error:nil];
    // Keep the original resource envelope out of the way; TrollStore will regenerate code signatures while installing.
    for (NSString *bundleSuffix in @[@"_CodeSignature", @"CodeResources"]) {
        NSDirectoryEnumerator *sigEnumerator = [fm enumeratorAtPath:appPath];
        NSMutableArray *signatures = [NSMutableArray array];
        NSString *sigRel = nil;
        while ((sigRel = [sigEnumerator nextObject])) {
            if ([sigRel.lastPathComponent isEqualToString:bundleSuffix] || ([bundleSuffix isEqualToString:@"CodeResources"] && [sigRel.lastPathComponent isEqualToString:@"CodeResources"])) [signatures addObject:[appPath stringByAppendingPathComponent:sigRel]];
        }
        for (NSString *sig in signatures) [fm removeItemAtPath:sig error:nil];
    }

    NSString *display = displayName.length ? displayName : originalMain[@"CFBundleDisplayName"] ?: appName.stringByDeletingPathExtension;
    NSString *safe = [[display componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"/\\:\n\r"]] componentsJoinedByString:@"_"];
    NSString *output = [[TSIPAPackageStore packageDirectoryPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@-%@.ipa", safe, [NSUUID.UUID.UUIDString substringToIndex:8]]];
    [[NSFileManager defaultManager] createDirectoryAtPath:TSIPAPackageStore.packageDirectoryPath withIntermediateDirectories:YES attributes:nil error:nil];
    NSError *zipError = nil;
    BOOL zipped = [TSArchiveExtractor createZipFromDirectory:staging outputPath:output error:&zipError];
    [fm removeItemAtPath:staging error:nil];
    if (!zipped) { if (error) *error = zipError; return NO; }
    if (outputPath) *outputPath = output;
    return YES;
}
@end

@implementation TSRepackageEditorController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Modify Application", nil);
    self.view.backgroundColor = UIColor.systemBackgroundColor;
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelPressed)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Create IPA", nil) style:UIBarButtonItemStyleDone target:self action:@selector(repackagePressed)];
    UIScrollView *scroll = [UIScrollView new]; scroll.translatesAutoresizingMaskIntoConstraints = NO;
    UIStackView *stack = [[UIStackView alloc] init]; stack.axis = UILayoutConstraintAxisVertical; stack.spacing = 14; stack.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:scroll]; [scroll addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[[scroll.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor], [scroll.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor], [scroll.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor], [scroll.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor], [stack.topAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.topAnchor constant:18], [stack.bottomAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.bottomAnchor constant:-24], [stack.leadingAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.leadingAnchor constant:18], [stack.trailingAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.trailingAnchor constant:-18]]];
    TSAppInfo *info = [[TSAppInfo alloc] initWithIPAPath:self.sourceIPA]; [info sync_loadBasicInfo];
    self.bundleIDField = [self fieldWithPlaceholder:@"com.example.app" value:info.bundleIdentifier keyboard:UIKeyboardTypeURL];
    self.displayNameField = [self fieldWithPlaceholder:NSLocalizedString(@"Application Name", nil) value:info.displayName keyboard:UIKeyboardTypeDefault];
    self.versionField = [self fieldWithPlaceholder:@"1.0" value:info.versionString keyboard:UIKeyboardTypeDecimalPad];
    [stack addArrangedSubview:[self header:NSLocalizedString(@"Package Identity", nil)]];
    [stack addArrangedSubview:[self labeledField:NSLocalizedString(@"Bundle ID", nil) field:self.bundleIDField]];
    [stack addArrangedSubview:[self labeledField:NSLocalizedString(@"Application Name", nil) field:self.displayNameField]];
    [stack addArrangedSubview:[self labeledField:NSLocalizedString(@"Version", nil) field:self.versionField]];
    [stack addArrangedSubview:[self header:NSLocalizedString(@"Optional Cleanup", nil)]];
    self.removeURLSwitch = [UISwitch new]; self.removeURLSwitch.on = NO;
    self.removeWidgetsSwitch = [UISwitch new]; self.removeWidgetsSwitch.on = YES;
    self.removeWatchSwitch = [UISwitch new]; self.removeWatchSwitch.on = YES;
    [stack addArrangedSubview:[self switchRow:NSLocalizedString(@"Remove URL Schemes", nil) detail:NSLocalizedString(@"Deep links and app-to-app callbacks may stop working.", nil) control:self.removeURLSwitch]];
    [stack addArrangedSubview:[self switchRow:NSLocalizedString(@"Remove Widget Extensions", nil) detail:NSLocalizedString(@"Only extensions identified as widgets are removed.", nil) control:self.removeWidgetsSwitch]];
    [stack addArrangedSubview:[self switchRow:NSLocalizedString(@"Remove Watch App", nil) detail:NSLocalizedString(@"Removes embedded Watch targets and WatchKit support files.", nil) control:self.removeWatchSwitch]];
    UILabel *warning = [UILabel new]; warning.numberOfLines = 0; warning.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote]; warning.textColor = UIColor.secondaryLabelColor; warning.text = NSLocalizedString(@"The output is a new IPA. The source file is left unchanged. Repackaging cannot make incompatible apps compatible, and removing extensions or URL schemes can break features.", nil); [stack addArrangedSubview:warning];
}
- (UITextField *)fieldWithPlaceholder:(NSString *)placeholder value:(NSString *)value keyboard:(UIKeyboardType)keyboard {
    UITextField *field = [UITextField new]; field.borderStyle = UITextBorderStyleRoundedRect; field.placeholder = placeholder; field.text = value ?: @""; field.keyboardType = keyboard; field.autocorrectionType = UITextAutocorrectionTypeNo; field.autocapitalizationType = UITextAutocapitalizationTypeNone; field.clearButtonMode = UITextFieldViewModeWhileEditing; return field;
}
- (UIView *)header:(NSString *)title { UILabel *label = [UILabel new]; label.text = title; label.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline]; return label; }
- (UIView *)labeledField:(NSString *)title field:(UITextField *)field { UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[[self header:title], field]]; stack.axis = UILayoutConstraintAxisVertical; stack.spacing = 6; return stack; }
- (UIView *)switchRow:(NSString *)title detail:(NSString *)detail control:(UISwitch *)control {
    UIStackView *horizontal = [UIStackView new]; horizontal.axis = UILayoutConstraintAxisHorizontal; horizontal.alignment = UIStackViewAlignmentCenter; horizontal.spacing = 12;
    UIStackView *labels = [UIStackView new]; labels.axis = UILayoutConstraintAxisVertical; labels.spacing = 2;
    UILabel *name = [UILabel new]; name.text = title; name.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    UILabel *description = [UILabel new]; description.text = detail; description.numberOfLines = 0; description.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote]; description.textColor = UIColor.secondaryLabelColor;
    [labels addArrangedSubview:name]; [labels addArrangedSubview:description]; [horizontal addArrangedSubview:labels]; [horizontal addArrangedSubview:control]; return horizontal;
}
- (void)cancelPressed { [self dismissViewControllerAnimated:YES completion:^{ if (self.completion) self.completion(nil, nil); }]; }
- (void)repackagePressed {
    [self.view endEditing:YES];
    self.navigationItem.rightBarButtonItem.enabled = NO;
    [TSPresentationDelegate startActivity:NSLocalizedString(@"Repackaging Application", nil)];
    NSString *source = self.sourceIPA.copy, *bundleID = self.bundleIDField.text.copy ?: @"", *name = self.displayNameField.text.copy ?: @"", *version = self.versionField.text.copy ?: @"";
    BOOL removeURL = self.removeURLSwitch.isOn, removeWidgets = self.removeWidgetsSwitch.isOn, removeWatch = self.removeWatchSwitch.isOn;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSString *output = nil; NSError *error = nil;
        BOOL ok = [TSAppRepackager repackageIPAAtPath:source bundleIdentifier:bundleID displayName:name version:version removeURLSchemes:removeURL removeWidgets:removeWidgets removeWatch:removeWatch outputPath:&output error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            [TSPresentationDelegate stopActivityWithCompletion:^{
                self.navigationItem.rightBarButtonItem.enabled = YES;
                if (!ok) {
                    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Repackage Failed", nil) message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
                    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
                    [self presentViewController:alert animated:YES completion:nil]; return;
                }
                void (^callback)(void) = ^{ if (self.completion) self.completion(output, nil); };
                [self dismissViewControllerAnimated:YES completion:callback];
            }];
        });
    });
}
@end
