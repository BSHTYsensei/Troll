#import "TSArchiveExtractor.h"
#import <archive.h>
#import <archive_entry.h>
#import <sys/stat.h>
#import <fcntl.h>
#import <unistd.h>
#import <errno.h>
#import <limits.h>
#import <stdlib.h>
#import <string.h>
#import <stdio.h>
#import <stdint.h>

static NSError *TSArchiveError(NSInteger code, NSString *message) {
    return [NSError errorWithDomain:@"com.opa334.TrollStore.Archive" code:code userInfo:@{NSLocalizedDescriptionKey: message ?: NSLocalizedString(@"Archive operation failed.", nil)}];
}

// Create per-operation work storage beside the caller's app-owned destination.
// This deliberately avoids NSTemporaryDirectory()/shared /tmp paths and verifies
// the resolved parent and newly-created directory before any archive is written.
static NSString *TSCreatePrivateSiblingDirectory(NSString *destinationPath, NSError **errorOut) {
    NSString *parentPath = destinationPath.stringByDeletingLastPathComponent;
    char resolvedParent[PATH_MAX] = {0};
    if (!parentPath.length || !realpath(parentPath.fileSystemRepresentation, resolvedParent)) {
        if (errorOut) *errorOut = TSArchiveError(10, NSLocalizedString(@"The destination parent directory could not be resolved.", nil));
        return nil;
    }
    struct stat parentStat;
    if (lstat(resolvedParent, &parentStat) != 0 || !S_ISDIR(parentStat.st_mode) || S_ISLNK(parentStat.st_mode)) {
        if (errorOut) *errorOut = TSArchiveError(10, NSLocalizedString(@"The destination parent is not a real directory.", nil));
        return nil;
    }
    NSString *templatePath = [[NSString stringWithUTF8String:resolvedParent] stringByAppendingPathComponent:@".TrollStoreArchive.XXXXXX"];
    if (!templatePath.fileSystemRepresentation || strlen(templatePath.fileSystemRepresentation) >= PATH_MAX) {
        if (errorOut) *errorOut = TSArchiveError(10, NSLocalizedString(@"The archive work path is too long.", nil));
        return nil;
    }
    char buffer[PATH_MAX] = {0};
    strlcpy(buffer, templatePath.fileSystemRepresentation, sizeof(buffer));
    char *created = mkdtemp(buffer);
    if (!created) {
        if (errorOut) *errorOut = TSArchiveError(10, [NSString stringWithFormat:NSLocalizedString(@"Could not create private archive storage: %@", nil), [NSString stringWithUTF8String:strerror(errno)]]);
        return nil;
    }
    struct stat createdStat;
    if (chmod(created, 0700) != 0 || lstat(created, &createdStat) != 0 ||
        !S_ISDIR(createdStat.st_mode) || S_ISLNK(createdStat.st_mode) || createdStat.st_uid != geteuid()) {
        int savedErrno = errno;
        rmdir(created);
        if (errorOut) *errorOut = TSArchiveError(10, [NSString stringWithFormat:NSLocalizedString(@"Private archive storage failed its safety check: %@", nil), [NSString stringWithUTF8String:strerror(savedErrno)]]);
        return nil;
    }
    return [NSString stringWithUTF8String:created];
}

static NSString *TSSafeArchivePath(const char *raw) {
    if (!raw) return nil;
    NSString *path = [NSString stringWithUTF8String:raw];
    if (!path.length) return nil;
    path = [path stringByReplacingOccurrencesOfString:@"\\" withString:@"/"];
    // Reject absolute roots before trimming the directory terminator; otherwise
    // a malicious "/" entry would normalize to the harmless "./" root marker.
    if ([path hasPrefix:@"/"] || [path hasPrefix:@"~"] ||
        (path.length >= 2 && [[NSCharacterSet letterCharacterSet] characterIsMember:[path characterAtIndex:0]] && [path characterAtIndex:1] == ':')) return nil;
    while ([path hasPrefix:@"./"]) path = [path substringFromIndex:2];
    while ([path hasSuffix:@"/"]) path = [path substringToIndex:path.length - 1];
    // Tar archives commonly contain a harmless root-directory entry named ./.
    if (!path.length || [path isEqualToString:@"."]) return @".";
    NSArray<NSString *> *parts = [path componentsSeparatedByString:@"/"];
    for (NSString *part in parts) if (!part.length || [part isEqualToString:@".."] || [part isEqualToString:@"."]) return nil;
    return path;
}

static BOOL TSSafeArchiveSymlinkTarget(NSString *relativePath, const char *rawTarget) {
    if (!relativePath.length || !rawTarget) return NO;
    NSString *target = [NSString stringWithUTF8String:rawTarget];
    if (!target.length) return NO;
    target = [target stringByReplacingOccurrencesOfString:@"\\" withString:@"/"];
    if ([target hasPrefix:@"/"] || [target hasPrefix:@"~"] ||
        (target.length >= 2 && [[NSCharacterSet letterCharacterSet] characterIsMember:[target characterAtIndex:0]] && [target characterAtIndex:1] == ':')) return NO;
    NSMutableArray<NSString *> *components = [[relativePath.stringByDeletingLastPathComponent componentsSeparatedByString:@"/"] mutableCopy];
    if (components.count == 1 && !components.firstObject.length) [components removeAllObjects];
    for (NSString *component in [target componentsSeparatedByString:@"/"]) {
        if (!component.length || [component isEqualToString:@"."]) continue;
        if ([component isEqualToString:@".."]) {
            if (components.count == 0) return NO;
            [components removeLastObject];
        } else {
            [components addObject:component];
        }
    }
    return components.count != 0;
}

static BOOL TSExtractSingleArchive(NSString *archivePath, NSString *destinationPath, NSError **errorOut) {
    NSFileManager *fm = NSFileManager.defaultManager;
    if (![fm fileExistsAtPath:destinationPath] && ![fm createDirectoryAtPath:destinationPath withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0700} error:errorOut]) return NO;
    struct stat destinationLStat;
    if (lstat(destinationPath.fileSystemRepresentation, &destinationLStat) != 0 || !S_ISDIR(destinationLStat.st_mode) || S_ISLNK(destinationLStat.st_mode)) {
        if (errorOut) *errorOut = TSArchiveError(1, NSLocalizedString(@"The extraction destination must be a real directory, not a symbolic link.", nil));
        return NO;
    }
    char resolvedArchive[PATH_MAX] = {0};
    struct stat archiveStat;
    if (!realpath(archivePath.fileSystemRepresentation, resolvedArchive) || stat(resolvedArchive, &archiveStat) != 0 || !S_ISREG(archiveStat.st_mode) || archiveStat.st_size <= 0) {
        if (errorOut) *errorOut = TSArchiveError(2, NSLocalizedString(@"The selected archive is not a readable regular file.", nil));
        return NO;
    }
    char resolvedRoot[PATH_MAX] = {0};
    if (!realpath(destinationPath.fileSystemRepresentation, resolvedRoot)) {
        if (errorOut) *errorOut = TSArchiveError(1, [NSString stringWithFormat:NSLocalizedString(@"The extraction directory could not be resolved: %@", nil), [NSString stringWithUTF8String:strerror(errno)]]);
        return NO;
    }
    NSString *canonicalRoot = [NSString stringWithUTF8String:resolvedRoot];
    struct stat rootStat;
    if (!canonicalRoot.length || lstat(resolvedRoot, &rootStat) != 0 || !S_ISDIR(rootStat.st_mode) || S_ISLNK(rootStat.st_mode)) {
        if (errorOut) *errorOut = TSArchiveError(1, NSLocalizedString(@"The extraction destination is not a real directory.", nil));
        return NO;
    }
    struct archive *reader = archive_read_new();
    struct archive *disk = archive_write_disk_new();
    if (!reader || !disk) {
        if (reader) archive_read_free(reader);
        if (disk) archive_write_free(disk);
        if (errorOut) *errorOut = TSArchiveError(1, @"Could not initialize the archive reader.");
        return NO;
    }
    archive_read_support_filter_all(reader);
    // Register only the concrete container formats TrollStore accepts and let
    // libarchive identify them from their headers. IPA files are ZIP archives
    // despite their .ipa extension; DEB files are AR archives containing TAR.
    // Do not enable the RAW fallback, which can make arbitrary input look valid.
    archive_read_support_format_zip(reader);
    archive_read_support_format_tar(reader);
    archive_read_support_format_ar(reader);
    archive_write_disk_set_options(disk, ARCHIVE_EXTRACT_TIME | ARCHIVE_EXTRACT_SECURE_NODOTDOT | ARCHIVE_EXTRACT_SECURE_SYMLINKS);
    int result = archive_read_open_filename(reader, resolvedArchive, 256 * 1024);
    if (result != ARCHIVE_OK) {
        if (errorOut) *errorOut = TSArchiveError(2, [NSString stringWithFormat:@"%@", @(result)]);
        archive_read_free(reader); archive_write_free(disk); return NO;
    }

    BOOL success = YES;
    const uint64_t maximumExpandedBytes = 32ULL * 1024ULL * 1024ULL * 1024ULL;
    const NSUInteger maximumEntries = 500000;
    uint64_t totalExpandedBytes = 0;
    NSUInteger entryCount = 0;
    NSMutableSet<NSString *> *seenPaths = [NSMutableSet set];
    struct archive_entry *entry = NULL;
    while ((result = archive_read_next_header(reader, &entry)) == ARCHIVE_OK) {
        if (++entryCount > maximumEntries) {
            success = NO;
            if (errorOut) *errorOut = TSArchiveError(3, NSLocalizedString(@"The archive contains too many entries.", nil));
            break;
        }
        NSString *relative = TSSafeArchivePath(archive_entry_pathname(entry));
        if ([relative isEqualToString:@"."] && archive_entry_filetype(entry) == AE_IFDIR) {
            if (archive_read_data_skip(reader) < ARCHIVE_OK) {
                success = NO;
                if (errorOut) *errorOut = TSArchiveError(3, NSLocalizedString(@"Could not skip the archive root directory entry.", nil));
                break;
            }
            continue;
        }
        if (!relative || [relative isEqualToString:@"."]) {
            // Reject traversal/absolute paths instead of allowing a package to escape its destination.
            success = NO;
            if (errorOut) *errorOut = TSArchiveError(3, NSLocalizedString(@"The archive contains an unsafe absolute or parent-relative path.", nil));
            break;
        }
        NSString *pathKey = relative.precomposedStringWithCanonicalMapping.lowercaseString;
        if ([seenPaths containsObject:pathKey]) {
            success = NO;
            if (errorOut) *errorOut = TSArchiveError(3, NSLocalizedString(@"The archive contains duplicate file paths.", nil));
            break;
        }
        [seenPaths addObject:pathKey];
        const mode_t entryType = archive_entry_filetype(entry);
        if (entryType == AE_IFREG) {
            la_int64_t entrySize = archive_entry_size(entry);
            if (entrySize < 0 || (uint64_t)entrySize > maximumExpandedBytes || totalExpandedBytes > maximumExpandedBytes - (uint64_t)entrySize) {
                success = NO;
                if (errorOut) *errorOut = TSArchiveError(3, NSLocalizedString(@"The archive contains an invalid or excessively large file.", nil));
                break;
            }
        }
        if ((entryType != AE_IFDIR && entryType != AE_IFREG && entryType != AE_IFLNK) || archive_entry_hardlink(entry)) {
            success = NO;
            if (errorOut) *errorOut = TSArchiveError(3, NSLocalizedString(@"The archive contains an unsupported special file or hard link.", nil));
            break;
        }
        if (entryType == AE_IFLNK && !TSSafeArchiveSymlinkTarget(relative, archive_entry_symlink(entry))) {
            success = NO;
            if (errorOut) *errorOut = TSArchiveError(3, NSLocalizedString(@"The archive contains a symbolic link outside its extraction directory.", nil));
            break;
        }
        NSString *targetPath = [canonicalRoot stringByAppendingPathComponent:relative];
        targetPath = targetPath.stringByStandardizingPath;
        NSString *root = canonicalRoot;
        if (![targetPath isEqualToString:root] && ![targetPath hasPrefix:[root stringByAppendingString:@"/"]]) {
            success = NO;
            if (errorOut) *errorOut = TSArchiveError(3, NSLocalizedString(@"The archive path escapes the extraction directory.", nil));
            break;
        }
        archive_entry_set_pathname(entry, targetPath.fileSystemRepresentation);
        result = archive_write_header(disk, entry);
        if (result != ARCHIVE_OK) {
            success = NO;
            if (errorOut) *errorOut = TSArchiveError(4, [NSString stringWithUTF8String:archive_error_string(disk) ?: "Could not write archive entry."]);
            break;
        }
        const la_int64_t declaredEntrySize = entryType == AE_IFREG ? archive_entry_size(entry) : 0;
        const void *block = NULL;
        size_t blockSize = 0;
        la_int64_t offset = 0;
        while ((result = archive_read_data_block(reader, &block, &blockSize, &offset)) == ARCHIVE_OK) {
            if (offset < 0 || (uint64_t)offset > maximumExpandedBytes || blockSize > maximumExpandedBytes - (uint64_t)offset ||
                (entryType == AE_IFREG && ((uint64_t)offset + (uint64_t)blockSize > (uint64_t)declaredEntrySize)) ||
                blockSize > maximumExpandedBytes || totalExpandedBytes > maximumExpandedBytes - (uint64_t)blockSize) {
                success = NO;
                if (errorOut) *errorOut = TSArchiveError(5, NSLocalizedString(@"The archive expands beyond the supported size limit.", nil));
                break;
            }
            totalExpandedBytes += (uint64_t)blockSize;
            result = archive_write_data_block(disk, block, blockSize, offset);
            if (result != ARCHIVE_OK) {
                success = NO;
                if (errorOut) *errorOut = TSArchiveError(5, [NSString stringWithUTF8String:archive_error_string(disk) ?: "Could not write archive data."]);
                break;
            }
        }
        if (!success) break;
        if (result != ARCHIVE_EOF && result != ARCHIVE_OK) {
            success = NO;
            if (errorOut) *errorOut = TSArchiveError(6, [NSString stringWithUTF8String:archive_error_string(reader) ?: "Could not read archive data."]);
            break;
        }
        if (archive_write_finish_entry(disk) != ARCHIVE_OK) {
            success = NO;
            if (errorOut) *errorOut = TSArchiveError(7, [NSString stringWithUTF8String:archive_error_string(disk) ?: "Could not finish archive entry."]);
            break;
        }
    }
    if (result != ARCHIVE_EOF && result != ARCHIVE_OK && success) {
        success = NO;
        if (errorOut) *errorOut = TSArchiveError(8, [NSString stringWithUTF8String:archive_error_string(reader) ?: "Could not read archive headers."]);
    }
    archive_read_close(reader); archive_read_free(reader);
    if (archive_write_close(disk) != ARCHIVE_OK) {
        success = NO;
        if (errorOut && !*errorOut) *errorOut = TSArchiveError(9, [NSString stringWithUTF8String:archive_error_string(disk) ?: "Could not finalize archive extraction."]);
    }
    archive_write_free(disk);
    return success;
}

@implementation TSArchiveExtractor

+ (BOOL)archiveContainsInstallableIPAAtPath:(NSString *)archivePath {
    if (!archivePath.length || ![[NSFileManager defaultManager] fileExistsAtPath:archivePath] || ![archivePath.pathExtension.lowercaseString isEqualToString:@"zip"]) return NO;
    char resolvedArchive[PATH_MAX] = {0};
    struct stat inputStat;
    if (!realpath(archivePath.fileSystemRepresentation, resolvedArchive) || stat(resolvedArchive, &inputStat) != 0 || !S_ISREG(inputStat.st_mode) || inputStat.st_size <= 0) return NO;
    struct archive *reader = archive_read_new();
    if (!reader) return NO;
    archive_read_support_filter_all(reader);
    archive_read_support_format_zip(reader);
    int result = archive_read_open_filename(reader, resolvedArchive, 128 * 1024);
    BOOL safe = (result == ARCHIVE_OK);
    const uint64_t maximumExpandedBytes = 32ULL * 1024ULL * 1024ULL * 1024ULL;
    const NSUInteger maximumEntries = 500000;
    uint64_t totalDeclaredBytes = 0;
    NSUInteger entryCount = 0;
    NSMutableSet<NSString *> *seenPaths = [NSMutableSet set];
    NSMutableSet<NSString *> *regularPaths = [NSMutableSet set];
    NSString *expectedExecutablePath = nil;
    BOOL validAppInfo = NO;
    struct archive_entry *entry = NULL;
    while (safe && (result = archive_read_next_header(reader, &entry)) == ARCHIVE_OK) {
        if (++entryCount > maximumEntries) { safe = NO; break; }
        NSString *relative = TSSafeArchivePath(archive_entry_pathname(entry));
        mode_t entryType = archive_entry_filetype(entry);
        if ([relative isEqualToString:@"."] && entryType == AE_IFDIR) {
            if (archive_read_data_skip(reader) < ARCHIVE_OK) safe = NO;
            continue;
        }
        NSString *pathKey = relative.precomposedStringWithCanonicalMapping.lowercaseString;
        if (!relative || [relative isEqualToString:@"."] || [seenPaths containsObject:pathKey]) { safe = NO; break; }
        [seenPaths addObject:pathKey];
        if ((entryType != AE_IFDIR && entryType != AE_IFREG && entryType != AE_IFLNK) || archive_entry_hardlink(entry)) { safe = NO; break; }
        if (entryType == AE_IFLNK && !TSSafeArchiveSymlinkTarget(relative, archive_entry_symlink(entry))) { safe = NO; break; }
        if (entryType == AE_IFREG) {
            la_int64_t size = archive_entry_size(entry);
            if (size < 0 || (uint64_t)size > maximumExpandedBytes || totalDeclaredBytes > maximumExpandedBytes - (uint64_t)size) { safe = NO; break; }
            totalDeclaredBytes += (uint64_t)size;
            [regularPaths addObject:relative];
        }
        NSArray<NSString *> *parts = relative.pathComponents;
        BOOL appInfoPath = parts.count == 3 && [parts[0] isEqualToString:@"Payload"] && [parts[1].pathExtension.lowercaseString isEqualToString:@"app"] && [parts[2] isEqualToString:@"Info.plist"] && archive_entry_filetype(entry) == AE_IFREG;
        if (appInfoPath) {
            // Avoid spending unbounded memory on a malformed archive entry.
            la_int64_t entrySize = archive_entry_size(entry);
            if (entrySize < 1 || entrySize > 4 * 1024 * 1024) { safe = NO; break; }
            NSMutableData *plistData = [NSMutableData dataWithCapacity:(NSUInteger)entrySize];
            uint8_t buffer[16 * 1024];
            la_ssize_t count = 0;
            while ((count = archive_read_data(reader, buffer, sizeof(buffer))) > 0) {
                if (plistData.length + (NSUInteger)count > 4 * 1024 * 1024) { safe = NO; break; }
                [plistData appendBytes:buffer length:(NSUInteger)count];
            }
            if (!safe || count < 0 || plistData.length != (NSUInteger)entrySize) { safe = NO; break; }
            id value = [NSPropertyListSerialization propertyListWithData:plistData options:NSPropertyListImmutable format:nil error:nil];
            if (![value isKindOfClass:NSDictionary.class]) { safe = NO; break; }
            NSDictionary *appInfo = value;
            NSString *bundleID = [appInfo[@"CFBundleIdentifier"] isKindOfClass:NSString.class] ? appInfo[@"CFBundleIdentifier"] : nil;
            NSString *executable = [appInfo[@"CFBundleExecutable"] isKindOfClass:NSString.class] ? appInfo[@"CFBundleExecutable"] : nil;
            if (!bundleID.length || !executable.length || [executable containsString:@"/"] || [executable containsString:@"\\"] || [executable isEqualToString:@"."] || [executable isEqualToString:@".."]) { safe = NO; break; }
            expectedExecutablePath = [NSString stringWithFormat:@"%@/%@", [relative stringByDeletingLastPathComponent], executable];
            validAppInfo = YES;
        } else {
            int skipResult = archive_read_data_skip(reader);
            if (skipResult < ARCHIVE_OK) { safe = NO; break; }
        }
    }
    BOOL atEnd = (result == ARCHIVE_EOF);
    archive_read_close(reader);
    archive_read_free(reader);
    return safe && atEnd && validAppInfo && expectedExecutablePath.length && [regularPaths containsObject:expectedExecutablePath];
}

+ (BOOL)extractArchiveAtPath:(NSString *)archivePath toDirectory:(NSString *)destinationPath error:(NSError **)error {
    if (!archivePath.length || !destinationPath.length || ![[NSFileManager defaultManager] fileExistsAtPath:archivePath]) {
        if (error) *error = TSArchiveError(10, NSLocalizedString(@"The selected archive is unavailable.", nil));
        return NO;
    }

    NSFileManager *fm = NSFileManager.defaultManager;
    NSString *destinationName = destinationPath.lastPathComponent;
    if (!destinationName.length || [destinationName isEqualToString:@"."] || [destinationName isEqualToString:@".."] ||
        [destinationName containsString:@"/"] || [destinationName containsString:@"\\"]) {
        if (error) *error = TSArchiveError(10, NSLocalizedString(@"The extraction destination path is invalid.", nil));
        return NO;
    }

    NSError *stageError = nil;
    NSString *staging = TSCreatePrivateSiblingDirectory(destinationPath, &stageError);
    if (!staging) { if (error) *error = stageError; return NO; }
    NSString *canonicalParent = staging.stringByDeletingLastPathComponent;
    NSString *canonicalDestination = [canonicalParent stringByAppendingPathComponent:destinationName];

    // Do not replace an unexpected file or symbolic link at the destination.
    struct stat existingDestination;
    BOOL destinationExists = (lstat(canonicalDestination.fileSystemRepresentation, &existingDestination) == 0);
    if (destinationExists && (!S_ISDIR(existingDestination.st_mode) || S_ISLNK(existingDestination.st_mode))) {
        [fm removeItemAtPath:staging error:nil];
        if (error) *error = TSArchiveError(10, NSLocalizedString(@"The extraction destination exists but is not a real directory.", nil));
        return NO;
    }
    if (!destinationExists && errno != ENOENT) {
        int savedErrno = errno;
        [fm removeItemAtPath:staging error:nil];
        if (error) *error = TSArchiveError(10, [NSString stringWithFormat:NSLocalizedString(@"Could not inspect the extraction destination: %@", nil), [NSString stringWithUTF8String:strerror(savedErrno)]]);
        return NO;
    }

    NSError *extractError = nil;
    BOOL success = NO;
    if ([archivePath.pathExtension.lowercaseString isEqualToString:@"deb"]) {
        NSString *outer = [staging stringByAppendingPathComponent:@".deb-container"];
        if (![fm createDirectoryAtPath:outer withIntermediateDirectories:NO attributes:@{NSFilePosixPermissions:@0700} error:&extractError]) {
            success = NO;
        } else if (!TSExtractSingleArchive(archivePath, outer, &extractError)) {
            success = NO;
        } else {
            NSArray<NSString *> *outerItems = [fm contentsOfDirectoryAtPath:outer error:&extractError];
            NSMutableArray<NSString *> *dataArchives = [NSMutableArray array];
            for (NSString *item in outerItems ?: @[]) {
                if (![item.lastPathComponent.lowercaseString hasPrefix:@"data.tar"]) continue;
                NSString *candidate = [outer stringByAppendingPathComponent:item];
                struct stat candidateStat;
                if (lstat(candidate.fileSystemRepresentation, &candidateStat) == 0 && S_ISREG(candidateStat.st_mode) && !S_ISLNK(candidateStat.st_mode))
                    [dataArchives addObject:candidate];
            }
            if (dataArchives.count != 1) {
                extractError = TSArchiveError(11, NSLocalizedString(@"The DEB package must contain exactly one regular data.tar archive.", nil));
            } else {
                success = TSExtractSingleArchive(dataArchives.firstObject, staging, &extractError);
            }
        }
        [fm removeItemAtPath:outer error:nil];
    } else {
        // libarchive detects ZIP/IPA and TAR by their headers; the extension is
        // deliberately not used to select a container format.
        success = TSExtractSingleArchive(archivePath, staging, &extractError);
    }

    if (!success) {
        [fm removeItemAtPath:staging error:nil];
        if (error) *error = extractError ?: TSArchiveError(12, NSLocalizedString(@"The archive could not be extracted.", nil));
        return NO;
    }

    // Commit only after every entry has been extracted successfully. Keep an old
    // destination as a same-volume backup until the staging directory is in place.
    NSString *backupPath = nil;
    if (destinationExists) {
        backupPath = [canonicalParent stringByAppendingPathComponent:[NSString stringWithFormat:@".%@.TrollStoreBackup.%@", destinationName, NSUUID.UUID.UUIDString]];
        if (rename(canonicalDestination.fileSystemRepresentation, backupPath.fileSystemRepresentation) != 0) {
            int savedErrno = errno;
            [fm removeItemAtPath:staging error:nil];
            if (error) *error = TSArchiveError(13, [NSString stringWithFormat:NSLocalizedString(@"Could not preserve the previous extraction directory: %@", nil), [NSString stringWithUTF8String:strerror(savedErrno)]]);
            return NO;
        }
    }

    if (rename(staging.fileSystemRepresentation, canonicalDestination.fileSystemRepresentation) != 0) {
        int savedErrno = errno;
        if (backupPath && rename(backupPath.fileSystemRepresentation, canonicalDestination.fileSystemRepresentation) != 0)
            NSLog(@"[ArchiveExtractor] failed to restore previous destination %@ from %@: %s", canonicalDestination, backupPath, strerror(errno));
        [fm removeItemAtPath:staging error:nil];
        if (error) *error = TSArchiveError(14, [NSString stringWithFormat:NSLocalizedString(@"Could not commit the extracted archive: %@", nil), [NSString stringWithUTF8String:strerror(savedErrno)]]);
        return NO;
    }

    if (backupPath && ![fm removeItemAtPath:backupPath error:nil])
        NSLog(@"[ArchiveExtractor] extraction committed; previous directory backup remains at %@", backupPath);
    return YES;
}

+ (BOOL)createZipFromDirectory:(NSString *)sourceDirectory outputPath:(NSString *)outputPath error:(NSError **)error {
    NSFileManager *fm = NSFileManager.defaultManager;
    BOOL isDir = NO;
    if (![fm fileExistsAtPath:sourceDirectory isDirectory:&isDir] || !isDir) {
        if (error) *error = TSArchiveError(20, NSLocalizedString(@"The source directory does not exist.", nil));
        return NO;
    }
    if (!outputPath.length || [outputPath.lastPathComponent isEqualToString:@"."] || [outputPath.lastPathComponent isEqualToString:@".."] ||
        [outputPath.lastPathComponent containsString:@"/"] || [outputPath.lastPathComponent containsString:@"\\"]) {
        if (error) *error = TSArchiveError(20, NSLocalizedString(@"The output archive path is invalid.", nil));
        return NO;
    }
    struct stat originalSourceStat;
    if (lstat(sourceDirectory.fileSystemRepresentation, &originalSourceStat) != 0 || !S_ISDIR(originalSourceStat.st_mode) || S_ISLNK(originalSourceStat.st_mode)) {
        if (error) *error = TSArchiveError(20, NSLocalizedString(@"The source directory must not be a symbolic link.", nil));
        return NO;
    }
    NSString *outputParent = outputPath.stringByDeletingLastPathComponent;
    NSError *directoryError = nil;
    if (outputParent.length && ![fm createDirectoryAtPath:outputParent withIntermediateDirectories:YES attributes:nil error:&directoryError]) {
        if (error) *error = directoryError;
        return NO;
    }
    char resolvedParent[PATH_MAX] = {0};
    struct stat parentStat;
    if (!outputParent.length || !realpath(outputParent.fileSystemRepresentation, resolvedParent) ||
        lstat(outputParent.fileSystemRepresentation, &parentStat) != 0 || !S_ISDIR(parentStat.st_mode) ||
        S_ISLNK(parentStat.st_mode) || parentStat.st_uid != geteuid()) {
        if (error) *error = TSArchiveError(20, NSLocalizedString(@"The output directory is not a real directory owned by TrollStore.", nil));
        return NO;
    }
    NSString *canonicalParent = [NSString stringWithUTF8String:resolvedParent];
    NSString *canonicalOutputPath = [canonicalParent stringByAppendingPathComponent:outputPath.lastPathComponent];
    struct stat existingOutputStat;
    if (lstat(canonicalOutputPath.fileSystemRepresentation, &existingOutputStat) == 0) {
        if (!S_ISREG(existingOutputStat.st_mode) || S_ISLNK(existingOutputStat.st_mode) || existingOutputStat.st_uid != geteuid()) {
            if (error) *error = TSArchiveError(20, NSLocalizedString(@"The existing output path is not a regular file owned by TrollStore.", nil));
            return NO;
        }
    } else if (errno != ENOENT) {
        if (error) *error = TSArchiveError(20, NSLocalizedString(@"Could not inspect the output archive destination.", nil));
        return NO;
    }
    char resolvedSource[PATH_MAX] = {0};
    struct stat sourceStat;
    if (!realpath(sourceDirectory.fileSystemRepresentation, resolvedSource) || lstat(resolvedSource, &sourceStat) != 0 || !S_ISDIR(sourceStat.st_mode) || S_ISLNK(sourceStat.st_mode)) {
        if (error) *error = TSArchiveError(20, NSLocalizedString(@"The source directory is not a real directory.", nil));
        return NO;
    }
    NSString *root = [NSString stringWithUTF8String:resolvedSource];
    NSString *tmpTemplate = [canonicalParent stringByAppendingPathComponent:[NSString stringWithFormat:@".%@.XXXXXX", outputPath.lastPathComponent]];
    char tmpBuffer[PATH_MAX] = {0};
    if (!tmpTemplate.fileSystemRepresentation || strlen(tmpTemplate.fileSystemRepresentation) >= sizeof(tmpBuffer)) {
        if (error) *error = TSArchiveError(21, NSLocalizedString(@"The temporary output path is too long.", nil));
        return NO;
    }
    strlcpy(tmpBuffer, tmpTemplate.fileSystemRepresentation, sizeof(tmpBuffer));
    int tmpFD = mkstemp(tmpBuffer);
    if (tmpFD < 0) {
        if (error) *error = TSArchiveError(21, [NSString stringWithFormat:NSLocalizedString(@"Could not create a private output file: %@", nil), [NSString stringWithUTF8String:strerror(errno)]]);
        return NO;
    }
    fchmod(tmpFD, 0600);
    close(tmpFD);
    NSString *tmpPath = [NSString stringWithUTF8String:tmpBuffer];
    struct archive *writer = archive_write_new();
    if (!writer) {
        if (error) *error = TSArchiveError(21, NSLocalizedString(@"Could not initialize the ZIP writer.", nil));
        return NO;
    }
    archive_write_set_format_zip(writer);
    archive_write_set_options(writer, "zip:compression=deflate");
    archive_write_set_bytes_per_block(writer, 256 * 1024);
    int result = archive_write_open_filename(writer, tmpPath.fileSystemRepresentation);
    if (result != ARCHIVE_OK) {
        if (error) *error = TSArchiveError(21, [NSString stringWithUTF8String:archive_error_string(writer) ?: "Could not create ZIP output."]);
        archive_write_free(writer);
        [fm removeItemAtPath:tmpPath error:nil];
        return NO;
    }
    __block NSError *enumerationError = nil;
    NSDirectoryEnumerator *enumerator = [fm enumeratorAtURL:[NSURL fileURLWithPath:root] includingPropertiesForKeys:@[NSURLIsDirectoryKey, NSURLIsSymbolicLinkKey] options:0 errorHandler:^BOOL(NSURL *url, NSError *innerError) { enumerationError = innerError; return NO; }];
    NSURL *url = nil;
    BOOL success = YES;
    while ((url = [enumerator nextObject])) {
        NSString *absolute = url.path.stringByStandardizingPath;
        if (![absolute hasPrefix:[root stringByAppendingString:@"/"]]) continue;
        NSString *relative = [absolute substringFromIndex:root.length + 1];
        struct stat st;
        if (lstat(absolute.fileSystemRepresentation, &st) != 0) { success = NO; break; }
        // Never let the enumerator descend through a package symlink. The link
        // itself may be archived only after its target is proven to stay inside
        // the source root; its descendants are deliberately not traversed.
        if (S_ISLNK(st.st_mode)) [enumerator skipDescendants];
        struct archive_entry *entry = archive_entry_new();
        archive_entry_set_pathname(entry, relative.fileSystemRepresentation);
        archive_entry_set_perm(entry, st.st_mode & 0777);
        archive_entry_set_mtime(entry, st.st_mtime, 0);
        if (S_ISDIR(st.st_mode)) {
            archive_entry_set_filetype(entry, AE_IFDIR); archive_entry_set_size(entry, 0);
        } else if (S_ISLNK(st.st_mode)) {
            char linkBuffer[PATH_MAX + 1] = {0};
            ssize_t len = readlink(absolute.fileSystemRepresentation, linkBuffer, PATH_MAX);
            if (len < 0) { archive_entry_free(entry); success = NO; break; }
            linkBuffer[len] = '\0';
            if (!TSSafeArchiveSymlinkTarget(relative, linkBuffer)) { archive_entry_free(entry); success = NO; break; }
            archive_entry_set_filetype(entry, AE_IFLNK); archive_entry_set_symlink(entry, linkBuffer); archive_entry_set_size(entry, 0);
        } else if (S_ISREG(st.st_mode)) {
            archive_entry_set_filetype(entry, AE_IFREG); archive_entry_set_size(entry, st.st_size);
        } else { archive_entry_free(entry); success = NO; break; }
        result = archive_write_header(writer, entry);
        if (result != ARCHIVE_OK) { archive_entry_free(entry); success = NO; break; }
        if (S_ISREG(st.st_mode)) {
            int fd = open(absolute.fileSystemRepresentation, O_RDONLY | O_CLOEXEC | O_NOFOLLOW);
            struct stat openedStat;
            if (fd < 0 || fstat(fd, &openedStat) != 0 || !S_ISREG(openedStat.st_mode) ||
                openedStat.st_dev != st.st_dev || openedStat.st_ino != st.st_ino || openedStat.st_size != st.st_size) {
                if (fd >= 0) close(fd);
                archive_entry_free(entry); success = NO; break;
            }
            uint64_t copiedBytes = 0;
            uint8_t buffer[256 * 1024];
            ssize_t count = 0;
            while ((count = read(fd, buffer, sizeof(buffer))) > 0) {
                const uint8_t *cursor = buffer; ssize_t remain = count;
                while (remain > 0) {
                    la_ssize_t written = archive_write_data(writer, cursor, (size_t)remain);
                    if (written <= 0) { success = NO; break; }
                    copiedBytes += (uint64_t)written;
                    cursor += written; remain -= written;
                }
                if (!success) break;
            }
            close(fd);
            if (count < 0 || copiedBytes != (uint64_t)st.st_size) success = NO;
        }
        archive_entry_free(entry);
        if (!success) break;
        if (archive_write_finish_entry(writer) != ARCHIVE_OK) { success = NO; break; }
    }
    if (enumerationError) success = NO;
    if (archive_write_close(writer) != ARCHIVE_OK) success = NO;
    archive_write_free(writer);
    if (!success) {
        [fm removeItemAtPath:tmpPath error:nil];
        if (error) *error = enumerationError ?: TSArchiveError(22, NSLocalizedString(@"Failed to package the output archive.", nil));
        return NO;
    }
    // tmpPath is beside outputPath, so rename commits atomically on the same
    // filesystem and leaves an existing archive intact if the commit fails.
    if (rename(tmpPath.fileSystemRepresentation, canonicalOutputPath.fileSystemRepresentation) != 0) {
        int savedErrno = errno;
        [fm removeItemAtPath:tmpPath error:nil];
        if (error) *error = TSArchiveError(23, [NSString stringWithFormat:NSLocalizedString(@"Could not atomically replace the output archive: %@", nil), [NSString stringWithUTF8String:strerror(savedErrno)]]);
        return NO;
    }
    return YES;
}

+ (NSArray<NSString *> *)dynamicLibrariesUnderDirectory:(NSString *)directory {
    NSString *canonicalRoot = nil;
    char resolvedRoot[PATH_MAX] = {0};
    if (!directory.length || !realpath(directory.fileSystemRepresentation, resolvedRoot)) return @[];
    canonicalRoot = [NSString stringWithUTF8String:resolvedRoot];
    struct stat rootStat;
    if (lstat(resolvedRoot, &rootStat) != 0 || !S_ISDIR(rootStat.st_mode) || S_ISLNK(rootStat.st_mode)) return @[];
    NSMutableArray *libraries = [NSMutableArray array];
    NSDirectoryEnumerator *enumerator = [NSFileManager.defaultManager enumeratorAtPath:canonicalRoot];
    NSString *relative = nil;
    while ((relative = [enumerator nextObject])) {
        NSString *path = [canonicalRoot stringByAppendingPathComponent:relative];
        struct stat st;
        if (lstat(path.fileSystemRepresentation, &st) != 0) continue;
        // Do not recurse through symlinks even when their target resolves back
        // inside the root. Injection candidates must be real files/directories.
        if (S_ISLNK(st.st_mode)) { [enumerator skipDescendants]; continue; }
        NSString *extension = relative.pathExtension.lowercaseString;
        if ([extension isEqualToString:@"framework"] && S_ISDIR(st.st_mode)) {
            [libraries addObject:path];
            [enumerator skipDescendants];
        } else if ([extension isEqualToString:@"dylib"] && S_ISREG(st.st_mode)) {
            [libraries addObject:path];
        }
    }
    return libraries.copy;
}
@end
