#import "TSArchiveExtractor.h"
#import <archive.h>
#import <archive_entry.h>
#import <sys/stat.h>
#import <fcntl.h>
#import <unistd.h>
#import <errno.h>
#import <limits.h>
#import <stdlib.h>
#import <string.h>

static NSError *TSArchiveError(NSInteger code, NSString *message) {
    return [NSError errorWithDomain:@"com.opa334.TrollStore.Archive" code:code userInfo:@{NSLocalizedDescriptionKey: message ?: NSLocalizedString(@"Archive operation failed.", nil)}];
}

// Create per-operation work storage beside the caller's app-owned destination.
// This deliberately avoids NSTemporaryDirectory()/shared /tmp paths and verifies
// the resolved parent and newly-created directory before any archive is written.
static NSString *TSCreatePrivateSiblingDirectory(NSString *destinationPath, NSError **errorOut) {
    NSString *parentPath = destinationPath.stringByDeletingLastPathComponent;
    char resolvedParent[PATH_MAX] = {0};
    if (!parentPath.length || !realpath(parentPath.fileSystemRepresentation, resolvedParent)) {
        if (errorOut) *errorOut = TSArchiveError(10, NSLocalizedString(@"The destination parent directory could not be resolved.", nil));
        return nil;
    }
    struct stat parentStat;
    if (lstat(resolvedParent, &parentStat) != 0 || !S_ISDIR(parentStat.st_mode) || S_ISLNK(parentStat.st_mode)) {
        if (errorOut) *errorOut = TSArchiveError(10, NSLocalizedString(@"The destination parent is not a real directory.", nil));
        return nil;
    }
    NSString *templatePath = [[NSString stringWithUTF8String:resolvedParent] stringByAppendingPathComponent:@".TrollStoreArchive.XXXXXX"];
    if (!templatePath.fileSystemRepresentation || strlen(templatePath.fileSystemRepresentation) >= PATH_MAX) {
        if (errorOut) *errorOut = TSArchiveError(10, NSLocalizedString(@"The archive work path is too long.", nil));
        return nil;
    }
    char buffer[PATH_MAX] = {0};
    strlcpy(buffer, templatePath.fileSystemRepresentation, sizeof(buffer));
    char *created = mkdtemp(buffer);
    if (!created) {
        if (errorOut) *errorOut = TSArchiveError(10, [NSString stringWithFormat:NSLocalizedString(@"Could not create private archive storage: %@", nil), [NSString stringWithUTF8String:strerror(errno)]]);
        return nil;
    }
    struct stat createdStat;
    if (chmod(created, 0700) != 0 || lstat(created, &createdStat) != 0 ||
        !S_ISDIR(createdStat.st_mode) || S_ISLNK(createdStat.st_mode) || createdStat.st_uid != geteuid()) {
        int savedErrno = errno;
        rmdir(created);
        if (errorOut) *errorOut = TSArchiveError(10, [NSString stringWithFormat:NSLocalizedString(@"Private archive storage failed its safety check: %@", nil), [NSString stringWithUTF8String:strerror(savedErrno)]]);
        return nil;
    }
    return [NSString stringWithUTF8String:created];
}

static NSString *TSSafeArchivePath(const char *raw) {
    if (!raw) return nil;
    NSString *path = [NSString stringWithUTF8String:raw];
    if (!path.length) return nil;
    path = [path stringByReplacingOccurrencesOfString:@"\\" withString:@"/"];
    // Reject absolute roots before trimming the directory terminator; otherwise
    // a malicious "/" entry would normalize to the harmless "./" root marker.
    if ([path hasPrefix:@"/"] || [path hasPrefix:@"~"] ||
        (path.length >= 2 && [[NSCharacterSet letterCharacterSet] characterIsMember:[path characterAtIndex:0]] && [path characterAtIndex:1] == ':')) return nil;
    while ([path hasPrefix:@"./"]) path = [path substringFromIndex:2];
    while ([path hasSuffix:@"/"]) path = [path substringToIndex:path.length - 1];
    // Tar archives commonly contain a harmless root-directory entry named ./.
    if (!path.length || [path isEqualToString:@"."]) return @".";
    NSArray<NSString *> *parts = [path componentsSeparatedByString:@"/"];
    for (NSString *part in parts) if (!part.length || [part isEqualToString:@".."] || [part isEqualToString:@"."]) return nil;
    return path;
}

static BOOL TSSafeArchiveSymlinkTarget(NSString *relativePath, const char *rawTarget) {
    if (!relativePath.length || !rawTarget) return NO;
    NSString *target = [NSString stringWithUTF8String:rawTarget];
    if (!target.length) return NO;
    target = [target stringByReplacingOccurrencesOfString:@"\\" withString:@"/"];
    if ([target hasPrefix:@"/"] || [target hasPrefix:@"~"] ||
        (target.length >= 2 && [[NSCharacterSet letterCharacterSet] characterIsMember:[target characterAtIndex:0]] && [target characterAtIndex:1] == ':')) return NO;
    NSMutableArray<NSString *> *components = [[relativePath.stringByDeletingLastPathComponent componentsSeparatedByString:@"/"] mutableCopy];
    if (components.count == 1 && !components.firstObject.length) [components removeAllObjects];
    for (NSString *component in [target componentsSeparatedByString:@"/"]) {
        if (!component.length || [component isEqualToString:@"."]) continue;
        if ([component isEqualToString:@".."]) {
            if (components.count == 0) return NO;
            [components removeLastObject];
        } else {
            [components addObject:component];
        }
    }
    return components.count != 0;
}

static BOOL TSExtractSingleArchive(NSString *archivePath, NSString *destinationPath, NSError **errorOut) {
    NSFileManager *fm = NSFileManager.defaultManager;
    if (![fm fileExistsAtPath:destinationPath] && ![fm createDirectoryAtPath:destinationPath withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0700} error:errorOut]) return NO;
    char resolvedRoot[PATH_MAX] = {0};
    if (!realpath(destinationPath.fileSystemRepresentation, resolvedRoot)) {
        if (errorOut) *errorOut = TSArchiveError(1, [NSString stringWithFormat:NSLocalizedString(@"The extraction directory could not be resolved: %@", nil), [NSString stringWithUTF8String:strerror(errno)]]);
        return NO;
    }
    NSString *canonicalRoot = [NSString stringWithUTF8String:resolvedRoot];
    struct stat rootStat;
    if (!canonicalRoot.length || lstat(resolvedRoot, &rootStat) != 0 || !S_ISDIR(rootStat.st_mode) || S_ISLNK(rootStat.st_mode)) {
        if (errorOut) *errorOut = TSArchiveError(1, NSLocalizedString(@"The extraction destination is not a real directory.", nil));
        return NO;
    }
    struct archive *reader = archive_read_new();
    struct archive *disk = archive_write_disk_new();
    if (!reader || !disk) {
        if (reader) archive_read_free(reader);
        if (disk) archive_write_free(disk);
        if (errorOut) *errorOut = TSArchiveError(1, @"Could not initialize the archive reader.");
        return NO;
    }
    archive_read_support_filter_all(reader);
    NSString *archiveName = archivePath.lastPathComponent.lowercaseString;
    if ([archiveName.pathExtension isEqualToString:@"zip"]) {
        archive_read_support_format_zip(reader);
    } else if ([archiveName.pathExtension isEqualToString:@"deb"]) {
        archive_read_support_format_ar(reader);
    } else {
        // Debian data.tar, data.tar.gz, data.tar.xz, and plain tar payloads.
        archive_read_support_format_tar(reader);
    }
    archive_write_disk_set_options(disk, ARCHIVE_EXTRACT_TIME | ARCHIVE_EXTRACT_PERM | ARCHIVE_EXTRACT_ACL | ARCHIVE_EXTRACT_FFLAGS | ARCHIVE_EXTRACT_SECURE_NODOTDOT | ARCHIVE_EXTRACT_SECURE_SYMLINKS);
    archive_write_disk_set_standard_lookup(disk);
    int result = archive_read_open_filename(reader, archivePath.fileSystemRepresentation, 256 * 1024);
    if (result != ARCHIVE_OK) {
        if (errorOut) *errorOut = TSArchiveError(2, [NSString stringWithFormat:@"%@", @(result)]);
        archive_read_free(reader); archive_write_free(disk); return NO;
    }

    BOOL success = YES;
    struct archive_entry *entry = NULL;
    while ((result = archive_read_next_header(reader, &entry)) == ARCHIVE_OK) {
        NSString *relative = TSSafeArchivePath(archive_entry_pathname(entry));
        if ([relative isEqualToString:@"."] && archive_entry_filetype(entry) == AE_IFDIR) {
            if (archive_read_data_skip(reader) < ARCHIVE_OK) {
                success = NO;
                if (errorOut) *errorOut = TSArchiveError(3, NSLocalizedString(@"Could not skip the archive root directory entry.", nil));
                break;
            }
            continue;
        }
        if (!relative || [relative isEqualToString:@"."]) {
            // Reject traversal/absolute paths instead of allowing a package to escape its destination.
            success = NO;
            if (errorOut) *errorOut = TSArchiveError(3, NSLocalizedString(@"The archive contains an unsafe absolute or parent-relative path.", nil));
            break;
        }
        const mode_t entryType = archive_entry_filetype(entry);
        if ((entryType != AE_IFDIR && entryType != AE_IFREG && entryType != AE_IFLNK) || archive_entry_hardlink(entry)) {
            success = NO;
            if (errorOut) *errorOut = TSArchiveError(3, NSLocalizedString(@"The archive contains an unsupported special file or hard link.", nil));
            break;
        }
        if (entryType == AE_IFLNK && !TSSafeArchiveSymlinkTarget(relative, archive_entry_symlink(entry))) {
            success = NO;
            if (errorOut) *errorOut = TSArchiveError(3, NSLocalizedString(@"The archive contains a symbolic link outside its extraction directory.", nil));
            break;
        }
        NSString *targetPath = [canonicalRoot stringByAppendingPathComponent:relative];
        targetPath = targetPath.stringByStandardizingPath;
        NSString *root = canonicalRoot;
        if (![targetPath isEqualToString:root] && ![targetPath hasPrefix:[root stringByAppendingString:@"/"]]) {
            success = NO;
            if (errorOut) *errorOut = TSArchiveError(3, NSLocalizedString(@"The archive path escapes the extraction directory.", nil));
            break;
        }
        archive_entry_set_pathname(entry, targetPath.fileSystemRepresentation);
        result = archive_write_header(disk, entry);
        if (result != ARCHIVE_OK) {
            success = NO;
            if (errorOut) *errorOut = TSArchiveError(4, [NSString stringWithUTF8String:archive_error_string(disk) ?: "Could not write archive entry."]);
            break;
        }
        const void *block = NULL;
        size_t blockSize = 0;
        la_int64_t offset = 0;
        while ((result = archive_read_data_block(reader, &block, &blockSize, &offset)) == ARCHIVE_OK) {
            result = archive_write_data_block(disk, block, blockSize, offset);
            if (result != ARCHIVE_OK) {
                success = NO;
                if (errorOut) *errorOut = TSArchiveError(5, [NSString stringWithUTF8String:archive_error_string(disk) ?: "Could not write archive data."]);
                break;
            }
        }
        if (!success) break;
        if (result != ARCHIVE_EOF && result != ARCHIVE_OK) {
            success = NO;
            if (errorOut) *errorOut = TSArchiveError(6, [NSString stringWithUTF8String:archive_error_string(reader) ?: "Could not read archive data."]);
            break;
        }
        if (archive_write_finish_entry(disk) != ARCHIVE_OK) {
            success = NO;
            if (errorOut) *errorOut = TSArchiveError(7, [NSString stringWithUTF8String:archive_error_string(disk) ?: "Could not finish archive entry."]);
            break;
        }
    }
    if (result != ARCHIVE_EOF && result != ARCHIVE_OK && success) {
        success = NO;
        if (errorOut) *errorOut = TSArchiveError(8, [NSString stringWithUTF8String:archive_error_string(reader) ?: "Could not read archive headers."]);
    }
    archive_read_close(reader); archive_read_free(reader);
    if (archive_write_close(disk) != ARCHIVE_OK) {
        success = NO;
        if (errorOut && !*errorOut) *errorOut = TSArchiveError(9, [NSString stringWithUTF8String:archive_error_string(disk) ?: "Could not finalize archive extraction."]);
    }
    archive_write_free(disk);
    return success;
}

@implementation TSArchiveExtractor

+ (BOOL)archiveContainsInstallableIPAAtPath:(NSString *)archivePath {
    if (!archivePath.length || ![[NSFileManager defaultManager] fileExistsAtPath:archivePath] || ![archivePath.pathExtension.lowercaseString isEqualToString:@"zip"]) return NO;
    struct archive *reader = archive_read_new();
    if (!reader) return NO;
    archive_read_support_filter_all(reader);
    archive_read_support_format_zip(reader);
    int result = archive_read_open_filename(reader, archivePath.fileSystemRepresentation, 128 * 1024);
    BOOL safe = (result == ARCHIVE_OK);
    NSMutableSet<NSString *> *regularPaths = [NSMutableSet set];
    NSString *expectedExecutablePath = nil;
    BOOL validAppInfo = NO;
    struct archive_entry *entry = NULL;
    while (safe && (result = archive_read_next_header(reader, &entry)) == ARCHIVE_OK) {
        NSString *relative = TSSafeArchivePath(archive_entry_pathname(entry));
        if (!relative) { safe = NO; break; }
        if (archive_entry_filetype(entry) == AE_IFREG) [regularPaths addObject:relative];
        NSArray<NSString *> *parts = relative.pathComponents;
        BOOL appInfoPath = parts.count == 3 && [parts[0] isEqualToString:@"Payload"] && [parts[1].pathExtension.lowercaseString isEqualToString:@"app"] && [parts[2] isEqualToString:@"Info.plist"] && archive_entry_filetype(entry) == AE_IFREG;
        if (appInfoPath) {
            // Avoid spending unbounded memory on a malformed archive entry.
            la_int64_t entrySize = archive_entry_size(entry);
            if (entrySize < 1 || entrySize > 4 * 1024 * 1024) { safe = NO; break; }
            NSMutableData *plistData = [NSMutableData dataWithCapacity:(NSUInteger)entrySize];
            uint8_t buffer[16 * 1024];
            la_ssize_t count = 0;
            while ((count = archive_read_data(reader, buffer, sizeof(buffer))) > 0) {
                if (plistData.length + (NSUInteger)count > 4 * 1024 * 1024) { safe = NO; break; }
                [plistData appendBytes:buffer length:(NSUInteger)count];
            }
            if (!safe || count < 0) { safe = NO; break; }
            id value = [NSPropertyListSerialization propertyListWithData:plistData options:NSPropertyListImmutable format:nil error:nil];
            if (![value isKindOfClass:NSDictionary.class]) { safe = NO; break; }
            NSDictionary *appInfo = value;
            NSString *bundleID = [appInfo[@"CFBundleIdentifier"] isKindOfClass:NSString.class] ? appInfo[@"CFBundleIdentifier"] : nil;
            NSString *executable = [appInfo[@"CFBundleExecutable"] isKindOfClass:NSString.class] ? appInfo[@"CFBundleExecutable"] : nil;
            if (!bundleID.length || !executable.length || [executable containsString:@"/"] || [executable containsString:@"\\"] || [executable isEqualToString:@"."] || [executable isEqualToString:@".."]) { safe = NO; break; }
            expectedExecutablePath = [NSString stringWithFormat:@"%@/%@", [relative stringByDeletingLastPathComponent], executable];
            validAppInfo = YES;
        } else {
            int skipResult = archive_read_data_skip(reader);
            if (skipResult < ARCHIVE_OK) { safe = NO; break; }
        }
    }
    BOOL atEnd = (result == ARCHIVE_EOF);
    archive_read_close(reader);
    archive_read_free(reader);
    return safe && atEnd && validAppInfo && expectedExecutablePath.length && [regularPaths containsObject:expectedExecutablePath];
}

+ (BOOL)extractArchiveAtPath:(NSString *)archivePath toDirectory:(NSString *)destinationPath error:(NSError **)error {
    if (!archivePath.length || !destinationPath.length || ![[NSFileManager defaultManager] fileExistsAtPath:archivePath]) {
        if (error) *error = TSArchiveError(10, NSLocalizedString(@"The selected archive is unavailable.", nil));
        return NO;
    }
    NSFileManager *fm = NSFileManager.defaultManager;
    [fm removeItemAtPath:destinationPath error:nil];
    if (![fm createDirectoryAtPath:destinationPath withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0755} error:error]) return NO;
    if ([archivePath.pathExtension.lowercaseString isEqualToString:@"deb"]) {
        NSError *extractError = nil;
        NSString *outer = TSCreatePrivateSiblingDirectory(destinationPath, &extractError);
        if (!outer || !TSExtractSingleArchive(archivePath, outer, &extractError)) {
            [fm removeItemAtPath:destinationPath error:nil];
            if (error) *error = extractError;
            if (outer) [fm removeItemAtPath:outer error:nil];
            return NO;
        }
        NSDirectoryEnumerator *enumerator = [fm enumeratorAtPath:outer];
        NSString *relative = nil;
        NSString *dataArchive = nil;
        while ((relative = [enumerator nextObject])) {
            NSString *lower = relative.lastPathComponent.lowercaseString;
            if ([lower hasPrefix:@"data.tar"]) { dataArchive = [outer stringByAppendingPathComponent:relative]; break; }
        }
        BOOL success = NO;
        if (dataArchive) success = TSExtractSingleArchive(dataArchive, destinationPath, &extractError);
        else extractError = TSArchiveError(11, NSLocalizedString(@"The DEB package does not contain a data.tar archive.", nil));
        [fm removeItemAtPath:outer error:nil];
        if (!success) { [fm removeItemAtPath:destinationPath error:nil]; if (error) *error = extractError; return NO; }
        return YES;
    }
    NSError *innerError = nil;
    BOOL success = TSExtractSingleArchive(archivePath, destinationPath, &innerError);
    if (!success) [fm removeItemAtPath:destinationPath error:nil];
    if (!success && error) *error = innerError;
    return success;
}

+ (BOOL)createZipFromDirectory:(NSString *)sourceDirectory outputPath:(NSString *)outputPath error:(NSError **)error {
    NSFileManager *fm = NSFileManager.defaultManager;
    BOOL isDir = NO;
    if (![fm fileExistsAtPath:sourceDirectory isDirectory:&isDir] || !isDir) {
        if (error) *error = TSArchiveError(20, NSLocalizedString(@"The source directory does not exist.", nil));
        return NO;
    }
    NSString *tmpPath = [outputPath stringByAppendingFormat:@".tmp.%@", NSUUID.UUID.UUIDString];
    [[NSFileManager defaultManager] removeItemAtPath:tmpPath error:nil];
    struct archive *writer = archive_write_new();
    if (!writer) {
        if (error) *error = TSArchiveError(21, NSLocalizedString(@"Could not initialize the ZIP writer.", nil));
        return NO;
    }
    NSString *outputParent = outputPath.stringByDeletingLastPathComponent;
    NSError *directoryError = nil;
    if (outputParent.length && ![fm createDirectoryAtPath:outputParent withIntermediateDirectories:YES attributes:nil error:&directoryError]) {
        if (error) *error = directoryError;
        archive_write_free(writer);
        return NO;
    }
    archive_write_set_format_zip(writer);
    archive_write_set_options(writer, "zip:compression=deflate");
    archive_write_set_bytes_per_block(writer, 256 * 1024);
    int result = archive_write_open_filename(writer, tmpPath.fileSystemRepresentation);
    if (result != ARCHIVE_OK) {
        if (error) *error = TSArchiveError(21, [NSString stringWithUTF8String:archive_error_string(writer) ?: "Could not create ZIP output."]);
        archive_write_free(writer); return NO;
    }
    NSString *root = sourceDirectory.stringByStandardizingPath;
    NSDirectoryEnumerator *enumerator = [fm enumeratorAtURL:[NSURL fileURLWithPath:root] includingPropertiesForKeys:@[NSURLIsDirectoryKey, NSURLIsSymbolicLinkKey] options:0 errorHandler:^BOOL(NSURL *url, NSError *innerError) { return NO; }];
    NSURL *url = nil;
    BOOL success = YES;
    while ((url = [enumerator nextObject])) {
        NSString *absolute = url.path.stringByStandardizingPath;
        if (![absolute hasPrefix:[root stringByAppendingString:@"/"]]) continue;
        NSString *relative = [absolute substringFromIndex:root.length + 1];
        struct stat st;
        if (lstat(absolute.fileSystemRepresentation, &st) != 0) continue;
        struct archive_entry *entry = archive_entry_new();
        archive_entry_set_pathname(entry, relative.fileSystemRepresentation);
        archive_entry_set_perm(entry, st.st_mode & 07777);
        archive_entry_set_uid(entry, st.st_uid); archive_entry_set_gid(entry, st.st_gid);
        archive_entry_set_mtime(entry, st.st_mtime, 0);
        if (S_ISDIR(st.st_mode)) {
            archive_entry_set_filetype(entry, AE_IFDIR); archive_entry_set_size(entry, 0);
        } else if (S_ISLNK(st.st_mode)) {
            char linkBuffer[PATH_MAX + 1] = {0};
            ssize_t len = readlink(absolute.fileSystemRepresentation, linkBuffer, PATH_MAX);
            if (len < 0) { archive_entry_free(entry); success = NO; break; }
            linkBuffer[len] = '\0';
            archive_entry_set_filetype(entry, AE_IFLNK); archive_entry_set_symlink(entry, linkBuffer); archive_entry_set_size(entry, 0);
        } else if (S_ISREG(st.st_mode)) {
            archive_entry_set_filetype(entry, AE_IFREG); archive_entry_set_size(entry, st.st_size);
        } else { archive_entry_free(entry); continue; }
        result = archive_write_header(writer, entry);
        if (result != ARCHIVE_OK) { archive_entry_free(entry); success = NO; break; }
        if (S_ISREG(st.st_mode)) {
            int fd = open(absolute.fileSystemRepresentation, O_RDONLY);
            if (fd < 0) { archive_entry_free(entry); success = NO; break; }
            uint8_t buffer[256 * 1024];
            ssize_t count = 0;
            while ((count = read(fd, buffer, sizeof(buffer))) > 0) {
                const uint8_t *cursor = buffer; ssize_t remain = count;
                while (remain > 0) {
                    la_ssize_t written = archive_write_data(writer, cursor, (size_t)remain);
                    if (written <= 0) { success = NO; break; }
                    cursor += written; remain -= written;
                }
                if (!success) break;
            }
            close(fd);
            if (count < 0) success = NO;
        }
        archive_entry_free(entry);
        if (!success) break;
        if (archive_write_finish_entry(writer) != ARCHIVE_OK) { success = NO; break; }
    }
    if (archive_write_close(writer) != ARCHIVE_OK) success = NO;
    archive_write_free(writer);
    if (!success) {
        [fm removeItemAtPath:tmpPath error:nil];
        if (error) *error = TSArchiveError(22, NSLocalizedString(@"Failed to package the output archive.", nil));
        return NO;
    }
    // tmpPath is beside outputPath, so rename commits atomically on the same
    // filesystem and leaves an existing archive intact if the commit fails.
    if (rename(tmpPath.fileSystemRepresentation, outputPath.fileSystemRepresentation) != 0) {
        int savedErrno = errno;
        [fm removeItemAtPath:tmpPath error:nil];
        if (error) *error = TSArchiveError(23, [NSString stringWithFormat:NSLocalizedString(@"Could not atomically replace the output archive: %@", nil), [NSString stringWithUTF8String:strerror(savedErrno)]]);
        return NO;
    }
    return YES;
}

+ (NSArray<NSString *> *)dynamicLibrariesUnderDirectory:(NSString *)directory {
    NSMutableArray *libraries = [NSMutableArray array];
    NSDirectoryEnumerator *enumerator = [NSFileManager.defaultManager enumeratorAtPath:directory];
    NSString *relative = nil;
    while ((relative = [enumerator nextObject])) {
        NSString *extension = relative.pathExtension.lowercaseString;
        if ([extension isEqualToString:@"framework"]) {
            NSString *path = [directory stringByAppendingPathComponent:relative];
            BOOL isDirectory = NO;
            if ([NSFileManager.defaultManager fileExistsAtPath:path isDirectory:&isDirectory] && isDirectory) {
                [libraries addObject:path];
                [enumerator skipDescendants];
            }
        } else if ([extension isEqualToString:@"dylib"]) {
            NSString *path = [directory stringByAppendingPathComponent:relative];
            BOOL isDirectory = NO;
            if ([NSFileManager.defaultManager fileExistsAtPath:path isDirectory:&isDirectory] && !isDirectory) [libraries addObject:path];
        }
    }
    return libraries.copy;
}
@end
