#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface TSSigningManager : NSObject
+ (NSString *)signingDirectoryPath;
+ (NSArray<NSDictionary *> *)credentialRecords;
+ (nullable NSDictionary *)credentialRecordForIdentifier:(NSString *)identifier;
+ (nullable NSString *)defaultCredentialIdentifier;
+ (void)setDefaultCredentialIdentifier:(NSString *)identifier;
+ (NSString *)signingMode;
+ (void)setSigningMode:(NSString *)mode;
+ (NSString *)selectedTemplateForMode:(NSString *)mode;
+ (void)setSelectedTemplate:(NSString *)templateName forMode:(NSString *)mode;
+ (NSArray<NSDictionary *> *)templateDefinitionsForMode:(NSString *)mode;
+ (nullable NSDictionary *)certificateDetailsForCredentialIdentifier:(NSString *)identifier;
+ (nullable NSDictionary *)provisioningProfileDetailsForCredentialIdentifier:(NSString *)identifier;

+ (BOOL)importPKCS12Data:(NSData *)data
               fileName:(NSString *)fileName
               password:(NSString *)password
                  error:(NSError * _Nullable * _Nullable)error;
+ (BOOL)importPEMCertificateData:(NSData *)certificateData
                  privateKeyData:(NSData *)privateKeyData
                        fileName:(NSString *)fileName
                        password:(NSString *)password
                           error:(NSError * _Nullable * _Nullable)error;
+ (BOOL)importProvisioningProfileData:(NSData *)data
                 forCredentialIdentifier:(NSString *)identifier
                              fileName:(NSString *)fileName
                                 error:(NSError * _Nullable * _Nullable)error;
+ (void)deleteCredentialWithIdentifier:(NSString *)identifier;

/// Creates a short-lived, permission-restricted plist for RootHelper. Passwords and
/// decrypted PEM private keys are never stored in NSUserDefaults or logged.
+ (nullable NSString *)prepareRootHelperSigningConfiguration:(NSError * _Nullable * _Nullable)error;
+ (void)cleanupRootHelperSigningConfiguration:(nullable NSString *)configurationPath;
@end

NS_ASSUME_NONNULL_END
