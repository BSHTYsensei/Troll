#import "TSInstallationController.h"

#import "TSApplicationsManager.h"
#import "TSAppInfo.h"
#import "TSAppRepackager.h"
#import <TSUtil.h>
#import <TSPresentationDelegate.h>

extern NSUserDefaults* trollStoreUserDefaults(void);

@interface TSInstallSession : NSObject
@property(nonatomic, copy) NSString *ipaPath;
@property(nonatomic, copy) NSString *entitlementsPath;
@property(nonatomic, assign) BOOL force;
@property(nonatomic, assign) NSInteger method; // 0 = installd, 1 = Custom
@property(nonatomic, assign) BOOL preserveEntitlementsOverride;
@property(nonatomic, assign) BOOL stealthInstall;
@property(nonatomic, strong) NSMutableString *debugLog;
@property(nonatomic, strong) NSMutableDictionary<NSNumber *, NSNumber *> *retryCountsByError;
@property(nonatomic, copy) void (^completion)(BOOL, NSError *);
@property(nonatomic, assign) BOOL finished;
@end
@implementation TSInstallSession
@end

@interface TSInstallationController ()
+ (void)performInstallSession:(TSInstallSession *)session;
+ (void)presentFailureForSession:(TSInstallSession *)session error:(NSError *)error code:(int)code;
+ (void)finishInstallSession:(TSInstallSession *)session success:(BOOL)success error:(NSError *)error;
+ (void)presentEntitlementsEditorForIPA:(NSString*)pathToIPA completion:(void (^)(BOOL, NSError*))completionBlock;
@end

@implementation TSInstallationController

+ (void)handleAppInstallFromFile:(NSString*)pathToIPA forceInstall:(BOOL)force completion:(void (^)(BOOL, NSError*))completionBlock
{
    if (pathToIPA.length == 0) {
        NSError *error = [NSError errorWithDomain:TrollStoreErrorDomain code:166 userInfo:@{NSLocalizedDescriptionKey: NSLocalizedString(@"The IPA file does not exist or is not accessible.", nil)}];
        if (completionBlock) completionBlock(NO, error);
        return;
    }
    NSUserDefaults *defaults = trollStoreUserDefaults();
    NSNumber *methodNumber = [defaults objectForKey:@"installationMethod"];
    TSInstallSession *session = [TSInstallSession new];
    session.ipaPath = [pathToIPA copy];
    session.force = force;
    session.method = methodNumber ? methodNumber.integerValue : 1;
    if (session.method != 0 && session.method != 1) session.method = 1;
    session.preserveEntitlementsOverride = [defaults boolForKey:@"TSCustomEntitlementsOverrideEnabled"];
    session.stealthInstall = [defaults boolForKey:@"TSStealthInstallEnabled"];
    NSString *support = [NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES) firstObject];
    session.entitlementsPath = [[support stringByAppendingPathComponent:@"TSCustomEntitlements.plist"] copy];
    session.debugLog = [NSMutableString new];
    session.retryCountsByError = [NSMutableDictionary new];
    session.completion = [completionBlock copy];
    [self performInstallSession:session];
}

+ (void)performInstallSession:(TSInstallSession *)session
{
    if (session.finished) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        [TSPresentationDelegate startActivity:NSLocalizedString(@"Installing", nil)];
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
            NSString *attemptLog = nil;
            TSApplicationsManager *manager = [TSApplicationsManager sharedInstance];
            int ret = [manager installIpa:session.ipaPath force:session.force installationMethod:(int)session.method
                preserveEntitlementsOverride:session.preserveEntitlementsOverride customEntitlementsPath:session.entitlementsPath
                stealthInstall:session.stealthInstall log:&attemptLog];
            if (session.debugLog.length) [session.debugLog appendString:@"\n\n========== RETRY ATTEMPT ==========\n"];
            [session.debugLog appendFormat:@"method=%@ force=%d preserveEntitlements=%d stealth=%d path=%@\nreturn=%d\n%@",
                session.method == 0 ? @"installd" : @"Custom", session.force, session.preserveEntitlementsOverride,
                session.stealthInstall, session.ipaPath, ret, attemptLog ?: @"(no rootHelper log)"];
            NSError *error = ret == 0 ? nil : [manager errorForCode:ret];
            dispatch_async(dispatch_get_main_queue(), ^{
                [TSPresentationDelegate stopActivityWithCompletion:^{
                    if (ret == 0) {
                        [self finishInstallSession:session success:YES error:nil];
                    } else if (ret == 171 && !session.force) {
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:[NSString stringWithFormat:NSLocalizedString(@"Install Error %d", nil), ret] message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
                        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *action) {
                            [self finishInstallSession:session success:NO error:error];
                        }]];
                        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Force Installation", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
                            session.force = YES;
                            [self performInstallSession:session];
                        }]];
                        [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
                    } else if (ret == 171 && session.force) {
                        // Do not show Force Installation repeatedly once force=true.
                        // Let the user retry or switch method, without losing the force flag.
                        [self presentFailureForSession:session error:error code:ret];
                    } else if (ret == 182) {
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Reboot Required", nil) message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
                        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *action) {
                            [self finishInstallSession:session success:YES error:nil];
                        }]];
                        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Reboot Now", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
                            [self finishInstallSession:session success:YES error:nil];
                            spawnRoot(rootHelperPath(), @[@"reboot"], nil, nil);
                        }]];
                        [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
                    } else if (ret == 184) {
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Warning", nil) message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
                        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *action) {
                            [self finishInstallSession:session success:YES error:nil];
                        }]];
                        [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
                    } else if (ret == 193) {
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Provisioning Profile Warning", nil) message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
                        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *action) {
                            [self finishInstallSession:session success:YES error:nil];
                        }]];
                        [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
                    } else {
                        [self presentFailureForSession:session error:error code:ret];
                    }
                }];
            });
        });
    });
}

+ (void)presentFailureForSession:(TSInstallSession *)session error:(NSError *)error code:(int)code
{
    if (session.finished) return;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:[NSString stringWithFormat:NSLocalizedString(@"Install Error %d", nil), code] message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
    NSUInteger retries = [session.retryCountsByError[@(code)] unsignedIntegerValue];
    if (retries < 2) {
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Retry", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            session.retryCountsByError[@(code)] = @(retries + 1);
            [self performInstallSession:session];
        }]];
    }
    NSInteger alternativeMethod = session.method == 0 ? 1 : 0;
    NSString *switchTitle = alternativeMethod == 0 ? NSLocalizedString(@"Retry with installd", nil) : NSLocalizedString(@"Retry with Custom", nil);
    [alert addAction:[UIAlertAction actionWithTitle:switchTitle style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        session.retryCountsByError[@(code)] = @(retries + 1);
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            NSString *cleanupLog = nil;
            int cleanupRet = spawnRoot(rootHelperPath(), @[@"cleanup-install", session.ipaPath, [NSString stringWithFormat:@"%d", code]], nil, &cleanupLog);
            @synchronized(session.debugLog) {
                [session.debugLog appendFormat:@"\n========== PRE-RETRY CLEANUP ==========\nreturn=%d\n%@", cleanupRet, cleanupLog ?: @""];
            }
            session.method = alternativeMethod;
            [self performInstallSession:session];
        });
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Copy Debug Log", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        UIPasteboard.generalPasteboard.string = session.debugLog.copy ?: @"";
        dispatch_async(dispatch_get_main_queue(), ^{
            if (session.finished) return;
            UIAlertController *copied = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Copied", nil) message:NSLocalizedString(@"Debug log copied to the clipboard.", nil) preferredStyle:UIAlertControllerStyleAlert];
            [copied addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *okAction) {
                [self presentFailureForSession:session error:error code:code];
            }]];
            [TSPresentationDelegate presentViewController:copied animated:YES completion:nil];
        });
    }]];
    if (code == 173) {
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Open Settings", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            UIViewController *root = TSPresentationDelegate.presentationViewController;
            if ([root isKindOfClass:UITabBarController.class]) ((UITabBarController *)root).selectedIndex = 1;
        }]];
    }
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *action) {
        [self finishInstallSession:session success:NO error:error];
    }]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}

+ (void)finishInstallSession:(TSInstallSession *)session success:(BOOL)success error:(NSError *)error
{
    if (session.finished) return;
    session.finished = YES;
    // The one-shot override is consumed only after a successful/non-fatal install or final abandonment.
    [trollStoreUserDefaults() setBool:NO forKey:@"TSCustomEntitlementsOverrideEnabled"];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TrollStoreReloadSettingsNotification" object:nil userInfo:nil];
    if (session.completion) session.completion(success, error);
}

+ (void)presentInstallationAlertIfEnabledForFile:(NSString*)pathToIPA isRemoteInstall:(BOOL)remoteInstall completion:(void (^)(BOOL, NSError*))completionBlock
{
	NSNumber* installAlertConfigurationNum = [trollStoreUserDefaults() objectForKey:@"installAlertConfiguration"];
	NSUInteger installAlertConfiguration = 0;
	if(installAlertConfigurationNum)
	{
		installAlertConfiguration = installAlertConfigurationNum.unsignedIntegerValue;
		if(installAlertConfiguration > 2)
		{
			// broken pref? revert to 0
			installAlertConfiguration = 0;
		}
	}

	// Check if user disabled alert for this kind of install
	if(installAlertConfiguration > 0)
	{
		if(installAlertConfiguration == 2 || (installAlertConfiguration == 1 && !remoteInstall))
		{
			[self handleAppInstallFromFile:pathToIPA completion:completionBlock];
			return;
		}
	}

	TSAppInfo* appInfo = [[TSAppInfo alloc] initWithIPAPath:pathToIPA];
	[appInfo loadInfoWithCompletion:^(NSError* error)
	{
		dispatch_async(dispatch_get_main_queue(), ^
		{
			if(!error)
			{
				UIAlertController* installAlert = [UIAlertController alertControllerWithTitle:@"" message:@"" preferredStyle:UIAlertControllerStyleAlert];
				installAlert.attributedTitle = [appInfo detailedInfoTitle];
				NSMutableAttributedString *installDescription = [[appInfo detailedInfoDescription] mutableCopy] ?: [NSMutableAttributedString new];
				if ([trollStoreUserDefaults() boolForKey:@"TSCustomEntitlementsOverrideEnabled"])
				{
					NSString *support = [NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES) firstObject];
					NSString *overlayPath = [support stringByAppendingPathComponent:@"TSCustomEntitlements.plist"];
					NSDictionary *overlay = [NSDictionary dictionaryWithContentsOfFile:overlayPath];
					NSDictionary *byBinary = [appInfo entitlementsByBinarySubpaths];
					NSString *mainExecutableSubpath = [appInfo mainExecutableSubpath];
					NSDictionary *original = mainExecutableSubpath.length ? byBinary[mainExecutableSubpath] : nil;
					NSUInteger overridden = 0, added = 0;
					if ([overlay isKindOfClass:NSDictionary.class])
					{
						for (id key in overlay) { if (original[key] != nil) overridden++; else added++; }
					}
					NSString *summary = [NSString stringWithFormat:@"\n\n%@", [NSString stringWithFormat:NSLocalizedString(@"Entitlements change: %lu keys overridden, %lu keys added. Unspecified keys are preserved.", nil), (unsigned long)overridden, (unsigned long)added]];
					[installDescription appendAttributedString:[[NSAttributedString alloc] initWithString:summary attributes:@{NSFontAttributeName: [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote]}]];
				}
				installAlert.attributedMessage = installDescription;
				UIAlertAction* installAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Install", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
				{
					[self handleAppInstallFromFile:pathToIPA completion:completionBlock];
				}];
				[installAlert addAction:installAction];

				UIAlertAction *modifyBeforeInstallAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Modify / Repackage Before Install", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
					[TSAppRepackager presentFromViewController:TSPresentationDelegate.presentationViewController sourceIPA:pathToIPA completion:^(NSString *outputPath, NSError *repackError) {
						if (outputPath) [self presentInstallationAlertIfEnabledForFile:outputPath isRemoteInstall:NO completion:completionBlock];
						else if (repackError) {
							UIAlertController *errorAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Repackage Failed", nil) message:repackError.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
							[errorAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
							[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:nil];
						}
					}];
				}];
				[installAlert addAction:modifyBeforeInstallAction];

				UIAlertAction* editEntitlementsAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Edit Entitlements Before Install", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
				{
					[self presentEntitlementsEditorForIPA:pathToIPA completion:completionBlock];
				}];
				[installAlert addAction:editEntitlementsAction];

				UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:^(UIAlertAction* action)
				{
					if(completionBlock) completionBlock(NO, nil);
				}];
				[installAlert addAction:cancelAction];

				[TSPresentationDelegate presentViewController:installAlert animated:YES completion:nil];
			}
			else
			{
				UIAlertController* errorAlert = [UIAlertController alertControllerWithTitle:[NSString stringWithFormat:NSLocalizedString(@"Parse Error %ld", nil), error.code] message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
				UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];
				[errorAlert addAction:closeAction];

				[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:^{
					if(completionBlock) completionBlock(NO, error);
				}];
			}
		});
	}];
}

+ (void)presentEntitlementsEditorForIPA:(NSString*)pathToIPA completion:(void (^)(BOOL, NSError*))completionBlock
{
	Class editorClass = NSClassFromString(@"TSEntitlementsEditorViewController");
	if(!editorClass)
	{
		UIAlertController* errorAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil) message:NSLocalizedString(@"The Entitlements editor is unavailable in this build.", nil) preferredStyle:UIAlertControllerStyleAlert];
		[errorAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:nil]];
		[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:nil];
		if(completionBlock) completionBlock(NO, nil);
		return;
	}

	UIViewController* editor = [[editorClass alloc] init];
	void (^saveAndInstall)(void) = ^
	{
		// The editor saves/validates the plist first; only then start installation.
		[self handleAppInstallFromFile:pathToIPA completion:completionBlock];
	};
	void (^cancelInstall)(void) = ^
	{
		if(completionBlock) completionBlock(NO, nil);
	};
	@try
	{
		[editor setValue:[saveAndInstall copy] forKey:@"onSave"];
		[editor setValue:[cancelInstall copy] forKey:@"onCancel"];
		[editor setValue:[pathToIPA copy] forKey:@"sourceIPAPath"];
	}
	@catch(NSException* exception)
	{
		NSLog(@"[Entitlements] unable to connect editor callback: %@", exception);
		UIAlertController* errorAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil) message:NSLocalizedString(@"The Entitlements editor could not be connected to the installer.", nil) preferredStyle:UIAlertControllerStyleAlert];
		[errorAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:nil]];
		[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:nil];
		if(completionBlock) completionBlock(NO, nil);
		return;
	}

	UINavigationController* navigationController = [[UINavigationController alloc] initWithRootViewController:editor];
	[TSPresentationDelegate presentViewController:navigationController animated:YES completion:nil];
}

+ (void)handleAppInstallFromFile:(NSString*)pathToIPA completion:(void (^)(BOOL, NSError*))completionBlock
{
	[self handleAppInstallFromFile:pathToIPA forceInstall:NO completion:completionBlock];
}

+ (void)handleAppInstallFromRemoteURL:(NSURL*)remoteURL completion:(void (^)(BOOL, NSError*))completionBlock
{
	NSURLRequest* downloadRequest = [NSURLRequest requestWithURL:remoteURL];

	dispatch_async(dispatch_get_main_queue(), ^
	{
		NSURLSessionDownloadTask* downloadTask = [NSURLSession.sharedSession downloadTaskWithRequest:downloadRequest completionHandler:^(NSURL *location, NSURLResponse *response, NSError *error)
		{
			dispatch_async(dispatch_get_main_queue(), ^
			{
				[TSPresentationDelegate stopActivityWithCompletion:^
				{
					if(error)
					{
						UIAlertController* errorAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Error downloading app: %@", nil), error] preferredStyle:UIAlertControllerStyleAlert];
						UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];
						[errorAlert addAction:closeAction];

						[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:^
						{
							if(completionBlock) completionBlock(NO, error);
						}];
					}
					else
					{
						NSString* tmpIpaPath = [NSTemporaryDirectory() stringByAppendingPathComponent:@"tmp.ipa"];
						[[NSFileManager defaultManager] removeItemAtPath:tmpIpaPath error:nil];
						[[NSFileManager defaultManager] moveItemAtPath:location.path toPath:tmpIpaPath error:nil];
						[self presentInstallationAlertIfEnabledForFile:tmpIpaPath isRemoteInstall:YES completion:^(BOOL success, NSError* error)
						{
							[[NSFileManager defaultManager] removeItemAtPath:tmpIpaPath error:nil];
							if(completionBlock) completionBlock(success, error);
						}];
					}
				}];
			});
		}];

		[TSPresentationDelegate startActivity:NSLocalizedString(@"Downloading", nil) withCancelHandler:^
		{
			[downloadTask cancel];
		}];

		[downloadTask resume];
	});
}

+ (void)initializeBundledLdid
{
#ifndef TROLLSTORE_LITE
	// Prefer the executable that was packaged with this project. This is deliberately
	// local-only: no GitHub release lookup, version comparison, or download.
	NSString* bundledLdidPath = [[NSBundle mainBundle] pathForResource:@"ldid" ofType:nil inDirectory:@"ldid-bootstrap"];

	if(!bundledLdidPath || ![[NSFileManager defaultManager] isReadableFileAtPath:bundledLdidPath])
	{
		UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil) message:NSLocalizedString(@"The bundled custom ldid binary could not be found. Rebuild the app with your ldid in bin/ldid.", nil) preferredStyle:UIAlertControllerStyleAlert];
		[alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:nil]];
		[TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
		return;
	}

	[TSPresentationDelegate startActivity:NSLocalizedString(@"Initializing bundled ldid", nil)];
	dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^
	{
		NSString* ignoredLog = nil;
		int ret = spawnRoot(rootHelperPath(), @[@"install-ldid", bundledLdidPath], nil, &ignoredLog);
		dispatch_async(dispatch_get_main_queue(), ^
		{
			[TSPresentationDelegate stopActivityWithCompletion:^{
				if(ret != 0)
				{
					UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Failed to initialize bundled ldid (error %d).", nil), ret] preferredStyle:UIAlertControllerStyleAlert];
					[alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:nil]];
					[TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
				}
				[[NSNotificationCenter defaultCenter] postNotificationName:@"TrollStoreReloadSettingsNotification" object:nil userInfo:nil];
			}];
		});
	});
#endif
}

@end