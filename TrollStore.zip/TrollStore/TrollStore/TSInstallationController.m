#import "TSInstallationController.h"

#import "TSApplicationsManager.h"
#import "TSAppInfo.h"
#import "TSAppRepackager.h"
#import "TSPluginStore.h"
#import "TSPluginSelectionController.h"
#import <TSUtil.h>
#import <TSPresentationDelegate.h>

extern NSUserDefaults* trollStoreUserDefaults(void);

@interface TSInstallSession : NSObject
@property(nonatomic, copy) NSString *ipaPath;
@property(nonatomic, copy) NSString *entitlementsPath;
@property(nonatomic, assign) BOOL force;
@property(nonatomic, assign) NSInteger method; // 0 = installd, 1 = Custom
@property(nonatomic, assign) BOOL replaceMainEntitlements;
@property(nonatomic, assign) BOOL protectFromHomeScreenDeletion;
@property(nonatomic, assign) BOOL stealthInstall;
@property(nonatomic, copy) NSArray<NSString *> *pluginPaths;
@property(nonatomic, strong) NSMutableString *debugLog;
@property(nonatomic, strong) NSMutableDictionary<NSNumber *, NSNumber *> *retryCountsByError;
@property(nonatomic, copy) void (^completion)(BOOL, NSError *);
@property(nonatomic, assign) BOOL finished;
@end
@implementation TSInstallSession
@end

@interface TSInstallationController ()
+ (void)performInstallSession:(TSInstallSession *)session;
+ (void)presentFailureForSession:(TSInstallSession *)session error:(NSError *)error code:(int)code;
+ (void)finishInstallSession:(TSInstallSession *)session success:(BOOL)success error:(NSError *)error;
+ (void)presentEntitlementsEditorForIPA:(NSString *)pathToIPA completion:(void (^)(NSString * _Nullable, NSError * _Nullable))completionBlock;
+ (void)handleAppInstallFromFile:(NSString *)pathToIPA forceInstall:(BOOL)force entitlementsOverridePath:(NSString * _Nullable)entitlementsPath completion:(void (^)(BOOL, NSError *))completionBlock;
+ (void)beginInstallSessionForFile:(NSString *)pathToIPA force:(BOOL)force entitlementsOverridePath:(NSString * _Nullable)entitlementsPath pluginPaths:(NSArray<NSString *> *)pluginPaths completion:(void (^)(BOOL, NSError *))completionBlock;
+ (void)presentInstallationConfirmationForFile:(NSString *)pathToIPA isRemoteInstall:(BOOL)remoteInstall entitlementsOverridePath:(NSString * _Nullable)entitlementsPath forceConfirmation:(BOOL)forceConfirmation completion:(void (^)(BOOL, NSError *))completionBlock;
@end

@implementation TSInstallationController

+ (void)handleAppInstallFromFile:(NSString*)pathToIPA forceInstall:(BOOL)force completion:(void (^)(BOOL, NSError*))completionBlock
{
    [self handleAppInstallFromFile:pathToIPA forceInstall:force entitlementsOverridePath:nil completion:completionBlock];
}

+ (void)handleAppInstallFromFile:(NSString *)pathToIPA forceInstall:(BOOL)force entitlementsOverridePath:(NSString *)entitlementsPath completion:(void (^)(BOOL, NSError *))completionBlock
{
    if (pathToIPA.length == 0 || ![[NSFileManager defaultManager] isReadableFileAtPath:pathToIPA]) {
        NSError *error = [NSError errorWithDomain:TrollStoreErrorDomain code:166 userInfo:@{NSLocalizedDescriptionKey: NSLocalizedString(@"The IPA file does not exist or is not accessible.", nil)}];
        if (completionBlock) completionBlock(NO, error);
        return;
    }
    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self handleAppInstallFromFile:pathToIPA forceInstall:force entitlementsOverridePath:entitlementsPath completion:completionBlock]; });
        return;
    }
#ifndef TROLLSTORE_LITE
    NSArray<NSString *> *availablePlugins = [trollStoreUserDefaults() boolForKey:@"TSPluginInjectionEnabled"] ? [TSPluginStore availableInjectableLibraryPaths] : @[];
    if (availablePlugins.count) {
        TSPluginSelectionController *selector = [[TSPluginSelectionController alloc] initWithLibraryPaths:availablePlugins];
        __weak TSPluginSelectionController *weakSelector = selector;
        selector.completion = ^(NSArray<NSString *> *selectedPaths, BOOL cancelled) {
            __strong TSPluginSelectionController *strongSelector = weakSelector;
            [strongSelector.navigationController dismissViewControllerAnimated:YES completion:^{
                if (cancelled) { if (completionBlock) completionBlock(NO, nil); return; }
                [self beginInstallSessionForFile:pathToIPA force:force entitlementsOverridePath:entitlementsPath pluginPaths:selectedPaths completion:completionBlock];
            }];
        };
        UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:selector];
        [TSPresentationDelegate presentViewController:navigation animated:YES completion:nil];
        return;
    }
#endif
    [self beginInstallSessionForFile:pathToIPA force:force entitlementsOverridePath:entitlementsPath pluginPaths:@[] completion:completionBlock];
}

+ (void)beginInstallSessionForFile:(NSString *)pathToIPA force:(BOOL)force entitlementsOverridePath:(NSString *)entitlementsPath pluginPaths:(NSArray<NSString *> *)pluginPaths completion:(void (^)(BOOL, NSError *))completionBlock
{
    NSUserDefaults *defaults = trollStoreUserDefaults();
    NSNumber *methodNumber = [defaults objectForKey:@"installationMethod"];
    TSInstallSession *session = [TSInstallSession new];
    session.ipaPath = [pathToIPA copy];
    session.force = force;
    session.method = methodNumber ? methodNumber.integerValue : 1;
    if (session.method != 0 && session.method != 1) session.method = 1;
    session.replaceMainEntitlements = entitlementsPath.length > 0;
    session.entitlementsPath = [entitlementsPath copy];
    session.protectFromHomeScreenDeletion = [defaults boolForKey:@"TSProtectHomeScreenDeletionEnabled"];
    session.stealthInstall = [defaults boolForKey:@"TSStealthInstallEnabled"];
    session.pluginPaths = [pluginPaths copy] ?: @[];
    session.debugLog = [NSMutableString new];
    session.retryCountsByError = [NSMutableDictionary new];
    session.completion = [completionBlock copy];
    [self performInstallSession:session];
}

+ (void)performInstallSession:(TSInstallSession *)session
{
    if (session.finished) return;
    dispatch_async(dispatch_get_main_queue(), ^{
        [TSPresentationDelegate startActivity:NSLocalizedString(@"Installing", nil)];
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
            NSString *attemptLog = nil;
            TSApplicationsManager *manager = [TSApplicationsManager sharedInstance];
            int ret = [manager installIpa:session.ipaPath force:session.force installationMethod:(int)session.method
                replaceMainEntitlements:session.replaceMainEntitlements customEntitlementsPath:session.entitlementsPath
                stealthInstall:session.stealthInstall protectFromHomeScreenDeletion:session.protectFromHomeScreenDeletion
                pluginPaths:session.pluginPaths log:&attemptLog];
            if (session.debugLog.length) [session.debugLog appendString:@"\n\n========== RETRY ATTEMPT ==========\n"];
            [session.debugLog appendFormat:@"method=%@ force=%d editedEntitlements=%d protectHomeScreenDeletion=%d stealth=%d path=%@\nreturn=%d\n%@",
                session.method == 0 ? @"installd" : @"Custom", session.force, session.replaceMainEntitlements,
                session.protectFromHomeScreenDeletion, session.stealthInstall, session.ipaPath, ret, attemptLog ?: @"(no rootHelper log)"];
            if (session.pluginPaths.count) [session.debugLog appendFormat:@"\npluginInjectionPaths=%@", session.pluginPaths];
            NSError *error = ret == 0 ? nil : [manager errorForCode:ret];
            dispatch_async(dispatch_get_main_queue(), ^{
                [TSPresentationDelegate stopActivityWithCompletion:^{
                    if (ret == 0) {
                        [self finishInstallSession:session success:YES error:nil];
                    } else if (ret == 171 && !session.force) {
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:[NSString stringWithFormat:NSLocalizedString(@"Install Error %d", nil), ret] message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
                        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *action) {
                            [self finishInstallSession:session success:NO error:error];
                        }]];
                        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Force Installation", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
                            session.force = YES;
                            [self performInstallSession:session];
                        }]];
                        [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
                    } else if (ret == 171 && session.force) {
                        // Do not show Force Installation repeatedly once force=true.
                        // Let the user retry or switch method, without losing the force flag.
                        [self presentFailureForSession:session error:error code:ret];
                    } else if (ret == 182) {
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Reboot Required", nil) message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
                        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *action) {
                            [self finishInstallSession:session success:YES error:nil];
                        }]];
                        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Reboot Now", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
                            [self finishInstallSession:session success:YES error:nil];
                            spawnRoot(rootHelperPath(), @[@"reboot"], nil, nil);
                        }]];
                        [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
                    } else if (ret == 184) {
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Warning", nil) message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
                        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *action) {
                            [self finishInstallSession:session success:YES error:nil];
                        }]];
                        [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
                    } else if (ret == 193) {
                        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Provisioning Profile Warning", nil) message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
                        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *action) {
                            [self finishInstallSession:session success:YES error:nil];
                        }]];
                        [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
                    } else {
                        [self presentFailureForSession:session error:error code:ret];
                    }
                }];
            });
        });
    });
}

+ (void)presentFailureForSession:(TSInstallSession *)session error:(NSError *)error code:(int)code
{
    if (session.finished) return;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:[NSString stringWithFormat:NSLocalizedString(@"Install Error %d", nil), code] message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
    NSUInteger retries = [session.retryCountsByError[@(code)] unsignedIntegerValue];
    if (retries < 2) {
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Retry", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            session.retryCountsByError[@(code)] = @(retries + 1);
            [self performInstallSession:session];
        }]];
    }
    NSInteger alternativeMethod = session.method == 0 ? 1 : 0;
    NSString *switchTitle = alternativeMethod == 0 ? NSLocalizedString(@"Retry with installd", nil) : NSLocalizedString(@"Retry with Custom", nil);
    [alert addAction:[UIAlertAction actionWithTitle:switchTitle style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        session.retryCountsByError[@(code)] = @(retries + 1);
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            NSString *cleanupLog = nil;
            int cleanupRet = spawnRoot(rootHelperPath(), @[@"cleanup-install", session.ipaPath, [NSString stringWithFormat:@"%d", code]], nil, &cleanupLog);
            @synchronized(session.debugLog) {
                [session.debugLog appendFormat:@"\n========== PRE-RETRY CLEANUP ==========\nreturn=%d\n%@", cleanupRet, cleanupLog ?: @""];
            }
            session.method = alternativeMethod;
            [self performInstallSession:session];
        });
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Copy Debug Log", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        UIPasteboard.generalPasteboard.string = session.debugLog.copy ?: @"";
        dispatch_async(dispatch_get_main_queue(), ^{
            if (session.finished) return;
            UIAlertController *copied = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Copied", nil) message:NSLocalizedString(@"Debug log copied to the clipboard.", nil) preferredStyle:UIAlertControllerStyleAlert];
            [copied addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *okAction) {
                [self presentFailureForSession:session error:error code:code];
            }]];
            [TSPresentationDelegate presentViewController:copied animated:YES completion:nil];
        });
    }]];
    if (code == 173) {
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Open Settings", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            UIViewController *root = TSPresentationDelegate.presentationViewController;
            if ([root isKindOfClass:UITabBarController.class]) ((UITabBarController *)root).selectedIndex = 1;
        }]];
    }
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *action) {
        [self finishInstallSession:session success:NO error:error];
    }]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}

+ (void)finishInstallSession:(TSInstallSession *)session success:(BOOL)success error:(NSError *)error
{
    if (session.finished) return;
    session.finished = YES;
    if (session.completion) session.completion(success, error);
}

+ (void)presentInstallationAlertIfEnabledForFile:(NSString*)pathToIPA isRemoteInstall:(BOOL)remoteInstall completion:(void (^)(BOOL, NSError*))completionBlock
{
    BOOL editEntitlements = [trollStoreUserDefaults() boolForKey:@"TSEditEntitlementsBeforeInstallEnabled"];
    if (editEntitlements) {
        [self presentEntitlementsEditorForIPA:pathToIPA completion:^(NSString *entitlementsPath, NSError *editorError) {
            if (!entitlementsPath.length) {
                if (completionBlock) completionBlock(NO, editorError);
                return;
            }
            // The edited plist is a single-install transaction. Keep it alive through
            // plugin selection, retries and any confirmation/repackage branch, then remove it.
            void (^finish)(BOOL, NSError *) = ^(BOOL success, NSError *installError) {
                [[NSFileManager defaultManager] removeItemAtPath:entitlementsPath error:nil];
                if (completionBlock) completionBlock(success, installError);
            };
            [self presentInstallationConfirmationForFile:pathToIPA isRemoteInstall:remoteInstall
                entitlementsOverridePath:entitlementsPath forceConfirmation:YES completion:finish];
        }];
        return;
    }
    [self presentInstallationConfirmationForFile:pathToIPA isRemoteInstall:remoteInstall
        entitlementsOverridePath:nil forceConfirmation:NO completion:completionBlock];
}

+ (void)presentInstallationConfirmationForFile:(NSString *)pathToIPA isRemoteInstall:(BOOL)remoteInstall entitlementsOverridePath:(NSString *)entitlementsPath forceConfirmation:(BOOL)forceConfirmation completion:(void (^)(BOOL, NSError *))completionBlock
{
    NSNumber *configurationNumber = [trollStoreUserDefaults() objectForKey:@"installAlertConfiguration"];
    NSUInteger configuration = configurationNumber ? configurationNumber.unsignedIntegerValue : 0;
    if (configuration > 2) configuration = 0;
    BOOL skipConfirmation = !forceConfirmation && configuration > 0 && (configuration == 2 || (configuration == 1 && !remoteInstall));
    if (skipConfirmation) {
        [self handleAppInstallFromFile:pathToIPA forceInstall:NO entitlementsOverridePath:entitlementsPath completion:completionBlock];
        return;
    }

    TSAppInfo *appInfo = [[TSAppInfo alloc] initWithIPAPath:pathToIPA];
    [appInfo loadInfoWithCompletion:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            if (error) {
                UIAlertController *errorAlert = [UIAlertController alertControllerWithTitle:[NSString stringWithFormat:NSLocalizedString(@"Parse Error %ld", nil), (long)error.code]
                    message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
                [errorAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:nil]];
                [TSPresentationDelegate presentViewController:errorAlert animated:YES completion:^{ if (completionBlock) completionBlock(NO, error); }];
                return;
            }

            UIAlertController *installAlert = [UIAlertController alertControllerWithTitle:@"" message:@"" preferredStyle:UIAlertControllerStyleAlert];
            installAlert.attributedTitle = [appInfo detailedInfoTitle];
            NSMutableAttributedString *description = [[appInfo detailedInfoDescription] mutableCopy] ?: [NSMutableAttributedString new];
            if (entitlementsPath.length) {
                NSDictionary *edited = [NSDictionary dictionaryWithContentsOfFile:entitlementsPath];
                NSString *summary = [NSString stringWithFormat:@"\n\n%@", [NSString stringWithFormat:NSLocalizedString(@"Using the edited main-app Entitlements document (%lu keys). App extensions keep their original Entitlements.", nil), (unsigned long)edited.count]];
                [description appendAttributedString:[[NSAttributedString alloc] initWithString:summary attributes:@{NSFontAttributeName:[UIFont preferredFontForTextStyle:UIFontTextStyleFootnote]}]];
            }
            installAlert.attributedMessage = description;

            [installAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Install", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
                [self handleAppInstallFromFile:pathToIPA forceInstall:NO entitlementsOverridePath:entitlementsPath completion:completionBlock];
            }]];
            [installAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Modify / Repackage Before Install", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
                [TSAppRepackager presentFromViewController:TSPresentationDelegate.presentationViewController sourceIPA:pathToIPA completion:^(NSString *outputPath, NSError *repackError) {
                    if (outputPath) {
                        [self presentInstallationConfirmationForFile:outputPath isRemoteInstall:NO entitlementsOverridePath:entitlementsPath forceConfirmation:YES completion:completionBlock];
                    } else if (repackError) {
                        UIAlertController *errorAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Repackage Failed", nil) message:repackError.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
                        [errorAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *a) { if (completionBlock) completionBlock(NO, repackError); }]];
                        [TSPresentationDelegate presentViewController:errorAlert animated:YES completion:nil];
                    } else if (completionBlock) completionBlock(NO, nil);
                }];
            }]];
            [installAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *action) {
                if (completionBlock) completionBlock(NO, nil);
            }]];
            [TSPresentationDelegate presentViewController:installAlert animated:YES completion:nil];
        });
    }];
}

+ (void)presentEntitlementsEditorForIPA:(NSString*)pathToIPA completion:(void (^)(NSString * _Nullable, NSError * _Nullable))completionBlock
{
    Class editorClass = NSClassFromString(@"TSEntitlementsEditorViewController");
    if (!editorClass) {
        NSError *error = [NSError errorWithDomain:TrollStoreErrorDomain code:186 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"The Entitlements editor is unavailable in this build.", nil)}];
        UIAlertController *errorAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil) message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
        [errorAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:nil]];
        [TSPresentationDelegate presentViewController:errorAlert animated:YES completion:^{ if (completionBlock) completionBlock(nil, error); }];
        return;
    }

    UIViewController *editor = [[editorClass alloc] init];
    void (^saveAndContinue)(NSString *) = ^(NSString *entitlementsPath) {
        if (entitlementsPath.length) { if (completionBlock) completionBlock(entitlementsPath, nil); }
        else if (completionBlock) completionBlock(nil, [NSError errorWithDomain:TrollStoreErrorDomain code:186 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"The edited Entitlements file was not created.", nil)}]);
    };
    void (^cancelInstall)(void) = ^{ if (completionBlock) completionBlock(nil, nil); };
    @try {
        [editor setValue:[saveAndContinue copy] forKey:@"onSave"];
        [editor setValue:[cancelInstall copy] forKey:@"onCancel"];
        [editor setValue:[pathToIPA copy] forKey:@"sourceIPAPath"];
    } @catch (NSException *exception) {
        NSError *error = [NSError errorWithDomain:TrollStoreErrorDomain code:186 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"The Entitlements editor could not be connected to the installer.", nil)}];
        NSLog(@"[Entitlements] unable to connect editor callback: %@", exception);
        UIAlertController *errorAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil) message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
        [errorAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:nil]];
        [TSPresentationDelegate presentViewController:errorAlert animated:YES completion:^{ if (completionBlock) completionBlock(nil, error); }];
        return;
    }
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:editor];
    // Require an explicit Cancel or Done action so an interactive swipe cannot
    // dismiss the editor without completing/cancelling the install transaction.
    navigationController.modalInPresentation = YES;
    [TSPresentationDelegate presentViewController:navigationController animated:YES completion:nil];
}

+ (void)handleAppInstallFromFile:(NSString*)pathToIPA completion:(void (^)(BOOL, NSError*))completionBlock
{
	[self handleAppInstallFromFile:pathToIPA forceInstall:NO completion:completionBlock];
}

+ (void)handleAppInstallFromRemoteURL:(NSURL*)remoteURL completion:(void (^)(BOOL, NSError*))completionBlock
{
	NSURLRequest* downloadRequest = [NSURLRequest requestWithURL:remoteURL];

	dispatch_async(dispatch_get_main_queue(), ^
	{
		NSURLSessionDownloadTask* downloadTask = [NSURLSession.sharedSession downloadTaskWithRequest:downloadRequest completionHandler:^(NSURL *location, NSURLResponse *response, NSError *error)
		{
			dispatch_async(dispatch_get_main_queue(), ^
			{
				[TSPresentationDelegate stopActivityWithCompletion:^
				{
					if(error)
					{
						UIAlertController* errorAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Error downloading app: %@", nil), error] preferredStyle:UIAlertControllerStyleAlert];
						UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];
						[errorAlert addAction:closeAction];

						[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:^
						{
							if(completionBlock) completionBlock(NO, error);
						}];
					}
					else
					{
						NSString* tmpIpaPath = [NSTemporaryDirectory() stringByAppendingPathComponent:@"tmp.ipa"];
						[[NSFileManager defaultManager] removeItemAtPath:tmpIpaPath error:nil];
						[[NSFileManager defaultManager] moveItemAtPath:location.path toPath:tmpIpaPath error:nil];
						[self presentInstallationAlertIfEnabledForFile:tmpIpaPath isRemoteInstall:YES completion:^(BOOL success, NSError* error)
						{
							[[NSFileManager defaultManager] removeItemAtPath:tmpIpaPath error:nil];
							if(completionBlock) completionBlock(success, error);
						}];
					}
				}];
			});
		}];

		[TSPresentationDelegate startActivity:NSLocalizedString(@"Downloading", nil) withCancelHandler:^
		{
			[downloadTask cancel];
		}];

		[downloadTask resume];
	});
}

+ (void)initializeBundledLdid
{
#ifndef TROLLSTORE_LITE
	// Prefer the executable that was packaged with this project. This is deliberately
	// local-only: no GitHub release lookup, version comparison, or download.
	NSString* bundledLdidPath = [[NSBundle mainBundle] pathForResource:@"ldid" ofType:nil inDirectory:@"ldid-bootstrap"];

	if(!bundledLdidPath || ![[NSFileManager defaultManager] isReadableFileAtPath:bundledLdidPath])
	{
		UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil) message:NSLocalizedString(@"The bundled custom ldid binary could not be found. Rebuild the app with your ldid in bin/ldid.", nil) preferredStyle:UIAlertControllerStyleAlert];
		[alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:nil]];
		[TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
		return;
	}

	[TSPresentationDelegate startActivity:NSLocalizedString(@"Initializing bundled ldid", nil)];
	dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^
	{
		NSString* ignoredLog = nil;
		int ret = spawnRoot(rootHelperPath(), @[@"install-ldid", bundledLdidPath], nil, &ignoredLog);
		dispatch_async(dispatch_get_main_queue(), ^
		{
			[TSPresentationDelegate stopActivityWithCompletion:^{
				if(ret != 0)
				{
					UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Failed to initialize bundled ldid (error %d).", nil), ret] preferredStyle:UIAlertControllerStyleAlert];
					[alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:nil]];
					[TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
				}
				[[NSNotificationCenter defaultCenter] postNotificationName:@"TrollStoreReloadSettingsNotification" object:nil userInfo:nil];
			}];
		});
	});
#endif
}

@end