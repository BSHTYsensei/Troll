#import "TSRootViewController.h"
#import "TSAppTableViewController.h"
#import "TSAppCollectionViewController.h"
#import "TSSettingsListController.h"
#import "TSPluginStoreController.h"
#import "TSIPAPackageStore.h"
#import "TSThemeManager.h"
#import <TSUtil.h>
#import <TSPresentationDelegate.h>
#import <QuartzCore/QuartzCore.h>
#import <math.h>

@interface TSFadeScaleTabTransition : NSObject <UIViewControllerAnimatedTransitioning>
@property(nonatomic, assign) BOOL movingForward;
@end

@implementation TSFadeScaleTabTransition
- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)context {
    return UIAccessibilityIsReduceMotionEnabled() ? 0.14 : 0.24;
}

- (void)animateTransition:(id<UIViewControllerContextTransitioning>)context {
    UIView *container = context.containerView;
    UIView *toView = [context viewForKey:UITransitionContextToViewKey];
    if (!toView) {
        UIViewController *toController = [context viewControllerForKey:UITransitionContextToViewControllerKey];
        toView = toController.view;
    }
    if (!toView) {
        [context completeTransition:NO];
        return;
    }

    CGRect finalFrame = [context finalFrameForViewController:[context viewControllerForKey:UITransitionContextToViewControllerKey]];
    if (CGRectIsNull(finalFrame) || CGRectIsEmpty(finalFrame)) finalFrame = container.bounds;
    toView.frame = finalFrame;

    // Do not detach/re-add the outgoing tab's view. UITabBarController owns the
    // source view hierarchy; moving it here can cause an extra layout pass and
    // a visible hitch when returning to a large app list.
    if (toView.superview != container) [container addSubview:toView];
    else [container bringSubviewToFront:toView];

    BOOL reduceMotion = UIAccessibilityIsReduceMotionEnabled();
    CGFloat direction = self.movingForward ? 1.0 : -1.0;
    toView.alpha = 0.0;
    toView.transform = reduceMotion ? CGAffineTransformIdentity : CGAffineTransformMakeTranslation(direction * 7.0, 0.0);

    [UIView animateWithDuration:[self transitionDuration:context]
                          delay:0
                        options:UIViewAnimationOptionCurveEaseOut | UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction
                     animations:^{
        toView.alpha = 1.0;
        toView.transform = CGAffineTransformIdentity;
    } completion:^(__unused BOOL finished) {
        BOOL completed = !context.transitionWasCancelled;
        toView.alpha = 1.0;
        toView.transform = CGAffineTransformIdentity;
        [context completeTransition:completed];
    }];
}
@end

@interface TSRootViewController () <UITabBarControllerDelegate>
@property(nonatomic, strong) UIView *floatingDock;
@property(nonatomic, strong) UIVisualEffectView *dockEffect;
@property(nonatomic, strong) UIStackView *dockStack;
@property(nonatomic, strong) UIView *dockSelectionPill;
@property(nonatomic, strong) NSMutableArray<UIButton *> *dockButtons;
@property(nonatomic, assign) NSUInteger lastDockSelectedIndex;
@property(nonatomic, strong) UIColor *lastDockAccentColor;
@end

@implementation TSRootViewController
- (void)loadView {
    [super loadView];
    UIViewController *appsRoot = [trollStoreUserDefaults() integerForKey:@"TSAppListLayout"] == 1 ? [TSAppCollectionViewController new] : [TSAppTableViewController new];
    appsRoot.title = NSLocalizedString(@"Apps", nil);
    TSIPAPackageStore *packages = [TSIPAPackageStore new]; packages.title = NSLocalizedString(@"Packages", nil);
    TSPluginStoreController *plugins = [TSPluginStoreController new]; plugins.title = NSLocalizedString(@"Plugins", nil);
    TSSettingsListController *settings = [TSSettingsListController new]; settings.title = NSLocalizedString(@"Settings", nil);

    UINavigationController *appsNav = [[UINavigationController alloc] initWithRootViewController:appsRoot];
    UINavigationController *packagesNav = [[UINavigationController alloc] initWithRootViewController:packages];
    UINavigationController *pluginsNav = [[UINavigationController alloc] initWithRootViewController:plugins];
    UINavigationController *settingsNav = [[UINavigationController alloc] initWithRootViewController:settings];
    appsNav.navigationBar.prefersLargeTitles=YES;
    appsRoot.navigationItem.largeTitleDisplayMode=UINavigationItemLargeTitleDisplayModeAlways;
    packagesNav.navigationBar.prefersLargeTitles = NO;
    pluginsNav.navigationBar.prefersLargeTitles = NO;
    settingsNav.navigationBar.prefersLargeTitles=NO;
    appsNav.tabBarItem.image = [UIImage systemImageNamed:@"square.grid.2x2.fill"];
    packagesNav.tabBarItem.image = [UIImage systemImageNamed:@"archivebox.fill"];
    pluginsNav.tabBarItem.image = [UIImage systemImageNamed:@"puzzlepiece.extension.fill"];
    settingsNav.tabBarItem.image = [UIImage systemImageNamed:@"gearshape.fill"];
    self.title = NSLocalizedString(@"TrollStore", nil);
    self.viewControllers=@[appsNav,packagesNav,pluginsNav,settingsNav];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.delegate = self;
    self.dockButtons = [NSMutableArray array];
    self.lastDockSelectedIndex = NSNotFound;
    TSPresentationDelegate.presentationViewController = self;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appearanceChanged) name:@"TSAppearanceChanged" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appearanceChanged) name:@"TrollStoreReloadSettingsNotification" object:nil];
    [TSThemeManager applyAppearance];
    [self configureDock];
}
- (void)dealloc { [[NSNotificationCenter defaultCenter] removeObserver:self]; }
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    CGRect previousFrame = self.floatingDock.frame;
    [self layoutDock];
    if (!CGRectEqualToRect(previousFrame, self.floatingDock.frame)) [self updateSelectionPillAnimated:NO];
}
- (void)viewDidAppear:(BOOL)animated { [super viewDidAppear:animated]; [self updateSelectionPillAnimated:NO]; }
- (void)appearanceChanged { [self configureDock]; [self refreshDockSelection]; [self updateSelectionPillAnimated:YES]; [TSThemeManager applyToViewController:self]; }

- (void)configureDock {
    BOOL show = [TSThemeManager floatingBarEnabled] && ![TSThemeManager floatingBarHidden];
    self.tabBar.hidden = show;
    for (UIViewController *vc in self.viewControllers) {
        if ([vc isKindOfClass:UINavigationController.class]) {
            ((UINavigationController *)vc).additionalSafeAreaInsets = show ? UIEdgeInsetsMake(0, 0, [TSThemeManager floatingBarHeight] + [TSThemeManager floatingBarBottomOffset] + 14, 0) : UIEdgeInsetsZero;
        }
    }
    if (!show) {
        [self.floatingDock removeFromSuperview];
        self.floatingDock = nil; self.dockEffect = nil; self.dockStack = nil; self.dockSelectionPill = nil;
        [self.dockButtons removeAllObjects];
        return;
    }
    if (self.floatingDock && self.dockButtons.count == self.viewControllers.count) {
        [self layoutDock]; [self refreshDockSelection]; [self updateSelectionPillAnimated:NO]; return;
    }
    [self.floatingDock removeFromSuperview];
    [self.dockButtons removeAllObjects];
    self.lastDockSelectedIndex = NSNotFound;
    self.lastDockAccentColor = nil;

    CGFloat height = [TSThemeManager floatingBarHeight];
    UIView *container = [UIView new];
    container.layer.cornerCurve = kCACornerCurveContinuous;
    container.layer.cornerRadius = height / 2.0;
    container.layer.borderWidth = 0.7;
    container.layer.borderColor = [UIColor.separatorColor colorWithAlphaComponent:0.32].CGColor;
    container.layer.shadowColor = UIColor.blackColor.CGColor;
    container.layer.shadowOpacity = 0.13;
    container.layer.shadowRadius = 20;
    container.layer.shadowOffset = CGSizeMake(0, 8);
    container.clipsToBounds = NO;

    UIVisualEffectView *effect = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemMaterial]];
    effect.frame = container.bounds;
    effect.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    effect.layer.cornerRadius = height / 2.0;
    effect.clipsToBounds = YES;
    [container addSubview:effect];

    UIView *pill = [UIView new];
    pill.backgroundColor = [[TSThemeManager accentColor] colorWithAlphaComponent:0.13];
    pill.layer.cornerCurve = kCACornerCurveContinuous;
    pill.layer.cornerRadius = 18;
    pill.layer.borderWidth = 0.6;
    pill.layer.borderColor = [[TSThemeManager accentColor] colorWithAlphaComponent:0.12].CGColor;
    pill.userInteractionEnabled = NO;
    [effect.contentView addSubview:pill];

    UIStackView *stack = [UIStackView new];
    stack.axis = UILayoutConstraintAxisHorizontal;
    stack.alignment = UIStackViewAlignmentFill;
    stack.distribution = UIStackViewDistributionFillEqually;
    stack.spacing = [TSThemeManager floatingBarSpacing];
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    [effect.contentView addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[
        [stack.topAnchor constraintEqualToAnchor:effect.contentView.topAnchor constant:5],
        [stack.bottomAnchor constraintEqualToAnchor:effect.contentView.bottomAnchor constant:-5],
        [stack.leadingAnchor constraintEqualToAnchor:effect.contentView.leadingAnchor constant:9],
        [stack.trailingAnchor constraintEqualToAnchor:effect.contentView.trailingAnchor constant:-9]
    ]];

    NSArray *titles = @[NSLocalizedString(@"Apps", nil), NSLocalizedString(@"Packages", nil), NSLocalizedString(@"Plugins", nil), NSLocalizedString(@"Settings", nil)];
    NSArray *symbols = @[@"square.grid.2x2.fill", @"archivebox.fill", @"puzzlepiece.extension.fill", @"gearshape.fill"];
    for (NSUInteger i = 0; i < titles.count; i++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.tag = i;
        button.accessibilityLabel = titles[i];
        button.titleLabel.adjustsFontSizeToFitWidth = YES;
        button.titleLabel.minimumScaleFactor = 0.72;
        UIButtonConfiguration *configuration = [UIButtonConfiguration plainButtonConfiguration];
        configuration.image = [UIImage systemImageNamed:symbols[i]];
        configuration.title = titles[i];
        configuration.imagePlacement=NSDirectionalRectEdgeTop;
        configuration.imagePadding=2;
        configuration.contentInsets = NSDirectionalEdgeInsetsMake(2, 0, 2, 0);
        configuration.titleTextAttributesTransformer = ^NSDictionary *(NSDictionary *attributes) {
            NSMutableDictionary *result = [attributes mutableCopy];
            result[NSFontAttributeName] = [UIFont systemFontOfSize:10 weight:UIFontWeightSemibold];
            return result;
        };
        button.configuration = configuration;
        button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        button.layer.cornerRadius = 16;
        [button addTarget:self action:@selector(dockButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
        [stack addArrangedSubview:button];
        [self.dockButtons addObject:button];
    }

    self.floatingDock = container;
    self.dockEffect = effect;
    self.dockStack = stack;
    self.dockSelectionPill = pill;
    [self.view addSubview:container];
    [self.view bringSubviewToFront:container];
    [self layoutDock];
    [self refreshDockSelection];
    [self updateSelectionPillAnimated:NO];
}

- (void)layoutDock {
    if (!self.floatingDock || !self.tabBar.hidden) return;
    CGFloat height = [TSThemeManager floatingBarHeight];
    CGFloat margin = [TSThemeManager floatingBarHorizontalMargin];
    CGFloat bottom = self.view.safeAreaInsets.bottom + [TSThemeManager floatingBarBottomOffset];
    CGFloat width = MIN(self.view.bounds.size.width-2*margin,440);
    CGRect targetFrame = CGRectMake((self.view.bounds.size.width - width) / 2.0, self.view.bounds.size.height - bottom - height, width, height);
    if (!CGRectEqualToRect(self.floatingDock.frame, targetFrame)) self.floatingDock.frame = targetFrame;
    self.floatingDock.layer.cornerRadius = height / 2.0;
    self.dockEffect.layer.cornerRadius = height / 2.0;
    CGFloat spacing = [TSThemeManager floatingBarSpacing];
    if (fabs(self.dockStack.spacing - spacing) > 0.1) self.dockStack.spacing = spacing;
}

- (void)dockButtonPressed:(UIButton *)sender {
    NSUInteger index = (NSUInteger)sender.tag;
    if (index >= self.viewControllers.count || index == self.selectedIndex) return;
    UIImpactFeedbackGenerator *feedback = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
    [feedback prepare]; [feedback impactOccurred];
    [UIView animateWithDuration:0.13 delay:0 options:UIViewAnimationOptionBeginFromCurrentState animations:^{
        sender.transform = CGAffineTransformMakeScale(0.92, 0.92);
    } completion:^(__unused BOOL finished) {
        [UIView animateWithDuration:0.24 delay:0 usingSpringWithDamping:0.62 initialSpringVelocity:0.3 options:UIViewAnimationOptionBeginFromCurrentState animations:^{
            sender.transform = CGAffineTransformIdentity;
        } completion:nil];
    }];
    [self setSelectedIndex:index];
    // didSelectViewController performs the single selection refresh. Avoid
    // rebuilding all button configurations twice for one tap.
}

- (void)applyDockButton:(UIButton *)button selected:(BOOL)selected accent:(UIColor *)accent {
    UIColor *foreground = selected ? accent : UIColor.secondaryLabelColor;
    UIButtonConfiguration *configuration = button.configuration;
    configuration.baseForegroundColor=foreground;
    configuration.titleTextAttributesTransformer = ^NSDictionary *(NSDictionary *attributes) {
        NSMutableDictionary *updated = [attributes mutableCopy];
        updated[NSFontAttributeName] = [UIFont systemFontOfSize:10 weight:selected ? UIFontWeightBold : UIFontWeightMedium];
        return updated;
    };
    button.configuration = configuration;
    button.tintColor = foreground;
}

- (void)refreshDockSelection {
    if (!self.dockButtons.count) return;
    UIColor *accent = [TSThemeManager accentColor];
    NSUInteger selectedIndex = MIN(self.selectedIndex, self.dockButtons.count - 1);
    BOOL accentChanged = !self.lastDockAccentColor || ![self.lastDockAccentColor isEqual:accent];
    if (accentChanged) {
        for (UIButton *button in self.dockButtons) [self applyDockButton:button selected:(NSUInteger)button.tag == selectedIndex accent:accent];
        self.dockSelectionPill.backgroundColor = [accent colorWithAlphaComponent:0.13];
        self.dockSelectionPill.layer.borderColor = [accent colorWithAlphaComponent:0.14].CGColor;
        self.lastDockAccentColor = accent;
        self.lastDockSelectedIndex = selectedIndex;
        return;
    }
    if (self.lastDockSelectedIndex == selectedIndex) return;
    if (self.lastDockSelectedIndex < self.dockButtons.count) {
        [self applyDockButton:self.dockButtons[self.lastDockSelectedIndex] selected:NO accent:accent];
    }
    [self applyDockButton:self.dockButtons[selectedIndex] selected:YES accent:accent];
    self.lastDockSelectedIndex = selectedIndex;
}

- (void)updateSelectionPillAnimated:(BOOL)animated {
    if (!self.dockSelectionPill || self.selectedIndex >= self.dockButtons.count) return;
    UIButton *button = self.dockButtons[self.selectedIndex];
    CGRect target = [button convertRect:button.bounds toView:self.dockEffect.contentView];
    target = CGRectInset(target, 3, 2);
    void (^updates)(void) = ^{ self.dockSelectionPill.frame = target; };
    if (animated) [UIView animateWithDuration:0.34 delay:0 usingSpringWithDamping:0.78 initialSpringVelocity:0.35 options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction animations:updates completion:nil];
    else updates();
}

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController {
    [self refreshDockSelection];
    [self updateSelectionPillAnimated:YES];
}

- (id<UIViewControllerAnimatedTransitioning>)tabBarController:(UITabBarController *)tabBarController animationControllerForTransitionFromViewController:(UIViewController *)fromVC toViewController:(UIViewController *)toVC {
    NSUInteger fromIndex = [tabBarController.viewControllers indexOfObject:fromVC];
    NSUInteger toIndex = [tabBarController.viewControllers indexOfObject:toVC];
    TSFadeScaleTabTransition *animator = [TSFadeScaleTabTransition new];
    animator.movingForward = toIndex >= fromIndex;
    return animator;
}
@end
