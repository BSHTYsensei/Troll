#import "TSRootViewController.h"
#import "TSAppTableViewController.h"
#import "TSAppCollectionViewController.h"
#import "TSSettingsListController.h"
#import "TSPluginStoreController.h"
#import "TSIPAPackageStore.h"
#import "TSThemeManager.h"
#import <TSUtil.h>
#import <TSPresentationDelegate.h>
#import <QuartzCore/QuartzCore.h>
#import <math.h>

static const NSUInteger TSNoPendingTab = NSNotFound;

@interface TSRootViewController ()
@property(nonatomic, strong) UIView *contentContainer;
@property(nonatomic, strong) UIView *floatingDock;
@property(nonatomic, strong) UIVisualEffectView *dockEffect;
@property(nonatomic, strong) UIStackView *dockStack;
@property(nonatomic, strong) UIView *dockSelectionPill;
@property(nonatomic, strong) UIView *dockTopSeparator;
@property(nonatomic, strong) NSMutableArray<UIButton *> *dockButtons;
@property(nonatomic, strong) NSMutableArray *tabControllers;
@property(nonatomic, strong) NSMutableIndexSet *loadedTabIndexes;
@property(nonatomic, strong) UINavigationController *currentTabController;
@property(nonatomic, assign) NSUInteger currentTabIndex;
@property(nonatomic, assign) NSUInteger pendingTabIndex;
@property(nonatomic, assign) BOOL rootIsVisible;
@property(nonatomic, assign) BOOL tabTransitionInFlight;
@property(nonatomic, assign) BOOL dockIsFloating;
@property(nonatomic, strong) UIColor *lastDockAccentColor;
@property(nonatomic, assign) NSUInteger lastDockSelectedIndex;
@end

@implementation TSRootViewController

- (void)loadView {
    UIView *rootView = [UIView new];
    rootView.backgroundColor = UIColor.systemBackgroundColor;
    rootView.opaque = YES;

    UIView *content = [UIView new];
    content.translatesAutoresizingMaskIntoConstraints = NO;
    content.backgroundColor = UIColor.clearColor;
    content.clipsToBounds = NO;
    [rootView addSubview:content];
    [NSLayoutConstraint activateConstraints:@[
        [content.topAnchor constraintEqualToAnchor:rootView.topAnchor],
        [content.leadingAnchor constraintEqualToAnchor:rootView.leadingAnchor],
        [content.trailingAnchor constraintEqualToAnchor:rootView.trailingAnchor],
        [content.bottomAnchor constraintEqualToAnchor:rootView.bottomAnchor]
    ]];

    self.view = rootView;
    self.contentContainer = content;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.dockButtons = [NSMutableArray arrayWithCapacity:4];
    self.loadedTabIndexes = [NSMutableIndexSet indexSet];
    self.currentTabIndex = NSNotFound;
    self.pendingTabIndex = TSNoPendingTab;
    self.lastDockSelectedIndex = NSNotFound;
    TSPresentationDelegate.presentationViewController = self;

    // The reference design is the compact floating capsule. Apply this once
    // for users upgrading from the previous build, whose default was the
    // full-width/system-style bar. Later user changes remain respected.
    NSUserDefaults *uiDefaults = trollStoreUserDefaults();
    if (![uiDefaults boolForKey:@"TSVideoReferenceStyleMigrated"]) {
        [uiDefaults setBool:YES forKey:@"TSFloatingTabBarEnabled"];
        [uiDefaults setInteger:0 forKey:@"TSFloatingBarStyle"];
        [uiDefaults setBool:NO forKey:@"TSHideFloatingTabBar"];
        [uiDefaults setDouble:62.0 forKey:@"TSFloatingBarHeight"];
        [uiDefaults setDouble:40.0 forKey:@"TSFloatingBarMargin"];
        [uiDefaults setDouble:0.0 forKey:@"TSFloatingBarSpacing"];
        [uiDefaults setDouble:8.0 forKey:@"TSFloatingBarBottomOffset"];
        [uiDefaults setBool:YES forKey:@"TSVideoReferenceStyleMigrated"];
    }

    [self buildTabControllers];
    [self configureDock];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appearanceChanged) name:@"TSAppearanceChanged" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appearanceChanged) name:@"TrollStoreReloadSettingsNotification" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appListLayoutPreferenceChanged) name:@"TSAppListLayoutChanged" object:nil];

    // The initial tab and its navigation hierarchy are installed before the
    // window becomes visible. No stock tab bar or legacy root can be displayed
    // for an intermediate frame.
    NSUInteger initialIndex = self.pendingTabIndex == TSNoPendingTab ? 0 : self.pendingTabIndex;
    self.pendingTabIndex = TSNoPendingTab;
    [TSThemeManager applyToViewController:self];
    [self selectTabAtIndex:initialIndex animated:NO];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)appListLayoutPreferenceChanged {
    if (self.tabControllers.count == 0 || ![self.tabControllers[0] isKindOfClass:UINavigationController.class]) return;
    UINavigationController *appsNavigationController = self.tabControllers[0];
    NSInteger sourceCategory = [trollStoreUserDefaults() integerForKey:@"TSAppSourceCategory"];
    UIViewController *newRoot = nil;
    if ([trollStoreUserDefaults() integerForKey:@"TSAppListLayout"] == 1) {
        TSAppCollectionViewController *grid = [TSAppCollectionViewController new];
        grid.sourceCategory = sourceCategory;
        grid.title = NSLocalizedString(@"Apps", nil);
        newRoot = grid;
    } else {
        TSAppTableViewController *list = [TSAppTableViewController new];
        list.sourceCategory = sourceCategory;
        list.title = NSLocalizedString(@"Apps", nil);
        newRoot = list;
    }
    newRoot.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeAlways;
    [appsNavigationController setViewControllers:@[newRoot] animated:NO];
    [TSThemeManager applyNavigationAppearanceToController:appsNavigationController];
}

- (void)buildTabControllers {
    // Keep four stable slots, but construct each navigation stack only when the
    // user first opens that section. Several root controllers prepare data in
    // init/viewDidLoad, so creating every tab at launch needlessly competes with
    // the first frame and the initial Apps catalog scan.
    self.tabControllers = [NSMutableArray arrayWithObjects:
                           [NSNull null], [NSNull null], [NSNull null], [NSNull null], nil];
}

- (UINavigationController *)tabControllerAtIndex:(NSUInteger)index {
    if (index >= self.tabControllers.count) return nil;

    id existing = self.tabControllers[index];
    if ([existing isKindOfClass:UINavigationController.class]) {
        return (UINavigationController *)existing;
    }

    UIViewController *rootController = nil;
    switch (index) {
        case 0:
            rootController = [trollStoreUserDefaults() integerForKey:@"TSAppListLayout"] == 1
                ? [TSAppCollectionViewController new]
                : [TSAppTableViewController new];
            rootController.title = NSLocalizedString(@"Apps", nil);
            rootController.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeAlways;
            break;
        case 1:
            rootController = [TSIPAPackageStore new];
            rootController.title = NSLocalizedString(@"Packages", nil);
            rootController.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeAlways;
            break;
        case 2:
            rootController = [TSPluginStoreController new];
            rootController.title = NSLocalizedString(@"Plugins", nil);
            rootController.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeAlways;
            break;
        case 3:
            rootController = [TSSettingsListController new];
            rootController.title = NSLocalizedString(@"Settings", nil);
            rootController.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
            break;
        default:
            return nil;
    }

    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:rootController];
    // Apps, Packages and Plugins use the reference video's large, left-aligned
    // section heading. Settings intentionally keeps its compact centered title.
    navigationController.navigationBar.prefersLargeTitles = (index != 3);
    self.tabControllers[index] = navigationController;
    return navigationController;
}

- (BOOL)shouldAutomaticallyForwardAppearanceMethods {
    // Only the selected navigation stack is visible. Forwarding automatically
    // to every cached tab would call viewWillAppear on hidden screens and cause
    // unnecessary list refreshes when the app returns from background.
    return NO;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.currentTabController beginAppearanceTransition:YES animated:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.currentTabController endAppearanceTransition];
    self.rootIsVisible = YES;
    [self layoutDock];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.rootIsVisible = NO;
    [self.currentTabController beginAppearanceTransition:NO animated:animated];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [self.currentTabController endAppearanceTransition];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    // Auto Layout owns contentContainer's frame; only update already-loaded
    // child views when the container bounds actually changed.
    CGRect contentBounds = self.contentContainer.bounds;
    for (NSUInteger index = [self.loadedTabIndexes firstIndex];
         index != NSNotFound;
         index = [self.loadedTabIndexes indexGreaterThanIndex:index]) {
        UINavigationController *controller = [self tabControllerAtIndex:index];
        if (controller && !CGRectEqualToRect(controller.view.frame, contentBounds)) {
            controller.view.frame = contentBounds;
        }
    }
    [self layoutDock];
}

- (NSUInteger)selectedIndex {
    return self.currentTabIndex == NSNotFound ? 0 : self.currentTabIndex;
}

- (void)setSelectedIndex:(NSUInteger)selectedIndex {
    [self selectTabAtIndex:selectedIndex animated:YES];
}

- (void)ensureTabLoadedAtIndex:(NSUInteger)index {
    if (index >= self.tabControllers.count || [self.loadedTabIndexes containsIndex:index]) return;

    UINavigationController *controller = [self tabControllerAtIndex:index];
    if (!controller) return;
    [self addChildViewController:controller];
    UIView *tabView = controller.view;
    tabView.frame = self.contentContainer.bounds;
    tabView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tabView.backgroundColor = UIColor.clearColor;
    tabView.hidden = YES;
    [self.contentContainer addSubview:tabView];
    [controller didMoveToParentViewController:self];
    [self.loadedTabIndexes addIndex:index];
    [TSThemeManager applyNavigationAppearanceToController:controller];
    [self updateAdditionalSafeAreaInsets];
}

- (void)selectTabAtIndex:(NSUInteger)index animated:(BOOL)animated {
    if (index >= self.tabControllers.count) return;
    if (!self.isViewLoaded) {
        self.pendingTabIndex = index;
        return;
    }
    if (self.tabTransitionInFlight) {
        self.pendingTabIndex = index;
        return;
    }
    if (self.currentTabController && self.currentTabIndex == index) {
        [self refreshDockSelection];
        return;
    }

    [self ensureTabLoadedAtIndex:index];
    UINavigationController *toController = [self tabControllerAtIndex:index];
    if (!toController) return;
    UIView *toView = toController.view;
    toView.frame = self.contentContainer.bounds;

    UINavigationController *fromController = self.currentTabController;
    UIView *fromView = fromController.view;
    BOOL shouldAnimate = animated && self.rootIsVisible && !UIAccessibilityIsReduceMotionEnabled() && fromController != nil;

    if (!fromController) {
        toView.hidden = NO;
        toView.alpha = 1.0;
        toView.transform = CGAffineTransformIdentity;
        [self.contentContainer bringSubviewToFront:toView];
        self.currentTabController = toController;
        self.currentTabIndex = index;
        [self refreshDockSelection];
        [self updateSelectionPillAnimated:NO];
        return;
    }

    self.tabTransitionInFlight = YES;
    if (self.rootIsVisible) {
        [fromController beginAppearanceTransition:NO animated:shouldAnimate];
        [toController beginAppearanceTransition:YES animated:shouldAnimate];
    }

    // Update the tab state before animating the content. Preserve the old index
    // separately so Standard mode can slide in the correct direction.
    NSUInteger previousTabIndex = self.currentTabIndex;
    self.currentTabIndex = index;
    [self refreshDockSelection];
    [self updateSelectionPillAnimated:shouldAnimate];

    toView.hidden = NO;
    toView.alpha = shouldAnimate ? 0.0 : 1.0;
    toView.transform = CGAffineTransformIdentity;
    fromView.alpha = 1.0;
    fromView.transform = CGAffineTransformIdentity;
    [self.contentContainer bringSubviewToFront:toView];

    void (^finishTransition)(void) = ^{
        fromView.hidden = YES;
        fromView.alpha = 1.0;
        fromView.transform = CGAffineTransformIdentity;
        toView.hidden = NO;
        toView.alpha = 1.0;
        toView.transform = CGAffineTransformIdentity;

        if (self.rootIsVisible) {
            [fromController endAppearanceTransition];
            [toController endAppearanceTransition];
        }
        self.currentTabController = toController;
        self.currentTabIndex = index;
        self.tabTransitionInFlight = NO;

        NSUInteger pending = self.pendingTabIndex;
        self.pendingTabIndex = TSNoPendingTab;
        if (pending != TSNoPendingTab && pending != self.currentTabIndex) {
            dispatch_async(dispatch_get_main_queue(), ^{ [self selectTabAtIndex:pending animated:YES]; });
        }
    };

    if (!shouldAnimate) {
        finishTransition();
        return;
    }

    // The video defaults to a short fade. The optional Standard mode uses a
    // restrained native-style horizontal slide; neither path chains a delayed
    // press animation or a long spring after the user's tap.
    BOOL useStandardSlide = [trollStoreUserDefaults() integerForKey:@"TSNavigationTransitionStyle"] == 1;
    NSTimeInterval duration = useStandardSlide ? 0.22 : 0.16;
    CGFloat direction = index > previousTabIndex ? 1.0 : -1.0;
    if (useStandardSlide) {
        CGFloat offset = MIN(28.0, CGRectGetWidth(self.contentContainer.bounds) * 0.06) * direction;
        fromView.transform = CGAffineTransformIdentity;
        toView.transform = CGAffineTransformMakeTranslation(offset, 0.0);
    }
    [UIView animateWithDuration:duration
                          delay:0
                        options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction | UIViewAnimationOptionCurveEaseInOut
                     animations:^{
        fromView.alpha = useStandardSlide ? 0.92 : 0.0;
        toView.alpha = 1.0;
        if (useStandardSlide) {
            fromView.transform = CGAffineTransformMakeTranslation(-direction * MIN(28.0, CGRectGetWidth(self.contentContainer.bounds) * 0.06), 0.0);
            toView.transform = CGAffineTransformIdentity;
        }
    } completion:^(__unused BOOL finished) {
        finishTransition();
    }];
}

- (void)configureDock {
    self.dockIsFloating = [TSThemeManager floatingBarStyle] != 1;

    if (!self.floatingDock) [self buildDock];
    self.floatingDock.hidden = [TSThemeManager floatingBarHidden];
    self.floatingDock.userInteractionEnabled = YES;
    self.dockSelectionPill.hidden = !self.dockIsFloating;
    self.dockTopSeparator.hidden = self.dockIsFloating;
    self.dockEffect.effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemChromeMaterial];
    self.floatingDock.layer.borderWidth = 0.0;
    self.floatingDock.layer.shadowOpacity = self.dockIsFloating ? 0.10 : 0.0;
    self.floatingDock.layer.shadowRadius = self.dockIsFloating ? 16.0 : 0.0;
    [self updateAdditionalSafeAreaInsets];
    [self refreshDockSelection];
    [self layoutDock];
}

- (void)buildDock {
    UIView *container = [UIView new];
    container.translatesAutoresizingMaskIntoConstraints = YES;
    container.layer.cornerCurve = kCACornerCurveContinuous;
    container.layer.borderWidth = 0.0;
    container.layer.borderColor = UIColor.clearColor.CGColor;
    container.layer.shadowColor = UIColor.blackColor.CGColor;
    container.layer.shadowOpacity = self.dockIsFloating ? 0.10 : 0.0;
    container.layer.shadowRadius = self.dockIsFloating ? 16.0 : 0.0;
    container.layer.shadowOffset = CGSizeMake(0, 4);
    container.clipsToBounds = NO;

    UIVisualEffectView *effect = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemChromeMaterial]];
    effect.frame = container.bounds;
    effect.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    effect.clipsToBounds = YES;
    [container addSubview:effect];

    UIView *pill = [UIView new];
    pill.backgroundColor = UIColor.tertiarySystemFillColor;
    pill.layer.cornerCurve = kCACornerCurveContinuous;
    pill.layer.cornerRadius = 24;
    pill.layer.borderWidth = 0.0;
    pill.userInteractionEnabled = NO;
    [effect.contentView addSubview:pill];

    UIStackView *stack = [UIStackView new];
    stack.axis = UILayoutConstraintAxisHorizontal;
    stack.alignment = UIStackViewAlignmentFill;
    stack.distribution = UIStackViewDistributionFillEqually;
    stack.spacing = self.dockIsFloating ? [TSThemeManager floatingBarSpacing] : 0.0;
    stack.frame = CGRectZero;
    [effect.contentView addSubview:stack];

    UIView *separator = [UIView new];
    separator.backgroundColor = [UIColor.separatorColor colorWithAlphaComponent:0.38];
    separator.userInteractionEnabled = NO;
    [effect.contentView addSubview:separator];

    NSArray *titles = @[NSLocalizedString(@"Apps", nil), NSLocalizedString(@"Packages", nil), NSLocalizedString(@"Plugins", nil), NSLocalizedString(@"Settings", nil)];
    NSArray *symbols = @[@"square.grid.3x3.fill", @"shippingbox.fill", @"puzzlepiece.fill", @"gearshape.fill"];
    for (NSUInteger index = 0; index < titles.count; index++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.tag = index;
        button.accessibilityLabel = titles[index];
        button.accessibilityTraits = UIAccessibilityTraitButton;
        button.titleLabel.adjustsFontSizeToFitWidth = YES;
        button.titleLabel.minimumScaleFactor = 0.72;
        UIButtonConfiguration *configuration = [UIButtonConfiguration plainButtonConfiguration];
        UIImageSymbolConfiguration *symbolConfiguration = [UIImageSymbolConfiguration configurationWithPointSize:16.0 weight:UIImageSymbolWeightRegular];
        configuration.image = [UIImage systemImageNamed:symbols[index] withConfiguration:symbolConfiguration];
        configuration.title = titles[index];
        configuration.imagePlacement = NSDirectionalRectEdgeTop;
        configuration.imagePadding = 2;
        configuration.contentInsets = NSDirectionalEdgeInsetsMake(3, 1, 3, 1);
        configuration.titleTextAttributesTransformer = ^NSDictionary *(NSDictionary *attributes) {
            NSMutableDictionary *result = [attributes mutableCopy];
            result[NSFontAttributeName] = [UIFont systemFontOfSize:10.5 weight:UIFontWeightMedium];
            return result;
        };
        button.configuration = configuration;
        button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        button.layer.cornerRadius = 16;
        [button addTarget:self action:@selector(dockButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
        [stack addArrangedSubview:button];
        [self.dockButtons addObject:button];
    }

    self.floatingDock = container;
    self.dockEffect = effect;
    self.dockStack = stack;
    self.dockSelectionPill = pill;
    self.dockTopSeparator = separator;
    [self.view addSubview:container];
    [self.view bringSubviewToFront:container];
}

- (void)updateAdditionalSafeAreaInsets {
    CGFloat bottom = [TSThemeManager floatingBarHidden] ? 0.0 : (self.dockIsFloating ? [TSThemeManager floatingBarHeight] + [TSThemeManager floatingBarBottomOffset] + 14.0 : 52.0);
    for (NSUInteger index = [self.loadedTabIndexes firstIndex];
         index != NSNotFound;
         index = [self.loadedTabIndexes indexGreaterThanIndex:index]) {
        UINavigationController *controller = [self tabControllerAtIndex:index];
        if (!controller) continue;
        UIEdgeInsets insets = controller.additionalSafeAreaInsets;
        if (fabs(insets.bottom - bottom) > 0.5) {
            insets.bottom = bottom;
            controller.additionalSafeAreaInsets = insets;
        }
    }
}

- (void)layoutDock {
    if (!self.floatingDock || !self.isViewLoaded) return;

    CGFloat safeBottom = self.view.safeAreaInsets.bottom;
    CGFloat width = self.view.bounds.size.width;
    // Standard mode follows the full-width iOS tab bar geometry. Floating mode
    // remains available as an optional appearance setting.
    CGFloat height = self.dockIsFloating ? [TSThemeManager floatingBarHeight] : 52.0 + safeBottom;
    NSInteger dockStyle = [TSThemeManager floatingBarStyle];
    CGFloat margin = self.dockIsFloating ? (dockStyle == 2 ? MAX(18.0, [TSThemeManager floatingBarHorizontalMargin] - 14.0) : [TSThemeManager floatingBarHorizontalMargin]) : 0.0;
    CGFloat dockWidth = self.dockIsFloating ? MIN(width - 2.0 * margin, 440.0) : width;
    CGFloat bottomOffset = self.dockIsFloating ? [TSThemeManager floatingBarBottomOffset] : 0.0;
    CGFloat originY = self.dockIsFloating ? CGRectGetHeight(self.view.bounds) - safeBottom - bottomOffset - height : CGRectGetHeight(self.view.bounds) - height;
    CGRect frame = CGRectMake((width - dockWidth) / 2.0, originY, dockWidth, height);
    BOOL dockFrameChanged = !CGRectEqualToRect(self.floatingDock.frame, frame);
    if (dockFrameChanged) self.floatingDock.frame = frame;

    CGFloat radius = self.dockIsFloating ? height / 2.0 : 0.0;
    self.floatingDock.layer.cornerRadius = radius;
    self.floatingDock.layer.maskedCorners = self.dockIsFloating ? (kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner | kCALayerMinXMaxYCorner | kCALayerMaxXMaxYCorner) : 0;
    self.floatingDock.layer.shadowOpacity = self.dockIsFloating ? 0.10 : 0.0;
    self.floatingDock.layer.shadowRadius = self.dockIsFloating ? 16.0 : 0.0;
    if (dockFrameChanged || !self.floatingDock.layer.shadowPath) {
        self.floatingDock.layer.shadowPath = self.dockIsFloating
            ? [UIBezierPath bezierPathWithRoundedRect:self.floatingDock.bounds cornerRadius:radius].CGPath
            : nil;
    }
    self.dockEffect.layer.cornerRadius = radius;
    self.dockEffect.layer.maskedCorners = self.floatingDock.layer.maskedCorners;

    CGFloat stackTop = self.dockIsFloating ? 4.0 : 2.0;
    CGFloat stackBottom = self.dockIsFloating ? 4.0 : safeBottom + 2.0;
    CGFloat horizontalInset = self.dockIsFloating ? 5.0 : 8.0;
    self.dockStack.frame = CGRectMake(horizontalInset,
                                      stackTop,
                                      MAX(0, dockWidth - horizontalInset * 2.0),
                                      MAX(0, height - stackTop - stackBottom));
    self.dockStack.spacing = self.dockIsFloating ? [TSThemeManager floatingBarSpacing] : 0.0;
    self.dockTopSeparator.frame = CGRectMake(0.0, 0.0, dockWidth, 0.5);
    [self updateSelectionPillAnimated:NO];
}

- (void)dockButtonPressed:(UIButton *)sender {
    NSUInteger index = (NSUInteger)sender.tag;
    if (index >= self.tabControllers.count || index == self.currentTabIndex) return;

    UIImpactFeedbackGenerator *feedback = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
    [feedback prepare];
    [feedback impactOccurred];

    // The old 120 ms press animation followed by a 240 ms spring release was
    // decorative but made the bar feel sluggish. Selection feedback is now
    // carried by the immediate tint/indicator update instead.
    [self selectTabAtIndex:index animated:YES];
}

- (void)applyDockButton:(UIButton *)button selected:(BOOL)selected accent:(UIColor *)accent {
    UIColor *foreground = selected ? accent : UIColor.secondaryLabelColor;
    UIButtonConfiguration *configuration = button.configuration;
    configuration.baseForegroundColor = foreground;
    configuration.titleTextAttributesTransformer = ^NSDictionary *(NSDictionary *attributes) {
        NSMutableDictionary *updated = [attributes mutableCopy];
        updated[NSFontAttributeName] = [UIFont systemFontOfSize:10.5 weight:selected ? UIFontWeightSemibold : UIFontWeightMedium];
        return updated;
    };
    button.configuration = configuration;
    button.tintColor = foreground;
    button.accessibilityTraits = selected ? (UIAccessibilityTraitButton | UIAccessibilityTraitSelected) : UIAccessibilityTraitButton;
}

- (void)refreshDockSelection {
    if (!self.dockButtons.count) return;
    UIColor *accent = [TSThemeManager accentColor];
    NSUInteger selected = MIN(self.selectedIndex, self.dockButtons.count - 1);
    BOOL accentChanged = !self.lastDockAccentColor || ![self.lastDockAccentColor isEqual:accent];

    if (accentChanged) {
        for (UIButton *button in self.dockButtons) [self applyDockButton:button selected:(NSUInteger)button.tag == selected accent:accent];
        self.dockSelectionPill.backgroundColor = UIColor.tertiarySystemFillColor;
        self.lastDockAccentColor = accent;
        self.lastDockSelectedIndex = selected;
        return;
    }

    if (self.lastDockSelectedIndex == selected) return;
    if (self.lastDockSelectedIndex < self.dockButtons.count) {
        [self applyDockButton:self.dockButtons[self.lastDockSelectedIndex] selected:NO accent:accent];
    }
    [self applyDockButton:self.dockButtons[selected] selected:YES accent:accent];
    self.lastDockSelectedIndex = selected;
}

- (void)updateSelectionPillAnimated:(BOOL)animated {
    if (!self.dockIsFloating) {
        self.dockSelectionPill.hidden = YES;
        return;
    }
    self.dockSelectionPill.hidden = NO;
    if (!self.dockSelectionPill || self.selectedIndex >= self.dockButtons.count) return;
    UIButton *button = self.dockButtons[self.selectedIndex];
    CGRect target = [button convertRect:button.bounds toView:self.dockEffect.contentView];
    target = CGRectInset(target, 3.0, 3.0);
    if (CGRectEqualToRect(self.dockSelectionPill.frame, target)) return;
    void (^updates)(void) = ^{
        if (!CGRectEqualToRect(self.dockSelectionPill.frame, target)) {
            self.dockSelectionPill.frame = target;
        }
    };
    if (animated && !UIAccessibilityIsReduceMotionEnabled()) {
        [UIView animateWithDuration:0.18 delay:0 options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction | UIViewAnimationOptionCurveEaseInOut animations:updates completion:nil];
    } else {
        updates();
    }
}

- (void)appearanceChanged {
    [TSThemeManager applyToViewController:self];
    // configureDock already updates the selected state, material geometry and
    // selection pill. Avoid a second full pass for the same notification.
    [self configureDock];
    [self setNeedsStatusBarAppearanceUpdate];
}

@end
