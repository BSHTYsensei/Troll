#import "TSRootViewController.h"
#import "TSAppTableViewController.h"
#import "TSAppCollectionViewController.h"
#import "TSSettingsListController.h"
#import "TSPluginStoreController.h"
#import "TSIPAPackageStore.h"
#import "TSThemeManager.h"
#import <TSUtil.h>
#import <TSPresentationDelegate.h>
#import <QuartzCore/QuartzCore.h>


@interface TSFadeScaleTabTransition : NSObject <UIViewControllerAnimatedTransitioning>
@property(nonatomic,assign) BOOL presenting;
@end
@implementation TSFadeScaleTabTransition
- (NSTimeInterval)transitionDuration:(id<UIViewControllerContextTransitioning>)transitionContext { return 0.22; }
- (void)animateTransition:(id<UIViewControllerContextTransitioning>)context {
    UIViewController *from=[context viewControllerForKey:UITransitionContextFromViewControllerKey];
    UIViewController *to=[context viewControllerForKey:UITransitionContextToViewControllerKey];
    UIView *container=context.containerView;
    CGRect final=[context finalFrameForViewController:to];
    to.view.frame=final; to.view.alpha=0.35; to.view.transform=CGAffineTransformMakeScale(0.985,0.985);
    if (!to.view.superview) [container addSubview:to.view];
    [UIView animateWithDuration:[self transitionDuration:context] delay:0 options:UIViewAnimationOptionCurveEaseOut|UIViewAnimationOptionBeginFromCurrentState animations:^{
        to.view.alpha=1; to.view.transform=CGAffineTransformIdentity; from.view.alpha=0.82;
    } completion:^(BOOL finished){ from.view.alpha=1; [context completeTransition:![context transitionWasCancelled]]; }];
}
@end

@interface TSRootViewController () <UITabBarControllerDelegate>
@property(nonatomic,strong) UIView *floatingDock;
@property(nonatomic,strong) UIVisualEffectView *dockEffect;
@property(nonatomic,strong) UIStackView *dockStack;
@property(nonatomic,strong) NSMutableArray<UIButton *> *dockButtons;
@end
@implementation TSRootViewController
- (void)loadView {
    [super loadView];
    UIViewController *appsRoot=nil;
    if ([trollStoreUserDefaults() integerForKey:@"TSAppListLayout"] == 1) appsRoot=[TSAppCollectionViewController new]; else appsRoot=[TSAppTableViewController new];
    appsRoot.title=NSLocalizedString(@"Apps",nil);
    TSIPAPackageStore *packages=[TSIPAPackageStore new]; packages.title=NSLocalizedString(@"Packages",nil);
    TSPluginStoreController *plugins=[TSPluginStoreController new]; plugins.title=NSLocalizedString(@"Plugins",nil);
    TSSettingsListController *settings=[TSSettingsListController new]; settings.title=NSLocalizedString(@"Settings",nil);
    UINavigationController *appsNav=[[UINavigationController alloc] initWithRootViewController:appsRoot];
    UINavigationController *packagesNav=[[UINavigationController alloc] initWithRootViewController:packages];
    UINavigationController *pluginsNav=[[UINavigationController alloc] initWithRootViewController:plugins];
    UINavigationController *settingsNav=[[UINavigationController alloc] initWithRootViewController:settings];
    appsNav.tabBarItem.image=[UIImage systemImageNamed:@"square.grid.2x2.fill"]; packagesNav.tabBarItem.image=[UIImage systemImageNamed:@"archivebox.fill"]; pluginsNav.tabBarItem.image=[UIImage systemImageNamed:@"puzzlepiece.extension.fill"]; settingsNav.tabBarItem.image=[UIImage systemImageNamed:@"gearshape.fill"];
    self.title=NSLocalizedString(@"TrollStore",nil); self.viewControllers=@[appsNav,packagesNav,pluginsNav,settingsNav];
}
- (void)viewDidLoad {
    [super viewDidLoad]; self.delegate=self; self.dockButtons=[NSMutableArray array];
    TSPresentationDelegate.presentationViewController=self;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appearanceChanged) name:@"TSAppearanceChanged" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appearanceChanged) name:@"TrollStoreReloadSettingsNotification" object:nil];
    [TSThemeManager applyAppearance]; [self configureDock];
}
- (void)dealloc { [[NSNotificationCenter defaultCenter] removeObserver:self]; }
- (void)viewDidLayoutSubviews { [super viewDidLayoutSubviews]; [self layoutDock]; }
- (void)appearanceChanged { [self configureDock]; [TSThemeManager applyToViewController:self]; }
- (void)configureDock {
    BOOL show=[TSThemeManager floatingBarEnabled] && ![TSThemeManager floatingBarHidden];
    self.tabBar.hidden=show;
    for (UIViewController *vc in self.viewControllers) if ([vc isKindOfClass:UINavigationController.class]) ((UINavigationController *)vc).additionalSafeAreaInsets=show?UIEdgeInsetsMake(0,0,[TSThemeManager floatingBarHeight]+[TSThemeManager floatingBarBottomOffset]+14,0):UIEdgeInsetsZero;
    if (!show) { [self.floatingDock removeFromSuperview]; self.floatingDock=nil; self.dockEffect=nil; self.dockStack=nil; [self.dockButtons removeAllObjects]; return; }
    if (self.floatingDock && self.dockButtons.count==self.viewControllers.count) { [self layoutDock]; [self refreshDockSelection]; return; }
    [self.floatingDock removeFromSuperview]; [self.dockButtons removeAllObjects];
    UIView *container=[UIView new]; container.translatesAutoresizingMaskIntoConstraints=YES; container.layer.cornerCurve=kCACornerCurveContinuous; container.layer.cornerRadius=[TSThemeManager floatingBarHeight]/2; container.layer.shadowColor=UIColor.blackColor.CGColor; container.layer.shadowOpacity=0.16; container.layer.shadowRadius=16; container.layer.shadowOffset=CGSizeMake(0,6); container.clipsToBounds=NO;
    UIVisualEffectView *effect=[[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemMaterial]]; effect.frame=container.bounds; effect.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight; effect.layer.cornerRadius=container.layer.cornerRadius; effect.clipsToBounds=YES; [container addSubview:effect];
    UIStackView *stack=[UIStackView new]; stack.axis=UILayoutConstraintAxisHorizontal; stack.alignment=UIStackViewAlignmentFill; stack.distribution=UIStackViewDistributionFillEqually; stack.spacing=[TSThemeManager floatingBarSpacing]; stack.translatesAutoresizingMaskIntoConstraints=NO; [effect.contentView addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[[stack.topAnchor constraintEqualToAnchor:effect.contentView.topAnchor constant:5],[stack.bottomAnchor constraintEqualToAnchor:effect.contentView.bottomAnchor constant:-5],[stack.leadingAnchor constraintEqualToAnchor:effect.contentView.leadingAnchor constant:10],[stack.trailingAnchor constraintEqualToAnchor:effect.contentView.trailingAnchor constant:-10]]];
    NSArray *titles=@[NSLocalizedString(@"Apps",nil),NSLocalizedString(@"Packages",nil),NSLocalizedString(@"Plugins",nil),NSLocalizedString(@"Settings",nil)]; NSArray *symbols=@[@"square.grid.2x2.fill",@"archivebox.fill",@"puzzlepiece.extension.fill",@"gearshape.fill"];
    for (NSUInteger i=0;i<titles.count;i++) {
        UIButton *button=[UIButton buttonWithType:UIButtonTypeSystem]; button.tag=i; button.accessibilityLabel=titles[i]; button.titleLabel.adjustsFontSizeToFitWidth=YES; button.titleLabel.minimumScaleFactor=0.7; button.tintColor=[TSThemeManager accentColor];
        UIImage *image=[UIImage systemImageNamed:symbols[i]];
        UIButtonConfiguration *configuration=[UIButtonConfiguration plainButtonConfiguration];
        configuration.image=image; configuration.title=titles[i]; configuration.imagePlacement=NSDirectionalRectEdgeTop; configuration.imagePadding=2; configuration.contentInsets=NSDirectionalEdgeInsetsMake(2,0,2,0);
        configuration.titleTextAttributesTransformer=^NSDictionary *(NSDictionary *attributes) { NSMutableDictionary *updated=[attributes mutableCopy]; updated[NSFontAttributeName]=[UIFont systemFontOfSize:10 weight:UIFontWeightSemibold]; return updated; };
        button.configuration=configuration; button.contentHorizontalAlignment=UIControlContentHorizontalAlignmentCenter; button.layer.cornerRadius=12; [button addTarget:self action:@selector(dockButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
        [stack addArrangedSubview:button]; [self.dockButtons addObject:button];
    }
    self.floatingDock=container; self.dockEffect=effect; self.dockStack=stack; [self.view addSubview:container]; [self.view bringSubviewToFront:container]; [self layoutDock]; [self refreshDockSelection];
}
- (void)layoutDock {
    if (!self.floatingDock || self.tabBar.hidden==NO) return;
    CGFloat h=[TSThemeManager floatingBarHeight], margin=[TSThemeManager floatingBarHorizontalMargin], bottom=self.view.safeAreaInsets.bottom+[TSThemeManager floatingBarBottomOffset];
    CGFloat width=MIN(self.view.bounds.size.width-2*margin,440); self.floatingDock.frame=CGRectMake((self.view.bounds.size.width-width)/2, self.view.bounds.size.height-bottom-h, width,h);
    self.floatingDock.layer.cornerRadius=h/2; self.dockEffect.layer.cornerRadius=h/2; self.dockStack.spacing=[TSThemeManager floatingBarSpacing];
}
- (void)dockButtonPressed:(UIButton *)sender {
    NSUInteger index=(NSUInteger)sender.tag; if(index>=self.viewControllers.count)return;
    UIImpactFeedbackGenerator *feedback=[[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight]; [feedback prepare]; [feedback impactOccurred];
    [UIView animateWithDuration:0.12 animations:^{ sender.transform=CGAffineTransformMakeScale(0.92,0.92); } completion:^(__unused BOOL done){ [UIView animateWithDuration:0.18 delay:0 usingSpringWithDamping:0.66 initialSpringVelocity:0 options:UIViewAnimationOptionBeginFromCurrentState animations:^{ sender.transform=CGAffineTransformIdentity; } completion:nil]; }];
    [self setSelectedIndex:index];
}
- (void)refreshDockSelection {
    for (UIButton *button in self.dockButtons) {
        BOOL selected=(NSUInteger)button.tag==self.selectedIndex;
        UIColor *foreground=selected?[TSThemeManager accentColor]:UIColor.secondaryLabelColor;
        button.tintColor=foreground;
        UIButtonConfiguration *configuration=button.configuration;
        configuration.baseForegroundColor=foreground;
        UIBackgroundConfiguration *background=[UIBackgroundConfiguration clearConfiguration];
        background.backgroundColor=UIColor.clearColor;
        background.cornerRadius=12;
        configuration.background=background;
        configuration.titleTextAttributesTransformer=^NSDictionary *(NSDictionary *attributes) {
            NSMutableDictionary *updated=[attributes mutableCopy];
            updated[NSFontAttributeName]=[UIFont systemFontOfSize:10 weight:selected?UIFontWeightBold:UIFontWeightMedium];
            return updated;
        };
        button.configuration=configuration;
    }
}
- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController { [self refreshDockSelection]; }
- (id<UIViewControllerAnimatedTransitioning>)tabBarController:(UITabBarController *)tabBarController animationControllerForTransitionFromViewController:(UIViewController *)fromVC toViewController:(UIViewController *)toVC {
    TSFadeScaleTabTransition *animator=[TSFadeScaleTabTransition new]; animator.presenting=YES; return animator;
}
@end
