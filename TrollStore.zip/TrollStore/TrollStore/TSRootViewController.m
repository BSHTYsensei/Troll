#import "TSRootViewController.h"
#import "TSAppTableViewController.h"
#import "TSAppCollectionViewController.h"
#import "TSSettingsListController.h"
#import "TSPluginStoreController.h"
#import "TSIPAPackageStore.h"
#import "TSThemeManager.h"
#import <TSUtil.h>
#import <TSPresentationDelegate.h>
#import <QuartzCore/QuartzCore.h>
#import <math.h>

static const NSUInteger TSNoPendingTab = NSNotFound;

@interface TSRootViewController ()
@property(nonatomic, strong) UIView *contentContainer;
@property(nonatomic, strong) UIView *floatingDock;
@property(nonatomic, strong) UIVisualEffectView *dockEffect;
@property(nonatomic, strong) UIStackView *dockStack;
@property(nonatomic, strong) UIView *dockSelectionPill;
@property(nonatomic, strong) NSMutableArray<UIButton *> *dockButtons;
@property(nonatomic, strong) NSArray<UINavigationController *> *tabControllers;
@property(nonatomic, strong) NSMutableIndexSet *loadedTabIndexes;
@property(nonatomic, strong) UINavigationController *currentTabController;
@property(nonatomic, assign) NSUInteger currentTabIndex;
@property(nonatomic, assign) NSUInteger pendingTabIndex;
@property(nonatomic, assign) BOOL rootIsVisible;
@property(nonatomic, assign) BOOL tabTransitionInFlight;
@property(nonatomic, assign) BOOL dockIsFloating;
@property(nonatomic, strong) UIColor *lastDockAccentColor;
@property(nonatomic, assign) NSUInteger lastDockSelectedIndex;
@end

@implementation TSRootViewController

- (void)loadView {
    UIView *rootView = [UIView new];
    rootView.backgroundColor = UIColor.systemBackgroundColor;
    rootView.opaque = YES;

    UIView *content = [UIView new];
    content.translatesAutoresizingMaskIntoConstraints = NO;
    content.backgroundColor = UIColor.clearColor;
    content.clipsToBounds = NO;
    [rootView addSubview:content];
    [NSLayoutConstraint activateConstraints:@[
        [content.topAnchor constraintEqualToAnchor:rootView.topAnchor],
        [content.leadingAnchor constraintEqualToAnchor:rootView.leadingAnchor],
        [content.trailingAnchor constraintEqualToAnchor:rootView.trailingAnchor],
        [content.bottomAnchor constraintEqualToAnchor:rootView.bottomAnchor]
    ]];

    self.view = rootView;
    self.contentContainer = content;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    self.dockButtons = [NSMutableArray arrayWithCapacity:4];
    self.loadedTabIndexes = [NSMutableIndexSet indexSet];
    self.currentTabIndex = NSNotFound;
    self.pendingTabIndex = TSNoPendingTab;
    self.lastDockSelectedIndex = NSNotFound;
    TSPresentationDelegate.presentationViewController = self;

    [self buildTabControllers];
    [self configureDock];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appearanceChanged) name:@"TSAppearanceChanged" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appearanceChanged) name:@"TrollStoreReloadSettingsNotification" object:nil];

    // The initial tab and its navigation hierarchy are installed before the
    // window becomes visible. No stock tab bar or legacy root can be displayed
    // for an intermediate frame.
    NSUInteger initialIndex = self.pendingTabIndex == TSNoPendingTab ? 0 : self.pendingTabIndex;
    self.pendingTabIndex = TSNoPendingTab;
    [TSThemeManager applyToViewController:self];
    [self selectTabAtIndex:initialIndex animated:NO];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)buildTabControllers {
    UIViewController *appsRoot = [trollStoreUserDefaults() integerForKey:@"TSAppListLayout"] == 1 ? [TSAppCollectionViewController new] : [TSAppTableViewController new];
    appsRoot.title = NSLocalizedString(@"Apps", nil);

    TSIPAPackageStore *packages = [TSIPAPackageStore new];
    packages.title = NSLocalizedString(@"Packages", nil);

    TSPluginStoreController *plugins = [TSPluginStoreController new];
    plugins.title = NSLocalizedString(@"Plugins", nil);

    TSSettingsListController *settings = [TSSettingsListController new];
    settings.title = NSLocalizedString(@"Settings", nil);

    UINavigationController *appsNavigation = [[UINavigationController alloc] initWithRootViewController:appsRoot];
    UINavigationController *packagesNavigation = [[UINavigationController alloc] initWithRootViewController:packages];
    UINavigationController *pluginsNavigation = [[UINavigationController alloc] initWithRootViewController:plugins];
    UINavigationController *settingsNavigation = [[UINavigationController alloc] initWithRootViewController:settings];

    appsNavigation.navigationBar.prefersLargeTitles = YES;
    appsRoot.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeAlways;
    packagesNavigation.navigationBar.prefersLargeTitles = NO;
    pluginsNavigation.navigationBar.prefersLargeTitles = NO;
    settingsNavigation.navigationBar.prefersLargeTitles = NO;

    self.tabControllers = @[appsNavigation, packagesNavigation, pluginsNavigation, settingsNavigation];
}

- (BOOL)shouldAutomaticallyForwardAppearanceMethods {
    // Only the selected navigation stack is visible. Forwarding automatically
    // to every cached tab would call viewWillAppear on hidden screens and cause
    // unnecessary list refreshes when the app returns from background.
    return NO;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self.currentTabController beginAppearanceTransition:YES animated:animated];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self.currentTabController endAppearanceTransition];
    self.rootIsVisible = YES;
    [self layoutDock];
    [self updateSelectionPillAnimated:NO];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    self.rootIsVisible = NO;
    [self.currentTabController beginAppearanceTransition:NO animated:animated];
}

- (void)viewDidDisappear:(BOOL)animated {
    [super viewDidDisappear:animated];
    [self.currentTabController endAppearanceTransition];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.contentContainer.frame = self.view.bounds;
    for (NSNumber *number in self.loadedTabIndexes) {
        UINavigationController *controller = self.tabControllers[number.unsignedIntegerValue];
        controller.view.frame = self.contentContainer.bounds;
    }
    [self layoutDock];
}

- (NSUInteger)selectedIndex {
    return self.currentTabIndex == NSNotFound ? 0 : self.currentTabIndex;
}

- (void)setSelectedIndex:(NSUInteger)selectedIndex {
    [self selectTabAtIndex:selectedIndex animated:YES];
}

- (void)ensureTabLoadedAtIndex:(NSUInteger)index {
    if (index >= self.tabControllers.count || [self.loadedTabIndexes containsIndex:index]) return;

    UINavigationController *controller = self.tabControllers[index];
    [self addChildViewController:controller];
    UIView *tabView = controller.view;
    tabView.frame = self.contentContainer.bounds;
    tabView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    tabView.backgroundColor = UIColor.clearColor;
    tabView.hidden = YES;
    [self.contentContainer addSubview:tabView];
    [controller didMoveToParentViewController:self];
    [self.loadedTabIndexes addIndex:index];
    [TSThemeManager applyNavigationAppearanceToController:controller];
    [self updateAdditionalSafeAreaInsets];
}

- (void)selectTabAtIndex:(NSUInteger)index animated:(BOOL)animated {
    if (index >= self.tabControllers.count) return;
    if (!self.isViewLoaded) {
        self.pendingTabIndex = index;
        return;
    }
    if (self.tabTransitionInFlight) {
        self.pendingTabIndex = index;
        return;
    }
    if (self.currentTabController && self.currentTabIndex == index) {
        [self refreshDockSelection];
        return;
    }

    [self ensureTabLoadedAtIndex:index];
    UINavigationController *toController = self.tabControllers[index];
    UIView *toView = toController.view;
    toView.frame = self.contentContainer.bounds;

    UINavigationController *fromController = self.currentTabController;
    UIView *fromView = fromController.view;
    BOOL shouldAnimate = animated && self.rootIsVisible && !UIAccessibilityIsReduceMotionEnabled() && fromController != nil;

    if (!fromController) {
        toView.hidden = NO;
        toView.alpha = 1.0;
        toView.transform = CGAffineTransformIdentity;
        [self.contentContainer bringSubviewToFront:toView];
        self.currentTabController = toController;
        self.currentTabIndex = index;
        [self refreshDockSelection];
        [self updateSelectionPillAnimated:NO];
        return;
    }

    self.tabTransitionInFlight = YES;
    if (self.rootIsVisible) {
        [fromController beginAppearanceTransition:NO animated:shouldAnimate];
        [toController beginAppearanceTransition:YES animated:shouldAnimate];
    }

    toView.hidden = NO;
    toView.alpha = shouldAnimate ? 0.0 : 1.0;
    toView.transform = shouldAnimate ? CGAffineTransformMakeTranslation((index > self.currentTabIndex ? 1.0 : -1.0) * 9.0, 0.0) : CGAffineTransformIdentity;
    [self.contentContainer bringSubviewToFront:toView];

    void (^finishTransition)(void) = ^{
        fromView.hidden = YES;
        fromView.alpha = 1.0;
        fromView.transform = CGAffineTransformIdentity;
        toView.hidden = NO;
        toView.alpha = 1.0;
        toView.transform = CGAffineTransformIdentity;

        if (self.rootIsVisible) {
            [fromController endAppearanceTransition];
            [toController endAppearanceTransition];
        }
        self.currentTabController = toController;
        self.currentTabIndex = index;
        self.tabTransitionInFlight = NO;
        [self refreshDockSelection];
        [self updateSelectionPillAnimated:YES];

        NSUInteger pending = self.pendingTabIndex;
        self.pendingTabIndex = TSNoPendingTab;
        if (pending != TSNoPendingTab && pending != self.currentTabIndex) {
            dispatch_async(dispatch_get_main_queue(), ^{ [self selectTabAtIndex:pending animated:YES]; });
        }
    };

    if (!shouldAnimate) {
        finishTransition();
        return;
    }

    CGFloat direction = index > self.currentTabIndex ? -1.0 : 1.0;
    fromView.transform = CGAffineTransformIdentity;
    [UIView animateWithDuration:0.27
                          delay:0
         usingSpringWithDamping:0.94
          initialSpringVelocity:0.16
                        options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction | UIViewAnimationOptionCurveEaseOut
                     animations:^{
        fromView.alpha = 0.88;
        fromView.transform = CGAffineTransformMakeTranslation(direction * 5.0, 0.0);
        toView.alpha = 1.0;
        toView.transform = CGAffineTransformIdentity;
    } completion:^(__unused BOOL finished) {
        finishTransition();
    }];
}

- (void)configureDock {
    // The old implementation fell back to the system UITabBar when floating
    // mode was disabled. That bar no longer exists, so use the same custom dock
    // in a full-width bottom-bar style instead of exposing the legacy UI.
    self.dockIsFloating = [TSThemeManager floatingBarEnabled] && ![TSThemeManager floatingBarHidden];

    if (!self.floatingDock) [self buildDock];
    self.floatingDock.hidden = NO;
    self.floatingDock.userInteractionEnabled = YES;
    [self updateAdditionalSafeAreaInsets];
    [self layoutDock];
    [self refreshDockSelection];
    [self updateSelectionPillAnimated:NO];
}

- (void)buildDock {
    UIView *container = [UIView new];
    container.translatesAutoresizingMaskIntoConstraints = YES;
    container.layer.cornerCurve = kCACornerCurveContinuous;
    container.layer.borderWidth = 0.7;
    container.layer.borderColor = [UIColor.separatorColor colorWithAlphaComponent:0.32].CGColor;
    container.layer.shadowColor = UIColor.blackColor.CGColor;
    container.layer.shadowOpacity = 0.14;
    container.layer.shadowRadius = 22;
    container.layer.shadowOffset = CGSizeMake(0, 8);
    container.clipsToBounds = NO;

    UIVisualEffectView *effect = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemChromeMaterial]];
    effect.frame = container.bounds;
    effect.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    effect.clipsToBounds = YES;
    [container addSubview:effect];

    UIView *pill = [UIView new];
    pill.backgroundColor = [[TSThemeManager accentColor] colorWithAlphaComponent:0.13];
    pill.layer.cornerCurve = kCACornerCurveContinuous;
    pill.layer.cornerRadius = 18;
    pill.layer.borderWidth = 0.6;
    pill.layer.borderColor = [[TSThemeManager accentColor] colorWithAlphaComponent:0.16].CGColor;
    pill.userInteractionEnabled = NO;
    [effect.contentView addSubview:pill];

    UIStackView *stack = [UIStackView new];
    stack.axis = UILayoutConstraintAxisHorizontal;
    stack.alignment = UIStackViewAlignmentFill;
    stack.distribution = UIStackViewDistributionFillEqually;
    stack.spacing = [TSThemeManager floatingBarSpacing];
    stack.frame = CGRectZero;
    [effect.contentView addSubview:stack];

    NSArray *titles = @[NSLocalizedString(@"Apps", nil), NSLocalizedString(@"Packages", nil), NSLocalizedString(@"Plugins", nil), NSLocalizedString(@"Settings", nil)];
    NSArray *symbols = @[@"square.grid.2x2.fill", @"archivebox.fill", @"puzzlepiece.extension.fill", @"gearshape.fill"];
    for (NSUInteger index = 0; index < titles.count; index++) {
        UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
        button.tag = index;
        button.accessibilityLabel = titles[index];
        button.accessibilityTraits = UIAccessibilityTraitButton;
        button.titleLabel.adjustsFontSizeToFitWidth = YES;
        button.titleLabel.minimumScaleFactor = 0.72;
        UIButtonConfiguration *configuration = [UIButtonConfiguration plainButtonConfiguration];
        configuration.image = [UIImage systemImageNamed:symbols[index]];
        configuration.title = titles[index];
        configuration.imagePlacement = NSDirectionalRectEdgeTop;
        configuration.imagePadding = 3;
        configuration.contentInsets = NSDirectionalEdgeInsetsMake(3, 1, 3, 1);
        configuration.titleTextAttributesTransformer = ^NSDictionary *(NSDictionary *attributes) {
            NSMutableDictionary *result = [attributes mutableCopy];
            result[NSFontAttributeName] = [UIFont systemFontOfSize:10 weight:UIFontWeightMedium];
            return result;
        };
        button.configuration = configuration;
        button.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        button.layer.cornerRadius = 16;
        [button addTarget:self action:@selector(dockButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
        [stack addArrangedSubview:button];
        [self.dockButtons addObject:button];
    }

    self.floatingDock = container;
    self.dockEffect = effect;
    self.dockStack = stack;
    self.dockSelectionPill = pill;
    [self.view addSubview:container];
    [self.view bringSubviewToFront:container];
}

- (void)updateAdditionalSafeAreaInsets {
    CGFloat bottom = self.dockIsFloating ? [TSThemeManager floatingBarHeight] + [TSThemeManager floatingBarBottomOffset] + 14.0 : 64.0;
    for (NSNumber *number in self.loadedTabIndexes) {
        UINavigationController *controller = self.tabControllers[number.unsignedIntegerValue];
        UIEdgeInsets insets = controller.additionalSafeAreaInsets;
        if (fabs(insets.bottom - bottom) > 0.5) {
            insets.bottom = bottom;
            controller.additionalSafeAreaInsets = insets;
        }
    }
}

- (void)layoutDock {
    if (!self.floatingDock || !self.isViewLoaded) return;

    CGFloat safeBottom = self.view.safeAreaInsets.bottom;
    CGFloat width = self.view.bounds.size.width;
    CGFloat height = self.dockIsFloating ? [TSThemeManager floatingBarHeight] : 64.0 + safeBottom;
    CGFloat margin = self.dockIsFloating ? [TSThemeManager floatingBarHorizontalMargin] : 0.0;
    CGFloat dockWidth = self.dockIsFloating ? MIN(width - 2.0 * margin, 440.0) : width;
    CGFloat bottomOffset = self.dockIsFloating ? [TSThemeManager floatingBarBottomOffset] : 0.0;
    CGFloat originY = self.dockIsFloating ? CGRectGetHeight(self.view.bounds) - safeBottom - bottomOffset - height : CGRectGetHeight(self.view.bounds) - height;
    CGRect frame = CGRectMake((width - dockWidth) / 2.0, originY, dockWidth, height);
    if (!CGRectEqualToRect(self.floatingDock.frame, frame)) self.floatingDock.frame = frame;

    CGFloat radius = self.dockIsFloating ? height / 2.0 : 18.0;
    self.floatingDock.layer.cornerRadius = radius;
    self.floatingDock.layer.maskedCorners = self.dockIsFloating ? (kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner | kCALayerMinXMaxYCorner | kCALayerMaxXMaxYCorner) : (kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner);
    self.floatingDock.layer.shadowOpacity = self.dockIsFloating ? 0.14 : 0.0;
    self.floatingDock.layer.shadowRadius = self.dockIsFloating ? 22.0 : 0.0;
    self.dockEffect.layer.cornerRadius = radius;
    self.dockEffect.layer.maskedCorners = self.floatingDock.layer.maskedCorners;

    CGFloat stackTop = 5.0;
    CGFloat stackBottom = self.dockIsFloating ? 5.0 : safeBottom + 4.0;
    self.dockStack.frame = CGRectMake(self.dockIsFloating ? 9.0 : 14.0,
                                      stackTop,
                                      MAX(0, dockWidth - (self.dockIsFloating ? 18.0 : 28.0)),
                                      MAX(0, height - stackTop - stackBottom));
    self.dockStack.spacing = [TSThemeManager floatingBarSpacing];
    [self.dockEffect layoutIfNeeded];
    [self updateSelectionPillAnimated:NO];
}

- (void)dockButtonPressed:(UIButton *)sender {
    NSUInteger index = (NSUInteger)sender.tag;
    if (index >= self.tabControllers.count || index == self.currentTabIndex) return;

    UIImpactFeedbackGenerator *feedback = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
    [feedback prepare];
    [feedback impactOccurred];

    [UIView animateWithDuration:0.12 delay:0 options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction animations:^{
        sender.transform = CGAffineTransformMakeScale(0.94, 0.94);
    } completion:^(__unused BOOL finished) {
        [UIView animateWithDuration:0.24 delay:0 usingSpringWithDamping:0.58 initialSpringVelocity:0.28 options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction animations:^{
            sender.transform = CGAffineTransformIdentity;
        } completion:nil];
    }];

    [self selectTabAtIndex:index animated:YES];
}

- (void)applyDockButton:(UIButton *)button selected:(BOOL)selected accent:(UIColor *)accent {
    UIColor *foreground = selected ? accent : UIColor.secondaryLabelColor;
    UIButtonConfiguration *configuration = button.configuration;
    configuration.baseForegroundColor = foreground;
    configuration.titleTextAttributesTransformer = ^NSDictionary *(NSDictionary *attributes) {
        NSMutableDictionary *updated = [attributes mutableCopy];
        updated[NSFontAttributeName] = [UIFont systemFontOfSize:10 weight:selected ? UIFontWeightBold : UIFontWeightMedium];
        return updated;
    };
    button.configuration = configuration;
    button.tintColor = foreground;
}

- (void)refreshDockSelection {
    if (!self.dockButtons.count) return;
    UIColor *accent = [TSThemeManager accentColor];
    NSUInteger selected = MIN(self.selectedIndex, self.dockButtons.count - 1);
    BOOL accentChanged = !self.lastDockAccentColor || ![self.lastDockAccentColor isEqual:accent];

    if (accentChanged) {
        for (UIButton *button in self.dockButtons) [self applyDockButton:button selected:(NSUInteger)button.tag == selected accent:accent];
        self.dockSelectionPill.backgroundColor = [accent colorWithAlphaComponent:0.13];
        self.dockSelectionPill.layer.borderColor = [accent colorWithAlphaComponent:0.16].CGColor;
        self.lastDockAccentColor = accent;
        self.lastDockSelectedIndex = selected;
        return;
    }

    if (self.lastDockSelectedIndex == selected) return;
    if (self.lastDockSelectedIndex < self.dockButtons.count) {
        [self applyDockButton:self.dockButtons[self.lastDockSelectedIndex] selected:NO accent:accent];
    }
    [self applyDockButton:self.dockButtons[selected] selected:YES accent:accent];
    self.lastDockSelectedIndex = selected;
}

- (void)updateSelectionPillAnimated:(BOOL)animated {
    if (!self.dockSelectionPill || self.selectedIndex >= self.dockButtons.count) return;
    UIButton *button = self.dockButtons[self.selectedIndex];
    CGRect target = [button convertRect:button.bounds toView:self.dockEffect.contentView];
    target = CGRectInset(target, 3.0, 2.0);
    void (^updates)(void) = ^{ self.dockSelectionPill.frame = target; };
    if (animated && !UIAccessibilityIsReduceMotionEnabled()) {
        [UIView animateWithDuration:0.34 delay:0 usingSpringWithDamping:0.78 initialSpringVelocity:0.32 options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionAllowUserInteraction animations:updates completion:nil];
    } else {
        updates();
    }
}

- (void)appearanceChanged {
    [self configureDock];
    [self refreshDockSelection];
    [self updateSelectionPillAnimated:YES];
    [TSThemeManager applyToViewController:self];
    [self setNeedsStatusBarAppearanceUpdate];
}

@end
