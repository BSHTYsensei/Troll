#import <UIKit/UIKit.h>
#import "TSAppInfo.h"
#import <CoreServices.h>

@interface TSAppTableViewController : UITableViewController <UISearchResultsUpdating, UIDocumentPickerDelegate, LSApplicationWorkspaceObserverProtocol>
{
    UIImage* _placeholderIcon;
    NSArray<TSAppInfo*>* _cachedAppInfos;
    NSArray<TSAppInfo*>* _cachedTrollStoreAppCatalog;
    NSArray<TSAppInfo*>* _cachedAppStoreAppCatalog;
    NSArray<TSAppInfo*>* _cachedSystemAppCatalog;
    NSCache<NSString*, UIImage*>* _cachedIcons;
    UISearchController* _searchController;
    UISegmentedControl* _appCategoryControl;
	NSString* _searchKey;
    BOOL _showAppStoreApps;
    NSInteger _sourceCategory;
    NSUInteger _reloadGeneration;
}
@property(nonatomic,assign) NSInteger sourceCategory;

@end