#import "TSAppUpdateManager.h"
#import <TSUtil.h>

@implementation TSAppUpdateManager
+ (void)copyBlockedBundleIdentifiersWithCompletion:(void (^)(NSSet<NSString *> *, NSError *))completion {
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        NSString *output = nil, *errors = nil;
        int result = spawnRoot(rootHelperPath(), @[@"list-blocked-app-updates"], &output, &errors);
        NSError *error = nil;
        NSMutableSet *identifiers = [NSMutableSet set];
        if (result == 0) {
            NSData *data = [output dataUsingEncoding:NSUTF8StringEncoding];
            id object = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:&error] : nil;
            NSArray *values = [object isKindOfClass:NSDictionary.class] ? object[@"blockedBundleIdentifiers"] : nil;
            if (![values isKindOfClass:NSArray.class]) {
                if (!error) error = [NSError errorWithDomain:@"TSAppUpdateManager" code:1 userInfo:@{NSLocalizedDescriptionKey:errors.length ? errors : @"RootHelper returned an invalid update-lock list."}];
            } else {
                for (id value in values) if ([value isKindOfClass:NSString.class] && [value length]) [identifiers addObject:value];
            }
        } else {
            error = [NSError errorWithDomain:@"TSAppUpdateManager" code:result userInfo:@{NSLocalizedDescriptionKey:errors.length ? errors : [NSString stringWithFormat:@"Unable to query blocked updates (code %d).", result]}];
        }
        dispatch_async(dispatch_get_main_queue(), ^{ if (completion) completion(identifiers.copy, error); });
    });
}
+ (void)setUpdatesBlocked:(BOOL)blocked forBundleIdentifier:(NSString *)bundleIdentifier completion:(void (^)(BOOL, NSString *))completion {
    if (!bundleIdentifier.length) { if (completion) completion(NO, @"Missing bundle identifier."); return; }
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSString *output = nil, *errors = nil;
        int result = spawnRoot(rootHelperPath(), @[(blocked ? @"block-app-update" : @"unblock-app-update"), bundleIdentifier], &output, &errors);
        NSString *message = errors.length ? errors : (result == 0 ? (blocked ? NSLocalizedString(@"Updates are now blocked for this app.", nil) : NSLocalizedString(@"Updates are allowed again for this app.", nil)) : [NSString stringWithFormat:NSLocalizedString(@"Operation failed with code %d.", nil), result]);
        dispatch_async(dispatch_get_main_queue(), ^{ if (completion) completion(result == 0, message); });
    });
}
@end
