#import "TSAppUpdateManager.h"
#import <TSUtil.h>

// Avoid spawning RootHelper every time the Apps tab becomes visible. The list of
// blocked updates is tiny and changes only when one of TrollStore's own actions
// toggles it, so a short cache plus in-flight request coalescing is sufficient.
static dispatch_queue_t TSBlockedUpdatesStateQueue(void) {
    static dispatch_queue_t queue;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{ queue = dispatch_queue_create("com.opa334.TrollStore.blocked-updates-cache", DISPATCH_QUEUE_SERIAL); });
    return queue;
}
static NSSet<NSString *> *TSBlockedUpdatesCachedIdentifiers;
static NSDate *TSBlockedUpdatesCacheDate;
static BOOL TSBlockedUpdatesRequestInFlight;
static NSMutableArray *TSBlockedUpdatesPendingCompletions;
static const NSTimeInterval TSBlockedUpdatesCacheTTL = 60.0;

@implementation TSAppUpdateManager
+ (void)copyBlockedBundleIdentifiersWithCompletion:(void (^)(NSSet<NSString *> *, NSError *))completion {
    dispatch_async(TSBlockedUpdatesStateQueue(), ^{
        BOOL cacheIsFresh = TSBlockedUpdatesCachedIdentifiers && TSBlockedUpdatesCacheDate && -TSBlockedUpdatesCacheDate.timeIntervalSinceNow < TSBlockedUpdatesCacheTTL;
        if (cacheIsFresh) {
            NSSet<NSString *> *snapshot = TSBlockedUpdatesCachedIdentifiers;
            dispatch_async(dispatch_get_main_queue(), ^{ if (completion) completion(snapshot, nil); });
            return;
        }

        if (completion) {
            if (!TSBlockedUpdatesPendingCompletions) TSBlockedUpdatesPendingCompletions = [NSMutableArray array];
            [TSBlockedUpdatesPendingCompletions addObject:[completion copy]];
        }
        if (TSBlockedUpdatesRequestInFlight) return;
        TSBlockedUpdatesRequestInFlight = YES;

        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            NSString *output = nil, *errors = nil;
            int result = spawnRoot(rootHelperPath(), @[@"list-blocked-app-updates"], &output, &errors);
            NSError *error = nil;
            NSMutableSet<NSString *> *identifiers = [NSMutableSet set];
            if (result == 0) {
                NSData *data = [output dataUsingEncoding:NSUTF8StringEncoding];
                id object = data ? [NSJSONSerialization JSONObjectWithData:data options:0 error:&error] : nil;
                NSArray *values = [object isKindOfClass:NSDictionary.class] ? object[@"blockedBundleIdentifiers"] : nil;
                if (![values isKindOfClass:NSArray.class]) {
                    if (!error) error = [NSError errorWithDomain:@"TSAppUpdateManager" code:1 userInfo:@{NSLocalizedDescriptionKey:errors.length ? errors : @"RootHelper returned an invalid update-lock list."}];
                } else {
                    for (id value in values) if ([value isKindOfClass:NSString.class] && [value length]) [identifiers addObject:value];
                }
            } else {
                error = [NSError errorWithDomain:@"TSAppUpdateManager" code:result userInfo:@{NSLocalizedDescriptionKey:errors.length ? errors : [NSString stringWithFormat:@"Unable to query blocked updates (code %d).", result]}];
            }

            dispatch_async(TSBlockedUpdatesStateQueue(), ^{
                if (!error) {
                    TSBlockedUpdatesCachedIdentifiers = identifiers.copy;
                    TSBlockedUpdatesCacheDate = [NSDate date];
                }
                NSSet<NSString *> *snapshot = TSBlockedUpdatesCachedIdentifiers ?: [NSSet set];
                NSArray *callbacks = TSBlockedUpdatesPendingCompletions.copy ?: @[];
                [TSBlockedUpdatesPendingCompletions removeAllObjects];
                TSBlockedUpdatesRequestInFlight = NO;
                dispatch_async(dispatch_get_main_queue(), ^{
                    for (void (^callback)(NSSet<NSString *> *, NSError *) in callbacks) callback(snapshot, error);
                });
            });
        });
    });
}

+ (void)setUpdatesBlocked:(BOOL)blocked forBundleIdentifier:(NSString *)bundleIdentifier completion:(void (^)(BOOL, NSString *))completion {
    if (!bundleIdentifier.length) { if (completion) completion(NO, @"Missing bundle identifier."); return; }
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSString *output = nil, *errors = nil;
        int result = spawnRoot(rootHelperPath(), @[(blocked ? @"block-app-update" : @"unblock-app-update"), bundleIdentifier], &output, &errors);
        NSString *message = errors.length ? errors : (result == 0 ? (blocked ? NSLocalizedString(@"Updates are now blocked for this app.", nil) : NSLocalizedString(@"Updates are allowed again for this app.", nil)) : [NSString stringWithFormat:NSLocalizedString(@"Operation failed with code %d.", nil), result]);
        if (result == 0) {
            dispatch_sync(TSBlockedUpdatesStateQueue(), ^{
                if (TSBlockedUpdatesCachedIdentifiers) {
                    NSMutableSet<NSString *> *updated = [TSBlockedUpdatesCachedIdentifiers mutableCopy];
                    if (blocked) [updated addObject:bundleIdentifier];
                    else [updated removeObject:bundleIdentifier];
                    TSBlockedUpdatesCachedIdentifiers = updated.copy;
                    TSBlockedUpdatesCacheDate = [NSDate date];
                }
            });
        }
        dispatch_async(dispatch_get_main_queue(), ^{ if (completion) completion(result == 0, message); });
    });
}
@end
