#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@interface TSPluginRepositoryManager : NSObject
+ (NSArray<NSString *> *)repositoryURLs;
+ (BOOL)addRepositoryURL:(NSString *)url error:(NSError * _Nullable * _Nullable)error;
+ (void)removeRepositoryURL:(NSString *)url;
+ (void)refreshPackagesWithCompletion:(void (^)(NSArray<NSDictionary *> *packages, NSError * _Nullable error))completion;
+ (void)downloadPackage:(NSDictionary *)package completion:(void (^)(NSURL * _Nullable importedURL, NSError * _Nullable error))completion;
@end
NS_ASSUME_NONNULL_END
