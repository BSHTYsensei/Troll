#import <UIKit/UIKit.h>
@class TSRootViewController;

@interface TSSceneDelegate : UIResponder <UIWindowSceneDelegate>
@property (strong, nonatomic) UIWindow * window;
@property (nonatomic, strong) TSRootViewController *rootViewController;
@end
