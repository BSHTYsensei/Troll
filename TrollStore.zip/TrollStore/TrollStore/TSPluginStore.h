#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN
@interface TSPluginStore : NSObject
+ (NSString *)pluginDirectoryPath;
+ (void)ensurePluginDirectory;
+ (NSArray<NSURL *> *)availablePluginItems;
+ (NSArray<NSString *> *)availableInjectableLibraryPaths;
+ (NSArray<NSString *> *)injectableLibraryPathsForPluginItem:(NSURL *)item;
+ (NSUInteger)injectableLibraryCountForPluginItem:(NSURL *)item;
+ (NSURL * _Nullable)importPluginAtURL:(NSURL *)sourceURL error:(NSError * _Nullable * _Nullable)error;
+ (BOOL)removePluginItemAtURL:(NSURL *)item error:(NSError * _Nullable * _Nullable)error;
+ (BOOL)isInjectableLibraryPath:(NSString *)path;
@end
NS_ASSUME_NONNULL_END
