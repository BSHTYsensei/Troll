#import <UIKit/UIKit.h>

@interface TSTweakInjector : NSObject <UIDocumentPickerDelegate>
+ (void)presentForBundleIdentifier:(NSString *)bundleIdentifier displayName:(NSString *)displayName fromViewController:(UIViewController *)viewController;
@end
