#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@interface TSAppRepackager : NSObject
+ (void)presentFromViewController:(UIViewController *)viewController
                       sourceIPA:(NSString *)sourceIPA
                      completion:(void (^ _Nullable)(NSString * _Nullable outputPath, NSError * _Nullable error))completion;
+ (BOOL)repackageIPAAtPath:(NSString *)sourceIPA
          bundleIdentifier:(NSString *)bundleIdentifier
                displayName:(NSString *)displayName
                    version:(NSString *)version
             removeURLSchemes:(BOOL)removeURLSchemes
               removeWidgets:(BOOL)removeWidgets
                  removeWatch:(BOOL)removeWatch
                  outputPath:(NSString * _Nullable * _Nullable)outputPath
                       error:(NSError * _Nullable * _Nullable)error;
@end
NS_ASSUME_NONNULL_END
