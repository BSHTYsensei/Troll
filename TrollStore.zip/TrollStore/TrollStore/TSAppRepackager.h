#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@interface TSAppRepackager : NSObject
+ (NSString *)customIconPath;
+ (UIImage * _Nullable)customIconPreviewImage;
+ (BOOL)hasCustomIcon;
+ (BOOL)importCustomIconAtURL:(NSURL *)url error:(NSError * _Nullable * _Nullable)error;
+ (void)removeCustomIcon;
+ (void)presentFromViewController:(UIViewController *)viewController
                       sourceIPA:(NSString *)sourceIPA
                      completion:(void (^ _Nullable)(NSString * _Nullable outputPath, NSError * _Nullable error))completion;
+ (BOOL)repackageIPAAtPath:(NSString *)sourceIPA
          bundleIdentifier:(NSString *)bundleIdentifier
                displayName:(NSString *)displayName
                    version:(NSString *)version
             removeURLSchemes:(BOOL)removeURLSchemes
               removeWidgets:(BOOL)removeWidgets
                  removeWatch:(BOOL)removeWatch
             customIconData:(NSData * _Nullable)customIconData
                  outputPath:(NSString * _Nullable * _Nullable)outputPath
                       error:(NSError * _Nullable * _Nullable)error;
@end
NS_ASSUME_NONNULL_END
