int TSRunRefreshAppRegistrationsShortcut(void);
