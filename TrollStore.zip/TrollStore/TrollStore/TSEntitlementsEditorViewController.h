#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TSEntitlementsEditorViewController : UIViewController
@property(nonatomic, copy, nullable) void (^onSave)(void);
@property(nonatomic, copy, nullable) void (^onCancel)(void);
@property(nonatomic, copy, nullable) NSString *sourceIPAPath;
@end

NS_ASSUME_NONNULL_END
