#import "TSEntitlementsEditorViewController.h"

#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import "TSAppInfo.h"
#import "TSCommonTCCServiceNames.h"

static NSString* TSEntitlementsTemplate(void)
{
    return @"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
           @"<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n"
           @"<plist version=\"1.0\">\n<dict>\n</dict>\n</plist>\n";
}

@interface TSEntitlementsEditorViewController () <UITextViewDelegate, UITableViewDataSource, UITableViewDelegate>
@property(nonatomic, strong) UITextView* editorView;
@property(nonatomic, strong) UITextView* originalEntitlementsView;
@property(nonatomic, strong) UITextView* finalPreviewView;
@property(nonatomic, strong) UIButton* presetsButton;
@property(nonatomic, strong) UISegmentedControl* editorModeControl;
@property(nonatomic, strong) UITableView* visualTableView;
@property(nonatomic, strong) NSLayoutConstraint* visualTableHeightConstraint;
@property(nonatomic, strong) UILabel* xmlEditorLabel;
@property(nonatomic, copy) NSDictionary<NSString*, NSDictionary*>* originalEntitlementsByBinary;
@property(nonatomic, copy) NSDictionary* originalMainEntitlements;
@property(nonatomic, strong) UIBarButtonItem *doneItem;
@property(nonatomic, assign) BOOL sourceEntitlementsLoaded;
@end

@implementation TSEntitlementsEditorViewController


- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Edit Entitlements Before Install", nil);
    self.view.backgroundColor = UIColor.systemGroupedBackgroundColor;

    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", nil)
        style:UIBarButtonItemStylePlain target:self action:@selector(cancelEditing)];
    UIBarButtonItem *resetItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Reset", nil)
        style:UIBarButtonItemStylePlain target:self action:@selector(resetDocument)];
    self.doneItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", nil)
        style:UIBarButtonItemStyleDone target:self action:@selector(saveAndInstall)];
    self.doneItem.enabled = NO;
    self.navigationItem.rightBarButtonItems = @[self.doneItem, resetItem];

    [self buildLayout];
    [self loadDocument];
}

- (void)buildLayout
{
    UIScrollView* scrollView = [UIScrollView new];
    scrollView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:scrollView];
    [NSLayoutConstraint activateConstraints:@[
        [scrollView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],
        [scrollView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [scrollView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [scrollView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor]
    ]];

    UIStackView* content = [UIStackView new];
    content.axis = UILayoutConstraintAxisVertical;
    content.spacing = 16;
    content.translatesAutoresizingMaskIntoConstraints = NO;
    [scrollView addSubview:content];
    [NSLayoutConstraint activateConstraints:@[
        [content.topAnchor constraintEqualToAnchor:scrollView.contentLayoutGuide.topAnchor constant:18],
        [content.leadingAnchor constraintEqualToAnchor:scrollView.frameLayoutGuide.leadingAnchor constant:16],
        [content.trailingAnchor constraintEqualToAnchor:scrollView.frameLayoutGuide.trailingAnchor constant:-16],
        [content.bottomAnchor constraintEqualToAnchor:scrollView.contentLayoutGuide.bottomAnchor constant:-22]
    ]];

    UILabel *help = [UILabel new];
    help.text = NSLocalizedString(@"The editable document starts with the selected IPA's original main-app Entitlements. Changes apply to that complete Entitlements dictionary for this installation only. Done continues to installation confirmation; Cancel abandons the entire installation. App extensions keep their own original Entitlements.", nil);
    help.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    help.textColor = UIColor.secondaryLabelColor;
    help.numberOfLines = 0;
    [content addArrangedSubview:help];

    UILabel *originalLabel = [UILabel new];
    originalLabel.text = NSLocalizedString(@"Original Entitlements (read only)", nil);
    originalLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    [content addArrangedSubview:originalLabel];

    self.originalEntitlementsView = [UITextView new];
    self.originalEntitlementsView.editable = NO;
    self.originalEntitlementsView.selectable = YES;
    self.originalEntitlementsView.font = [UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightRegular];
    self.originalEntitlementsView.backgroundColor = UIColor.tertiarySystemGroupedBackgroundColor;
    self.originalEntitlementsView.layer.cornerRadius = 10;
    self.originalEntitlementsView.textContainerInset = UIEdgeInsetsMake(10, 9, 10, 9);
    [self.originalEntitlementsView.heightAnchor constraintGreaterThanOrEqualToConstant:150].active = YES;
    self.originalEntitlementsView.text = NSLocalizedString(@"Loading the selected IPA's original Entitlements...", nil);
    [content addArrangedSubview:self.originalEntitlementsView];

    self.editorModeControl = [[UISegmentedControl alloc] initWithItems:@[
        NSLocalizedString(@"Visual", nil), NSLocalizedString(@"XML (advanced)", nil)
    ]];
    self.editorModeControl.selectedSegmentIndex = 0;
    [self.editorModeControl addTarget:self action:@selector(editorModeChanged:) forControlEvents:UIControlEventValueChanged];
    [content addArrangedSubview:self.editorModeControl];

    self.visualTableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleInsetGrouped];
    self.visualTableView.dataSource = self;
    self.visualTableView.delegate = self;
    self.visualTableView.backgroundColor = UIColor.clearColor;
    self.visualTableView.rowHeight = UITableViewAutomaticDimension;
    self.visualTableView.estimatedRowHeight = 58;
    self.visualTableHeightConstraint = [self.visualTableView.heightAnchor constraintEqualToConstant:250];
    self.visualTableHeightConstraint.active = YES;
    [content addArrangedSubview:self.visualTableView];

    UILabel* editorLabel = [UILabel new];
    editorLabel.text = NSLocalizedString(@"Entitlements property list (XML)", nil);
    editorLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    self.xmlEditorLabel = editorLabel;
    [content addArrangedSubview:editorLabel];

    self.presetsButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.presetsButton setTitle:NSLocalizedString(@"Add Entitlement Preset", nil) forState:UIControlStateNormal];
    [self.presetsButton addTarget:self action:@selector(showPresetPicker) forControlEvents:UIControlEventTouchUpInside];
    self.presetsButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeading;
    [content addArrangedSubview:self.presetsButton];

    self.editorView = [UITextView new];
    self.editorView.font = [UIFont monospacedSystemFontOfSize:13 weight:UIFontWeightRegular];
    self.editorView.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.editorView.autocorrectionType = UITextAutocorrectionTypeNo;
    self.editorView.spellCheckingType = UITextSpellCheckingTypeNo;
    self.editorView.smartQuotesType = UITextSmartQuotesTypeNo;
    self.editorView.smartDashesType = UITextSmartDashesTypeNo;
    self.editorView.backgroundColor = UIColor.secondarySystemGroupedBackgroundColor;
    self.editorView.layer.cornerRadius = 12;
    self.editorView.layer.borderWidth = 1.0 / UIScreen.mainScreen.scale;
    self.editorView.layer.borderColor = UIColor.separatorColor.CGColor;
    self.editorView.textContainerInset = UIEdgeInsetsMake(12, 10, 12, 10);
    self.editorView.accessibilityLabel = NSLocalizedString(@"Entitlements property list (XML)", nil);
    self.editorView.delegate = self;
    [self.editorView.heightAnchor constraintGreaterThanOrEqualToConstant:300].active = YES;
    [content addArrangedSubview:self.editorView];
    self.xmlEditorLabel.hidden = YES;
    self.editorView.hidden = YES;

    UILabel *previewLabel = [UILabel new];
    previewLabel.text = NSLocalizedString(@"Final Main-App Entitlements Preview", nil);
    previewLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    [content addArrangedSubview:previewLabel];

    self.finalPreviewView = [UITextView new];
    self.finalPreviewView.editable = NO;
    self.finalPreviewView.selectable = YES;
    self.finalPreviewView.font = [UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightRegular];
    self.finalPreviewView.backgroundColor = UIColor.tertiarySystemGroupedBackgroundColor;
    self.finalPreviewView.layer.cornerRadius = 10;
    self.finalPreviewView.textContainerInset = UIEdgeInsetsMake(10, 9, 10, 9);
    [self.finalPreviewView.heightAnchor constraintGreaterThanOrEqualToConstant:180].active = YES;
    [content addArrangedSubview:self.finalPreviewView];

    UILabel* footer = [UILabel new];
    footer.text = NSLocalizedString(@"Only add keys you understand. Invalid property lists are rejected before installation. Some entitlements are restricted by iOS and cannot be made functional by signing alone.", nil);
    footer.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    footer.textColor = UIColor.secondaryLabelColor;
    footer.numberOfLines = 0;
    [content addArrangedSubview:footer];
}

- (void)loadDocument
{
    self.editorView.text = TSEntitlementsTemplate();
    self.originalEntitlementsByBinary = @{};
    self.originalMainEntitlements = @{};
    [self refreshVisualTable];
    [self loadSourceEntitlements];
}

- (void)loadSourceEntitlements
{
    if (self.sourceIPAPath.length == 0) {
        self.originalEntitlementsView.text = NSLocalizedString(@"An IPA must be selected before editing its Entitlements.", nil);
        self.doneItem.enabled = NO;
        return;
    }

    NSString *ipaPath = [self.sourceIPAPath copy];
    TSAppInfo *appInfo = [[TSAppInfo alloc] initWithIPAPath:ipaPath];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSError *loadError = [appInfo sync_loadInfo];
        NSDictionary *binaryEntitlements = loadError ? @{} : [appInfo entitlementsByBinarySubpaths];
        NSString *mainPath = [appInfo mainExecutableSubpath];
        NSDictionary *candidate = mainPath.length ? binaryEntitlements[mainPath] : nil;
        NSDictionary *mainEntitlements = [candidate isKindOfClass:NSDictionary.class] ? candidate : @{};
        NSArray *binaryPaths = [[binaryEntitlements allKeys] sortedArrayUsingSelector:@selector(localizedStandardCompare:)];
        NSMutableString *display = [NSMutableString new];
        for (NSString *binaryPath in binaryPaths) {
            [display appendFormat:@"%@\n", binaryPath];
            NSDictionary *dict = binaryEntitlements[binaryPath];
            NSData *plistData = [NSPropertyListSerialization dataWithPropertyList:([dict isKindOfClass:NSDictionary.class] ? dict : @{}) format:NSPropertyListXMLFormat_v1_0 options:0 error:nil];
            NSString *plistText = plistData ? [[NSString alloc] initWithData:plistData encoding:NSUTF8StringEncoding] : @"<dict/>";
            [display appendFormat:@"%@\n\n", plistText ?: @"<dict/>"];
        }
        NSData *mainData = loadError ? nil : [NSPropertyListSerialization dataWithPropertyList:mainEntitlements format:NSPropertyListXMLFormat_v1_0 options:0 error:nil];
        NSString *mainXML = mainData ? [[NSString alloc] initWithData:mainData encoding:NSUTF8StringEncoding] : nil;
        dispatch_async(dispatch_get_main_queue(), ^{
            self.originalEntitlementsByBinary = binaryEntitlements;
            self.originalMainEntitlements = mainEntitlements;
            if (loadError || !mainXML.length) {
                self.sourceEntitlementsLoaded = NO;
                self.doneItem.enabled = NO;
                self.originalEntitlementsView.text = [NSString stringWithFormat:NSLocalizedString(@"Could not load the IPA's original main-app Entitlements. Installation is blocked: %@", nil), loadError.localizedDescription ?: NSLocalizedString(@"Invalid Entitlements data.", nil)];
                return;
            }
            self.sourceEntitlementsLoaded = YES;
            self.doneItem.enabled = YES;
            // Start with the complete extracted main executable dictionary, not an entitlements.
            self.editorView.text = mainXML;
            self.originalEntitlementsView.text = display.length ? display : NSLocalizedString(@"No embedded Entitlements were found in this IPA. The editable main-app document starts as an empty dictionary.", nil);
            [self refreshVisualTable];
            [self updateFinalPreview];
        });
    });
}

- (NSDictionary*)parsedEntitlementsDictionary
{
    NSData *data = [self.editorView.text dataUsingEncoding:NSUTF8StringEncoding];
    if (!data) return @{};
    id value = [NSPropertyListSerialization propertyListWithData:data options:NSPropertyListMutableContainersAndLeaves format:nil error:nil];
    return [value isKindOfClass:NSDictionary.class] ? value : @{};
}

- (void)textViewDidChange:(UITextView *)textView
{
    if (textView == self.editorView) {
        [self refreshVisualTable];
        [self updateFinalPreview];
    }
}

- (void)editorModeChanged:(UISegmentedControl *)control
{
    BOOL showXML = control.selectedSegmentIndex == 1;
    self.visualTableView.hidden = showXML;
    self.xmlEditorLabel.hidden = !showXML;
    self.editorView.hidden = !showXML;
    if (!showXML) [self refreshVisualTable];
}

- (void)refreshVisualTable
{
    if (!self.visualTableView) return;
    NSUInteger rows = [self sortedEntitlementKeys].count;
    // Keep the table embedded in the parent scroll view without making its
    // intrinsic height ambiguous or forcing a second nested scrolling region.
    CGFloat rowHeight = 62.0;
    CGFloat desiredHeight = rows == 0 ? 88.0 : MIN(420.0, MAX(120.0, 42.0 + rows * rowHeight));
    self.visualTableHeightConstraint.constant = desiredHeight;
    [self.visualTableView reloadData];
}

- (void)writeEntitlementsDictionary:(NSDictionary *)entitlements
{
    NSDictionary *safeEntitlements = [entitlements isKindOfClass:NSDictionary.class] ? entitlements : @{};
    NSError *error = nil;
    NSData *xmlData = [NSPropertyListSerialization dataWithPropertyList:safeEntitlements format:NSPropertyListXMLFormat_v1_0 options:0 error:&error];
    if (!xmlData) {
        [self showError:error.localizedDescription ?: NSLocalizedString(@"Unable to serialize the Entitlements dictionary.", nil)];
        return;
    }
    self.editorView.text = [[NSString alloc] initWithData:xmlData encoding:NSUTF8StringEncoding] ?: TSEntitlementsTemplate();
    [self refreshVisualTable];
    [self updateFinalPreview];
}

- (NSArray<NSString *> *)sortedEntitlementKeys
{
    return [[[self parsedEntitlementsDictionary] allKeys] sortedArrayUsingSelector:@selector(localizedStandardCompare:)];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSUInteger count = [self sortedEntitlementKeys].count;
    return count == 0 ? 1 : count; // placeholder row when the entitlements is empty
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"EntitlementEntitlementsCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
    NSArray<NSString *> *keys = [self sortedEntitlementKeys];
    if (keys.count == 0) {
        cell.textLabel.text = NSLocalizedString(@"No Entitlements keys. Add a preset or create a custom key.", nil);
        cell.textLabel.numberOfLines = 0;
        cell.detailTextLabel.text = nil;
        cell.accessoryView = nil;
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    if (indexPath.row >= keys.count) return cell;
    NSString *key = keys[indexPath.row];
    id value = [self parsedEntitlementsDictionary][key];
    cell.textLabel.text = key;
    cell.textLabel.numberOfLines = 0;
    cell.detailTextLabel.numberOfLines = 2;
    cell.accessoryView = nil;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    if ([value isKindOfClass:NSString.class]) {
        cell.detailTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"String · %@", nil), value];
    } else if ([value isKindOfClass:NSNumber.class] && CFGetTypeID((__bridge CFTypeRef)value) == CFBooleanGetTypeID()) {
        BOOL on = [value boolValue];
        cell.detailTextLabel.text = NSLocalizedString(on ? @"Boolean: On" : @"Boolean: Off", nil);
        UISwitch *toggle = [UISwitch new];
        toggle.on = on;
        toggle.accessibilityIdentifier = key;
        [toggle addTarget:self action:@selector(visualBooleanChanged:) forControlEvents:UIControlEventValueChanged];
        cell.accessoryView = toggle;
        cell.accessoryType = UITableViewCellAccessoryNone;
    } else if ([value isKindOfClass:NSArray.class]) {
        cell.detailTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"Array · %lu item(s)", nil), (unsigned long)[value count]];
    } else if ([value isKindOfClass:NSDictionary.class]) {
        cell.detailTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"Dictionary · %lu key(s)", nil), (unsigned long)[value count]];
    } else if ([value isKindOfClass:NSNumber.class]) {
        cell.detailTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"Number · %@", nil), value];
    } else {
        cell.detailTextLabel.text = NSLocalizedString(@"Tap to edit this value in XML mode.", nil);
    }
    return cell;
}

- (void)visualBooleanChanged:(UISwitch *)sender
{
    NSString *key = sender.accessibilityIdentifier;
    if (!key.length) return;
    NSMutableDictionary *entitlements = [[self parsedEntitlementsDictionary] mutableCopy] ?: [NSMutableDictionary new];
    entitlements[key] = @(sender.isOn);
    [self writeEntitlementsDictionary:entitlements];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSArray<NSString *> *keys = [self sortedEntitlementKeys];
    if (indexPath.row >= keys.count) return;
    NSString *key = keys[indexPath.row];
    id current = [self parsedEntitlementsDictionary][key];
    if ([current isKindOfClass:NSNumber.class] && CFGetTypeID((__bridge CFTypeRef)current) == CFBooleanGetTypeID()) return;

    BOOL isComposite = [current isKindOfClass:NSArray.class] || [current isKindOfClass:NSDictionary.class];
    UIAlertController *editor = [UIAlertController alertControllerWithTitle:key
        message:isComposite ? NSLocalizedString(@"Enter a JSON array or object. For complex property-list values, use XML (advanced).", nil) : NSLocalizedString(@"Edit entitlement value", nil)
        preferredStyle:UIAlertControllerStyleAlert];
    [editor addTextFieldWithConfigurationHandler:^(UITextField *field) {
        field.autocapitalizationType = UITextAutocapitalizationTypeNone;
        field.autocorrectionType = UITextAutocorrectionTypeNo;
        field.clearButtonMode = UITextFieldViewModeWhileEditing;
        if ([current isKindOfClass:NSString.class]) field.text = current;
        else if (isComposite) {
            NSData *json = [NSJSONSerialization dataWithJSONObject:current options:NSJSONWritingFragmentsAllowed error:nil];
            field.text = json ? [[NSString alloc] initWithData:json encoding:NSUTF8StringEncoding] : @"";
        } else field.text = [current description] ?: @"";
    }];
    [editor addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [editor addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Save", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        NSString *text = editor.textFields.firstObject.text ?: @"";
        id nextValue = nil;
        NSError *parseError = nil;
        if ([current isKindOfClass:NSString.class]) nextValue = text;
        else if (isComposite) {
            NSData *data = [text dataUsingEncoding:NSUTF8StringEncoding];
            nextValue = data ? [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingFragmentsAllowed error:&parseError] : nil;
            if (![nextValue isKindOfClass:NSArray.class] && ![nextValue isKindOfClass:NSDictionary.class]) nextValue = nil;
        } else if ([current isKindOfClass:NSNumber.class]) {
            NSNumberFormatter *formatter = [NSNumberFormatter new];
            nextValue = [formatter numberFromString:text];
        }
        if (!nextValue || ![NSPropertyListSerialization propertyList:nextValue isValidForFormat:NSPropertyListXMLFormat_v1_0]) {
            [self showError:parseError.localizedDescription ?: NSLocalizedString(@"The value is invalid for its current property-list type. Use XML (advanced) for complex values.", nil)];
            return;
        }
        NSMutableDictionary *entitlements = [[self parsedEntitlementsDictionary] mutableCopy] ?: [NSMutableDictionary new];
        entitlements[key] = nextValue;
        [self writeEntitlementsDictionary:entitlements];
    }]];
    [self presentViewController:editor animated:YES completion:nil];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath { return [self sortedEntitlementKeys].count > 0; }

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle != UITableViewCellEditingStyleDelete) return;
    NSArray<NSString *> *keys = [self sortedEntitlementKeys];
    if (indexPath.row >= keys.count) return;
    NSMutableDictionary *entitlements = [[self parsedEntitlementsDictionary] mutableCopy] ?: [NSMutableDictionary new];
    [entitlements removeObjectForKey:keys[indexPath.row]];
    [self writeEntitlementsDictionary:entitlements];
}

- (void)updateFinalPreview
{
    if (!self.finalPreviewView || !self.editorView) return;
    NSDictionary *edited = [self parsedEntitlementsDictionary];
    NSData *plistData = [NSPropertyListSerialization dataWithPropertyList:edited format:NSPropertyListXMLFormat_v1_0 options:0 error:nil];
    NSString *plistText = plistData ? [[NSString alloc] initWithData:plistData encoding:NSUTF8StringEncoding] : TSEntitlementsTemplate();
    NSString *summaryText = [NSString stringWithFormat:NSLocalizedString(@"Complete main-app Entitlements document: %lu key(s). Keys removed from this document are removed from the main executable's signed Entitlements. App extensions are not changed.", nil), (unsigned long)edited.count];
    NSMutableAttributedString *summary = [[NSMutableAttributedString alloc] initWithString:[summaryText stringByAppendingFormat:@"\n\n%@", plistText ?: TSEntitlementsTemplate()]];
    self.finalPreviewView.attributedText = summary;
}

- (void)showPresetPicker
{
    UIAlertController *picker = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Add Entitlement Preset", nil) message:NSLocalizedString(@"Some private entitlements may destabilize apps or expose protected capabilities; signing does not grant every capability on every iOS version.", nil) preferredStyle:UIAlertControllerStyleActionSheet];
    [picker addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Add Custom Entitlement Key", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self showAddCustomKeyPrompt]; });
    }]];
    NSArray<NSDictionary*> *presets = @[
        @{@"key": @"get-task-allow", @"title": @"get-task-allow · Boolean (low risk)", @"value": @YES},
        @{@"key": @"platform-application", @"title": @"platform-application · Boolean (high risk)", @"value": @YES},
        @{@"key": @"com.apple.private.security.no-sandbox", @"title": @"no-sandbox · Boolean (high risk)", @"value": @YES},
        @{@"key": @"com.apple.private.security.container-required", @"title": @"container-required · Boolean", @"value": @YES},
        @{@"key": @"com.apple.private.tcc.allow", @"title": @"com.apple.private.tcc.allow · Array (high risk)", @"value": @[]},
        @{@"key": @"com.apple.security.application-groups", @"title": @"application-groups · Array", @"value": @[]},
        @{@"key": @"keychain-access-groups", @"title": @"keychain-access-groups · Array", @"value": @[]},
        @{@"key": @"com.apple.developer.icloud-container-identifiers", @"title": @"iCloud container identifiers · Array", @"value": @[]}
    ];
    __weak typeof(self) weakSelf = self;
    for (NSDictionary *preset in presets) {
        [picker addAction:[UIAlertAction actionWithTitle:NSLocalizedString(preset[@"title"], nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            void (^insertPreset)(void) = ^{
                __strong typeof(weakSelf) self = weakSelf;
                if (!self) return;
                NSString *presetKey = preset[@"key"];
                if ([presetKey isEqualToString:@"com.apple.private.tcc.allow"]) {
                    [self showTCCServicePicker];
                    return;
                }
                NSMutableDictionary *entitlements = [[self parsedEntitlementsDictionary] mutableCopy] ?: [NSMutableDictionary new];
                entitlements[presetKey] = preset[@"value"];
                [self writeEntitlementsDictionary:entitlements];
            };
            NSString *key = preset[@"key"];
            BOOL risky = [key isEqualToString:@"platform-application"] || [key isEqualToString:@"com.apple.private.security.no-sandbox"] || [key isEqualToString:@"com.apple.private.tcc.allow"];
            if (!risky) { insertPreset(); return; }
            UIAlertController *warning = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"High-risk Entitlement", nil) message:[NSString stringWithFormat:NSLocalizedString(@"%@ is a private or privileged entitlement. Adding it may cause crashes or unexpected access behavior. Add it anyway?", nil), key] preferredStyle:UIAlertControllerStyleAlert];
            [warning addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
            [warning addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Add Anyway", nil) style:UIAlertActionStyleDestructive handler:^(UIAlertAction *warningAction) { insertPreset(); }]];
            [self presentViewController:warning animated:YES completion:nil];
        }]];
    }
    [picker addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    picker.popoverPresentationController.sourceView = self.presetsButton;
    picker.popoverPresentationController.sourceRect = self.presetsButton.bounds;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)showAddCustomKeyPrompt
{
    UIAlertController *prompt = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Custom Entitlement Key", nil)
        message:NSLocalizedString(@"Enter the exact entitlement key name.", nil) preferredStyle:UIAlertControllerStyleAlert];
    [prompt addTextFieldWithConfigurationHandler:^(UITextField *field) {
        field.placeholder = @"com.example.entitlement";
        field.autocapitalizationType = UITextAutocapitalizationTypeNone;
        field.autocorrectionType = UITextAutocorrectionTypeNo;
        field.clearButtonMode = UITextFieldViewModeWhileEditing;
    }];
    [prompt addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [prompt addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Add Key", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *key = [prompt.textFields.firstObject.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        if (!key.length) {
            [self showError:NSLocalizedString(@"Enter the exact entitlement key name.", nil)];
            return;
        }
        if ([self parsedEntitlementsDictionary][key] != nil) {
            [self showError:NSLocalizedString(@"This key already exists. Remove it first or edit the existing row.", nil)];
            return;
        }
        dispatch_async(dispatch_get_main_queue(), ^{ [self showValueTypePickerForKey:key]; });
    }]];
    [self presentViewController:prompt animated:YES completion:nil];
}

- (void)showValueTypePickerForKey:(NSString *)key
{
    UIAlertController *picker = [UIAlertController alertControllerWithTitle:key message:NSLocalizedString(@"Choose a value type for this key.", nil) preferredStyle:UIAlertControllerStyleActionSheet];
    NSDictionary *types = @{
        NSLocalizedString(@"String", nil): @"",
        NSLocalizedString(@"Boolean", nil): @NO,
        NSLocalizedString(@"Array", nil): @[],
        NSLocalizedString(@"Dictionary", nil): @{},
        NSLocalizedString(@"Number", nil): @0
    };
    for (NSString *title in types) {
        [picker addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            NSMutableDictionary *entitlements = [[self parsedEntitlementsDictionary] mutableCopy] ?: [NSMutableDictionary new];
            entitlements[key] = types[title];
            [self writeEntitlementsDictionary:entitlements];
        }]];
    }
    [picker addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    picker.popoverPresentationController.sourceView = self.presetsButton;
    picker.popoverPresentationController.sourceRect = self.presetsButton.bounds;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)showTCCServicePicker
{
    UIAlertController *picker = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Add Common TCC Service", nil)
        message:NSLocalizedString(@"Choose a common TCC service to add.", nil) preferredStyle:UIAlertControllerStyleActionSheet];
    NSArray<NSString *> *serviceKeys = [[commonTCCServices allKeys] sortedArrayUsingSelector:@selector(localizedStandardCompare:)];
    NSDictionary *existing = [self parsedEntitlementsDictionary];
    NSArray *existingServices = [existing[@"com.apple.private.tcc.allow"] isKindOfClass:NSArray.class] ? existing[@"com.apple.private.tcc.allow"] : @[];
    for (NSString *serviceKey in serviceKeys) {
        NSString *serviceName = commonTCCServices[serviceKey];
        NSString *title = [NSString stringWithFormat:@"%@ (%@)", NSLocalizedString(serviceName, nil), serviceKey];
        [picker addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            NSMutableArray *services = [existingServices mutableCopy] ?: [NSMutableArray new];
            if (![services containsObject:serviceKey]) [services addObject:serviceKey];
            NSMutableDictionary *entitlements = [[self parsedEntitlementsDictionary] mutableCopy] ?: [NSMutableDictionary new];
            entitlements[@"com.apple.private.tcc.allow"] = services;
            [self writeEntitlementsDictionary:entitlements];
        }]];
    }
    [picker addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    picker.popoverPresentationController.sourceView = self.presetsButton;
    picker.popoverPresentationController.sourceRect = self.presetsButton.bounds;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)saveAndInstall
{
    if (!self.sourceEntitlementsLoaded) {
        [self showError:NSLocalizedString(@"The original Entitlements have not loaded successfully. Installation cannot continue.", nil)];
        return;
    }
    NSData *data = [self.editorView.text dataUsingEncoding:NSUTF8StringEncoding];
    NSError *parseError = nil;
    id object = data ? [NSPropertyListSerialization propertyListWithData:data options:NSPropertyListMutableContainersAndLeaves format:nil error:&parseError] : nil;
    if (![object isKindOfClass:NSDictionary.class] || ![NSPropertyListSerialization propertyList:object isValidForFormat:NSPropertyListXMLFormat_v1_0]) {
        NSString *message = NSLocalizedString(@"The Entitlements document must be a valid XML plist dictionary.", nil);
        if (parseError.localizedDescription.length) message = [message stringByAppendingFormat:@"\n%@", parseError.localizedDescription];
        [self showError:message];
        return;
    }

    NSError *error = nil;
    NSData *output = [NSPropertyListSerialization dataWithPropertyList:object format:NSPropertyListXMLFormat_v1_0 options:0 error:&error];
    NSString *filename = [NSString stringWithFormat:@"TSEntitlements-%@.plist", NSUUID.UUID.UUIDString];
    NSString *outputPath = [NSTemporaryDirectory() stringByAppendingPathComponent:filename];
    if (!output || ![output writeToFile:outputPath options:NSDataWritingAtomic error:&error]) {
        [self showError:error.localizedDescription ?: NSLocalizedString(@"Unable to create the temporary Entitlements document.", nil)];
        return;
    }
    self.savedEntitlementsPath = outputPath;
    void (^completion)(NSString *) = [self.onSave copy];
    UIViewController *presenter = self.navigationController ?: self;
    [presenter dismissViewControllerAnimated:YES completion:^{
        if (completion) completion(outputPath);
    }];
}

- (void)cancelEditing
{
    void (^completion)(void) = [self.onCancel copy];
    UIViewController* presenter = self.navigationController ?: self;
    [presenter dismissViewControllerAnimated:YES completion:completion];
}

- (void)resetDocument
{
    if (!self.sourceEntitlementsLoaded) return;
    NSDictionary *original = self.originalMainEntitlements ?: @{};
    NSData *data = [NSPropertyListSerialization dataWithPropertyList:original format:NSPropertyListXMLFormat_v1_0 options:0 error:nil];
    self.editorView.text = data ? [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] : TSEntitlementsTemplate();
    [self refreshVisualTable];
    [self updateFinalPreview];
}

- (void)showError:(NSString*)message
{
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Invalid Entitlements", nil)
        message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
