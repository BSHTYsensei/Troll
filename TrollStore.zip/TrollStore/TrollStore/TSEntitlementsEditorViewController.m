#import "TSEntitlementsEditorViewController.h"

#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import "TSAppInfo.h"
#import "TSCommonTCCServiceNames.h"

extern NSUserDefaults* trollStoreUserDefaults(void);

static NSString* TSEntitlementsTemplate(void)
{
    return @"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
           @"<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n"
           @"<plist version=\"1.0\">\n<dict>\n</dict>\n</plist>\n";
}

@interface TSEntitlementsEditorViewController () <UITextViewDelegate, UITableViewDataSource, UITableViewDelegate>
@property(nonatomic, strong) UISwitch* applySwitch;
@property(nonatomic, strong) UITextView* editorView;
@property(nonatomic, strong) UITextView* originalEntitlementsView;
@property(nonatomic, strong) UITextView* mergedPreviewView;
@property(nonatomic, strong) UIButton* presetsButton;
@property(nonatomic, strong) UISegmentedControl* editorModeControl;
@property(nonatomic, strong) UITableView* visualTableView;
@property(nonatomic, strong) NSLayoutConstraint* visualTableHeightConstraint;
@property(nonatomic, strong) UILabel* xmlEditorLabel;
@property(nonatomic, copy) NSDictionary<NSString*, NSDictionary*>* originalEntitlementsByBinary;
@property(nonatomic, copy) NSDictionary* originalMainEntitlements;
@property(nonatomic, copy) NSString* entitlementFilePath;
@end

@implementation TSEntitlementsEditorViewController

- (NSString*)entitlementFilePath
{
    if(!_entitlementFilePath)
    {
        NSString* applicationSupport = [NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES) firstObject];
        _entitlementFilePath = [applicationSupport stringByAppendingPathComponent:@"TSCustomEntitlements.plist"];
    }
    return _entitlementFilePath;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = self.onSave ? NSLocalizedString(@"Edit Entitlements Before Install", nil) : NSLocalizedString(@"Edit Entitlements", nil);
    self.view.backgroundColor = UIColor.systemGroupedBackgroundColor;

    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", nil)
        style:UIBarButtonItemStylePlain target:self action:@selector(cancelEditing)];
    UIBarButtonItem* resetItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Reset", nil)
        style:UIBarButtonItemStylePlain target:self action:@selector(resetDocument)];
    NSString* saveTitle = self.onSave ? NSLocalizedString(@"Save & Install", nil) : NSLocalizedString(@"Save", nil);
    UIBarButtonItem* saveItem = [[UIBarButtonItem alloc] initWithTitle:saveTitle
        style:UIBarButtonItemStyleDone target:self action:@selector(saveAndInstall)];
    self.navigationItem.rightBarButtonItems = @[saveItem, resetItem];

    [self buildLayout];
    self.applySwitch.on = [trollStoreUserDefaults() boolForKey:@"TSCustomEntitlementsOverrideEnabled"];
    [self loadDocument];
}

- (void)buildLayout
{
    UIScrollView* scrollView = [UIScrollView new];
    scrollView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:scrollView];
    [NSLayoutConstraint activateConstraints:@[
        [scrollView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],
        [scrollView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [scrollView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [scrollView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor]
    ]];

    UIStackView* content = [UIStackView new];
    content.axis = UILayoutConstraintAxisVertical;
    content.spacing = 16;
    content.translatesAutoresizingMaskIntoConstraints = NO;
    [scrollView addSubview:content];
    [NSLayoutConstraint activateConstraints:@[
        [content.topAnchor constraintEqualToAnchor:scrollView.contentLayoutGuide.topAnchor constant:18],
        [content.leadingAnchor constraintEqualToAnchor:scrollView.frameLayoutGuide.leadingAnchor constant:16],
        [content.trailingAnchor constraintEqualToAnchor:scrollView.frameLayoutGuide.trailingAnchor constant:-16],
        [content.bottomAnchor constraintEqualToAnchor:scrollView.contentLayoutGuide.bottomAnchor constant:-22]
    ]];

    UIStackView* toggleRow = [UIStackView new];
    toggleRow.axis = UILayoutConstraintAxisHorizontal;
    toggleRow.alignment = UIStackViewAlignmentCenter;
    toggleRow.spacing = 12;
    toggleRow.backgroundColor = UIColor.secondarySystemGroupedBackgroundColor;
    toggleRow.layoutMarginsRelativeArrangement = YES;
    toggleRow.layoutMargins = UIEdgeInsetsMake(14, 14, 14, 14);
    toggleRow.layer.cornerRadius = 12;

    UILabel* toggleLabel = [UILabel new];
    toggleLabel.text = NSLocalizedString(@"Apply custom Entitlements during installation", nil);
    toggleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    toggleLabel.numberOfLines = 0;
    [toggleLabel setContentHuggingPriority:UILayoutPriorityDefaultLow forAxis:UILayoutConstraintAxisHorizontal];
    self.applySwitch = [UISwitch new];
    [self.applySwitch setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    [toggleRow addArrangedSubview:toggleLabel];
    [toggleRow addArrangedSubview:self.applySwitch];
    [content addArrangedSubview:toggleRow];

    UILabel* help = [UILabel new];
    help.text = NSLocalizedString(@"When enabled, keys in this plist override matching Entitlements in the main app executable during TrollStore's normal signing flow. Unspecified keys are preserved. Extensions retain their own Entitlements.", nil);
    help.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    help.textColor = UIColor.secondaryLabelColor;
    help.numberOfLines = 0;
    [content addArrangedSubview:help];

    UILabel *originalLabel = [UILabel new];
    originalLabel.text = NSLocalizedString(@"Original Entitlements (read only)", nil);
    originalLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    [content addArrangedSubview:originalLabel];

    self.originalEntitlementsView = [UITextView new];
    self.originalEntitlementsView.editable = NO;
    self.originalEntitlementsView.selectable = YES;
    self.originalEntitlementsView.font = [UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightRegular];
    self.originalEntitlementsView.backgroundColor = UIColor.tertiarySystemGroupedBackgroundColor;
    self.originalEntitlementsView.layer.cornerRadius = 10;
    self.originalEntitlementsView.textContainerInset = UIEdgeInsetsMake(10, 9, 10, 9);
    [self.originalEntitlementsView.heightAnchor constraintGreaterThanOrEqualToConstant:150].active = YES;
    self.originalEntitlementsView.text = NSLocalizedString(@"Open this editor from the install confirmation to inspect the IPA's original values.", nil);
    [content addArrangedSubview:self.originalEntitlementsView];

    self.editorModeControl = [[UISegmentedControl alloc] initWithItems:@[
        NSLocalizedString(@"Visual", nil), NSLocalizedString(@"XML (advanced)", nil)
    ]];
    self.editorModeControl.selectedSegmentIndex = 0;
    [self.editorModeControl addTarget:self action:@selector(editorModeChanged:) forControlEvents:UIControlEventValueChanged];
    [content addArrangedSubview:self.editorModeControl];

    self.visualTableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleInsetGrouped];
    self.visualTableView.dataSource = self;
    self.visualTableView.delegate = self;
    self.visualTableView.backgroundColor = UIColor.clearColor;
    self.visualTableView.rowHeight = UITableViewAutomaticDimension;
    self.visualTableView.estimatedRowHeight = 58;
    self.visualTableHeightConstraint = [self.visualTableView.heightAnchor constraintEqualToConstant:250];
    self.visualTableHeightConstraint.active = YES;
    [content addArrangedSubview:self.visualTableView];

    UILabel* editorLabel = [UILabel new];
    editorLabel.text = NSLocalizedString(@"Entitlements property list (XML)", nil);
    editorLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    self.xmlEditorLabel = editorLabel;
    [content addArrangedSubview:editorLabel];

    self.presetsButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [self.presetsButton setTitle:NSLocalizedString(@"Add Entitlement Preset", nil) forState:UIControlStateNormal];
    [self.presetsButton addTarget:self action:@selector(showPresetPicker) forControlEvents:UIControlEventTouchUpInside];
    self.presetsButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeading;
    [content addArrangedSubview:self.presetsButton];

    self.editorView = [UITextView new];
    self.editorView.font = [UIFont monospacedSystemFontOfSize:13 weight:UIFontWeightRegular];
    self.editorView.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.editorView.autocorrectionType = UITextAutocorrectionTypeNo;
    self.editorView.spellCheckingType = UITextSpellCheckingTypeNo;
    self.editorView.smartQuotesType = UITextSmartQuotesTypeNo;
    self.editorView.smartDashesType = UITextSmartDashesTypeNo;
    self.editorView.backgroundColor = UIColor.secondarySystemGroupedBackgroundColor;
    self.editorView.layer.cornerRadius = 12;
    self.editorView.layer.borderWidth = 1.0 / UIScreen.mainScreen.scale;
    self.editorView.layer.borderColor = UIColor.separatorColor.CGColor;
    self.editorView.textContainerInset = UIEdgeInsetsMake(12, 10, 12, 10);
    self.editorView.accessibilityLabel = NSLocalizedString(@"Entitlements property list (XML)", nil);
    self.editorView.delegate = self;
    [self.editorView.heightAnchor constraintGreaterThanOrEqualToConstant:300].active = YES;
    [content addArrangedSubview:self.editorView];
    self.xmlEditorLabel.hidden = YES;
    self.editorView.hidden = YES;

    UILabel *previewLabel = [UILabel new];
    previewLabel.text = NSLocalizedString(@"Merged Entitlements Preview", nil);
    previewLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    [content addArrangedSubview:previewLabel];

    self.mergedPreviewView = [UITextView new];
    self.mergedPreviewView.editable = NO;
    self.mergedPreviewView.selectable = YES;
    self.mergedPreviewView.font = [UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightRegular];
    self.mergedPreviewView.backgroundColor = UIColor.tertiarySystemGroupedBackgroundColor;
    self.mergedPreviewView.layer.cornerRadius = 10;
    self.mergedPreviewView.textContainerInset = UIEdgeInsetsMake(10, 9, 10, 9);
    [self.mergedPreviewView.heightAnchor constraintGreaterThanOrEqualToConstant:180].active = YES;
    [content addArrangedSubview:self.mergedPreviewView];

    UILabel* footer = [UILabel new];
    footer.text = NSLocalizedString(@"Only add keys you understand. Invalid property lists are rejected before installation. Some entitlements are restricted by iOS and cannot be made functional by signing alone.", nil);
    footer.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    footer.textColor = UIColor.secondaryLabelColor;
    footer.numberOfLines = 0;
    [content addArrangedSubview:footer];
}

- (void)loadDocument
{
    NSData* data = [NSData dataWithContentsOfFile:self.entitlementFilePath];
    NSError* error = nil;
    id plist = data ? [NSPropertyListSerialization propertyListWithData:data options:NSPropertyListMutableContainersAndLeaves format:nil error:&error] : nil;
    NSData* xmlData = plist ? [NSPropertyListSerialization dataWithPropertyList:plist format:NSPropertyListXMLFormat_v1_0 options:0 error:nil] : nil;
    NSString* xml = xmlData ? [[NSString alloc] initWithData:xmlData encoding:NSUTF8StringEncoding] : nil;
    self.editorView.text = xml ?: TSEntitlementsTemplate();
    [self refreshVisualTable];
    [self loadSourceEntitlements];
    [self updateMergedPreview];
}

- (void)loadSourceEntitlements
{
    if (self.sourceIPAPath.length == 0) {
        self.originalEntitlementsView.text = NSLocalizedString(@"Open this editor from the install confirmation to inspect the IPA's original values. When opened from Settings, only the custom overlay is available.", nil);
        self.originalEntitlementsByBinary = @{};
        self.originalMainEntitlements = @{};
        [self updateMergedPreview];
        return;
    }

    NSString *ipaPath = [self.sourceIPAPath copy];
    TSAppInfo *appInfo = [[TSAppInfo alloc] initWithIPAPath:ipaPath];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSError *loadError = [appInfo sync_loadInfo];
        NSDictionary *binaryEntitlements = loadError ? @{} : [appInfo entitlementsByBinarySubpaths];
        NSString *mainPath = [appInfo mainExecutableSubpath];
        NSDictionary *mainCandidate = mainPath.length ? binaryEntitlements[mainPath] : nil;
        NSDictionary *mainEntitlements = [mainCandidate isKindOfClass:NSDictionary.class] ? mainCandidate : @{};
        NSArray *binaryPaths = [[binaryEntitlements allKeys] sortedArrayUsingSelector:@selector(localizedStandardCompare:)];
        NSMutableString *display = [NSMutableString new];
        for (NSString *binaryPath in binaryPaths) {
            [display appendFormat:@"%@\n", binaryPath];
            NSDictionary *dict = binaryEntitlements[binaryPath];
            NSData *plistData = [NSPropertyListSerialization dataWithPropertyList:([dict isKindOfClass:NSDictionary.class] ? dict : @{}) format:NSPropertyListXMLFormat_v1_0 options:0 error:nil];
            NSString *plistText = plistData ? [[NSString alloc] initWithData:plistData encoding:NSUTF8StringEncoding] : @"<dict/>";
            [display appendFormat:@"%@\n\n", plistText ?: @"<dict/>"];
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            self.originalEntitlementsByBinary = binaryEntitlements;
            self.originalMainEntitlements = mainEntitlements;
            if (loadError) {
                self.originalEntitlementsView.text = [NSString stringWithFormat:NSLocalizedString(@"Could not load original Entitlements: %@", nil), loadError.localizedDescription ?: @""];
            } else if (display.length == 0) {
                self.originalEntitlementsView.text = NSLocalizedString(@"No embedded Entitlements were found in this IPA.", nil);
            } else {
                self.originalEntitlementsView.text = display;
            }
            [self updateMergedPreview];
        });
    });
}

- (NSDictionary*)parsedOverlayDictionary
{
    NSData *data = [self.editorView.text dataUsingEncoding:NSUTF8StringEncoding];
    if (!data) return @{};
    id value = [NSPropertyListSerialization propertyListWithData:data options:NSPropertyListMutableContainersAndLeaves format:nil error:nil];
    return [value isKindOfClass:NSDictionary.class] ? value : @{};
}

- (void)textViewDidChange:(UITextView *)textView
{
    if (textView == self.editorView) {
        [self refreshVisualTable];
        [self updateMergedPreview];
    }
}

- (void)editorModeChanged:(UISegmentedControl *)control
{
    BOOL showXML = control.selectedSegmentIndex == 1;
    self.visualTableView.hidden = showXML;
    self.xmlEditorLabel.hidden = !showXML;
    self.editorView.hidden = !showXML;
    if (!showXML) [self refreshVisualTable];
}

- (void)refreshVisualTable
{
    if (!self.visualTableView) return;
    NSUInteger rows = [self sortedOverlayKeys].count;
    // Keep the table embedded in the parent scroll view without making its
    // intrinsic height ambiguous or forcing a second nested scrolling region.
    CGFloat rowHeight = 62.0;
    CGFloat desiredHeight = rows == 0 ? 88.0 : MIN(420.0, MAX(120.0, 42.0 + rows * rowHeight));
    self.visualTableHeightConstraint.constant = desiredHeight;
    [self.visualTableView reloadData];
}

- (void)writeOverlayDictionary:(NSDictionary *)overlay
{
    NSDictionary *safeOverlay = [overlay isKindOfClass:NSDictionary.class] ? overlay : @{};
    NSError *error = nil;
    NSData *xmlData = [NSPropertyListSerialization dataWithPropertyList:safeOverlay format:NSPropertyListXMLFormat_v1_0 options:0 error:&error];
    if (!xmlData) {
        [self showError:error.localizedDescription ?: NSLocalizedString(@"Unable to serialize the Entitlements dictionary.", nil)];
        return;
    }
    self.editorView.text = [[NSString alloc] initWithData:xmlData encoding:NSUTF8StringEncoding] ?: TSEntitlementsTemplate();
    [self refreshVisualTable];
    [self updateMergedPreview];
}

- (NSArray<NSString *> *)sortedOverlayKeys
{
    return [[[self parsedOverlayDictionary] allKeys] sortedArrayUsingSelector:@selector(localizedStandardCompare:)];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSUInteger count = [self sortedOverlayKeys].count;
    return count == 0 ? 1 : count; // placeholder row when the overlay is empty
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"EntitlementOverlayCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:identifier];
    NSArray<NSString *> *keys = [self sortedOverlayKeys];
    if (keys.count == 0) {
        cell.textLabel.text = NSLocalizedString(@"No custom keys yet. Add a preset or create a custom key.", nil);
        cell.textLabel.numberOfLines = 0;
        cell.detailTextLabel.text = nil;
        cell.accessoryView = nil;
        cell.accessoryType = UITableViewCellAccessoryNone;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    if (indexPath.row >= keys.count) return cell;
    NSString *key = keys[indexPath.row];
    id value = [self parsedOverlayDictionary][key];
    cell.textLabel.text = key;
    cell.textLabel.numberOfLines = 0;
    cell.detailTextLabel.numberOfLines = 2;
    cell.accessoryView = nil;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    if ([value isKindOfClass:NSString.class]) {
        cell.detailTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"String · %@", nil), value];
    } else if ([value isKindOfClass:NSNumber.class] && CFGetTypeID((__bridge CFTypeRef)value) == CFBooleanGetTypeID()) {
        BOOL on = [value boolValue];
        cell.detailTextLabel.text = NSLocalizedString(on ? @"Boolean: On" : @"Boolean: Off", nil);
        UISwitch *toggle = [UISwitch new];
        toggle.on = on;
        toggle.accessibilityIdentifier = key;
        [toggle addTarget:self action:@selector(visualBooleanChanged:) forControlEvents:UIControlEventValueChanged];
        cell.accessoryView = toggle;
        cell.accessoryType = UITableViewCellAccessoryNone;
    } else if ([value isKindOfClass:NSArray.class]) {
        cell.detailTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"Array · %lu item(s)", nil), (unsigned long)[value count]];
    } else if ([value isKindOfClass:NSDictionary.class]) {
        cell.detailTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"Dictionary · %lu key(s)", nil), (unsigned long)[value count]];
    } else if ([value isKindOfClass:NSNumber.class]) {
        cell.detailTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"Number · %@", nil), value];
    } else {
        cell.detailTextLabel.text = NSLocalizedString(@"Tap to edit this value in XML mode.", nil);
    }
    return cell;
}

- (void)visualBooleanChanged:(UISwitch *)sender
{
    NSString *key = sender.accessibilityIdentifier;
    if (!key.length) return;
    NSMutableDictionary *overlay = [[self parsedOverlayDictionary] mutableCopy] ?: [NSMutableDictionary new];
    overlay[key] = @(sender.isOn);
    [self writeOverlayDictionary:overlay];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSArray<NSString *> *keys = [self sortedOverlayKeys];
    if (indexPath.row >= keys.count) return;
    NSString *key = keys[indexPath.row];
    id current = [self parsedOverlayDictionary][key];
    if ([current isKindOfClass:NSNumber.class] && CFGetTypeID((__bridge CFTypeRef)current) == CFBooleanGetTypeID()) return;

    BOOL isComposite = [current isKindOfClass:NSArray.class] || [current isKindOfClass:NSDictionary.class];
    UIAlertController *editor = [UIAlertController alertControllerWithTitle:key
        message:isComposite ? NSLocalizedString(@"Enter a JSON array or object. For complex property-list values, use XML (advanced).", nil) : NSLocalizedString(@"Edit entitlement value", nil)
        preferredStyle:UIAlertControllerStyleAlert];
    [editor addTextFieldWithConfigurationHandler:^(UITextField *field) {
        field.autocapitalizationType = UITextAutocapitalizationTypeNone;
        field.autocorrectionType = UITextAutocorrectionTypeNo;
        field.clearButtonMode = UITextFieldViewModeWhileEditing;
        if ([current isKindOfClass:NSString.class]) field.text = current;
        else if (isComposite) {
            NSData *json = [NSJSONSerialization dataWithJSONObject:current options:NSJSONWritingFragmentsAllowed error:nil];
            field.text = json ? [[NSString alloc] initWithData:json encoding:NSUTF8StringEncoding] : @"";
        } else field.text = [current description] ?: @"";
    }];
    [editor addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [editor addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Save", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        NSString *text = editor.textFields.firstObject.text ?: @"";
        id nextValue = nil;
        NSError *parseError = nil;
        if ([current isKindOfClass:NSString.class]) nextValue = text;
        else if (isComposite) {
            NSData *data = [text dataUsingEncoding:NSUTF8StringEncoding];
            nextValue = data ? [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingFragmentsAllowed error:&parseError] : nil;
            if (![nextValue isKindOfClass:NSArray.class] && ![nextValue isKindOfClass:NSDictionary.class]) nextValue = nil;
        } else if ([current isKindOfClass:NSNumber.class]) {
            NSNumberFormatter *formatter = [NSNumberFormatter new];
            nextValue = [formatter numberFromString:text];
        }
        if (!nextValue || ![NSPropertyListSerialization propertyList:nextValue isValidForFormat:NSPropertyListXMLFormat_v1_0]) {
            [self showError:parseError.localizedDescription ?: NSLocalizedString(@"The value is invalid for its current property-list type. Use XML (advanced) for complex values.", nil)];
            return;
        }
        NSMutableDictionary *overlay = [[self parsedOverlayDictionary] mutableCopy] ?: [NSMutableDictionary new];
        overlay[key] = nextValue;
        [self writeOverlayDictionary:overlay];
    }]];
    [self presentViewController:editor animated:YES completion:nil];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath { return [self sortedOverlayKeys].count > 0; }

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle != UITableViewCellEditingStyleDelete) return;
    NSArray<NSString *> *keys = [self sortedOverlayKeys];
    if (indexPath.row >= keys.count) return;
    NSMutableDictionary *overlay = [[self parsedOverlayDictionary] mutableCopy] ?: [NSMutableDictionary new];
    [overlay removeObjectForKey:keys[indexPath.row]];
    [self writeOverlayDictionary:overlay];
}

- (void)updateMergedPreview
{
    if (!self.mergedPreviewView || !self.editorView) return;
    NSDictionary *overlay = [self parsedOverlayDictionary];
    NSDictionary *original = self.originalMainEntitlements ?: @{};
    NSMutableDictionary *merged = [original mutableCopy] ?: [NSMutableDictionary new];
    NSMutableArray<NSString *> *overriddenKeys = [NSMutableArray new];
    NSMutableArray<NSString *> *addedKeys = [NSMutableArray new];
    NSArray<NSString *> *overlayKeys = [[overlay allKeys] sortedArrayUsingSelector:@selector(localizedStandardCompare:)];
    for (NSString *key in overlayKeys) {
        if (original[key] != nil) [overriddenKeys addObject:key];
        else [addedKeys addObject:key];
        merged[key] = overlay[key];
    }
    NSData *plistData = [NSPropertyListSerialization dataWithPropertyList:merged format:NSPropertyListXMLFormat_v1_0 options:0 error:nil];
    NSString *plistText = plistData ? [[NSString alloc] initWithData:plistData encoding:NSUTF8StringEncoding] : TSEntitlementsTemplate();
    NSMutableAttributedString *summary = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:NSLocalizedString(@"Overlay summary: %lu key(s) override original values; %lu key(s) are new. Unspecified keys remain unchanged.\n", nil), (unsigned long)overriddenKeys.count, (unsigned long)addedKeys.count]];
    if (overriddenKeys.count) {
        NSAttributedString *line = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:NSLocalizedString(@"Overridden keys: %@\n", nil), [overriddenKeys componentsJoinedByString:@", "]] attributes:@{NSForegroundColorAttributeName: UIColor.systemOrangeColor}];
        [summary appendAttributedString:line];
    }
    if (addedKeys.count) {
        NSAttributedString *line = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:NSLocalizedString(@"Added keys: %@\n", nil), [addedKeys componentsJoinedByString:@", "]] attributes:@{NSForegroundColorAttributeName: UIColor.systemGreenColor}];
        [summary appendAttributedString:line];
    }
    if (!overriddenKeys.count && !addedKeys.count) [summary appendAttributedString:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"No custom keys yet. Add a preset or create a custom key.\n", nil)]];
    if (self.sourceIPAPath.length == 0) [summary appendAttributedString:[[NSAttributedString alloc] initWithString:NSLocalizedString(@"No IPA source was supplied; this preview shows the overlay only.\n", nil)]];
    [summary appendAttributedString:[[NSAttributedString alloc] initWithString:@"\n"]];
    [summary appendAttributedString:[[NSAttributedString alloc] initWithString:plistText ?: TSEntitlementsTemplate()]];
    self.mergedPreviewView.attributedText = summary;
}

- (void)showPresetPicker
{
    UIAlertController *picker = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Add Entitlement Preset", nil) message:NSLocalizedString(@"Some private entitlements may destabilize apps or expose protected capabilities; signing does not grant every capability on every iOS version.", nil) preferredStyle:UIAlertControllerStyleActionSheet];
    [picker addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Add Custom Entitlement Key", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self showAddCustomKeyPrompt]; });
    }]];
    NSArray<NSDictionary*> *presets = @[
        @{@"key": @"get-task-allow", @"title": @"get-task-allow · Boolean (low risk)", @"value": @YES},
        @{@"key": @"platform-application", @"title": @"platform-application · Boolean (high risk)", @"value": @YES},
        @{@"key": @"com.apple.private.security.no-sandbox", @"title": @"no-sandbox · Boolean (high risk)", @"value": @YES},
        @{@"key": @"com.apple.private.security.container-required", @"title": @"container-required · Boolean", @"value": @YES},
        @{@"key": @"com.apple.private.tcc.allow", @"title": @"com.apple.private.tcc.allow · Array (high risk)", @"value": @[]},
        @{@"key": @"com.apple.security.application-groups", @"title": @"application-groups · Array", @"value": @[]},
        @{@"key": @"keychain-access-groups", @"title": @"keychain-access-groups · Array", @"value": @[]},
        @{@"key": @"com.apple.developer.icloud-container-identifiers", @"title": @"iCloud container identifiers · Array", @"value": @[]}
    ];
    __weak typeof(self) weakSelf = self;
    for (NSDictionary *preset in presets) {
        [picker addAction:[UIAlertAction actionWithTitle:NSLocalizedString(preset[@"title"], nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            void (^insertPreset)(void) = ^{
                __strong typeof(weakSelf) self = weakSelf;
                if (!self) return;
                NSString *presetKey = preset[@"key"];
                if ([presetKey isEqualToString:@"com.apple.private.tcc.allow"]) {
                    [self showTCCServicePicker];
                    return;
                }
                NSMutableDictionary *overlay = [[self parsedOverlayDictionary] mutableCopy] ?: [NSMutableDictionary new];
                overlay[presetKey] = preset[@"value"];
                [self writeOverlayDictionary:overlay];
            };
            NSString *key = preset[@"key"];
            BOOL risky = [key isEqualToString:@"platform-application"] || [key isEqualToString:@"com.apple.private.security.no-sandbox"] || [key isEqualToString:@"com.apple.private.tcc.allow"];
            if (!risky) { insertPreset(); return; }
            UIAlertController *warning = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"High-risk Entitlement", nil) message:[NSString stringWithFormat:NSLocalizedString(@"%@ is a private or privileged entitlement. Adding it may cause crashes or unexpected access behavior. Add it anyway?", nil), key] preferredStyle:UIAlertControllerStyleAlert];
            [warning addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
            [warning addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Add Anyway", nil) style:UIAlertActionStyleDestructive handler:^(UIAlertAction *warningAction) { insertPreset(); }]];
            [self presentViewController:warning animated:YES completion:nil];
        }]];
    }
    [picker addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    picker.popoverPresentationController.sourceView = self.presetsButton;
    picker.popoverPresentationController.sourceRect = self.presetsButton.bounds;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)showAddCustomKeyPrompt
{
    UIAlertController *prompt = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Custom Entitlement Key", nil)
        message:NSLocalizedString(@"Enter the exact entitlement key name.", nil) preferredStyle:UIAlertControllerStyleAlert];
    [prompt addTextFieldWithConfigurationHandler:^(UITextField *field) {
        field.placeholder = @"com.example.entitlement";
        field.autocapitalizationType = UITextAutocapitalizationTypeNone;
        field.autocorrectionType = UITextAutocorrectionTypeNo;
        field.clearButtonMode = UITextFieldViewModeWhileEditing;
    }];
    [prompt addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [prompt addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Add Key", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        NSString *key = [prompt.textFields.firstObject.text stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        if (!key.length) {
            [self showError:NSLocalizedString(@"Enter the exact entitlement key name.", nil)];
            return;
        }
        if ([self parsedOverlayDictionary][key] != nil) {
            [self showError:NSLocalizedString(@"This key already exists. Remove it first or edit the existing row.", nil)];
            return;
        }
        dispatch_async(dispatch_get_main_queue(), ^{ [self showValueTypePickerForKey:key]; });
    }]];
    [self presentViewController:prompt animated:YES completion:nil];
}

- (void)showValueTypePickerForKey:(NSString *)key
{
    UIAlertController *picker = [UIAlertController alertControllerWithTitle:key message:NSLocalizedString(@"Choose a value type for this key.", nil) preferredStyle:UIAlertControllerStyleActionSheet];
    NSDictionary *types = @{
        NSLocalizedString(@"String", nil): @"",
        NSLocalizedString(@"Boolean", nil): @NO,
        NSLocalizedString(@"Array", nil): @[],
        NSLocalizedString(@"Dictionary", nil): @{},
        NSLocalizedString(@"Number", nil): @0
    };
    for (NSString *title in types) {
        [picker addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            NSMutableDictionary *overlay = [[self parsedOverlayDictionary] mutableCopy] ?: [NSMutableDictionary new];
            overlay[key] = types[title];
            [self writeOverlayDictionary:overlay];
        }]];
    }
    [picker addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    picker.popoverPresentationController.sourceView = self.presetsButton;
    picker.popoverPresentationController.sourceRect = self.presetsButton.bounds;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)showTCCServicePicker
{
    UIAlertController *picker = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Add Common TCC Service", nil)
        message:NSLocalizedString(@"Choose a common TCC service to add.", nil) preferredStyle:UIAlertControllerStyleActionSheet];
    NSArray<NSString *> *serviceKeys = [[commonTCCServices allKeys] sortedArrayUsingSelector:@selector(localizedStandardCompare:)];
    NSDictionary *existing = [self parsedOverlayDictionary];
    NSArray *existingServices = [existing[@"com.apple.private.tcc.allow"] isKindOfClass:NSArray.class] ? existing[@"com.apple.private.tcc.allow"] : @[];
    for (NSString *serviceKey in serviceKeys) {
        NSString *serviceName = commonTCCServices[serviceKey];
        NSString *title = [NSString stringWithFormat:@"%@ (%@)", NSLocalizedString(serviceName, nil), serviceKey];
        [picker addAction:[UIAlertAction actionWithTitle:title style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            NSMutableArray *services = [existingServices mutableCopy] ?: [NSMutableArray new];
            if (![services containsObject:serviceKey]) [services addObject:serviceKey];
            NSMutableDictionary *overlay = [[self parsedOverlayDictionary] mutableCopy] ?: [NSMutableDictionary new];
            overlay[@"com.apple.private.tcc.allow"] = services;
            [self writeOverlayDictionary:overlay];
        }]];
    }
    [picker addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    picker.popoverPresentationController.sourceView = self.presetsButton;
    picker.popoverPresentationController.sourceRect = self.presetsButton.bounds;
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)saveAndInstall
{
    [self updateMergedPreview];
    NSData* data = [self.editorView.text dataUsingEncoding:NSUTF8StringEncoding];
    NSError* parseError = nil;
    id object = data ? [NSPropertyListSerialization propertyListWithData:data options:NSPropertyListMutableContainersAndLeaves format:nil error:&parseError] : nil;
    if(![object isKindOfClass:NSDictionary.class])
    {
        NSString* message = NSLocalizedString(@"The Entitlements document is not a valid XML plist dictionary.", nil);
        if(parseError.localizedDescription.length) message = [message stringByAppendingFormat:@"\n%@", parseError.localizedDescription];
        [self showError:message];
        return;
    }

    NSError* error = nil;
    NSString* folder = [self.entitlementFilePath stringByDeletingLastPathComponent];
    if(![[NSFileManager defaultManager] createDirectoryAtPath:folder withIntermediateDirectories:YES attributes:nil error:&error])
    {
        [self showError:error.localizedDescription ?: NSLocalizedString(@"Unable to create the Application Support folder.", nil)];
        return;
    }
    NSData* output = [NSPropertyListSerialization dataWithPropertyList:object format:NSPropertyListXMLFormat_v1_0 options:0 error:&error];
    if(!output || ![output writeToFile:self.entitlementFilePath options:NSDataWritingAtomic error:&error])
    {
        [self showError:error.localizedDescription ?: NSLocalizedString(@"Unable to save Entitlements.", nil)];
        return;
    }
    [trollStoreUserDefaults() setBool:self.applySwitch.isOn forKey:@"TSCustomEntitlementsOverrideEnabled"];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TrollStoreReloadSettingsNotification" object:nil userInfo:nil];

    if(self.onSave)
    {
        void (^completion)(void) = [self.onSave copy];
        UIViewController* presenter = self.navigationController ?: self;
        [presenter dismissViewControllerAnimated:YES completion:completion];
        return;
    }
    UIAlertController* savedAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Saved", nil)
        message:NSLocalizedString(@"Entitlements settings were saved.", nil) preferredStyle:UIAlertControllerStyleAlert];
    [savedAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
    {
        [self.navigationController dismissViewControllerAnimated:YES completion:nil];
    }]];
    [self presentViewController:savedAlert animated:YES completion:nil];
}

- (void)cancelEditing
{
    void (^completion)(void) = [self.onCancel copy];
    UIViewController* presenter = self.navigationController ?: self;
    [presenter dismissViewControllerAnimated:YES completion:completion];
}

- (void)resetDocument
{
    self.editorView.text = TSEntitlementsTemplate();
    self.applySwitch.on = NO;
    [self refreshVisualTable];
    [self updateMergedPreview];
}

- (void)showError:(NSString*)message
{
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Invalid Entitlements", nil)
        message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
