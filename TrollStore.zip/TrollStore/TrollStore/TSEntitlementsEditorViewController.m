#import "TSEntitlementsEditorViewController.h"

#import <Foundation/Foundation.h>

extern NSUserDefaults* trollStoreUserDefaults(void);

static NSString* TSEntitlementsTemplate(void)
{
    return @"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
           @"<!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\">\n"
           @"<plist version=\"1.0\">\n<dict>\n</dict>\n</plist>\n";
}

@interface TSEntitlementsEditorViewController ()
@property(nonatomic, strong) UISwitch* applySwitch;
@property(nonatomic, strong) UITextView* editorView;
@property(nonatomic, copy) NSString* entitlementFilePath;
@end

@implementation TSEntitlementsEditorViewController

- (NSString*)entitlementFilePath
{
    if(!_entitlementFilePath)
    {
        NSString* applicationSupport = [NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES) firstObject];
        _entitlementFilePath = [applicationSupport stringByAppendingPathComponent:@"TSCustomEntitlements.plist"];
    }
    return _entitlementFilePath;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = self.onSave ? NSLocalizedString(@"Edit Entitlements Before Install", nil) : NSLocalizedString(@"Edit Entitlements", nil);
    self.view.backgroundColor = UIColor.systemGroupedBackgroundColor;

    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Cancel", nil)
        style:UIBarButtonItemStylePlain target:self action:@selector(cancelEditing)];
    UIBarButtonItem* resetItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Reset", nil)
        style:UIBarButtonItemStylePlain target:self action:@selector(resetDocument)];
    NSString* saveTitle = self.onSave ? NSLocalizedString(@"Save & Install", nil) : NSLocalizedString(@"Save", nil);
    UIBarButtonItem* saveItem = [[UIBarButtonItem alloc] initWithTitle:saveTitle
        style:UIBarButtonItemStyleDone target:self action:@selector(saveAndInstall)];
    self.navigationItem.rightBarButtonItems = @[saveItem, resetItem];

    [self buildLayout];
    self.applySwitch.on = [trollStoreUserDefaults() boolForKey:@"TSCustomEntitlementsOverrideEnabled"];
    [self loadDocument];
}

- (void)buildLayout
{
    UIScrollView* scrollView = [UIScrollView new];
    scrollView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:scrollView];
    [NSLayoutConstraint activateConstraints:@[
        [scrollView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],
        [scrollView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [scrollView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [scrollView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor]
    ]];

    UIStackView* content = [UIStackView new];
    content.axis = UILayoutConstraintAxisVertical;
    content.spacing = 16;
    content.translatesAutoresizingMaskIntoConstraints = NO;
    [scrollView addSubview:content];
    [NSLayoutConstraint activateConstraints:@[
        [content.topAnchor constraintEqualToAnchor:scrollView.contentLayoutGuide.topAnchor constant:18],
        [content.leadingAnchor constraintEqualToAnchor:scrollView.frameLayoutGuide.leadingAnchor constant:16],
        [content.trailingAnchor constraintEqualToAnchor:scrollView.frameLayoutGuide.trailingAnchor constant:-16],
        [content.bottomAnchor constraintEqualToAnchor:scrollView.contentLayoutGuide.bottomAnchor constant:-22]
    ]];

    UIStackView* toggleRow = [UIStackView new];
    toggleRow.axis = UILayoutConstraintAxisHorizontal;
    toggleRow.alignment = UIStackViewAlignmentCenter;
    toggleRow.spacing = 12;
    toggleRow.backgroundColor = UIColor.secondarySystemGroupedBackgroundColor;
    toggleRow.layoutMarginsRelativeArrangement = YES;
    toggleRow.layoutMargins = UIEdgeInsetsMake(14, 14, 14, 14);
    toggleRow.layer.cornerRadius = 12;

    UILabel* toggleLabel = [UILabel new];
    toggleLabel.text = NSLocalizedString(@"Apply custom Entitlements during installation", nil);
    toggleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    toggleLabel.numberOfLines = 0;
    [toggleLabel setContentHuggingPriority:UILayoutPriorityDefaultLow forAxis:UILayoutConstraintAxisHorizontal];
    self.applySwitch = [UISwitch new];
    [self.applySwitch setContentHuggingPriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
    [toggleRow addArrangedSubview:toggleLabel];
    [toggleRow addArrangedSubview:self.applySwitch];
    [content addArrangedSubview:toggleRow];

    UILabel* help = [UILabel new];
    help.text = NSLocalizedString(@"When enabled, keys in this plist override matching Entitlements in the main app executable during TrollStore's normal signing flow. Unspecified keys are preserved. Extensions retain their own Entitlements.", nil);
    help.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    help.textColor = UIColor.secondaryLabelColor;
    help.numberOfLines = 0;
    [content addArrangedSubview:help];

    UILabel* editorLabel = [UILabel new];
    editorLabel.text = NSLocalizedString(@"Entitlements property list (XML)", nil);
    editorLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    [content addArrangedSubview:editorLabel];

    self.editorView = [UITextView new];
    self.editorView.font = [UIFont monospacedSystemFontOfSize:13 weight:UIFontWeightRegular];
    self.editorView.autocapitalizationType = UITextAutocapitalizationTypeNone;
    self.editorView.autocorrectionType = UITextAutocorrectionTypeNo;
    self.editorView.spellCheckingType = UITextSpellCheckingTypeNo;
    self.editorView.smartQuotesType = UITextSmartQuotesTypeNo;
    self.editorView.smartDashesType = UITextSmartDashesTypeNo;
    self.editorView.backgroundColor = UIColor.secondarySystemGroupedBackgroundColor;
    self.editorView.layer.cornerRadius = 12;
    self.editorView.layer.borderWidth = 1.0 / UIScreen.mainScreen.scale;
    self.editorView.layer.borderColor = UIColor.separatorColor.CGColor;
    self.editorView.textContainerInset = UIEdgeInsetsMake(12, 10, 12, 10);
    self.editorView.accessibilityLabel = NSLocalizedString(@"Entitlements property list (XML)", nil);
    [self.editorView.heightAnchor constraintGreaterThanOrEqualToConstant:300].active = YES;
    [content addArrangedSubview:self.editorView];

    UILabel* footer = [UILabel new];
    footer.text = NSLocalizedString(@"Only add keys you understand. Invalid property lists are rejected before installation. Some entitlements are restricted by iOS and cannot be made functional by signing alone.", nil);
    footer.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    footer.textColor = UIColor.secondaryLabelColor;
    footer.numberOfLines = 0;
    [content addArrangedSubview:footer];
}

- (void)loadDocument
{
    NSData* data = [NSData dataWithContentsOfFile:self.entitlementFilePath];
    NSError* error = nil;
    id plist = data ? [NSPropertyListSerialization propertyListWithData:data options:NSPropertyListMutableContainersAndLeaves format:nil error:&error] : nil;
    NSData* xmlData = plist ? [NSPropertyListSerialization dataWithPropertyList:plist format:NSPropertyListXMLFormat_v1_0 options:0 error:nil] : nil;
    NSString* xml = xmlData ? [[NSString alloc] initWithData:xmlData encoding:NSUTF8StringEncoding] : nil;
    self.editorView.text = xml ?: TSEntitlementsTemplate();
}

- (void)saveAndInstall
{
    NSData* data = [self.editorView.text dataUsingEncoding:NSUTF8StringEncoding];
    NSError* parseError = nil;
    id object = data ? [NSPropertyListSerialization propertyListWithData:data options:NSPropertyListMutableContainersAndLeaves format:nil error:&parseError] : nil;
    if(![object isKindOfClass:NSDictionary.class])
    {
        NSString* message = NSLocalizedString(@"The Entitlements document is not a valid XML plist dictionary.", nil);
        if(parseError.localizedDescription.length) message = [message stringByAppendingFormat:@"\n%@", parseError.localizedDescription];
        [self showError:message];
        return;
    }

    NSError* error = nil;
    NSString* folder = [self.entitlementFilePath stringByDeletingLastPathComponent];
    if(![[NSFileManager defaultManager] createDirectoryAtPath:folder withIntermediateDirectories:YES attributes:nil error:&error])
    {
        [self showError:error.localizedDescription ?: NSLocalizedString(@"Unable to create the Application Support folder.", nil)];
        return;
    }
    NSData* output = [NSPropertyListSerialization dataWithPropertyList:object format:NSPropertyListXMLFormat_v1_0 options:0 error:&error];
    if(!output || ![output writeToFile:self.entitlementFilePath options:NSDataWritingAtomic error:&error])
    {
        [self showError:error.localizedDescription ?: NSLocalizedString(@"Unable to save Entitlements.", nil)];
        return;
    }
    [trollStoreUserDefaults() setBool:self.applySwitch.isOn forKey:@"TSCustomEntitlementsOverrideEnabled"];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TrollStoreReloadSettingsNotification" object:nil userInfo:nil];

    if(self.onSave)
    {
        void (^completion)(void) = [self.onSave copy];
        UIViewController* presenter = self.navigationController ?: self;
        [presenter dismissViewControllerAnimated:YES completion:completion];
        return;
    }
    UIAlertController* savedAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Saved", nil)
        message:NSLocalizedString(@"Entitlements settings were saved.", nil) preferredStyle:UIAlertControllerStyleAlert];
    [savedAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction *action)
    {
        [self.navigationController dismissViewControllerAnimated:YES completion:nil];
    }]];
    [self presentViewController:savedAlert animated:YES completion:nil];
}

- (void)cancelEditing
{
    void (^completion)(void) = [self.onCancel copy];
    UIViewController* presenter = self.navigationController ?: self;
    [presenter dismissViewControllerAnimated:YES completion:completion];
}

- (void)resetDocument
{
    self.editorView.text = TSEntitlementsTemplate();
    self.applySwitch.on = NO;
}

- (void)showError:(NSString*)message
{
    UIAlertController* alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Invalid Entitlements", nil)
        message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
