#import "TSPluginStoreController.h"
#import "TSPluginStore.h"
#import "TSPluginRepositoryManager.h"
#import <TSPresentationDelegate.h>
#import <math.h>
@import UniformTypeIdentifiers;

@interface TSPluginStoreController () <UIDocumentPickerDelegate>
@property(nonatomic, copy) NSArray<NSURL *> *plugins;
@property(nonatomic, copy) NSArray<NSDictionary *> *remotePackages;
@property(nonatomic, strong) UISegmentedControl *scopeControl;
@property(nonatomic, strong) UILabel *headerTitle;
@property(nonatomic, strong) UILabel *headerSubtitle;
@property(nonatomic, strong) UILabel *repositoryStatusLabel;
@property(nonatomic, assign) BOOL loadingRepositories;
@end

@implementation TSPluginStoreController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Plugins", nil);
    self.tableView.rowHeight = 72;
    self.tableView.estimatedRowHeight = 72;
    self.tableView.tableFooterView = [UIView new];
    self.tableView.backgroundColor = UIColor.systemGroupedBackgroundColor;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addMenuPressed)];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh target:self action:@selector(refreshRepositories)];

    [TSPluginStore ensurePluginDirectory];
    self.plugins = [TSPluginStore availablePluginItems];
    self.remotePackages = @[];
    [self buildHeader];

    // Start with the public TrollFools-compatible community feed as an example
    // source. Package installation still requires an explicit per-package tap.
    if (![TSPluginRepositoryManager repositoryURLs].count) {
        [TSPluginRepositoryManager addRepositoryURL:@"https://armyb.github.io/TrollFools/" error:nil];
    }
    [self refreshRepositories];
}

- (void)buildHeader {
    self.headerTitle = [UILabel new];
    self.headerTitle.text = NSLocalizedString(@"Plugin Library", nil);
    self.headerTitle.font = [UIFont systemFontOfSize:21 weight:UIFontWeightBold];
    self.headerTitle.textColor = UIColor.labelColor;

    self.headerSubtitle = [UILabel new];
    self.headerSubtitle.text = NSLocalizedString(@"Browse repositories or keep your own .dylib, .framework, .deb and .zip packages in the local library.", nil);
    self.headerSubtitle.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    self.headerSubtitle.textColor = UIColor.secondaryLabelColor;
    self.headerSubtitle.numberOfLines = 0;

    self.scopeControl = [[UISegmentedControl alloc] initWithItems:@[NSLocalizedString(@"Local", nil), NSLocalizedString(@"Repositories", nil)]];
    self.scopeControl.selectedSegmentIndex = 0;
    [self.scopeControl addTarget:self action:@selector(scopeChanged:) forControlEvents:UIControlEventValueChanged];

    self.repositoryStatusLabel = [UILabel new];
    self.repositoryStatusLabel.font = [UIFont systemFontOfSize:11 weight:UIFontWeightMedium];
    self.repositoryStatusLabel.textColor = UIColor.tertiaryLabelColor;
    self.repositoryStatusLabel.numberOfLines = 2;
    self.repositoryStatusLabel.text = NSLocalizedString(@"Third-party source · Review package permissions and origin before installing.", nil);

    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[self.headerTitle, self.headerSubtitle, self.scopeControl, self.repositoryStatusLabel]];
    stack.axis = UILayoutConstraintAxisVertical;
    stack.spacing = 9;
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    UIView *header = [UIView new];
    [header addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[
        [stack.topAnchor constraintEqualToAnchor:header.topAnchor constant:16],
        [stack.bottomAnchor constraintEqualToAnchor:header.bottomAnchor constant:-12],
        [stack.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:18],
        [stack.trailingAnchor constraintEqualToAnchor:header.trailingAnchor constant:-18]
    ]];
    header.frame = CGRectMake(0, 0, CGRectGetWidth(self.tableView.bounds), 164);
    self.tableView.tableHeaderView = header;
}

- (void)viewWillAppear:(BOOL)animated { [super viewWillAppear:animated]; self.plugins = [TSPluginStore availablePluginItems]; [self.tableView reloadData]; }
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    UIView *header = self.tableView.tableHeaderView;
    if (header && fabs(header.bounds.size.width - self.tableView.bounds.size.width) > 0.5) {
        CGRect frame = header.frame; frame.size.width = self.tableView.bounds.size.width;
        header.frame = frame;
        CGSize fit = [header systemLayoutSizeFittingSize:CGSizeMake(frame.size.width, UILayoutFittingCompressedSize.height)];
        frame.size.height = MAX(150, fit.height); header.frame = frame; self.tableView.tableHeaderView = header;
    }
}

- (BOOL)isShowingRepositories { return self.scopeControl.selectedSegmentIndex == 1; }
- (void)scopeChanged:(UISegmentedControl *)sender {
    [self.tableView reloadData];
    if (sender.selectedSegmentIndex == 1 && !self.remotePackages.count) [self refreshRepositories];
}

- (void)addMenuPressed {
    UIAlertController *menu = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Plugin Library", nil) message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    [menu addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Import Local Plugin", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) { [self importLocalPlugin]; }]];
    [menu addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Add Repository", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) { [self addRepository]; }]];
    [menu addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Manage Repositories", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) { [self manageRepositories]; }]];
    [menu addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    menu.popoverPresentationController.barButtonItem = self.navigationItem.rightBarButtonItem;
    [TSPresentationDelegate presentViewController:menu animated:YES completion:nil];
}

- (void)importLocalPlugin {
    NSMutableArray<UTType *> *types = [NSMutableArray array];
    UTType *dataType = [UTType typeWithIdentifier:@"public.data"];
    UTType *packageType = [UTType typeWithIdentifier:@"com.apple.package"] ?: dataType;
    UTType *archiveType = [UTType typeWithIdentifier:@"public.archive"] ?: dataType;
    if (!dataType) return;
    for (NSString *extension in @[@"dylib", @"framework", @"deb", @"zip"]) {
        UTType *conformance = [extension isEqualToString:@"framework"] ? packageType : (([extension isEqualToString:@"deb"] || [extension isEqualToString:@"zip"]) ? archiveType : dataType);
        UTType *type = [UTType typeWithFilenameExtension:extension conformingToType:conformance];
        if (!type) type = [UTType typeWithFilenameExtension:extension] ?: dataType;
        if (type) [types addObject:type];
    }
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:types asCopy:YES];
    picker.delegate = self; picker.allowsMultipleSelection = YES;
    [TSPresentationDelegate presentViewController:picker animated:YES completion:nil];
}

- (void)addRepository {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Add Plugin Repository", nil) message:NSLocalizedString(@"Enter the HTTPS repository address. The app reads its trollpackages.json manifest.", nil) preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) { field.placeholder = @"https://example.com/repository/"; field.keyboardType = UIKeyboardTypeURL; field.autocapitalizationType = UITextAutocapitalizationTypeNone; field.autocorrectionType = UITextAutocorrectionTypeNo; field.clearButtonMode = UITextFieldViewModeWhileEditing; }];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Add", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        NSError *error = nil;
        if (![TSPluginRepositoryManager addRepositoryURL:alert.textFields.firstObject.text ?: @"" error:&error]) { [self showMessage:error.localizedDescription ?: NSLocalizedString(@"Could not add repository.", nil) title:NSLocalizedString(@"Repository Error", nil)]; return; }
        [self refreshRepositories];
    }]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}

- (void)manageRepositories {
    NSArray<NSString *> *sources = [TSPluginRepositoryManager repositoryURLs];
    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Manage Repositories", nil) message:NSLocalizedString(@"Remove a source to stop showing its packages.", nil) preferredStyle:UIAlertControllerStyleActionSheet];
    for (NSString *source in sources) {
        NSURL *url = [NSURL URLWithString:source];
        NSString *label = url.host.length ? [NSString stringWithFormat:@"Remove %@", url.host] : source;
        [sheet addAction:[UIAlertAction actionWithTitle:label style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
            [TSPluginRepositoryManager removeRepositoryURL:source];
            self.remotePackages = @[];
            [self refreshRepositories];
        }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Add Repository", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) { [self addRepository]; }]];
    [sheet addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:nil]];
    sheet.popoverPresentationController.barButtonItem = self.navigationItem.rightBarButtonItem;
    [TSPresentationDelegate presentViewController:sheet animated:YES completion:nil];
}

- (void)refreshRepositories {
    if (self.loadingRepositories) return;
    self.loadingRepositories = YES;
    self.navigationItem.leftBarButtonItem.enabled = NO;
    self.repositoryStatusLabel.text = NSLocalizedString(@"Refreshing repository indexes…", nil);
    [TSPluginRepositoryManager refreshPackagesWithCompletion:^(NSArray<NSDictionary *> *packages, NSError *error) {
        self.loadingRepositories = NO;
        self.navigationItem.leftBarButtonItem.enabled = YES;
        self.remotePackages = packages ?: @[];
        NSUInteger sourceCount = [TSPluginRepositoryManager repositoryURLs].count;
        if (error) self.repositoryStatusLabel.text = [NSString stringWithFormat:NSLocalizedString(@"%lu source(s) · %@", nil), (unsigned long)sourceCount, error.localizedDescription];
        else self.repositoryStatusLabel.text = [NSString stringWithFormat:NSLocalizedString(@"%lu packages from %lu source(s) · Third-party code; inspect before installing.", nil), (unsigned long)packages.count, (unsigned long)sourceCount];
        [self.tableView reloadData];
    }];
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSMutableArray<NSURL *> *importedURLs = [NSMutableArray array];
    NSMutableArray<NSString *> *errors = [NSMutableArray array];
    for (NSURL *url in urls) {
        NSError *error = nil;
        NSURL *saved = [TSPluginStore importPluginAtURL:url error:&error];
        if (saved) [importedURLs addObject:saved]; else [errors addObject:error.localizedDescription ?: url.lastPathComponent];
    }
    self.plugins = [TSPluginStore availablePluginItems];
    [self.tableView reloadData];
    NSMutableString *message = [NSMutableString stringWithFormat:NSLocalizedString(@"Imported %lu plugin item(s).", nil), (unsigned long)importedURLs.count];
    if (errors.count) [message appendFormat:NSLocalizedString(@"\n\nSome files could not be added:\n%@", nil), [errors componentsJoinedByString:@"\n"]];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Import Results", nil) message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Done", nil) style:UIAlertActionStyleCancel handler:nil]];
    if (importedURLs.count) [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Imported Files", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
        UIAlertController *confirm = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Delete Imported Files?", nil) message:NSLocalizedString(@"Only plugin items imported in this operation will be removed.", nil) preferredStyle:UIAlertControllerStyleAlert];
        [confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
        [confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) {
            for (NSURL *saved in importedURLs) [TSPluginStore removePluginItemAtURL:saved error:nil];
            self.plugins = [TSPluginStore availablePluginItems]; [self.tableView reloadData];
        }]];
        [TSPresentationDelegate presentViewController:confirm animated:YES completion:nil];
    }]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self isShowingRepositories] ? self.remotePackages.count : self.plugins.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TSPluginLibraryCell"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"TSPluginLibraryCell"];
    cell.textLabel.numberOfLines = 1;
    cell.detailTextLabel.numberOfLines = 1;
    cell.detailTextLabel.textColor = UIColor.secondaryLabelColor;
    cell.backgroundColor = UIColor.secondarySystemGroupedBackgroundColor;
    cell.layer.cornerCurve = kCACornerCurveContinuous;
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;

    if ([self isShowingRepositories]) {
        NSDictionary *package = self.remotePackages[indexPath.row];
        cell.textLabel.text = [NSString stringWithFormat:@"%@  %@", package[@"name"] ?: @"Plugin", package[@"version"] ?: @""];
        NSString *repoName = [package[@"repoName"] isKindOfClass:NSString.class] ? package[@"repoName"] : @"Repository";
        NSString *section = [package[@"section"] isKindOfClass:NSString.class] && [package[@"section"] length] ? package[@"section"] : repoName;
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ · %@", section, package[@"description"] ?: @""];
        cell.imageView.image = [UIImage systemImageNamed:@"puzzlepiece.extension.fill"];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    } else {
        NSURL *item = self.plugins[indexPath.row];
        NSString *extension = item.pathExtension.lowercaseString;
        NSUInteger count = [TSPluginStore injectableLibraryCountForPluginItem:item];
        cell.textLabel.text = item.lastPathComponent;
        if ([extension isEqualToString:@"dylib"]) {
            cell.detailTextLabel.text = NSLocalizedString(@"Dynamic library · Ready for injection", nil);
            cell.imageView.image = [UIImage systemImageNamed:@"puzzlepiece.extension"];
        } else if ([extension isEqualToString:@"framework"]) {
            cell.detailTextLabel.text = NSLocalizedString(@"Framework · Ready for injection", nil);
            cell.imageView.image = [UIImage systemImageNamed:@"shippingbox"];
        } else {
            cell.detailTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"%@ archive · %lu injectable library(s)", nil), extension.uppercaseString, (unsigned long)count];
            cell.imageView.image = [UIImage systemImageNamed:@"archivebox"];
        }
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if ([self isShowingRepositories]) { [self presentRemotePackage:self.remotePackages[indexPath.row]]; return; }
    NSURL *item = self.plugins[indexPath.row];
    NSArray<NSString *> *libraries = [TSPluginStore injectableLibraryPathsForPluginItem:item];
    NSDictionary *attributes = [NSFileManager.defaultManager attributesOfItemAtPath:item.path error:nil];
    unsigned long long fileSize = [attributes[NSFileSize] unsignedLongLongValue];
    NSMutableString *message = [NSMutableString stringWithFormat:@"%@\n%@\n\n", item.lastPathComponent, [NSByteCountFormatter stringFromByteCount:(long long)fileSize countStyle:NSByteCountFormatterCountStyleFile]];
    if (libraries.count) { [message appendFormat:NSLocalizedString(@"Contained dynamic libraries (%lu):\n", nil), (unsigned long)libraries.count]; for (NSString *path in libraries) [message appendFormat:@"• %@\n", path.lastPathComponent]; }
    else if ([item.pathExtension.lowercaseString isEqualToString:@"deb"] || [item.pathExtension.lowercaseString isEqualToString:@"zip"]) [message appendString:NSLocalizedString(@"No injectable .dylib or .framework payload was found. The original archive is still stored.", nil)];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:item.lastPathComponent message:message preferredStyle:UIAlertControllerStyleActionSheet];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Plugin", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) { NSError *error = nil; if (![TSPluginStore removePluginItemAtURL:item error:&error]) [self showMessage:error.localizedDescription ?: @"Could not delete plugin." title:NSLocalizedString(@"Delete Failed", nil)]; self.plugins = [TSPluginStore availablePluginItems]; [self.tableView reloadData]; }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:nil]];
    alert.popoverPresentationController.sourceView = tableView;
    alert.popoverPresentationController.sourceRect = [tableView rectForRowAtIndexPath:indexPath];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}

- (void)presentRemotePackage:(NSDictionary *)package {
    NSURL *source = package[@"repoURL"] ? [NSURL URLWithString:package[@"repoURL"]] : nil;
    NSString *detail = [NSString stringWithFormat:@"%@\n\n%@\n\n%@ · %@\n%@\n\n%@",
                       package[@"version"] ?: @"",
                       package[@"description"] ?: @"",
                       package[@"author"] ?: NSLocalizedString(@"Unknown author", nil),
                       package[@"size"] ?: NSLocalizedString(@"Size not specified", nil),
                       package[@"section"] ?: @"",
                       source.host ?: @""];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:package[@"name"] ?: NSLocalizedString(@"Plugin", nil) message:[detail stringByAppendingFormat:@"\n\n%@", NSLocalizedString(@"This is third-party executable code. Install only if you trust this repository and plugin author.", nil)] preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Download & Add to Local", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        [TSPresentationDelegate startActivity:NSLocalizedString(@"Downloading Plugin", nil)];
        [TSPluginRepositoryManager downloadPackage:package completion:^(NSURL *importedURL, NSError *error) {
            [TSPresentationDelegate stopActivityWithCompletion:^{
                if (!importedURL) { [self showMessage:error.localizedDescription ?: NSLocalizedString(@"Download failed.", nil) title:NSLocalizedString(@"Plugin Download", nil)]; return; }
                self.plugins = [TSPluginStore availablePluginItems];
                self.scopeControl.selectedSegmentIndex = 0;
                [self.tableView reloadData];
                [self showMessage:[NSString stringWithFormat:NSLocalizedString(@"%@ was added to the local plugin library. Select it when installing or injecting an app.", nil), importedURL.lastPathComponent] title:NSLocalizedString(@"Plugin Added", nil)];
            }];
        }];
    }]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}

- (void)showMessage:(NSString *)message title:(NSString *)title {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}
@end
