#import "TSPluginStoreController.h"
#import "TSPluginStore.h"
#import <TSPresentationDelegate.h>
#import <math.h>
@import UniformTypeIdentifiers;

@interface TSPluginStoreController () <UIDocumentPickerDelegate>
@property(nonatomic, copy) NSArray<NSURL *> *plugins;
@end
@implementation TSPluginStoreController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Plugins", nil);
    self.tableView.rowHeight = 68;
    self.tableView.tableFooterView = [UIView new];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addPluginPressed)];
    self.tableView.backgroundColor = UIColor.systemGroupedBackgroundColor;
    [TSPluginStore ensurePluginDirectory];
    [self reloadPlugins];
    UILabel *title = [UILabel new]; title.text = NSLocalizedString(@"Local Plugin Library", nil); title.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    UILabel *subtitle = [UILabel new]; subtitle.text = NSLocalizedString(@"Store .dylib, .framework and .deb/.zip files here. Libraries extracted from packages can be selected for injection when installing an IPA, provided plugin injection is enabled in Settings.", nil); subtitle.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote]; subtitle.textColor = UIColor.secondaryLabelColor; subtitle.numberOfLines = 0;
    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[title, subtitle]]; stack.axis = UILayoutConstraintAxisVertical; stack.spacing = 6; stack.translatesAutoresizingMaskIntoConstraints = NO;
    UIView *header = [UIView new]; [header addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[[stack.topAnchor constraintEqualToAnchor:header.topAnchor constant:12], [stack.bottomAnchor constraintEqualToAnchor:header.bottomAnchor constant:-12], [stack.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:18], [stack.trailingAnchor constraintEqualToAnchor:header.trailingAnchor constant:-18]]];
    header.frame = CGRectMake(0, 0, CGRectGetWidth(self.tableView.bounds), 112); self.tableView.tableHeaderView = header;
}
- (void)viewWillAppear:(BOOL)animated { [super viewWillAppear:animated]; [self reloadPlugins]; }
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    UIView *header = self.tableView.tableHeaderView;
    if (header && fabs(header.bounds.size.width - self.tableView.bounds.size.width) > 0.5) {
        CGRect frame = header.frame; frame.size.width = self.tableView.bounds.size.width; header.frame = frame;
        CGSize fit = [header systemLayoutSizeFittingSize:CGSizeMake(frame.size.width, UILayoutFittingCompressedSize.height)]; frame.size.height = MAX(100, fit.height); header.frame = frame; self.tableView.tableHeaderView = header;
    }
}
- (void)reloadPlugins { self.plugins = [TSPluginStore availablePluginItems]; [self.tableView reloadData]; }
- (void)addPluginPressed {
    NSMutableArray<UTType *> *types = [NSMutableArray array];
    UTType *dataType = [UTType typeWithIdentifier:@"public.data"];
    UTType *packageType = [UTType typeWithIdentifier:@"com.apple.package"] ?: dataType;
    UTType *archiveType = [UTType typeWithIdentifier:@"public.archive"] ?: dataType;
    if (!dataType) return;
    for (NSString *extension in @[@"dylib", @"framework", @"deb", @"zip"]) {
        UTType *conformance = [extension isEqualToString:@"framework"] ? packageType : (([extension isEqualToString:@"deb"] || [extension isEqualToString:@"zip"]) ? archiveType : dataType);
        UTType *type = [UTType typeWithFilenameExtension:extension conformingToType:conformance];
        if (!type) type = [UTType typeWithFilenameExtension:extension] ?: dataType;
        if (type) [types addObject:type];
    }
    if (!types.count) [types addObject:dataType];
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:types asCopy:YES];
    picker.delegate = self; picker.allowsMultipleSelection = YES;
    [TSPresentationDelegate presentViewController:picker animated:YES completion:nil];
}
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSMutableArray<NSURL *> *importedURLs = [NSMutableArray array];
    NSMutableArray<NSString *> *errors = [NSMutableArray array];
    for (NSURL *url in urls) { NSError *error = nil; NSURL *saved = [TSPluginStore importPluginAtURL:url error:&error]; if (saved) [importedURLs addObject:saved]; else [errors addObject:error.localizedDescription ?: url.lastPathComponent]; }
    [self reloadPlugins];
    NSMutableString *message = [NSMutableString stringWithFormat:NSLocalizedString(@"Imported %lu plugin item(s).", nil), (unsigned long)importedURLs.count];
    if (errors.count) [message appendFormat:NSLocalizedString(@"\n\nSome files could not be added:\n%@", nil), [errors componentsJoinedByString:@"\n"]];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Import Results", nil) message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Done", nil) style:UIAlertActionStyleCancel handler:nil]];
    if (importedURLs.count) [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Imported Files", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
        UIAlertController *confirm = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Delete Imported Files?", nil) message:NSLocalizedString(@"Only plugin items imported in this operation will be removed.", nil) preferredStyle:UIAlertControllerStyleAlert];
        [confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
        [confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) {
            for (NSURL *saved in importedURLs) { NSError *deleteError = nil; if (![TSPluginStore removePluginItemAtURL:saved error:&deleteError]) NSLog(@"[PluginStore] import cleanup failed: %@", deleteError.localizedDescription); }
            [self reloadPlugins];
        }]];
        [TSPresentationDelegate presentViewController:confirm animated:YES completion:nil];
    }]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return self.plugins.count; }
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TSLocalPlugin"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"TSLocalPlugin"];
    NSURL *item = self.plugins[indexPath.row]; NSString *ext = item.pathExtension.lowercaseString;
    NSUInteger count = [TSPluginStore injectableLibraryCountForPluginItem:item];
    if ([ext isEqualToString:@"dylib"]) { cell.detailTextLabel.text = NSLocalizedString(@"Dynamic library · Ready for selection", nil); cell.imageView.image = [UIImage systemImageNamed:@"puzzlepiece.extension"];
    } else if ([ext isEqualToString:@"framework"]) { cell.detailTextLabel.text = NSLocalizedString(@"Framework · Ready for selection", nil); cell.imageView.image = [UIImage systemImageNamed:@"shippingbox"];
    } else { cell.detailTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"%@ archive · %lu injectable library(s)", nil), ext.uppercaseString, (unsigned long)count]; cell.imageView.image = [UIImage systemImageNamed:@"archivebox"];
    }
    cell.textLabel.text = item.lastPathComponent; cell.detailTextLabel.textColor = UIColor.secondaryLabelColor; cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator; return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES]; NSURL *item = self.plugins[indexPath.row];
    NSArray<NSString *> *libraries = [TSPluginStore injectableLibraryPathsForPluginItem:item];
    NSDictionary<NSFileAttributeKey, id> *attributes = [NSFileManager.defaultManager attributesOfItemAtPath:item.path error:nil];
    unsigned long long fileSize = [attributes[NSFileSize] unsignedLongLongValue];
    NSMutableString *message = [NSMutableString stringWithFormat:@"%@\n%@\n\n", item.path, [NSByteCountFormatter stringFromByteCount:(long long)fileSize countStyle:NSByteCountFormatterCountStyleFile]];
    if (libraries.count) { [message appendFormat:NSLocalizedString(@"Contained dynamic libraries (%lu):\n", nil), (unsigned long)libraries.count]; for (NSString *path in libraries) [message appendFormat:@"• %@\n", path.lastPathComponent]; }
    else if ([item.pathExtension.lowercaseString isEqualToString:@"deb"] || [item.pathExtension.lowercaseString isEqualToString:@"zip"]) [message appendString:NSLocalizedString(@"No injectable .dylib or .framework payload was found. The original archive is still stored.", nil)];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:item.lastPathComponent message:message preferredStyle:UIAlertControllerStyleActionSheet];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Plugin", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) { NSError *error = nil; if (![TSPluginStore removePluginItemAtURL:item error:&error]) [self showMessage:error.localizedDescription ?: @"Could not delete plugin." title:NSLocalizedString(@"Delete Failed", nil)]; [self reloadPlugins]; }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:nil]];
    alert.popoverPresentationController.sourceView = tableView; alert.popoverPresentationController.sourceRect = [tableView rectForRowAtIndexPath:indexPath];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}
- (void)showMessage:(NSString *)message title:(NSString *)title { UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert]; [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]]; [TSPresentationDelegate presentViewController:alert animated:YES completion:nil]; }
@end
