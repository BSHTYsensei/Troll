#import "TSPluginStoreController.h"
#import "TSPluginStore.h"
#import "TSThemeManager.h"
#import <TSPresentationDelegate.h>
#import <math.h>
@import UniformTypeIdentifiers;

@interface TSPluginStoreController () <UIDocumentPickerDelegate>
@property(nonatomic, copy) NSArray<NSURL *> *plugins;
@property(nonatomic, strong) UILabel *headerTitle;
@property(nonatomic, strong) UILabel *headerSubtitle;
@property(nonatomic, strong) UILabel *emptyStateLabel;
@property(nonatomic, copy) NSDictionary<NSString *, NSArray<NSString *> *> *libraryPathsByPluginPath;
@property(nonatomic, copy) NSDictionary<NSString *, NSNumber *> *libraryCountsByPluginPath;
@property(nonatomic, assign) BOOL libraryRefreshInFlight;
@property(nonatomic, assign) BOOL libraryRefreshPending;
@property(nonatomic, strong) NSDate *lastLibraryRefreshDate;
@end

@implementation TSPluginStoreController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Plugins", nil);
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeAlways;
    self.tableView.rowHeight = 72;
    self.tableView.estimatedRowHeight = 72;
    self.tableView.tableFooterView = [UIView new];
    [TSThemeManager styleCardTableView:self.tableView];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Edit", nil) style:UIBarButtonItemStylePlain target:self action:@selector(toggleEditing)];
    __weak typeof(self) weakSelf = self;
    UIAction *importAction = [UIAction actionWithTitle:NSLocalizedString(@"Import from Files", nil) image:[UIImage systemImageNamed:@"doc.badge.plus"] identifier:@"ImportPlugin" handler:^(__kindof UIAction *action) {
        [weakSelf importLocalPlugin];
    }];
    UIAction *refreshAction = [UIAction actionWithTitle:NSLocalizedString(@"Refresh Library", nil) image:[UIImage systemImageNamed:@"arrow.clockwise"] identifier:@"RefreshPlugins" handler:^(__kindof UIAction *action) {
        [weakSelf refreshLocalLibrary];
    }];
    UIMenu *addMenu = [UIMenu menuWithTitle:@"" children:@[importAction, refreshAction]];
    UIImageSymbolConfiguration *plusConfiguration = [UIImageSymbolConfiguration configurationWithPointSize:18.0 weight:UIImageSymbolWeightMedium];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"plus.circle.fill" withConfiguration:plusConfiguration] menu:addMenu];

    // Remove the obsolete repository preference left by earlier builds. This screen
    // is deliberately offline and only reads the app's Documents/Plugins directory.
    [NSUserDefaults.standardUserDefaults removeObjectForKey:@"TSPluginRepositories"];
    [TSPluginStore ensurePluginDirectory];
    // The reference layout uses a large title and a clean empty canvas. Keep
    // the local library empty state visually quiet instead of adding a second
    // explanatory heading beneath the navigation title.
    self.tableView.tableHeaderView = nil;
    self.tableView.backgroundView = nil;
    self.plugins = @[];
    self.libraryPathsByPluginPath = @{};
    self.libraryCountsByPluginPath = @{};
    // viewWillAppear performs the first scan. Avoid starting the same scan twice
    // from viewDidLoad + viewWillAppear on the first visit to this tab.
}

- (void)toggleEditing {
    [self.tableView setEditing:!self.tableView.isEditing animated:YES];
    self.navigationItem.leftBarButtonItem.title = self.tableView.isEditing ? NSLocalizedString(@"Done", nil) : NSLocalizedString(@"Edit", nil);
}

- (void)buildHeader {
    self.headerTitle = [UILabel new];
    self.headerTitle.text = NSLocalizedString(@"Local Plugin Library", nil);
    self.headerTitle.font = [UIFont systemFontOfSize:21 weight:UIFontWeightBold];
    self.headerTitle.textColor = UIColor.labelColor;

    self.headerSubtitle = [UILabel new];
    self.headerSubtitle.text = NSLocalizedString(@"Your plugin library is stored on this device. Import .dylib, .framework, .deb or .zip files to use them when injecting an app.", nil);
    self.headerSubtitle.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    self.headerSubtitle.textColor = UIColor.secondaryLabelColor;
    self.headerSubtitle.numberOfLines = 0;

    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[self.headerTitle, self.headerSubtitle]];
    stack.axis = UILayoutConstraintAxisVertical;
    stack.spacing = 8;
    stack.translatesAutoresizingMaskIntoConstraints = NO;

    UIView *header = [UIView new];
    [header addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[
        [stack.topAnchor constraintEqualToAnchor:header.topAnchor constant:16],
        [stack.bottomAnchor constraintEqualToAnchor:header.bottomAnchor constant:-14],
        [stack.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:18],
        [stack.trailingAnchor constraintEqualToAnchor:header.trailingAnchor constant:-18]
    ]];
    header.frame = CGRectMake(0, 0, CGRectGetWidth(self.tableView.bounds), 112);
    self.tableView.tableHeaderView = header;
}

- (void)buildEmptyState {
    UIView *container = [UIView new];
    self.emptyStateLabel = [UILabel new];
    self.emptyStateLabel.text = NSLocalizedString(@"No Plugins Yet", nil);
    self.emptyStateLabel.textColor = UIColor.secondaryLabelColor;
    self.emptyStateLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    self.emptyStateLabel.textAlignment = NSTextAlignmentCenter;
    self.emptyStateLabel.numberOfLines = 0;
    self.emptyStateLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [container addSubview:self.emptyStateLabel];
    [NSLayoutConstraint activateConstraints:@[
        [self.emptyStateLabel.centerXAnchor constraintEqualToAnchor:container.centerXAnchor],
        [self.emptyStateLabel.centerYAnchor constraintEqualToAnchor:container.centerYAnchor],
        [self.emptyStateLabel.leadingAnchor constraintGreaterThanOrEqualToAnchor:container.leadingAnchor constant:28],
        [self.emptyStateLabel.trailingAnchor constraintLessThanOrEqualToAnchor:container.trailingAnchor constant:-28]
    ]];
    self.tableView.backgroundView = container;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if (!self.lastLibraryRefreshDate || -self.lastLibraryRefreshDate.timeIntervalSinceNow > 60.0) {
        [self refreshLocalLibrary];
    }
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    [TSThemeManager styleCardTableView:self.tableView];
}

- (void)refreshLocalLibrary {
    if (self.libraryRefreshInFlight) {
        self.libraryRefreshPending = YES;
        return;
    }
    self.libraryRefreshInFlight = YES;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        NSArray<NSURL *> *plugins = [TSPluginStore availablePluginItems];
        NSMutableDictionary<NSString *, NSArray<NSString *> *> *pathsByPlugin = [NSMutableDictionary dictionaryWithCapacity:plugins.count];
        NSMutableDictionary<NSString *, NSNumber *> *countsByPlugin = [NSMutableDictionary dictionaryWithCapacity:plugins.count];
        for (NSURL *item in plugins) {
            @autoreleasepool {
                NSArray<NSString *> *paths = [TSPluginStore injectableLibraryPathsForPluginItem:item] ?: @[];
                pathsByPlugin[item.path] = paths;
                countsByPlugin[item.path] = @(paths.count);
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            self.plugins = plugins ?: @[];
            self.libraryPathsByPluginPath = pathsByPlugin.copy;
            self.libraryCountsByPluginPath = countsByPlugin.copy;
            self.emptyStateLabel.hidden = self.plugins.count > 0;
            self.lastLibraryRefreshDate = [NSDate date];
            self.libraryRefreshInFlight = NO;
            [self.tableView reloadData];
            if (self.libraryRefreshPending) {
                self.libraryRefreshPending = NO;
                [self refreshLocalLibrary];
            }
        });
    });
}

- (void)importLocalPlugin {
    NSMutableArray<UTType *> *types = [NSMutableArray array];
    UTType *dataType = [UTType typeWithIdentifier:@"public.data"];
    UTType *packageType = [UTType typeWithIdentifier:@"com.apple.package"] ?: dataType;
    UTType *archiveType = [UTType typeWithIdentifier:@"public.archive"] ?: dataType;
    if (!dataType) {
        [self showMessage:NSLocalizedString(@"The Files picker is unavailable on this device.", nil) title:NSLocalizedString(@"Import Local Plugin", nil)];
        return;
    }
    for (NSString *extension in @[@"dylib", @"framework", @"deb", @"zip"]) {
        UTType *conformance = [extension isEqualToString:@"framework"] ? packageType : (([extension isEqualToString:@"deb"] || [extension isEqualToString:@"zip"]) ? archiveType : dataType);
        UTType *type = [UTType typeWithFilenameExtension:extension conformingToType:conformance];
        if (!type) type = [UTType typeWithFilenameExtension:extension] ?: dataType;
        if (type && ![types containsObject:type]) [types addObject:type];
    }
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:types asCopy:YES];
    picker.delegate = self;
    picker.allowsMultipleSelection = YES;
    [TSPresentationDelegate presentViewController:picker animated:YES completion:nil];
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    [TSPresentationDelegate startActivity:NSLocalizedString(@"Importing Plugins", nil)];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        NSMutableArray<NSURL *> *importedURLs = [NSMutableArray array];
        NSMutableArray<NSString *> *errors = [NSMutableArray array];
        for (NSURL *url in urls) {
            @autoreleasepool {
                NSError *error = nil;
                NSURL *saved = [TSPluginStore importPluginAtURL:url error:&error];
                if (saved) [importedURLs addObject:saved];
                else [errors addObject:error.localizedDescription ?: url.lastPathComponent];
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [self refreshLocalLibrary];
            [TSPresentationDelegate stopActivityWithCompletion:^{
                NSMutableString *message = [NSMutableString stringWithFormat:NSLocalizedString(@"Imported %lu plugin item(s).", nil), (unsigned long)importedURLs.count];
                if (errors.count) [message appendFormat:NSLocalizedString(@"\n\nSome files could not be added:\n%@", nil), [errors componentsJoinedByString:@"\n"]];
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Import Results", nil) message:message preferredStyle:UIAlertControllerStyleAlert];
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Done", nil) style:UIAlertActionStyleCancel handler:nil]];
                if (importedURLs.count) [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Imported Files", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
                    [TSPresentationDelegate startActivity:NSLocalizedString(@"Deleting Plugins", nil)];
                    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
                        for (NSURL *saved in importedURLs) [TSPluginStore removePluginItemAtURL:saved error:nil];
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [self refreshLocalLibrary];
                            [TSPresentationDelegate stopActivityWithCompletion:nil];
                        });
                    });
                }]];
                [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
            }];
        });
    });
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.plugins.count;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return indexPath.row < self.plugins.count;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle != UITableViewCellEditingStyleDelete || indexPath.row >= self.plugins.count) return;
    NSURL *item = self.plugins[indexPath.row];
    [TSPresentationDelegate startActivity:NSLocalizedString(@"Deleting Plugin", nil)];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        NSError *error = nil;
        BOOL removed = [TSPluginStore removePluginItemAtURL:item error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            [TSPresentationDelegate stopActivityWithCompletion:^{
                if (!removed) [self showMessage:error.localizedDescription ?: NSLocalizedString(@"Could not delete plugin.", nil) title:NSLocalizedString(@"Delete Failed", nil)];
                [self refreshLocalLibrary];
            }];
        });
    });
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TSPluginLibraryCell"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"TSPluginLibraryCell"];
    NSURL *item = self.plugins[indexPath.row];
    NSString *extension = item.pathExtension.lowercaseString;
    NSUInteger count = [self.libraryCountsByPluginPath[item.path] unsignedIntegerValue];

    cell.textLabel.numberOfLines = 1;
    cell.textLabel.text = item.lastPathComponent;
    cell.detailTextLabel.numberOfLines = 1;
    cell.detailTextLabel.textColor = UIColor.secondaryLabelColor;
    cell.textLabel.font = [UIFont systemFontOfSize:16.5 weight:UIFontWeightMedium];
    cell.textLabel.textColor = UIColor.labelColor;
    cell.detailTextLabel.font = [UIFont systemFontOfSize:12.0 weight:UIFontWeightRegular];
    cell.imageView.tintColor = [TSThemeManager accentColor];
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    if ([extension isEqualToString:@"dylib"]) {
        cell.detailTextLabel.text = NSLocalizedString(@"Dynamic library · Ready for injection", nil);
        cell.imageView.image = [UIImage systemImageNamed:@"puzzlepiece.extension"];
    } else if ([extension isEqualToString:@"framework"]) {
        cell.detailTextLabel.text = NSLocalizedString(@"Framework · Ready for injection", nil);
        cell.imageView.image = [UIImage systemImageNamed:@"shippingbox"];
    } else {
        cell.detailTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"%@ archive · %lu injectable library(s)", nil), extension.uppercaseString, (unsigned long)count];
        cell.imageView.image = [UIImage systemImageNamed:@"archivebox"];
    }
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    [TSThemeManager styleCardTableViewCell:cell];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSURL *item = self.plugins[indexPath.row];
    NSArray<NSString *> *libraries = self.libraryPathsByPluginPath[item.path] ?: @[];
    NSDictionary *attributes = [NSFileManager.defaultManager attributesOfItemAtPath:item.path error:nil];
    unsigned long long fileSize = [attributes[NSFileSize] unsignedLongLongValue];
    NSMutableString *message = [NSMutableString stringWithFormat:@"%@\n%@\n\n", item.lastPathComponent, [NSByteCountFormatter stringFromByteCount:(long long)fileSize countStyle:NSByteCountFormatterCountStyleFile]];
    if (libraries.count) {
        [message appendFormat:NSLocalizedString(@"Contained dynamic libraries (%lu):\n", nil), (unsigned long)libraries.count];
        for (NSString *path in libraries) [message appendFormat:@"• %@\n", path.lastPathComponent];
    } else if ([item.pathExtension.lowercaseString isEqualToString:@"deb"] || [item.pathExtension.lowercaseString isEqualToString:@"zip"]) {
        [message appendString:NSLocalizedString(@"No injectable .dylib or .framework payload was found. The original archive is still stored.", nil)];
    }

    UIAlertController *alert = [UIAlertController alertControllerWithTitle:item.lastPathComponent message:message preferredStyle:UIAlertControllerStyleActionSheet];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Plugin", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
        [TSPresentationDelegate startActivity:NSLocalizedString(@"Deleting Plugin", nil)];
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            NSError *error = nil;
            BOOL removed = [TSPluginStore removePluginItemAtURL:item error:&error];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self refreshLocalLibrary];
                [TSPresentationDelegate stopActivityWithCompletion:^{
                    if (!removed) [self showMessage:error.localizedDescription ?: @"Could not delete plugin." title:NSLocalizedString(@"Delete Failed", nil)];
                }];
            });
        });
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:nil]];
    alert.popoverPresentationController.sourceView = tableView;
    alert.popoverPresentationController.sourceRect = [tableView rectForRowAtIndexPath:indexPath];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}

- (void)showMessage:(NSString *)message title:(NSString *)title {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}

@end
