#import "TSPluginStoreController.h"
#import "TSIPAPackageStore.h"
#import <TSPresentationDelegate.h>
#import <CommonCrypto/CommonDigest.h>
#import <math.h>

static NSString * const TSPluginIndexURL = @"https://raw.githubusercontent.com/iosdumpzzz/iosdump.repo/main/Packages";
static NSString * const TSPluginRawBaseURL = @"https://raw.githubusercontent.com/iosdumpzzz/iosdump.repo/main/";
static NSString * const TSPluginCacheName = @"iosdumpzzz-Packages-index";

@interface TSPluginStoreController () <UISearchResultsUpdating>
@property(nonatomic, copy) NSArray<NSDictionary *> *packages;
@property(nonatomic, copy) NSArray<NSDictionary *> *visiblePackages;
@property(nonatomic, strong) UISearchController *searchController;
@property(nonatomic, copy) NSString *searchText;
@property(nonatomic, assign) BOOL loading;
@end

@implementation TSPluginStoreController
- (void)viewDidLoad {
    [super viewDidLoad]; self.title = NSLocalizedString(@"Plugins", nil); self.tableView.rowHeight = 76; self.tableView.tableFooterView = [UIView new];
    self.packages = @[]; self.visiblePackages = @[]; self.searchText = @"";
    self.searchController = [[UISearchController alloc] initWithSearchResultsController:nil]; self.searchController.searchResultsUpdater = self; self.searchController.obscuresBackgroundDuringPresentation = NO; self.navigationItem.searchController = self.searchController; self.definesPresentationContext = YES;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh target:self action:@selector(refreshRepository)];
    self.tableView.backgroundColor = UIColor.systemBackgroundColor;
    UILabel *headerTitle = [UILabel new];
    headerTitle.text = NSLocalizedString(@"Packages from iosdumpzzz repository", nil);
    headerTitle.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    UILabel *headerSubtitle = [UILabel new];
    headerSubtitle.text = NSLocalizedString(@"Browse and verify DEB packages. Packages requiring MobileSubstrate cannot be activated by TrollStore alone.", nil);
    headerSubtitle.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    headerSubtitle.textColor = UIColor.secondaryLabelColor;
    headerSubtitle.numberOfLines = 0;
    UIStackView *headerStack = [[UIStackView alloc] initWithArrangedSubviews:@[headerTitle, headerSubtitle]];
    headerStack.axis = UILayoutConstraintAxisVertical;
    headerStack.spacing = 5;
    headerStack.translatesAutoresizingMaskIntoConstraints = NO;
    UIView *header = [UIView new];
    [header addSubview:headerStack];
    [NSLayoutConstraint activateConstraints:@[[headerStack.topAnchor constraintEqualToAnchor:header.topAnchor constant:12], [headerStack.bottomAnchor constraintEqualToAnchor:header.bottomAnchor constant:-12], [headerStack.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:18], [headerStack.trailingAnchor constraintEqualToAnchor:header.trailingAnchor constant:-18]]];
    header.frame = CGRectMake(0, 0, CGRectGetWidth(self.tableView.bounds), 90);
    self.tableView.tableHeaderView = header;
    [self refreshRepository];
}
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    UIView *header = self.tableView.tableHeaderView;
    if (header && fabs(header.bounds.size.width - self.tableView.bounds.size.width) > 0.5) {
        CGRect frame = header.frame; frame.size.width = self.tableView.bounds.size.width; header.frame = frame;
        CGSize fit = [header systemLayoutSizeFittingSize:CGSizeMake(frame.size.width, UILayoutFittingCompressedSize.height)];
        frame.size.height = MAX(82, fit.height); header.frame = frame; self.tableView.tableHeaderView = header;
    }
}
- (void)updateSearchResultsForSearchController:(UISearchController *)searchController { self.searchText = searchController.searchBar.text ?: @""; [self applyFilter]; }
- (NSDictionary *)parseParagraph:(NSString *)paragraph {
    NSMutableDictionary *record = [NSMutableDictionary dictionary]; NSString *lastKey = nil;
    for (NSString *line in [paragraph componentsSeparatedByCharactersInSet:NSCharacterSet.newlineCharacterSet]) {
        if (!line.length) continue;
        if ([line hasPrefix:@" "] || [line hasPrefix:@"\t"]) { if (lastKey) record[lastKey] = [NSString stringWithFormat:@"%@\n%@", record[lastKey], [line substringFromIndex:1]]; continue; }
        NSRange colon = [line rangeOfString:@":"]; if (colon.location == NSNotFound || colon.location == 0) continue;
        NSString *key = [line substringToIndex:colon.location]; NSString *value = [[line substringFromIndex:colon.location + 1] stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceCharacterSet];
        record[key] = value; lastKey = key;
    }
    return record;
}
- (NSArray<NSDictionary *> *)parsePackagesIndex:(NSData *)data {
    NSString *text = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding]; if (!text.length) return @[];
    NSMutableArray *records = [NSMutableArray array]; NSMutableString *paragraph = [NSMutableString string];
    for (NSString *line in [text componentsSeparatedByCharactersInSet:NSCharacterSet.newlineCharacterSet]) {
        if (!line.length) { if (paragraph.length) { NSDictionary *record=[self parseParagraph:paragraph]; if (record[@"Package"] && record[@"Filename"]) [records addObject:record]; [paragraph setString:@""]; } }
        else { if (paragraph.length) [paragraph appendString:@"\n"]; [paragraph appendString:line]; }
    }
    if (paragraph.length) { NSDictionary *record=[self parseParagraph:paragraph]; if (record[@"Package"] && record[@"Filename"]) [records addObject:record]; }
    // Retain the latest version for each package + architecture; architecture variants remain separately selectable.
    NSMutableDictionary<NSString *, NSDictionary *> *latest = [NSMutableDictionary dictionary];
    for (NSDictionary *record in records) {
        NSString *package = record[@"Package"], *architecture = record[@"Architecture"] ?: @"unknown";
        NSString *key = [NSString stringWithFormat:@"%@|%@", package, architecture]; NSDictionary *existing = latest[key];
        if (!existing || [([record[@"Version"] description] ?: @"") compare:([existing[@"Version"] description] ?: @"") options:NSNumericSearch] == NSOrderedDescending) latest[key] = record;
    }
    return [[latest allValues] sortedArrayUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
        NSComparisonResult name = [([a[@"Name"] description] ?: a[@"Package"]) localizedStandardCompare:([b[@"Name"] description] ?: b[@"Package"])];
        if (name != NSOrderedSame) return name;
        return [([a[@"Architecture"] description] ?: @"") compare:([b[@"Architecture"] description] ?: @"")];
    }];
}
- (NSString *)cachedIndexPath { NSString *cache = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES).firstObject ?: NSTemporaryDirectory(); return [cache stringByAppendingPathComponent:TSPluginCacheName]; }
- (void)refreshRepository {
    if (self.loading) return; self.loading = YES; [TSPresentationDelegate startActivity:NSLocalizedString(@"Refreshing Plugin Repository", nil)];
    NSURL *url = [NSURL URLWithString:TSPluginIndexURL];
    NSURLSessionDataTask *task = [NSURLSession.sharedSession dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        if (!error && [response isKindOfClass:NSHTTPURLResponse.class] && ((NSHTTPURLResponse *)response).statusCode >= 400) error = [NSError errorWithDomain:@"TSPluginStore" code:((NSHTTPURLResponse *)response).statusCode userInfo:@{NSLocalizedDescriptionKey:@"Repository returned an HTTP error."}];
        if (!error && data.length) [data writeToFile:self.cachedIndexPath atomically:YES];
        if (error || !data.length) data = [NSData dataWithContentsOfFile:self.cachedIndexPath];
        NSArray *parsed = data.length ? [self parsePackagesIndex:data] : @[];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.loading = NO;
            [TSPresentationDelegate stopActivityWithCompletion:^{
                if (parsed.count) { self.packages = parsed; [self applyFilter]; }
                else [self showMessage:error ? [NSString stringWithFormat:NSLocalizedString(@"Could not load the plugin repository. %@", nil), error.localizedDescription ?: @""] : NSLocalizedString(@"Repository index is empty or malformed.", nil) title:NSLocalizedString(@"Repository Unavailable", nil)];
                [self.tableView reloadData];
            }];
        });
    }]; [task resume];
}
- (void)applyFilter {
    NSString *query = self.searchText ?: @""; if (!query.length) self.visiblePackages = self.packages;
    else { NSMutableArray *matches=[NSMutableArray array]; for (NSDictionary *item in self.packages) { NSString *haystack=[NSString stringWithFormat:@"%@ %@ %@ %@ %@", item[@"Name"]?:@"", item[@"Package"]?:@"", item[@"Description"]?:@"", item[@"Author"]?:@"", item[@"Architecture"]?:@""]; if ([haystack rangeOfString:query options:NSCaseInsensitiveSearch].location != NSNotFound) [matches addObject:item]; } self.visiblePackages=matches.copy; }
    [self.tableView reloadData];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return self.visiblePackages.count; }
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell=[tableView dequeueReusableCellWithIdentifier:@"PluginPackageCell"]; if(!cell) cell=[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"PluginPackageCell"];
    NSDictionary *item=self.visiblePackages[indexPath.row]; cell.textLabel.text=item[@"Name"] ?: item[@"Package"];
    NSString *description=item[@"Description"] ?: item[@"Package"]; NSString *version=item[@"Version"] ?: @"?"; NSString *arch=item[@"Architecture"] ?: @"unknown";
    cell.detailTextLabel.text=[NSString stringWithFormat:@"%@  •  %@\n%@",version,arch,description]; cell.detailTextLabel.numberOfLines=2; cell.detailTextLabel.textColor=UIColor.secondaryLabelColor;
    NSString *dependencyText = (item[@"Depends"] ?: @"").lowercaseString;
    BOOL substrate = [dependencyText containsString:@"mobilesubstrate"] || [dependencyText containsString:@"substrate"] || [dependencyText containsString:@"ellekit"] || [dependencyText containsString:@"libhooker"] || [dependencyText containsString:@"substitute"] || [dependencyText containsString:@"rocketbootstrap"];
    cell.imageView.image=[UIImage systemImageNamed:substrate?@"puzzlepiece.extension.fill":@"puzzlepiece.extension"]; cell.imageView.tintColor=substrate?UIColor.systemOrangeColor:UIColor.systemBlueColor;
    cell.accessoryType=UITableViewCellAccessoryDisclosureIndicator; return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath { [tableView deselectRowAtIndexPath:indexPath animated:YES]; [self showDetailsForPackage:self.visiblePackages[indexPath.row]]; }
- (NSString *)downloadURLStringForRecord:(NSDictionary *)record {
    NSString *filename=record[@"Filename"]; if(![filename isKindOfClass:NSString.class] || !filename.length) return nil;
    NSString *relative=[filename hasPrefix:@"./"]?[filename substringFromIndex:2]:filename;
    if ([relative containsString:@".."] || [relative hasPrefix:@"/"] || [relative containsString:@"\\"] || ![relative.lowercaseString hasSuffix:@".deb"]) return nil;
    NSMutableCharacterSet *safe = [NSMutableCharacterSet alphanumericCharacterSet]; [safe addCharactersInString:@"-._~"];
    NSMutableArray *parts=[NSMutableArray array]; for (NSString *part in [relative componentsSeparatedByString:@"/"]) { NSString *encoded=[part stringByAddingPercentEncodingWithAllowedCharacters:safe]; if(!encoded.length) return nil; [parts addObject:encoded]; }
    return [TSPluginRawBaseURL stringByAppendingString:[parts componentsJoinedByString:@"/"]];
}
- (NSString *)sha256ForFile:(NSString *)path {
    NSInputStream *stream=[NSInputStream inputStreamWithFileAtPath:path]; [stream open]; CC_SHA256_CTX ctx; CC_SHA256_Init(&ctx); uint8_t buffer[64*1024]; NSInteger count=0;
    while ((count=[stream read:buffer maxLength:sizeof(buffer)])>0) CC_SHA256_Update(&ctx,buffer,(CC_LONG)count);
    NSError *streamError=stream.streamError; [stream close]; if(count<0 || streamError) return nil;
    unsigned char digest[CC_SHA256_DIGEST_LENGTH]; CC_SHA256_Final(digest,&ctx); NSMutableString *hex=[NSMutableString stringWithCapacity:CC_SHA256_DIGEST_LENGTH*2]; for(int i=0;i<CC_SHA256_DIGEST_LENGTH;i++) [hex appendFormat:@"%02x",digest[i]]; return hex;
}
- (void)showDetailsForPackage:(NSDictionary *)record {
    NSString *name=record[@"Name"] ?: record[@"Package"]; NSString *deps=record[@"Depends"] ?: NSLocalizedString(@"No dependency metadata",nil);
    NSString *dependencyText = deps.lowercaseString;
    BOOL requiresSubstrate = [dependencyText containsString:@"mobilesubstrate"] || [dependencyText containsString:@"substrate"] || [dependencyText containsString:@"ellekit"] || [dependencyText containsString:@"libhooker"] || [dependencyText containsString:@"substitute"] || [dependencyText containsString:@"rocketbootstrap"];
    NSString *compatibility = requiresSubstrate ? NSLocalizedString(@"Requires MobileSubstrate. This package can be downloaded for inspection, but TrollStore alone cannot activate this system tweak.", nil) : NSLocalizedString(@"DEB package. It will be saved to Packages and is not installed automatically.", nil);
    NSString *message=[NSString stringWithFormat:@"%@\n%@\n\n%@\n\n%@\n\n%@\n\n%@",record[@"Package"]?:@"",[NSString stringWithFormat:NSLocalizedString(@"Version: %@\nArchitecture: %@\nAuthor: %@",nil),record[@"Version"]?:@"?",record[@"Architecture"]?:@"?",record[@"Author"]?:record[@"Maintainer"]?:@"?"],record[@"Description"]?:@"",[NSString stringWithFormat:NSLocalizedString(@"Dependencies: %@",nil),deps],compatibility,NSLocalizedString(@"Downloading saves the original DEB to the Packages tab. It is not installed or activated by this action.",nil)];
    UIAlertController *alert=[UIAlertController alertControllerWithTitle:name message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close",nil) style:UIAlertActionStyleCancel handler:nil]];
    if ([self downloadURLStringForRecord:record] && [record[@"SHA256"] isKindOfClass:NSString.class] && [record[@"SHA256"] length]==64) [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Download DEB",nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){ [self downloadRecord:record]; }]];
    if ([record[@"Homepage"] isKindOfClass:NSString.class] && [record[@"Homepage"] hasPrefix:@"https://"]) [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Open Homepage",nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){ [[UIApplication sharedApplication] openURL:[NSURL URLWithString:record[@"Homepage"]] options:@{} completionHandler:nil]; }]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}
- (void)downloadRecord:(NSDictionary *)record {
    NSString *urlString=[self downloadURLStringForRecord:record]; NSString *expected=[record[@"SHA256"] lowercaseString]; if(!urlString || expected.length!=64) { [self showMessage:NSLocalizedString(@"This package has no safe download metadata.",nil) title:NSLocalizedString(@"Download Unavailable",nil)]; return; }
    [TSPresentationDelegate startActivity:NSLocalizedString(@"Downloading Plugin Package",nil)];
    NSURLSessionDownloadTask *task=[NSURLSession.sharedSession downloadTaskWithURL:[NSURL URLWithString:urlString] completionHandler:^(NSURL *location, NSURLResponse *response, NSError *error) {
        NSError *saveError=nil; NSURL *saved=nil; NSString *failure=error.localizedDescription;
        if(!error && location && [response isKindOfClass:NSHTTPURLResponse.class] && ((NSHTTPURLResponse *)response).statusCode==200) {
            NSString *actual=[self sha256ForFile:location.path];
            NSNumber *expectedSize = @([record[@"Size"] longLongValue]);
            unsigned long long actualSize = [[[NSFileManager defaultManager] attributesOfItemAtPath:location.path error:nil][NSFileSize] unsignedLongLongValue];
            if(!actual || ![actual isEqualToString:expected] || ([record[@"Size"] respondsToSelector:@selector(longLongValue)] && expectedSize.unsignedLongLongValue > 0 && actualSize != expectedSize.unsignedLongLongValue)) failure=NSLocalizedString(@"SHA-256 or package size verification failed. The package was discarded.",nil);
            else {
                NSString *base=[record[@"Filename"] lastPathComponent];
                NSString *temporary=[NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"%@-%@",NSUUID.UUID.UUIDString,base]];
                if([[NSFileManager defaultManager] copyItemAtPath:location.path toPath:temporary error:&saveError]) { saved=[TSIPAPackageStore importPackageAtURL:[NSURL fileURLWithPath:temporary] error:&saveError]; [[NSFileManager defaultManager] removeItemAtPath:temporary error:nil]; }
            }
        } else if(!failure) failure=NSLocalizedString(@"The repository did not return the package.",nil);
        dispatch_async(dispatch_get_main_queue(), ^{
            [TSPresentationDelegate stopActivityWithCompletion:^{
                if(saved) [self showMessage:[NSString stringWithFormat:NSLocalizedString(@"Saved %@ to Packages.",nil),saved.lastPathComponent] title:NSLocalizedString(@"Download Complete",nil)];
                else [self showMessage:failure ?: saveError.localizedDescription ?: NSLocalizedString(@"Could not save the package.",nil) title:NSLocalizedString(@"Download Failed",nil)];
            }];
        });
    }]; [task resume];
}
- (void)showMessage:(NSString *)message title:(NSString *)title { UIAlertController *alert=[UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert]; [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK",nil) style:UIAlertActionStyleCancel handler:nil]]; [TSPresentationDelegate presentViewController:alert animated:YES completion:nil]; }
@end
