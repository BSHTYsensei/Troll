#import "TSPluginStoreController.h"
#import "TSPluginStore.h"
#import <TSPresentationDelegate.h>
#import <math.h>
@import UniformTypeIdentifiers;

@interface TSPluginStoreController () <UIDocumentPickerDelegate>
@property(nonatomic, copy) NSArray<NSURL *> *plugins;
@property(nonatomic, strong) UILabel *headerTitle;
@property(nonatomic, strong) UILabel *headerSubtitle;
@property(nonatomic, strong) UILabel *emptyStateLabel;
@end

@implementation TSPluginStoreController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Plugins", nil);
    self.tableView.rowHeight = 72;
    self.tableView.estimatedRowHeight = 72;
    self.tableView.tableFooterView = [UIView new];
    self.tableView.backgroundColor = UIColor.systemGroupedBackgroundColor;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(importLocalPlugin)];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemRefresh target:self action:@selector(refreshLocalLibrary)];

    // Remove the obsolete repository preference left by earlier builds. This screen
    // is deliberately offline and only reads the app's Documents/Plugins directory.
    [NSUserDefaults.standardUserDefaults removeObjectForKey:@"TSPluginRepositories"];
    [TSPluginStore ensurePluginDirectory];
    [self buildHeader];
    [self buildEmptyState];
    [self refreshLocalLibrary];
}

- (void)buildHeader {
    self.headerTitle = [UILabel new];
    self.headerTitle.text = NSLocalizedString(@"Local Plugin Library", nil);
    self.headerTitle.font = [UIFont systemFontOfSize:21 weight:UIFontWeightBold];
    self.headerTitle.textColor = UIColor.labelColor;

    self.headerSubtitle = [UILabel new];
    self.headerSubtitle.text = NSLocalizedString(@"Your plugin library is stored on this device. Import .dylib, .framework, .deb or .zip files to use them when injecting an app.", nil);
    self.headerSubtitle.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    self.headerSubtitle.textColor = UIColor.secondaryLabelColor;
    self.headerSubtitle.numberOfLines = 0;

    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[self.headerTitle, self.headerSubtitle]];
    stack.axis = UILayoutConstraintAxisVertical;
    stack.spacing = 8;
    stack.translatesAutoresizingMaskIntoConstraints = NO;

    UIView *header = [UIView new];
    [header addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[
        [stack.topAnchor constraintEqualToAnchor:header.topAnchor constant:16],
        [stack.bottomAnchor constraintEqualToAnchor:header.bottomAnchor constant:-14],
        [stack.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:18],
        [stack.trailingAnchor constraintEqualToAnchor:header.trailingAnchor constant:-18]
    ]];
    header.frame = CGRectMake(0, 0, CGRectGetWidth(self.tableView.bounds), 112);
    self.tableView.tableHeaderView = header;
}

- (void)buildEmptyState {
    UIView *container = [UIView new];
    self.emptyStateLabel = [UILabel new];
    self.emptyStateLabel.text = NSLocalizedString(@"No Plugins Yet", nil);
    self.emptyStateLabel.textColor = UIColor.secondaryLabelColor;
    self.emptyStateLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    self.emptyStateLabel.textAlignment = NSTextAlignmentCenter;
    self.emptyStateLabel.numberOfLines = 0;
    self.emptyStateLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [container addSubview:self.emptyStateLabel];
    [NSLayoutConstraint activateConstraints:@[
        [self.emptyStateLabel.centerXAnchor constraintEqualToAnchor:container.centerXAnchor],
        [self.emptyStateLabel.centerYAnchor constraintEqualToAnchor:container.centerYAnchor],
        [self.emptyStateLabel.leadingAnchor constraintGreaterThanOrEqualToAnchor:container.leadingAnchor constant:28],
        [self.emptyStateLabel.trailingAnchor constraintLessThanOrEqualToAnchor:container.trailingAnchor constant:-28]
    ]];
    self.tableView.backgroundView = container;
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self refreshLocalLibrary];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    UIView *header = self.tableView.tableHeaderView;
    if (header && fabs(header.bounds.size.width - self.tableView.bounds.size.width) > 0.5) {
        CGRect frame = header.frame;
        frame.size.width = self.tableView.bounds.size.width;
        header.frame = frame;
        CGSize fitting = [header systemLayoutSizeFittingSize:CGSizeMake(frame.size.width, UILayoutFittingCompressedSize.height)];
        frame.size.height = MAX(96, fitting.height);
        header.frame = frame;
        self.tableView.tableHeaderView = header;
    }
}

- (void)refreshLocalLibrary {
    self.plugins = [TSPluginStore availablePluginItems];
    self.emptyStateLabel.hidden = self.plugins.count > 0;
    [self.tableView reloadData];
}

- (void)importLocalPlugin {
    NSMutableArray<UTType *> *types = [NSMutableArray array];
    UTType *dataType = [UTType typeWithIdentifier:@"public.data"];
    UTType *packageType = [UTType typeWithIdentifier:@"com.apple.package"] ?: dataType;
    UTType *archiveType = [UTType typeWithIdentifier:@"public.archive"] ?: dataType;
    if (!dataType) {
        [self showMessage:NSLocalizedString(@"The Files picker is unavailable on this device.", nil) title:NSLocalizedString(@"Import Local Plugin", nil)];
        return;
    }
    for (NSString *extension in @[@"dylib", @"framework", @"deb", @"zip"]) {
        UTType *conformance = [extension isEqualToString:@"framework"] ? packageType : (([extension isEqualToString:@"deb"] || [extension isEqualToString:@"zip"]) ? archiveType : dataType);
        UTType *type = [UTType typeWithFilenameExtension:extension conformingToType:conformance];
        if (!type) type = [UTType typeWithFilenameExtension:extension] ?: dataType;
        if (type && ![types containsObject:type]) [types addObject:type];
    }
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:types asCopy:YES];
    picker.delegate = self;
    picker.allowsMultipleSelection = YES;
    [TSPresentationDelegate presentViewController:picker animated:YES completion:nil];
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSMutableArray<NSURL *> *importedURLs = [NSMutableArray array];
    NSMutableArray<NSString *> *errors = [NSMutableArray array];
    for (NSURL *url in urls) {
        NSError *error = nil;
        NSURL *saved = [TSPluginStore importPluginAtURL:url error:&error];
        if (saved) [importedURLs addObject:saved];
        else [errors addObject:error.localizedDescription ?: url.lastPathComponent];
    }
    [self refreshLocalLibrary];

    NSMutableString *message = [NSMutableString stringWithFormat:NSLocalizedString(@"Imported %lu plugin item(s).", nil), (unsigned long)importedURLs.count];
    if (errors.count) [message appendFormat:NSLocalizedString(@"\n\nSome files could not be added:\n%@", nil), [errors componentsJoinedByString:@"\n"]];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Import Results", nil) message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Done", nil) style:UIAlertActionStyleCancel handler:nil]];
    if (importedURLs.count) {
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Imported Files", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
            UIAlertController *confirm = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Delete Imported Files?", nil) message:NSLocalizedString(@"Only plugin items imported in this operation will be removed.", nil) preferredStyle:UIAlertControllerStyleAlert];
            [confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
            [confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) {
                for (NSURL *saved in importedURLs) [TSPluginStore removePluginItemAtURL:saved error:nil];
                [self refreshLocalLibrary];
            }]];
            [TSPresentationDelegate presentViewController:confirm animated:YES completion:nil];
        }]];
    }
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.plugins.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TSPluginLibraryCell"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"TSPluginLibraryCell"];
    NSURL *item = self.plugins[indexPath.row];
    NSString *extension = item.pathExtension.lowercaseString;
    NSUInteger count = [TSPluginStore injectableLibraryCountForPluginItem:item];

    cell.textLabel.numberOfLines = 1;
    cell.textLabel.text = item.lastPathComponent;
    cell.detailTextLabel.numberOfLines = 1;
    cell.detailTextLabel.textColor = UIColor.secondaryLabelColor;
    cell.backgroundColor = UIColor.secondarySystemGroupedBackgroundColor;
    cell.layer.cornerCurve = kCACornerCurveContinuous;
    cell.selectionStyle = UITableViewCellSelectionStyleDefault;
    if ([extension isEqualToString:@"dylib"]) {
        cell.detailTextLabel.text = NSLocalizedString(@"Dynamic library · Ready for injection", nil);
        cell.imageView.image = [UIImage systemImageNamed:@"puzzlepiece.extension"];
    } else if ([extension isEqualToString:@"framework"]) {
        cell.detailTextLabel.text = NSLocalizedString(@"Framework · Ready for injection", nil);
        cell.imageView.image = [UIImage systemImageNamed:@"shippingbox"];
    } else {
        cell.detailTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"%@ archive · %lu injectable library(s)", nil), extension.uppercaseString, (unsigned long)count];
        cell.imageView.image = [UIImage systemImageNamed:@"archivebox"];
    }
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSURL *item = self.plugins[indexPath.row];
    NSArray<NSString *> *libraries = [TSPluginStore injectableLibraryPathsForPluginItem:item];
    NSDictionary *attributes = [NSFileManager.defaultManager attributesOfItemAtPath:item.path error:nil];
    unsigned long long fileSize = [attributes[NSFileSize] unsignedLongLongValue];
    NSMutableString *message = [NSMutableString stringWithFormat:@"%@\n%@\n\n", item.lastPathComponent, [NSByteCountFormatter stringFromByteCount:(long long)fileSize countStyle:NSByteCountFormatterCountStyleFile]];
    if (libraries.count) {
        [message appendFormat:NSLocalizedString(@"Contained dynamic libraries (%lu):\n", nil), (unsigned long)libraries.count];
        for (NSString *path in libraries) [message appendFormat:@"• %@\n", path.lastPathComponent];
    } else if ([item.pathExtension.lowercaseString isEqualToString:@"deb"] || [item.pathExtension.lowercaseString isEqualToString:@"zip"]) {
        [message appendString:NSLocalizedString(@"No injectable .dylib or .framework payload was found. The original archive is still stored.", nil)];
    }

    UIAlertController *alert = [UIAlertController alertControllerWithTitle:item.lastPathComponent message:message preferredStyle:UIAlertControllerStyleActionSheet];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Plugin", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
        NSError *error = nil;
        if (![TSPluginStore removePluginItemAtURL:item error:&error]) [self showMessage:error.localizedDescription ?: @"Could not delete plugin." title:NSLocalizedString(@"Delete Failed", nil)];
        [self refreshLocalLibrary];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:nil]];
    alert.popoverPresentationController.sourceView = tableView;
    alert.popoverPresentationController.sourceRect = [tableView rectForRowAtIndexPath:indexPath];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}

- (void)showMessage:(NSString *)message title:(NSString *)title {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}

@end
