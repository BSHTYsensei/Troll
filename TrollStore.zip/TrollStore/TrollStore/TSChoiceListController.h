#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@interface TSChoiceListController : UITableViewController
- (instancetype)initWithTitle:(NSString *)title
                      options:(NSArray<NSString *> *)options
                selectedIndex:(NSInteger)selectedIndex
            selectionHandler:(void (^)(NSInteger selectedIndex))selectionHandler;
@end
NS_ASSUME_NONNULL_END
