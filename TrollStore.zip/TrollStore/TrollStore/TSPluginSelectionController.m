#import "TSPluginSelectionController.h"
#import "TSPluginStore.h"
#import <math.h>

@interface TSPluginSelectionController ()
@property(nonatomic, copy) NSArray<NSString *> *libraryPaths;
@property(nonatomic, strong) NSMutableSet<NSString *> *selectedPaths;
@end
@implementation TSPluginSelectionController
- (instancetype)initWithLibraryPaths:(NSArray<NSString *> *)libraryPaths {
    self = [super initWithStyle:UITableViewStyleInsetGrouped];
    if (self) { _libraryPaths = [libraryPaths copy] ?: @[]; _selectedPaths = [NSMutableSet set]; }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Select Plugins", nil);
    self.tableView.rowHeight = 64;
    self.tableView.tableFooterView = [UIView new];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelPressed)];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Install", nil) style:UIBarButtonItemStyleDone target:self action:@selector(donePressed)];
    UILabel *note = [UILabel new];
    note.text = NSLocalizedString(@"Choose one or more stored dynamic libraries. Leave everything unchecked to install without plugin injection. A plugin may cause an app to crash or fail to launch.", nil);
    note.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    note.textColor = UIColor.secondaryLabelColor;
    note.numberOfLines = 0;
    note.frame = CGRectMake(0, 0, CGRectGetWidth(self.tableView.bounds) - 36, 78);
    UIView *header = [UIView new]; header.frame = CGRectMake(0, 0, CGRectGetWidth(self.tableView.bounds), 90);
    note.translatesAutoresizingMaskIntoConstraints = NO; [header addSubview:note];
    [NSLayoutConstraint activateConstraints:@[[note.topAnchor constraintEqualToAnchor:header.topAnchor constant:10], [note.bottomAnchor constraintEqualToAnchor:header.bottomAnchor constant:-10], [note.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:18], [note.trailingAnchor constraintEqualToAnchor:header.trailingAnchor constant:-18]]];
    self.tableView.tableHeaderView = header;
}
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    UIView *header = self.tableView.tableHeaderView;
    if (header && fabs(header.bounds.size.width - self.tableView.bounds.size.width) > 0.5) {
        CGRect frame = header.frame; frame.size.width = self.tableView.bounds.size.width; header.frame = frame;
        CGSize fit = [header systemLayoutSizeFittingSize:CGSizeMake(frame.size.width, UILayoutFittingCompressedSize.height)];
        frame.size.height = MAX(78, fit.height); header.frame = frame; self.tableView.tableHeaderView = header;
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return self.libraryPaths.count; }
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TSPluginChoice"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"TSPluginChoice"];
    NSString *path = self.libraryPaths[indexPath.row];
    cell.textLabel.text = path.lastPathComponent;
    NSString *root = TSPluginStore.pluginDirectoryPath;
    NSString *relative = [path stringByReplacingOccurrencesOfString:[root stringByAppendingString:@"/"] withString:@""];
    cell.detailTextLabel.text = relative;
    cell.detailTextLabel.textColor = UIColor.secondaryLabelColor;
    cell.detailTextLabel.lineBreakMode = NSLineBreakByTruncatingMiddle;
    cell.imageView.image = [UIImage systemImageNamed:path.pathExtension.length && [path.pathExtension.lowercaseString isEqualToString:@"framework"] ? @"shippingbox" : @"puzzlepiece.extension"];
    cell.accessoryType = [self.selectedPaths containsObject:path] ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSString *path = self.libraryPaths[indexPath.row];
    if ([self.selectedPaths containsObject:path]) [self.selectedPaths removeObject:path]; else [self.selectedPaths addObject:path];
    [tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
}
- (void)cancelPressed { if (self.completion) self.completion(@[], YES); self.completion = nil; }
- (void)donePressed {
    NSArray *selected = [self.libraryPaths filteredArrayUsingPredicate:[NSPredicate predicateWithBlock:^BOOL(NSString *path, NSDictionary *bindings) { return [self.selectedPaths containsObject:path]; }]];
    if (self.completion) self.completion(selected, NO);
    self.completion = nil;
}
@end
