#import "TSIPAPackageStore.h"
#import "TSArchiveExtractor.h"
#import "TSAppRepackager.h"
#import "TSInstallationController.h"
#import "TSThemeManager.h"
#import <TSPresentationDelegate.h>
@import UniformTypeIdentifiers;

static NSString *TSStoreErrorDomain = @"com.opa334.TrollStore.PackageStore";
static NSSet<NSString *> *TSPackageExtensions(void) { return [NSSet setWithArray:@[@"ipa", @"tipa", @"tar", @"zip", @"deb"]]; }

@interface TSIPAPackageStore ()
@property(nonatomic, copy) NSArray<NSURL *> *packageItems;
@property(nonatomic, copy) NSDictionary<NSString *, NSNumber *> *packageSizes;
@property(nonatomic, assign) NSUInteger packageRefreshGeneration;
@property(nonatomic, assign) BOOL packageRefreshInFlight;
@property(nonatomic, assign) BOOL packageRefreshPending;
@property(nonatomic, strong) NSDate *lastPackageRefreshDate;
@end

@implementation TSIPAPackageStore

+ (NSString *)packageDirectoryPath {
    NSString *documents = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject ?: NSTemporaryDirectory();
    return [documents stringByAppendingPathComponent:@"Packages"];
}

+ (void)ensurePackageDirectory {
    [[NSFileManager defaultManager] createDirectoryAtPath:[self packageDirectoryPath] withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0755} error:nil];
}

+ (NSArray<NSURL *> *)availablePackages {
    [self ensurePackageDirectory];
    NSArray<NSURL *> *items = [[NSFileManager defaultManager] contentsOfDirectoryAtURL:[NSURL fileURLWithPath:[self packageDirectoryPath] isDirectory:YES] includingPropertiesForKeys:@[NSURLIsRegularFileKey, NSURLContentModificationDateKey, NSURLFileSizeKey] options:NSDirectoryEnumerationSkipsHiddenFiles error:nil] ?: @[];
    NSMutableArray *packages = [NSMutableArray array];
    for (NSURL *url in items) if ([TSPackageExtensions() containsObject:url.pathExtension.lowercaseString]) [packages addObject:url];
    [packages sortUsingComparator:^NSComparisonResult(NSURL *a, NSURL *b) {
        NSDate *da = nil, *db = nil;
        [a getResourceValue:&da forKey:NSURLContentModificationDateKey error:nil];
        [b getResourceValue:&db forKey:NSURLContentModificationDateKey error:nil];
        return [db compare:da];
    }];
    return packages.copy;
}

+ (NSURL *)importPackageAtURL:(NSURL *)sourceURL error:(NSError **)error {
    if (!sourceURL.isFileURL || ![TSPackageExtensions() containsObject:sourceURL.pathExtension.lowercaseString]) {
        if (error) *error = [NSError errorWithDomain:TSStoreErrorDomain code:1 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"Only IPA, TIPA, TAR, ZIP and DEB packages are supported.", nil)}];
        return nil;
    }
    [self ensurePackageDirectory];
    BOOL scoped = [sourceURL startAccessingSecurityScopedResource];
    NSString *base = sourceURL.lastPathComponent.lastPathComponent;
    if (!base.length || [base containsString:@"/"] || [base containsString:@"\\"]) base = [NSString stringWithFormat:@"Package.%@", sourceURL.pathExtension.lowercaseString];
    NSString *dest = [[self packageDirectoryPath] stringByAppendingPathComponent:base];
    NSString *stem = dest.stringByDeletingPathExtension;
    NSString *ext = dest.pathExtension;
    NSUInteger index = 1;
    while ([[NSFileManager defaultManager] fileExistsAtPath:dest]) {
        dest = [NSString stringWithFormat:@"%@-%lu.%@", stem, (unsigned long)index++, ext];
    }
    NSError *copyError = nil;
    BOOL ok = [[NSFileManager defaultManager] copyItemAtPath:sourceURL.path toPath:dest error:&copyError];
    if (scoped) [sourceURL stopAccessingSecurityScopedResource];
    if (!ok) { if (error) *error = copyError; return nil; }
    return [NSURL fileURLWithPath:dest];
}

+ (BOOL)removeImportedPackageAtURL:(NSURL *)url error:(NSError **)error {
    if (!url.isFileURL) return NO;
    NSString *root = self.packageDirectoryPath.stringByResolvingSymlinksInPath.stringByStandardizingPath;
    NSString *resolved = url.path.stringByResolvingSymlinksInPath.stringByStandardizingPath;
    NSString *parent = resolved.stringByDeletingLastPathComponent;
    if (![parent isEqualToString:root] || ![TSPackageExtensions() containsObject:url.pathExtension.lowercaseString]) {
        if (error) *error = [NSError errorWithDomain:TSStoreErrorDomain code:5 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"Refusing to delete a package outside the package store.", nil)}];
        return NO;
    }
    NSError *removeError = nil;
    BOOL removed = [NSFileManager.defaultManager removeItemAtPath:url.path error:&removeError];
    if (!removed && error) *error = removeError;
    return removed;
}

+ (NSURL *)exportInstalledAppAtPath:(NSString *)appBundlePath error:(NSError **)error {
    NSFileManager *fm = NSFileManager.defaultManager;
    BOOL isDir = NO;
    if (![fm fileExistsAtPath:appBundlePath isDirectory:&isDir] || !isDir || ![appBundlePath.pathExtension.lowercaseString isEqualToString:@"app"]) {
        if (error) *error = [NSError errorWithDomain:TSStoreErrorDomain code:2 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"The application bundle is unavailable.", nil)}];
        return nil;
    }
    [self ensurePackageDirectory];
    NSString *display = [[NSDictionary dictionaryWithContentsOfFile:[appBundlePath stringByAppendingPathComponent:@"Info.plist"]][@"CFBundleDisplayName"] description];
    if (!display.length) display = appBundlePath.lastPathComponent.stringByDeletingPathExtension;
    NSString *safe = [[display componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"/\\:\n\r"]] componentsJoinedByString:@"_"];
    NSString *output = [[self packageDirectoryPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@-%@.ipa", safe, [NSUUID.UUID.UUIDString substringToIndex:8]]];
    NSString *staging = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"TS-export-%@", NSUUID.UUID.UUIDString]];
    NSString *payload = [staging stringByAppendingPathComponent:@"Payload"];
    NSString *copyPath = [payload stringByAppendingPathComponent:appBundlePath.lastPathComponent];
    if (![fm createDirectoryAtPath:payload withIntermediateDirectories:YES attributes:nil error:error] || ![fm copyItemAtPath:appBundlePath toPath:copyPath error:error]) {
        [fm removeItemAtPath:staging error:nil];
        return nil;
    }
    BOOL success = [TSArchiveExtractor createZipFromDirectory:staging outputPath:output error:error];
    [fm removeItemAtPath:staging error:nil];
    if (!success) return nil;
    return [NSURL fileURLWithPath:output];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Packages", nil);
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeAlways;
    self.tableView.rowHeight = 66;
    self.tableView.tableFooterView = [UIView new];
    [TSThemeManager styleCardTableView:self.tableView];

    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Edit", nil) style:UIBarButtonItemStylePlain target:self action:@selector(toggleEditing)];
    __weak typeof(self) weakSelf = self;
    UIAction *importAction = [UIAction actionWithTitle:NSLocalizedString(@"Import from Files", nil) image:[UIImage systemImageNamed:@"doc.badge.plus"] identifier:@"ImportPackage" handler:^(__kindof UIAction *action) {
        [weakSelf importPressed];
    }];
    UIAction *downloadAction = [UIAction actionWithTitle:NSLocalizedString(@"Download from URL", nil) image:[UIImage systemImageNamed:@"link.badge.plus"] identifier:@"DownloadPackage" handler:^(__kindof UIAction *action) {
        [weakSelf downloadPressed];
    }];
    UIAction *refreshAction = [UIAction actionWithTitle:NSLocalizedString(@"Refresh", nil) image:[UIImage systemImageNamed:@"arrow.clockwise"] identifier:@"RefreshPackages" handler:^(__kindof UIAction *action) {
        [weakSelf refreshPackageList];
    }];
    UIMenu *addMenu = [UIMenu menuWithTitle:@"" children:@[importAction, downloadAction, refreshAction]];
    UIImageSymbolConfiguration *plusConfiguration = [UIImageSymbolConfiguration configurationWithPointSize:21.0 weight:UIImageSymbolWeightSemibold];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"plus.circle.fill" withConfiguration:plusConfiguration] menu:addMenu];
    [TSIPAPackageStore ensurePackageDirectory];
    self.packageItems = @[];
    self.packageSizes = @{};
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if (!self.lastPackageRefreshDate || -self.lastPackageRefreshDate.timeIntervalSinceNow > 20.0) [self refreshPackageList];
}

- (void)refreshPackageList {
    if (self.packageRefreshInFlight) {
        self.packageRefreshPending = YES;
        return;
    }
    self.packageRefreshInFlight = YES;
    NSUInteger generation = ++self.packageRefreshGeneration;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        NSArray<NSURL *> *items = [TSIPAPackageStore availablePackages];
        NSMutableDictionary<NSString *, NSNumber *> *sizes = [NSMutableDictionary dictionaryWithCapacity:items.count];
        for (NSURL *url in items) {
            NSNumber *size = nil;
            [url getResourceValue:&size forKey:NSURLFileSizeKey error:nil];
            if (size) sizes[url.path] = size;
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            if (generation != self.packageRefreshGeneration) return;
            self.packageItems = items ?: @[];
            self.packageSizes = sizes.copy;
            self.lastPackageRefreshDate = [NSDate date];
            self.packageRefreshInFlight = NO;
            [self.tableView reloadData];
            if (self.packageRefreshPending) {
                self.packageRefreshPending = NO;
                [self refreshPackageList];
            }
        });
    });
}

- (void)importPressed {
    UTType *dataType = [UTType typeWithIdentifier:@"public.data"];
    UTType *archiveType = [UTType typeWithIdentifier:@"public.archive"] ?: dataType;
    if (!dataType) return;
    UTType *ipa = [UTType typeWithFilenameExtension:@"ipa"] ?: dataType;
    UTType *tipa = [UTType typeWithFilenameExtension:@"tipa"] ?: dataType;
    UTType *tar = [UTType typeWithFilenameExtension:@"tar"] ?: dataType;
    UTType *zip = [UTType typeWithFilenameExtension:@"zip"] ?: archiveType;
    UTType *deb = [UTType typeWithFilenameExtension:@"deb"] ?: dataType;
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:@[ipa, tipa, tar, zip, deb] asCopy:YES];
    picker.allowsMultipleSelection = YES; picker.delegate = self;
    [TSPresentationDelegate presentViewController:picker animated:YES completion:nil];
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    [TSPresentationDelegate startActivity:NSLocalizedString(@"Importing Packages", nil)];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        NSMutableArray<NSURL *> *importedURLs = [NSMutableArray array];
        NSMutableArray<NSString *> *errors = [NSMutableArray array];
        for (NSURL *url in urls) {
            @autoreleasepool {
                NSError *error = nil;
                NSURL *saved = [TSIPAPackageStore importPackageAtURL:url error:&error];
                if (saved) [importedURLs addObject:saved];
                else [errors addObject:error.localizedDescription ?: url.lastPathComponent];
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [self refreshPackageList];
            [TSPresentationDelegate stopActivityWithCompletion:^{
                NSMutableString *message = [NSMutableString stringWithFormat:NSLocalizedString(@"Imported %lu package(s).", nil), (unsigned long)importedURLs.count];
                if (errors.count) [message appendFormat:NSLocalizedString(@"\n\nSome files could not be imported:\n%@", nil), [errors componentsJoinedByString:@"\n"]];
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Import Results", nil) message:message preferredStyle:UIAlertControllerStyleAlert];
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Done", nil) style:UIAlertActionStyleCancel handler:nil]];
                if (importedURLs.count) [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Imported Files", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
                    [TSPresentationDelegate startActivity:NSLocalizedString(@"Deleting Packages", nil)];
                    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
                        for (NSURL *saved in importedURLs) [TSIPAPackageStore removeImportedPackageAtURL:saved error:nil];
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [self refreshPackageList];
                            [TSPresentationDelegate stopActivityWithCompletion:nil];
                        });
                    });
                }]];
                [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
            }];
        });
    });
}

- (void)downloadPressed {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Download Package", nil) message:NSLocalizedString(@"Enter a direct HTTPS download URL. Software sources are not included.", nil) preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) { field.placeholder = @"https://example.com/app.ipa"; field.keyboardType = UIKeyboardTypeURL; field.autocorrectionType = UITextAutocorrectionTypeNo; field.autocapitalizationType = UITextAutocapitalizationTypeNone; }];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Download", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        NSString *value = alert.textFields.firstObject.text ?: @"";
        NSURL *url = [NSURL URLWithString:value];
        if (!url || ![url.scheme.lowercaseString isEqualToString:@"https"] || ![TSPackageExtensions() containsObject:url.pathExtension.lowercaseString]) {
            UIAlertController *invalid = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Invalid URL", nil) message:NSLocalizedString(@"Use a direct URL ending in .ipa, .tipa, .tar, .zip or .deb.", nil) preferredStyle:UIAlertControllerStyleAlert];
            [invalid addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
            [TSPresentationDelegate presentViewController:invalid animated:YES completion:nil]; return;
        }
        [TSPresentationDelegate startActivity:NSLocalizedString(@"Downloading Package", nil)];
        NSURLSessionDownloadTask *task = [NSURLSession.sharedSession downloadTaskWithURL:url completionHandler:^(NSURL *location, NSURLResponse *response, NSError *downloadError) {
            NSError *copyError = nil;
            NSURL *saved = nil;
            if (!downloadError && location) {
                NSString *name = (response.suggestedFilename.length ? response.suggestedFilename : url.lastPathComponent).lastPathComponent;
                if ([name containsString:@".."] || [name containsString:@"/"] || [name containsString:@"\\"]) name = @"DownloadedPackage";
                if (![TSPackageExtensions() containsObject:name.pathExtension.lowercaseString]) name = [NSString stringWithFormat:@"Downloaded.%@", url.pathExtension.lowercaseString];
                NSString *target = [[TSIPAPackageStore packageDirectoryPath] stringByAppendingPathComponent:name];
                if ([[NSFileManager defaultManager] fileExistsAtPath:target]) target = [[TSIPAPackageStore packageDirectoryPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@-%@", [NSUUID.UUID.UUIDString substringToIndex:8], name]];
                if ([[NSFileManager defaultManager] copyItemAtPath:location.path toPath:target error:&copyError]) saved = [NSURL fileURLWithPath:target];
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [TSPresentationDelegate stopActivityWithCompletion:^{
                    [self refreshPackageList];
                    if (!saved) {
                        UIAlertController *failed = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Download Failed", nil) message:(downloadError ?: copyError).localizedDescription ?: NSLocalizedString(@"The server did not return a package.", nil) preferredStyle:UIAlertControllerStyleAlert];
                        [failed addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
                        [TSPresentationDelegate presentViewController:failed animated:YES completion:nil];
                    }
                }];
            });
        }];
        [task resume];
    }]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return self.packageItems.count; }

- (void)toggleEditing {
    [self.tableView setEditing:!self.tableView.isEditing animated:YES];
    self.navigationItem.leftBarButtonItem.title = self.tableView.isEditing ? NSLocalizedString(@"Done", nil) : NSLocalizedString(@"Edit", nil);
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return indexPath.row < self.packageItems.count;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle != UITableViewCellEditingStyleDelete || indexPath.row >= self.packageItems.count) return;
    NSURL *url = self.packageItems[indexPath.row];
    NSError *error = nil;
    if (![TSIPAPackageStore removeImportedPackageAtURL:url error:&error]) {
        [self showError:error.localizedDescription ?: NSLocalizedString(@"The package could not be removed.", nil) title:NSLocalizedString(@"Remove Package Failed", nil)];
        [self refreshPackageList];
        return;
    }
    NSMutableArray *updated = [self.packageItems mutableCopy];
    [updated removeObjectAtIndex:indexPath.row];
    self.packageItems = updated.copy;
    [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PackageCell"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"PackageCell"];
    NSURL *url = self.packageItems[indexPath.row];
    NSNumber *size = self.packageSizes[url.path] ?: @0;
    cell.textLabel.text = url.lastPathComponent;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ · %@", url.pathExtension.uppercaseString, [NSByteCountFormatter stringFromByteCount:size.longLongValue countStyle:NSByteCountFormatterCountStyleFile]];
    cell.imageView.image = [UIImage systemImageNamed:[url.pathExtension.lowercaseString isEqualToString:@"ipa"] || [url.pathExtension.lowercaseString isEqualToString:@"tipa"] ? @"app.dashed" : @"archivebox"];
    cell.imageView.tintColor = [TSThemeManager accentColor];
    cell.textLabel.font = [UIFont systemFontOfSize:16.5 weight:UIFontWeightMedium];
    cell.textLabel.textColor = UIColor.labelColor;
    cell.detailTextLabel.textColor = UIColor.secondaryLabelColor;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    [TSThemeManager styleCardTableViewCell:cell];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row >= self.packageItems.count) return;
    NSURL *url = self.packageItems[indexPath.row];
    NSString *extension = url.pathExtension.lowercaseString;
    CGRect sourceRect = [tableView rectForRowAtIndexPath:indexPath];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    // Inspecting a ZIP can walk thousands of archive entries. Keep that work off
    // the main thread so the row highlight and navigation remain responsive.
    if ([extension isEqualToString:@"zip"]) {
        [TSPresentationDelegate startActivity:NSLocalizedString(@"Inspecting Archive", nil)];
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            BOOL containsIPA = [TSArchiveExtractor archiveContainsInstallableIPAAtPath:url.path];
            NSURL *actionURL = url;
            NSError *copyError = nil;
            if (containsIPA) {
                NSString *temporaryIPA = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"TS-ZIP-IPA-%@.ipa", NSUUID.UUID.UUIDString]];
                if ([[NSFileManager defaultManager] copyItemAtPath:url.path toPath:temporaryIPA error:&copyError]) actionURL = [NSURL fileURLWithPath:temporaryIPA];
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [TSPresentationDelegate stopActivityWithCompletion:^{
                    if (copyError) {
                        [self showError:copyError.localizedDescription ?: NSLocalizedString(@"Could not stage the IPA package.", nil) title:NSLocalizedString(@"Install Failed", nil)];
                        return;
                    }
                    [self presentActionsForPackageURL:url actionURL:actionURL sourceRect:sourceRect];
                }];
            });
        });
        return;
    }
    [self presentActionsForPackageURL:url actionURL:url sourceRect:sourceRect];
}

- (void)presentActionsForPackageURL:(NSURL *)url actionURL:(NSURL *)actionURL sourceRect:(CGRect)sourceRect {
    NSString *extension = url.pathExtension.lowercaseString;
    NSString *actionExtension = actionURL.pathExtension.lowercaseString;
    UIAlertController *actions = [UIAlertController alertControllerWithTitle:url.lastPathComponent message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    if ([actionExtension isEqualToString:@"ipa"] || [actionExtension isEqualToString:@"tipa"]) {
        [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Install", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [TSInstallationController presentInstallationAlertIfEnabledForFile:actionURL.path isRemoteInstall:NO completion:nil]; }]];
        [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Modify Before Install", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
            [TSAppRepackager presentFromViewController:self sourceIPA:actionURL.path completion:^(NSString *outputPath, NSError *error) {
                if (outputPath) [TSInstallationController presentInstallationAlertIfEnabledForFile:outputPath isRemoteInstall:NO completion:nil];
                else if (error) [self showError:error.localizedDescription title:NSLocalizedString(@"Repackage Failed", nil)];
            }];
        }]];
        [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Share IPA", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [self shareURL:actionURL]; }]];
    } else {
        [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Extract Archive", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [self extractPackage:url]; }]];
        if ([extension isEqualToString:@"zip"] || [extension isEqualToString:@"deb"]) {
            [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Find Dynamic Libraries", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [self showLibrariesInPackage:url]; }]];
        }
        [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Share File", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [self shareURL:url]; }]];
    }
    [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) {
        [TSPresentationDelegate startActivity:NSLocalizedString(@"Deleting Package", nil)];
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            NSError *error = nil;
            BOOL removed = [TSIPAPackageStore removeImportedPackageAtURL:url error:&error];
            dispatch_async(dispatch_get_main_queue(), ^{
                [self refreshPackageList];
                [TSPresentationDelegate stopActivityWithCompletion:^{
                    if (!removed) [self showError:error.localizedDescription ?: NSLocalizedString(@"Could not delete package.", nil) title:NSLocalizedString(@"Delete Failed", nil)];
                }];
            });
        });
    }]];
    [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    actions.popoverPresentationController.sourceView = self.tableView;
    actions.popoverPresentationController.sourceRect = sourceRect;
    [TSPresentationDelegate presentViewController:actions animated:YES completion:nil];
}

- (void)extractPackage:(NSURL *)url {
    NSString *name = url.lastPathComponent.stringByDeletingPathExtension;
    NSString *destination = [[TSIPAPackageStore packageDirectoryPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"Extracted-%@", name]];
    [TSPresentationDelegate startActivity:NSLocalizedString(@"Extracting Archive", nil)];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        NSError *error = nil; BOOL ok = [TSArchiveExtractor extractArchiveAtPath:url.path toDirectory:destination error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            [TSPresentationDelegate stopActivityWithCompletion:^{ [self showError:ok ? [NSString stringWithFormat:NSLocalizedString(@"Extracted to %@", nil), destination] : error.localizedDescription title:ok ? NSLocalizedString(@"Extraction Complete", nil) : NSLocalizedString(@"Extraction Failed", nil)]; }];
        });
    });
}

- (void)showLibrariesInPackage:(NSURL *)url {
    NSString *destination = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"TSTweakPackage-%@", NSUUID.UUID.UUIDString]];
    [TSPresentationDelegate startActivity:NSLocalizedString(@"Scanning Dynamic Libraries", nil)];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        NSError *error = nil;
        BOOL extracted = [TSArchiveExtractor extractArchiveAtPath:url.path toDirectory:destination error:&error];
        NSArray<NSString *> *libraries = extracted ? [TSArchiveExtractor dynamicLibrariesUnderDirectory:destination] : @[];
        dispatch_async(dispatch_get_main_queue(), ^{
            [TSPresentationDelegate stopActivityWithCompletion:^{
                if (!extracted) { [self showError:error.localizedDescription title:NSLocalizedString(@"Extraction Failed", nil)]; return; }
                if (!libraries.count) { [self showError:NSLocalizedString(@"No .dylib files were found in this package.", nil) title:NSLocalizedString(@"No Dynamic Libraries", nil)]; return; }
                NSString *message = [[libraries valueForKey:@"lastPathComponent"] componentsJoinedByString:@"\n"];
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Dynamic Libraries", nil) message:message preferredStyle:UIAlertControllerStyleAlert];
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Copy Paths", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { UIPasteboard.generalPasteboard.string = [libraries componentsJoinedByString:@"\n"]; }]];
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Done", nil) style:UIAlertActionStyleCancel handler:nil]];
                [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
            }];
        });
    });
}

- (void)shareURL:(NSURL *)url {
    UIActivityViewController *activity = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
    activity.popoverPresentationController.sourceView = self.view;
    activity.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds), 1, 1);
    [TSPresentationDelegate presentViewController:activity animated:YES completion:nil];
}

- (void)showError:(NSString *)message title:(NSString *)title {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}
@end
