#import "TSIPAPackageStore.h"
#import "TSArchiveExtractor.h"
#import "TSAppRepackager.h"
#import "TSInstallationController.h"
#import <TSPresentationDelegate.h>
@import UniformTypeIdentifiers;

static NSString *TSStoreErrorDomain = @"com.opa334.TrollStore.PackageStore";
static NSSet<NSString *> *TSPackageExtensions(void) { return [NSSet setWithArray:@[@"ipa", @"tipa", @"tar", @"zip", @"deb"]]; }

@implementation TSIPAPackageStore

+ (NSString *)packageDirectoryPath {
    NSString *documents = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES).firstObject ?: NSTemporaryDirectory();
    return [documents stringByAppendingPathComponent:@"Packages"];
}

+ (void)ensurePackageDirectory {
    [[NSFileManager defaultManager] createDirectoryAtPath:[self packageDirectoryPath] withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0755} error:nil];
}

+ (NSArray<NSURL *> *)availablePackages {
    [self ensurePackageDirectory];
    NSArray<NSURL *> *items = [[NSFileManager defaultManager] contentsOfDirectoryAtURL:[NSURL fileURLWithPath:[self packageDirectoryPath] isDirectory:YES] includingPropertiesForKeys:@[NSURLIsRegularFileKey, NSURLContentModificationDateKey, NSURLFileSizeKey] options:NSDirectoryEnumerationSkipsHiddenFiles error:nil] ?: @[];
    NSMutableArray *packages = [NSMutableArray array];
    for (NSURL *url in items) if ([TSPackageExtensions() containsObject:url.pathExtension.lowercaseString]) [packages addObject:url];
    [packages sortUsingComparator:^NSComparisonResult(NSURL *a, NSURL *b) {
        NSDate *da = nil, *db = nil;
        [a getResourceValue:&da forKey:NSURLContentModificationDateKey error:nil];
        [b getResourceValue:&db forKey:NSURLContentModificationDateKey error:nil];
        return [db compare:da];
    }];
    return packages.copy;
}

+ (NSURL *)importPackageAtURL:(NSURL *)sourceURL error:(NSError **)error {
    if (!sourceURL.isFileURL || ![TSPackageExtensions() containsObject:sourceURL.pathExtension.lowercaseString]) {
        if (error) *error = [NSError errorWithDomain:TSStoreErrorDomain code:1 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"Only IPA, TIPA, TAR, ZIP and DEB packages are supported.", nil)}];
        return nil;
    }
    [self ensurePackageDirectory];
    BOOL scoped = [sourceURL startAccessingSecurityScopedResource];
    NSString *base = sourceURL.lastPathComponent.lastPathComponent;
    if (!base.length || [base containsString:@"/"] || [base containsString:@"\\"]) base = [NSString stringWithFormat:@"Package.%@", sourceURL.pathExtension.lowercaseString];
    NSString *dest = [[self packageDirectoryPath] stringByAppendingPathComponent:base];
    NSString *stem = dest.stringByDeletingPathExtension;
    NSString *ext = dest.pathExtension;
    NSUInteger index = 1;
    while ([[NSFileManager defaultManager] fileExistsAtPath:dest]) {
        dest = [NSString stringWithFormat:@"%@-%lu.%@", stem, (unsigned long)index++, ext];
    }
    NSError *copyError = nil;
    BOOL ok = [[NSFileManager defaultManager] copyItemAtPath:sourceURL.path toPath:dest error:&copyError];
    if (scoped) [sourceURL stopAccessingSecurityScopedResource];
    if (!ok) { if (error) *error = copyError; return nil; }
    return [NSURL fileURLWithPath:dest];
}

+ (NSURL *)exportInstalledAppAtPath:(NSString *)appBundlePath error:(NSError **)error {
    NSFileManager *fm = NSFileManager.defaultManager;
    BOOL isDir = NO;
    if (![fm fileExistsAtPath:appBundlePath isDirectory:&isDir] || !isDir || ![appBundlePath.pathExtension.lowercaseString isEqualToString:@"app"]) {
        if (error) *error = [NSError errorWithDomain:TSStoreErrorDomain code:2 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"The application bundle is unavailable.", nil)}];
        return nil;
    }
    [self ensurePackageDirectory];
    NSString *display = [[NSDictionary dictionaryWithContentsOfFile:[appBundlePath stringByAppendingPathComponent:@"Info.plist"]][@"CFBundleDisplayName"] description];
    if (!display.length) display = appBundlePath.lastPathComponent.stringByDeletingPathExtension;
    NSString *safe = [[display componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"/\\:\n\r"]] componentsJoinedByString:@"_"];
    NSString *output = [[self packageDirectoryPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@-%@.ipa", safe, [NSUUID.UUID.UUIDString substringToIndex:8]]];
    NSString *staging = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"TS-export-%@", NSUUID.UUID.UUIDString]];
    NSString *payload = [staging stringByAppendingPathComponent:@"Payload"];
    NSString *copyPath = [payload stringByAppendingPathComponent:appBundlePath.lastPathComponent];
    if (![fm createDirectoryAtPath:payload withIntermediateDirectories:YES attributes:nil error:error] || ![fm copyItemAtPath:appBundlePath toPath:copyPath error:error]) {
        [fm removeItemAtPath:staging error:nil];
        return nil;
    }
    BOOL success = [TSArchiveExtractor createZipFromDirectory:staging outputPath:output error:error];
    [fm removeItemAtPath:staging error:nil];
    if (!success) return nil;
    return [NSURL fileURLWithPath:output];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Packages", nil);
    self.tableView.rowHeight = 66;
    self.tableView.tableFooterView = [UIView new];
    UIBarButtonItem *add = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(importPressed)];
    UIBarButtonItem *download = [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"arrow.down.circle"] style:UIBarButtonItemStylePlain target:self action:@selector(downloadPressed)];
    self.navigationItem.rightBarButtonItems = @[add, download];
    [TSIPAPackageStore ensurePackageDirectory];
}

- (void)viewWillAppear:(BOOL)animated { [super viewWillAppear:animated]; [self.tableView reloadData]; }

- (void)importPressed {
    UTType *ipa = [UTType typeWithFilenameExtension:@"ipa"] ?: UTType.data;
    UTType *tipa = [UTType typeWithFilenameExtension:@"tipa"] ?: UTType.data;
    UTType *tar = [UTType typeWithFilenameExtension:@"tar"] ?: UTType.data;
    UTType *zip = [UTType typeWithFilenameExtension:@"zip"] ?: UTType.archive;
    UTType *deb = [UTType typeWithFilenameExtension:@"deb"] ?: UTType.data;
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:@[ipa, tipa, tar, zip, deb] asCopy:YES];
    picker.allowsMultipleSelection = YES; picker.delegate = self;
    [TSPresentationDelegate presentViewController:picker animated:YES completion:nil];
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSMutableArray *errors = [NSMutableArray array];
    for (NSURL *url in urls) {
        NSError *error = nil;
        if (![TSIPAPackageStore importPackageAtURL:url error:&error]) [errors addObject:error.localizedDescription ?: url.lastPathComponent];
    }
    [self.tableView reloadData];
    if (errors.count) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Import Failed", nil) message:[errors componentsJoinedByString:@"\n"] preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
        [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
    }
}

- (void)downloadPressed {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Download Package", nil) message:NSLocalizedString(@"Enter a direct HTTPS download URL. Software sources are not included.", nil) preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) { field.placeholder = @"https://example.com/app.ipa"; field.keyboardType = UIKeyboardTypeURL; field.autocorrectionType = UITextAutocorrectionTypeNo; field.autocapitalizationType = UITextAutocapitalizationTypeNone; }];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Download", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        NSString *value = alert.textFields.firstObject.text ?: @"";
        NSURL *url = [NSURL URLWithString:value];
        if (!url || ![url.scheme.lowercaseString isEqualToString:@"https"] || ![TSPackageExtensions() containsObject:url.pathExtension.lowercaseString]) {
            UIAlertController *invalid = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Invalid URL", nil) message:NSLocalizedString(@"Use a direct URL ending in .ipa, .tipa, .tar, .zip or .deb.", nil) preferredStyle:UIAlertControllerStyleAlert];
            [invalid addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
            [TSPresentationDelegate presentViewController:invalid animated:YES completion:nil]; return;
        }
        [TSPresentationDelegate startActivity:NSLocalizedString(@"Downloading Package", nil)];
        NSURLSessionDownloadTask *task = [NSURLSession.sharedSession downloadTaskWithURL:url completionHandler:^(NSURL *location, NSURLResponse *response, NSError *downloadError) {
            NSError *copyError = nil;
            NSURL *saved = nil;
            if (!downloadError && location) {
                NSString *name = (response.suggestedFilename.length ? response.suggestedFilename : url.lastPathComponent).lastPathComponent;
                if ([name containsString:@".."] || [name containsString:@"/"] || [name containsString:@"\\"]) name = @"DownloadedPackage";
                if (![TSPackageExtensions() containsObject:name.pathExtension.lowercaseString]) name = [NSString stringWithFormat:@"Downloaded.%@", url.pathExtension.lowercaseString];
                NSString *target = [[TSIPAPackageStore packageDirectoryPath] stringByAppendingPathComponent:name];
                if ([[NSFileManager defaultManager] fileExistsAtPath:target]) target = [[TSIPAPackageStore packageDirectoryPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@-%@", [NSUUID.UUID.UUIDString substringToIndex:8], name]];
                if ([[NSFileManager defaultManager] copyItemAtPath:location.path toPath:target error:&copyError]) saved = [NSURL fileURLWithPath:target];
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                [TSPresentationDelegate stopActivityWithCompletion:^{
                    [self.tableView reloadData];
                    if (!saved) {
                        UIAlertController *failed = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Download Failed", nil) message:(downloadError ?: copyError).localizedDescription ?: NSLocalizedString(@"The server did not return a package.", nil) preferredStyle:UIAlertControllerStyleAlert];
                        [failed addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
                        [TSPresentationDelegate presentViewController:failed animated:YES completion:nil];
                    }
                }];
            });
        }];
        [task resume];
    }]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return TSIPAPackageStore.availablePackages.count; }

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PackageCell"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"PackageCell"];
    NSURL *url = TSIPAPackageStore.availablePackages[indexPath.row];
    NSNumber *size = nil; [url getResourceValue:&size forKey:NSURLFileSizeKey error:nil];
    cell.textLabel.text = url.lastPathComponent;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ · %@", url.pathExtension.uppercaseString, [NSByteCountFormatter stringFromByteCount:size.longLongValue countStyle:NSByteCountFormatterCountStyleFile]];
    cell.imageView.image = [UIImage systemImageNamed:[url.pathExtension.lowercaseString isEqualToString:@"ipa"] || [url.pathExtension.lowercaseString isEqualToString:@"tipa"] ? @"app.dashed" : @"archivebox"];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSURL *url = TSIPAPackageStore.availablePackages[indexPath.row];
    NSString *ext = url.pathExtension.lowercaseString;
    // A ZIP containing a normal Payload/*.app/Info.plist layout is an IPA package
    // with a nonstandard extension. Stage a temporary .ipa name so existing install
    // and repackaging paths can validate it normally; leave the user's source ZIP intact.
    NSURL *actionURL = url;
    if ([ext isEqualToString:@"zip"] && [TSArchiveExtractor archiveContainsInstallableIPAAtPath:url.path]) {
        NSString *temporaryIPA = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"TS-ZIP-IPA-%@.ipa", NSUUID.UUID.UUIDString]];
        NSError *copyError = nil;
        if (![[NSFileManager defaultManager] copyItemAtPath:url.path toPath:temporaryIPA error:&copyError]) {
            [self showError:copyError.localizedDescription ?: NSLocalizedString(@"Could not stage the IPA package.", nil) title:NSLocalizedString(@"Install Failed", nil)];
            [tableView deselectRowAtIndexPath:indexPath animated:YES];
            return;
        }
        actionURL = [NSURL fileURLWithPath:temporaryIPA];
    }
    NSString *actionExtension = actionURL.pathExtension.lowercaseString;
    UIAlertController *actions = [UIAlertController alertControllerWithTitle:url.lastPathComponent message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    if ([actionExtension isEqualToString:@"ipa"] || [actionExtension isEqualToString:@"tipa"]) {
        [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Install", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [TSInstallationController presentInstallationAlertIfEnabledForFile:actionURL.path isRemoteInstall:NO completion:nil]; }]];
        [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Modify Before Install", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
            [TSAppRepackager presentFromViewController:self sourceIPA:actionURL.path completion:^(NSString *outputPath, NSError *error) {
                if (outputPath) [TSInstallationController presentInstallationAlertIfEnabledForFile:outputPath isRemoteInstall:NO completion:nil];
                else if (error) [self showError:error.localizedDescription title:NSLocalizedString(@"Repackage Failed", nil)];
            }];
        }]];
        [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Share IPA", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [self shareURL:actionURL]; }]];
    } else {
        [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Extract Archive", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [self extractPackage:url]; }]];
        if ([ext isEqualToString:@"zip"] || [ext isEqualToString:@"deb"]) {
            [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Find Dynamic Libraries", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [self showLibrariesInPackage:url]; }]];
        }
        [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Share File", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [self shareURL:url]; }]];
    }
    [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) { [[NSFileManager defaultManager] removeItemAtURL:url error:nil]; [self.tableView reloadData]; }]];
    [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    actions.popoverPresentationController.sourceView = tableView; actions.popoverPresentationController.sourceRect = [tableView rectForRowAtIndexPath:indexPath];
    [TSPresentationDelegate presentViewController:actions animated:YES completion:nil];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)extractPackage:(NSURL *)url {
    NSString *name = url.lastPathComponent.stringByDeletingPathExtension;
    NSString *destination = [[TSIPAPackageStore packageDirectoryPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"Extracted-%@", name]];
    [TSPresentationDelegate startActivity:NSLocalizedString(@"Extracting Archive", nil)];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        NSError *error = nil; BOOL ok = [TSArchiveExtractor extractArchiveAtPath:url.path toDirectory:destination error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            [TSPresentationDelegate stopActivityWithCompletion:^{ [self showError:ok ? [NSString stringWithFormat:NSLocalizedString(@"Extracted to %@", nil), destination] : error.localizedDescription title:ok ? NSLocalizedString(@"Extraction Complete", nil) : NSLocalizedString(@"Extraction Failed", nil)]; }];
        });
    });
}

- (void)showLibrariesInPackage:(NSURL *)url {
    NSString *destination = [[NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"TSTweakPackage-%@", NSUUID.UUID.UUIDString]] copy];
    NSError *error = nil;
    if (![TSArchiveExtractor extractArchiveAtPath:url.path toDirectory:destination error:&error]) { [self showError:error.localizedDescription title:NSLocalizedString(@"Extraction Failed", nil)]; return; }
    NSArray *libraries = [TSArchiveExtractor dynamicLibrariesUnderDirectory:destination];
    if (!libraries.count) { [self showError:NSLocalizedString(@"No .dylib files were found in this package.", nil) title:NSLocalizedString(@"No Dynamic Libraries", nil)]; return; }
    NSString *message = [[libraries valueForKey:@"lastPathComponent"] componentsJoinedByString:@"\n"];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Dynamic Libraries", nil) message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Copy Paths", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { UIPasteboard.generalPasteboard.string = [libraries componentsJoinedByString:@"\n"]; }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Done", nil) style:UIAlertActionStyleCancel handler:nil]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}

- (void)shareURL:(NSURL *)url {
    UIActivityViewController *activity = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
    activity.popoverPresentationController.sourceView = self.view;
    activity.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds), 1, 1);
    [TSPresentationDelegate presentViewController:activity animated:YES completion:nil];
}

- (void)showError:(NSString *)message title:(NSString *)title {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}
@end
