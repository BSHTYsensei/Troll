#import <UIKit/UIKit.h>

@interface TSSettingsListController : UITableViewController
@end
