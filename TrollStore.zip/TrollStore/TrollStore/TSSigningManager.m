#import "TSSigningManager.h"
#import <Security/Security.h>
#import <CommonCrypto/CommonDigest.h>
#import <sys/stat.h>
#import <fcntl.h>
#import <unistd.h>

extern NSUserDefaults *trollStoreUserDefaults(void);

static NSString * const TSSigningErrorDomain = @"com.opa334.TrollStore.Signing";
static NSString * const TSSigningCredentialsDefaultsKey = @"TSSigningCredentials";
static NSString * const TSSigningKeychainService = @"com.opa334.TrollStore.SigningIdentity";

static NSError *TSSigningError(NSInteger code, NSString *message) {
    return [NSError errorWithDomain:TSSigningErrorDomain code:code userInfo:@{NSLocalizedDescriptionKey: message ?: NSLocalizedString(@"Signing configuration failed.", nil)}];
}

static NSString *TSHexString(const unsigned char *bytes, NSUInteger length) {
    NSMutableString *result = [NSMutableString stringWithCapacity:length * 2];
    for (NSUInteger index = 0; index < length; index++) [result appendFormat:@"%02x", bytes[index]];
    return result;
}

static id TSPropertyValue(id value) {
    if (![value isKindOfClass:NSDictionary.class]) return value ?: @"";
    NSDictionary *dictionary = value;
    id nested = dictionary[@"value"];
    if (nested) return TSPropertyValue(nested);
    NSMutableArray *parts = [NSMutableArray array];
    for (id key in [[dictionary allKeys] sortedArrayUsingSelector:@selector(compare:)]) {
        id item = dictionary[key];
        if ([item isKindOfClass:NSDictionary.class] || [item isKindOfClass:NSArray.class]) {
            NSString *flattened = [TSPropertyValue(item) description];
            if (flattened.length) [parts addObject:[NSString stringWithFormat:@"%@=%@", key, flattened]];
        }
    }
    return parts.count ? [parts componentsJoinedByString:@", "] : [dictionary description];
}

static NSString *TSDisplayDate(id value) {
    id flattened = TSPropertyValue(value);
    if ([flattened isKindOfClass:NSDate.class]) {
        NSDateFormatter *formatter = [NSDateFormatter new];
        formatter.locale = [NSLocale localeWithLocaleIdentifier:@"zh_CN"];
        formatter.timeZone = NSTimeZone.localTimeZone;
        formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss z";
        return [formatter stringFromDate:flattened];
    }
    return [flattened description] ?: NSLocalizedString(@"Unavailable", nil);
}

static NSDictionary *TSMetadataForCertificate(SecCertificateRef certificate, NSData **certificateDEROut) {
    if (!certificate) return @{};
    CFDataRef copiedData = SecCertificateCopyData(certificate);
    NSData *der = CFBridgingRelease(copiedData);
    if (certificateDEROut) *certificateDEROut = der;

    CFErrorRef copyError = NULL;
    CFDictionaryRef rawValues = SecCertificateCopyValues(certificate, NULL, &copyError);
    NSDictionary *values = rawValues ? CFBridgingRelease(rawValues) : @{};
    if (copyError) CFRelease(copyError);

    NSString *issuer = @"";
    NSString *notBefore = @"";
    NSString *notAfter = @"";
    NSMutableArray<NSString *> *oids = [NSMutableArray array];
    for (id key in values) {
        if (![key isKindOfClass:NSString.class]) continue;
        NSString *oid = key;
        NSDictionary *entry = [values[oid] isKindOfClass:NSDictionary.class] ? values[oid] : @{};
        NSString *label = [entry[@"label"] isKindOfClass:NSString.class] ? entry[@"label"] : @"";
        id propertyValue = entry[@"value"] ?: entry;
        NSString *display = [TSPropertyValue(propertyValue) description] ?: @"";
        NSString *lowerLabel = label.lowercaseString;
        if ([lowerLabel containsString:@"issuer"]) issuer = display;
        if ([lowerLabel containsString:@"not before"] || [lowerLabel containsString:@"valid before"] || [lowerLabel containsString:@"valid from"] || [lowerLabel containsString:@"validity start"]) notBefore = TSDisplayDate(propertyValue);
        if ([lowerLabel containsString:@"not after"] || [lowerLabel containsString:@"valid after"] || [lowerLabel containsString:@"valid until"] || [lowerLabel containsString:@"validity end"]) notAfter = TSDisplayDate(propertyValue);
        // SecCertificateCopyValues returns keys as the certificate's OID strings.
        [oids addObject:oid];
    }
    [oids sortUsingSelector:@selector(compare:)];

    CFStringRef summaryRef = SecCertificateCopySubjectSummary(certificate);
    NSString *subject = summaryRef ? CFBridgingRelease(summaryRef) : @"";
    unsigned char digest[CC_SHA256_DIGEST_LENGTH] = {0};
    if (der.length) CC_SHA256(der.bytes, (CC_LONG)der.length, digest);

    return @{
        @"label": subject.length ? subject : NSLocalizedString(@"Unnamed Certificate", nil),
        @"subject": subject ?: @"",
        @"issuer": issuer.length ? issuer : NSLocalizedString(@"Unavailable", nil),
        @"notBefore": notBefore.length ? notBefore : NSLocalizedString(@"Unavailable", nil),
        @"notAfter": notAfter.length ? notAfter : NSLocalizedString(@"Unavailable", nil),
        @"oids": oids,
        @"sha256": TSHexString(digest, sizeof(digest)),
        @"certificateDER": der ?: [NSData data]
    };
}

static NSMutableArray<NSDictionary *> *TSMutableCredentialRecords(void) {
    NSArray *saved = [trollStoreUserDefaults() arrayForKey:TSSigningCredentialsDefaultsKey];
    NSMutableArray *records = [NSMutableArray array];
    for (id item in saved) if ([item isKindOfClass:NSDictionary.class]) [records addObject:[item mutableCopy]];
    return records;
}

static NSString *TSCredentialFolder(NSString *identifier) {
    return [[TSSigningManager signingDirectoryPath] stringByAppendingPathComponent:identifier];
}

static BOOL TSWriteProtectedData(NSData *data, NSString *path, NSError **error) {
    NSFileManager *fm = NSFileManager.defaultManager;
    NSString *parent = path.stringByDeletingLastPathComponent;
    if (![fm createDirectoryAtPath:parent withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0700} error:error]) return NO;
    BOOL written = [data writeToFile:path options:NSDataWritingFileProtectionCompleteUntilFirstUserAuthentication | NSDataWritingAtomic error:error];
    if (written) chmod(path.fileSystemRepresentation, 0600);
    return written;
}

static BOOL TSKeychainStore(NSData *data, NSString *account, NSError **error) {
    NSDictionary *query = @{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: TSSigningKeychainService,
        (__bridge id)kSecAttrAccount: account
    };
    SecItemDelete((__bridge CFDictionaryRef)query);
    NSMutableDictionary *item = [query mutableCopy];
    item[(__bridge id)kSecValueData] = data;
    item[(__bridge id)kSecAttrAccessible] = (__bridge id)kSecAttrAccessibleWhenUnlockedThisDeviceOnly;
    OSStatus status = SecItemAdd((__bridge CFDictionaryRef)item, NULL);
    if (status == errSecSuccess) return YES;
    if (error) *error = TSSigningError(status, [NSString stringWithFormat:@"Could not store signing material in Keychain (OSStatus %d).", (int)status]);
    return NO;
}

static NSData *TSKeychainCopy(NSString *account, NSError **error) {
    NSDictionary *query = @{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: TSSigningKeychainService,
        (__bridge id)kSecAttrAccount: account,
        (__bridge id)kSecReturnData: @YES,
        (__bridge id)kSecMatchLimit: (__bridge id)kSecMatchLimitOne
    };
    CFTypeRef result = NULL;
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, &result);
    if (status == errSecSuccess && result) return CFBridgingRelease(result);
    if (error) *error = TSSigningError(status, [NSString stringWithFormat:@"Could not read signing material from Keychain (OSStatus %d).", (int)status]);
    return nil;
}

static void TSKeychainDelete(NSString *account) {
    NSDictionary *query = @{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: TSSigningKeychainService,
        (__bridge id)kSecAttrAccount: account
    };
    SecItemDelete((__bridge CFDictionaryRef)query);
}

static NSData *TSDERFromPEM(NSData *pemData) {
    NSString *text = [[NSString alloc] initWithData:pemData encoding:NSASCIIStringEncoding];
    if (!text) return nil;
    NSRange begin = [text rangeOfString:@"-----BEGIN CERTIFICATE-----"];
    NSRange end = [text rangeOfString:@"-----END CERTIFICATE-----" options:0 range:NSMakeRange(begin.location == NSNotFound ? 0 : NSMaxRange(begin), begin.location == NSNotFound ? text.length : text.length - NSMaxRange(begin))];
    if (begin.location == NSNotFound || end.location == NSNotFound || end.location <= begin.location) return nil;
    NSString *base64 = [text substringWithRange:NSMakeRange(NSMaxRange(begin), end.location - NSMaxRange(begin))];
    NSMutableString *compact = [NSMutableString string];
    for (NSUInteger index = 0; index < base64.length; index++) {
        unichar c = [base64 characterAtIndex:index];
        if (![[NSCharacterSet whitespaceAndNewlineCharacterSet] characterIsMember:c]) [compact appendFormat:@"%C", c];
    }
    return [[NSData alloc] initWithBase64EncodedString:compact options:0];
}

@implementation TSSigningManager

+ (NSString *)signingDirectoryPath {
    NSString *support = [NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES) firstObject];
    return [support stringByAppendingPathComponent:@"TSSigning"];
}

+ (NSArray<NSDictionary *> *)credentialRecords { return [TSMutableCredentialRecords() copy]; }

+ (NSDictionary *)credentialRecordForIdentifier:(NSString *)identifier {
    if (!identifier.length) return nil;
    for (NSDictionary *record in [self credentialRecords]) if ([record[@"id"] isEqualToString:identifier]) return record;
    return nil;
}

+ (NSString *)defaultCredentialIdentifier { return [trollStoreUserDefaults() stringForKey:@"TSSigningDefaultCredentialID"]; }
+ (void)setDefaultCredentialIdentifier:(NSString *)identifier {
    if (identifier.length) [trollStoreUserDefaults() setObject:identifier forKey:@"TSSigningDefaultCredentialID"];
    else [trollStoreUserDefaults() removeObjectForKey:@"TSSigningDefaultCredentialID"];
}
+ (NSString *)signingMode {
    NSString *mode = [trollStoreUserDefaults() stringForKey:@"TSSigningMode"];
    return ([mode isEqualToString:@"real"] || [mode isEqualToString:@"troll"]) ? mode : @"troll";
}
+ (void)setSigningMode:(NSString *)mode { [trollStoreUserDefaults() setObject:[mode isEqualToString:@"real"] ? @"real" : @"troll" forKey:@"TSSigningMode"]; }
+ (NSString *)selectedTemplateForMode:(NSString *)mode {
    NSString *key = [mode isEqualToString:@"real"] ? @"TSSigningRealTemplate" : @"TSSigningTrollTemplate";
    NSString *value = [trollStoreUserDefaults() stringForKey:key];
    return value.length ? value : ([mode isEqualToString:@"real"] ? @"app-store-managed" : @"trollstore-default");
}
+ (void)setSelectedTemplate:(NSString *)templateName forMode:(NSString *)mode {
    if (!templateName.length) return;
    NSString *key = [mode isEqualToString:@"real"] ? @"TSSigningRealTemplate" : @"TSSigningTrollTemplate";
    [trollStoreUserDefaults() setObject:templateName forKey:key];
}

+ (NSArray<NSDictionary *> *)templateDefinitionsForMode:(NSString *)mode {
    if ([mode isEqualToString:@"real"]) return @[
        @{@"id":@"app-store-managed", @"title":NSLocalizedString(@"App Store", nil), @"jobs":@8, @"hashType":@"sha256"},
        @{@"id":@"app-store-connect", @"title":NSLocalizedString(@"App Store Connect", nil), @"jobs":@8, @"hashType":@"sha256"},
        @{@"id":@"testflight", @"title":NSLocalizedString(@"TestFlight", nil), @"jobs":@4, @"hashType":@"sha256"},
        @{@"id":@"development", @"title":NSLocalizedString(@"Apple Development", nil), @"jobs":@4, @"hashType":@"sha256"},
        @{@"id":@"developer-distribution", @"title":NSLocalizedString(@"Developer Distribution", nil), @"jobs":@8, @"hashType":@"sha256"},
        @{@"id":@"ad-hoc", @"title":NSLocalizedString(@"Ad Hoc", nil), @"jobs":@2, @"hashType":@"sha256"},
        @{@"id":@"enterprise", @"title":NSLocalizedString(@"Enterprise / In-House", nil), @"jobs":@4, @"hashType":@"sha256"}
    ];
    return @[
        @{@"id":@"trollstore-default", @"title":NSLocalizedString(@"TrollStore Default", nil), @"jobs":@4, @"hashType":@"sha256"},
        @{@"id":@"trollstore-fast", @"title":NSLocalizedString(@"TrollStore Fast", nil), @"jobs":@8, @"hashType":@"sha256"},
        @{@"id":@"trollstore-compatible", @"title":NSLocalizedString(@"TrollStore Compatibility", nil), @"jobs":@1, @"hashType":@"sha256"}
    ];
}

+ (NSDictionary *)certificateDetailsForCredentialIdentifier:(NSString *)identifier {
    NSDictionary *record = [self credentialRecordForIdentifier:identifier];
    if (!record) return nil;
    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    for (NSString *key in @[@"issuer", @"notBefore", @"notAfter", @"oids", @"sha256", @"subject", @"label"]) if (record[key]) details[key] = record[key];
    return details;
}

+ (BOOL)importPKCS12Data:(NSData *)data fileName:(NSString *)fileName password:(NSString *)password error:(NSError **)error {
    if (data.length == 0) { if (error) *error = TSSigningError(1, NSLocalizedString(@"The selected P12 file is empty.", nil)); return NO; }
    CFArrayRef importedRaw = NULL;
    NSDictionary *options = @{(__bridge id)kSecImportExportPassphrase:password ?: @""};
    OSStatus status = SecPKCS12Import((__bridge CFDataRef)data, (__bridge CFDictionaryRef)options, &importedRaw);
    if (status != errSecSuccess || !importedRaw) {
        if (error) *error = TSSigningError(status, NSLocalizedString(@"Could not import the P12 identity. Check the password and file integrity.", nil));
        return NO;
    }
    NSArray *items = CFBridgingRelease(importedRaw);
    NSDictionary *first = items.firstObject;
    SecIdentityRef identity = (__bridge SecIdentityRef)first[(__bridge id)kSecImportItemIdentity];
    SecCertificateRef certificate = NULL;
    if (!identity || SecIdentityCopyCertificate(identity, &certificate) != errSecSuccess || !certificate) {
        if (certificate) CFRelease(certificate);
        if (error) *error = TSSigningError(2, NSLocalizedString(@"The P12 file does not contain a usable certificate/private-key identity.", nil));
        return NO;
    }
    NSData *certificateDER = nil;
    NSDictionary *metadata = TSMetadataForCertificate(certificate, &certificateDER);
    CFRelease(certificate);

    NSString *identifier = NSUUID.UUID.UUIDString;
    if (!TSKeychainStore(data, [identifier stringByAppendingString:@".identity"], error) ||
        !TSKeychainStore([password dataUsingEncoding:NSUTF8StringEncoding] ?: [NSData data], [identifier stringByAppendingString:@".password"], error)) {
        TSKeychainDelete([identifier stringByAppendingString:@".identity"]);
        return NO;
    }
    NSString *folder = TSCredentialFolder(identifier);
    NSString *certPath = [folder stringByAppendingPathComponent:@"certificate.der"];
    if (!TSWriteProtectedData(certificateDER, certPath, error)) {
        TSKeychainDelete([identifier stringByAppendingString:@".identity"]);
        TSKeychainDelete([identifier stringByAppendingString:@".password"]);
        return NO;
    }
    NSMutableDictionary *record = [metadata mutableCopy];
    [record removeObjectForKey:@"certificateDER"];
    record[@"id"] = identifier; record[@"format"] = @"p12"; record[@"fileName"] = fileName ?: @"identity.p12"; record[@"certificatePath"] = certPath;
    NSMutableArray *records = TSMutableCredentialRecords();
    [records addObject:record];
    [trollStoreUserDefaults() setObject:records forKey:TSSigningCredentialsDefaultsKey];
    if ([self defaultCredentialIdentifier].length == 0) [self setDefaultCredentialIdentifier:identifier];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TSSigningConfigurationChanged" object:nil];
    return YES;
}

+ (BOOL)importPEMCertificateData:(NSData *)certificateData privateKeyData:(NSData *)privateKeyData fileName:(NSString *)fileName password:(NSString *)password error:(NSError **)error {
    NSData *der = TSDERFromPEM(certificateData);
    if (!der) der = certificateData;
    SecCertificateRef certificate = SecCertificateCreateWithData(NULL, (__bridge CFDataRef)der);
    if (!certificate || privateKeyData.length == 0) {
        if (certificate) CFRelease(certificate);
        if (error) *error = TSSigningError(3, NSLocalizedString(@"The PEM certificate or private-key file is invalid.", nil));
        return NO;
    }
    NSDictionary *metadata = TSMetadataForCertificate(certificate, &der);
    CFRelease(certificate);
    NSString *identifier = NSUUID.UUID.UUIDString;
    if (!TSKeychainStore(privateKeyData, [identifier stringByAppendingString:@".identity"], error) ||
        !TSKeychainStore([password dataUsingEncoding:NSUTF8StringEncoding] ?: [NSData data], [identifier stringByAppendingString:@".password"], error)) {
        TSKeychainDelete([identifier stringByAppendingString:@".identity"]);
        return NO;
    }
    NSString *folder = TSCredentialFolder(identifier);
    NSString *certPath = [folder stringByAppendingPathComponent:@"certificate.pem"];
    if (!TSWriteProtectedData(certificateData, certPath, error)) {
        TSKeychainDelete([identifier stringByAppendingString:@".identity"]);
        TSKeychainDelete([identifier stringByAppendingString:@".password"]);
        return NO;
    }
    NSString *derPath = [folder stringByAppendingPathComponent:@"certificate.der"];
    if (!TSWriteProtectedData(der, derPath, error)) {
        TSKeychainDelete([identifier stringByAppendingString:@".identity"]);
        TSKeychainDelete([identifier stringByAppendingString:@".password"]);
        [[NSFileManager defaultManager] removeItemAtPath:folder error:nil];
        return NO;
    }
    NSMutableDictionary *record = [metadata mutableCopy];
    [record removeObjectForKey:@"certificateDER"];
    record[@"id"] = identifier; record[@"format"] = @"pem"; record[@"fileName"] = fileName ?: @"certificate.pem"; record[@"certificatePath"] = certPath;
    NSMutableArray *records = TSMutableCredentialRecords();
    [records addObject:record];
    [trollStoreUserDefaults() setObject:records forKey:TSSigningCredentialsDefaultsKey];
    if ([self defaultCredentialIdentifier].length == 0) [self setDefaultCredentialIdentifier:identifier];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TSSigningConfigurationChanged" object:nil];
    return YES;
}

+ (BOOL)importProvisioningProfileData:(NSData *)data forCredentialIdentifier:(NSString *)identifier fileName:(NSString *)fileName error:(NSError **)error {
    if (data.length == 0 || ![self credentialRecordForIdentifier:identifier]) { if (error) *error = TSSigningError(4, NSLocalizedString(@"Select a certificate before importing a provisioning profile.", nil)); return NO; }
    NSString *path = [TSCredentialFolder(identifier) stringByAppendingPathComponent:@"embedded.mobileprovision"];
    if (!TSWriteProtectedData(data, path, error)) return NO;
    NSMutableArray *records = TSMutableCredentialRecords();
    for (NSMutableDictionary *record in records) if ([record[@"id"] isEqualToString:identifier]) { record[@"profilePath"] = path; record[@"profileFileName"] = fileName ?: @"embedded.mobileprovision"; }
    [trollStoreUserDefaults() setObject:records forKey:TSSigningCredentialsDefaultsKey];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TSSigningConfigurationChanged" object:nil];
    return YES;
}

+ (void)deleteCredentialWithIdentifier:(NSString *)identifier {
    if (!identifier.length) return;
    TSKeychainDelete([identifier stringByAppendingString:@".identity"]);
    TSKeychainDelete([identifier stringByAppendingString:@".password"]);
    [[NSFileManager defaultManager] removeItemAtPath:TSCredentialFolder(identifier) error:nil];
    NSMutableArray *records = TSMutableCredentialRecords();
    NSIndexSet *matches = [records indexesOfObjectsPassingTest:^BOOL(NSDictionary *record, NSUInteger idx, BOOL *stop) { return [record[@"id"] isEqualToString:identifier]; }];
    [records removeObjectsAtIndexes:matches];
    [trollStoreUserDefaults() setObject:records forKey:TSSigningCredentialsDefaultsKey];
    if ([[self defaultCredentialIdentifier] isEqualToString:identifier]) [self setDefaultCredentialIdentifier:records.firstObject[@"id"]];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TSSigningConfigurationChanged" object:nil];
}

+ (NSString *)prepareRootHelperSigningConfiguration:(NSError **)error {
    NSString *mode = [self signingMode];
#ifdef TROLLSTORE_LITE
    if ([mode isEqualToString:@"real"]) { if (error) *error = TSSigningError(190, NSLocalizedString(@"Real signing is not available in TrollStore Lite builds.", nil)); return nil; }
#endif
    NSString *templateName = [self selectedTemplateForMode:mode];
    NSDictionary *template = nil;
    for (NSDictionary *candidate in [self templateDefinitionsForMode:mode]) if ([candidate[@"id"] isEqualToString:templateName]) { template = candidate; break; }
    if (!template) { if (error) *error = TSSigningError(5, NSLocalizedString(@"The selected signing template is unavailable.", nil)); return nil; }
    NSString *ldidConfigPath = nil;

    NSString *runtime = [[self signingDirectoryPath] stringByAppendingPathComponent:@"Runtime"];
    if (![[NSFileManager defaultManager] createDirectoryAtPath:runtime withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0700} error:error]) return nil;
    chmod(runtime.fileSystemRepresentation, 0700);
    NSString *uuid = NSUUID.UUID.UUIDString;
    NSMutableArray<NSString *> *temporaryFiles = [NSMutableArray array];
    NSMutableDictionary *configuration = [@{
        @"mode":mode,
        @"templateName":templateName,
        @"profileName":templateName,
        @"temporaryFiles":temporaryFiles
    } mutableCopy];

    if ([mode isEqualToString:@"real"]) {
        NSString *identifier = [self defaultCredentialIdentifier];
        NSDictionary *record = [self credentialRecordForIdentifier:identifier];
        if (!record) { if (error) *error = TSSigningError(190, NSLocalizedString(@"Real signing requires an imported P12 identity or PEM certificate/private-key pair. Import one in Signing Settings first.", nil)); return nil; }
        NSError *secretError = nil;
        NSData *identityData = TSKeychainCopy([identifier stringByAppendingString:@".identity"], &secretError);
        NSData *passwordData = TSKeychainCopy([identifier stringByAppendingString:@".password"], &secretError);
        if (!identityData) { if (error) *error = secretError ?: TSSigningError(6, NSLocalizedString(@"The selected signing identity is unavailable in Keychain.", nil)); return nil; }
        NSString *password = [[NSString alloc] initWithData:passwordData ?: [NSData data] encoding:NSUTF8StringEncoding] ?: @"";
        NSString *credentialPath = [runtime stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.%@", uuid, [record[@"format"] isEqualToString:@"pem"] ? @"key.pem" : @"p12"]];
        if (!TSWriteProtectedData(identityData, credentialPath, error)) return nil;
        [temporaryFiles addObject:credentialPath];
        configuration[@"credentialFormat"] = record[@"format"] ?: @"p12";
        configuration[@"credentialPath"] = credentialPath;
        configuration[@"password"] = password;
        configuration[@"certificatePath"] = record[@"certificatePath"] ?: @"";
        if ([record[@"format"] isEqualToString:@"pem"]) configuration[@"privateKeyPath"] = credentialPath;
        NSString *profilePath = record[@"profilePath"];
        if ([profilePath isKindOfClass:NSString.class] && profilePath.length) configuration[@"provisioningProfilePath"] = profilePath;
        configuration[@"hasProvisioningProfile"] = @([profilePath isKindOfClass:NSString.class] && profilePath.length > 0);
        configuration[@"credentialIdentifier"] = identifier;
    } else {
        configuration[@"credentialFormat"] = @"adhoc";
        configuration[@"hasProvisioningProfile"] = @YES;
    }

    // Build an ldidrc file using the exact option names supported by the 2026-10-30 ldid.
    // Identity material is referenced by short-lived protected paths; it is never put in preferences.
    NSMutableDictionary *ldidProfile = [@{
        @"adhoc": @(![mode isEqualToString:@"real"]),
        @"preserveEntitlements": @YES,
        @"mergeDeep": @YES,
        @"deep": @NO,
        @"superDeep": @NO,
        @"hashType": template[@"hashType"] ?: @"sha256",
        @"jobs": template[@"jobs"] ?: @4,
        @"verifyChain": @NO,
        @"verifyChainRoot": @NO
    } mutableCopy];
    if ([mode isEqualToString:@"real"]) {
        if ([configuration[@"credentialFormat"] isEqualToString:@"p12"]) {
            ldidProfile[@"p12"] = configuration[@"credentialPath"];
        } else {
            ldidProfile[@"certificate"] = configuration[@"certificatePath"];
            ldidProfile[@"privateKey"] = configuration[@"privateKeyPath"];
        }
        ldidProfile[@"password"] = configuration[@"password"] ?: @"";
    }
    // ldidrc profiles control real signing behavior (identity, CMS/ad-hoc mode,
    // hash type, entitlement policy and parallelism). The UI's distribution label
    // is descriptive only; certificate/profile evidence determines actual identity.
    NSDictionary *ldidRoot = @{
        @"defaults": @{ @"hashType": @"sha256", @"preserveEntitlements": @YES, @"mergeDeep": @YES },
        @"profiles": @{ templateName: ldidProfile }
    };
    NSData *ldidJSON = [NSJSONSerialization dataWithJSONObject:ldidRoot options:NSJSONWritingPrettyPrinted error:error];
    if (!ldidJSON) { for (NSString *path in temporaryFiles) [[NSFileManager defaultManager] removeItemAtPath:path error:nil]; return nil; }
    NSString *ldidConfigPath = [runtime stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.ldid.json", uuid]];
    if (!TSWriteProtectedData(ldidJSON, ldidConfigPath, error)) { for (NSString *path in temporaryFiles) [[NSFileManager defaultManager] removeItemAtPath:path error:nil]; return nil; }
    [temporaryFiles addObject:ldidConfigPath];
    configuration[@"ldidConfigPath"] = ldidConfigPath;
    configuration[@"profileName"] = templateName;

    NSString *configPath = [runtime stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.plist", uuid]];
    NSData *plist = [NSPropertyListSerialization dataWithPropertyList:configuration format:NSPropertyListXMLFormat_v1_0 options:0 error:error];
    if (!plist || !TSWriteProtectedData(plist, configPath, error)) {
        for (NSString *path in temporaryFiles) [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
        return nil;
    }
    chmod(configPath.fileSystemRepresentation, 0600);
    return configPath;
}

+ (void)cleanupRootHelperSigningConfiguration:(NSString *)configurationPath {
    if (!configurationPath.length) return;
    NSDictionary *configuration = [NSDictionary dictionaryWithContentsOfFile:configurationPath];
    for (NSString *path in configuration[@"temporaryFiles"]) if ([path isKindOfClass:NSString.class]) [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
    [[NSFileManager defaultManager] removeItemAtPath:configurationPath error:nil];
}

@end
