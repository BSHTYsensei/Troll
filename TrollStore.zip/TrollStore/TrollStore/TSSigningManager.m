#import "TSSigningManager.h"
#import <Security/Security.h>
#import <CommonCrypto/CommonDigest.h>
#import <sys/stat.h>
#import <fcntl.h>
#import <unistd.h>
#import <stdint.h>
#import <ctype.h>

extern NSUserDefaults *trollStoreUserDefaults(void);

static NSString * const TSSigningErrorDomain = @"com.opa334.TrollStore.Signing";
static NSString * const TSSigningCredentialsDefaultsKey = @"TSSigningCredentials";
static NSString * const TSSigningKeychainService = @"com.opa334.TrollStore.SigningIdentity";

static NSData *TSDERFromPEM(NSData *pemData);

static NSError *TSSigningError(NSInteger code, NSString *message) {
    return [NSError errorWithDomain:TSSigningErrorDomain code:code userInfo:@{NSLocalizedDescriptionKey: message ?: NSLocalizedString(@"Signing configuration failed.", nil)}];
}

static NSString *TSHexString(const unsigned char *bytes, NSUInteger length) {
    NSMutableString *result = [NSMutableString stringWithCapacity:length * 2];
    for (NSUInteger index = 0; index < length; index++) [result appendFormat:@"%02x", bytes[index]];
    return result;
}

typedef struct {
    const uint8_t *bytes;
    NSUInteger length;
    NSUInteger offset;
} TSDERReader;

typedef struct {
    uint8_t tag;
    const uint8_t *bytes;
    NSUInteger length;
} TSDERTLV;

static BOOL TSReadDERTLV(TSDERReader *reader, TSDERTLV *tlv) {
    if (!reader || !tlv || reader->offset >= reader->length) return NO;

    const uint8_t *bytes = reader->bytes;
    uint8_t tag = bytes[reader->offset++];
    if ((tag & 0x1f) == 0x1f) return NO; // High-tag-number form is not used by X.509 fields we inspect.
    if (reader->offset >= reader->length) return NO;

    uint8_t firstLength = bytes[reader->offset++];
    NSUInteger valueLength = 0;
    if ((firstLength & 0x80) == 0) {
        valueLength = firstLength;
    } else {
        NSUInteger lengthBytes = firstLength & 0x7f;
        if (lengthBytes == 0 || lengthBytes > sizeof(NSUInteger) || lengthBytes > reader->length - reader->offset) return NO;
        if (bytes[reader->offset] == 0) return NO; // DER lengths must be minimally encoded.
        for (NSUInteger index = 0; index < lengthBytes; index++) {
            uint8_t component = bytes[reader->offset++];
            if (valueLength > (NSUIntegerMax - component) / 256) return NO;
            valueLength = valueLength * 256 + component;
        }
        if (valueLength < 128) return NO;
    }

    if (valueLength > reader->length - reader->offset) return NO;
    tlv->tag = tag;
    tlv->bytes = bytes + reader->offset;
    tlv->length = valueLength;
    reader->offset += valueLength;
    return YES;
}

static NSString *TSOIDStringFromDER(const uint8_t *bytes, NSUInteger length) {
    if (!bytes || length == 0) return nil;
    NSMutableArray<NSNumber *> *components = [NSMutableArray array];
    uint64_t value = 0;
    BOOL componentOpen = NO;
    for (NSUInteger index = 0; index < length; index++) {
        uint8_t byte = bytes[index];
        if (value > (UINT64_MAX >> 7)) return nil;
        value = (value << 7) | (uint64_t)(byte & 0x7f);
        componentOpen = YES;
        if ((byte & 0x80) == 0) {
            [components addObject:@(value)];
            value = 0;
            componentOpen = NO;
        }
    }
    if (componentOpen || components.count == 0) return nil;

    uint64_t firstCombined = components.firstObject.unsignedLongLongValue;
    uint64_t firstArc = firstCombined < 40 ? 0 : (firstCombined < 80 ? 1 : 2);
    uint64_t secondArc = firstCombined - firstArc * 40;
    NSMutableString *oid = [NSMutableString stringWithFormat:@"%llu.%llu", (unsigned long long)firstArc, (unsigned long long)secondArc];
    for (NSUInteger index = 1; index < components.count; index++) {
        [oid appendFormat:@".%llu", (unsigned long long)components[index].unsignedLongLongValue];
    }
    return oid;
}

static BOOL TSCollectDEROIDs(const uint8_t *bytes, NSUInteger length, NSMutableSet<NSString *> *oids, NSUInteger depth) {
    if (!bytes || depth > 24) return NO;
    TSDERReader reader = { bytes, length, 0 };
    while (reader.offset < reader.length) {
        TSDERTLV item = {0};
        if (!TSReadDERTLV(&reader, &item)) return NO;
        if (item.tag == 0x06) {
            NSString *oid = TSOIDStringFromDER(item.bytes, item.length);
            if (oid.length) [oids addObject:oid];
        } else if ((item.tag & 0x20) != 0) {
            if (!TSCollectDEROIDs(item.bytes, item.length, oids, depth + 1)) return NO;
        }
    }
    return YES;
}

static NSString *TSX509NameAttributeLabel(NSString *oid) {
    static NSDictionary<NSString *, NSString *> *labels;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        labels = @{
            @"2.5.4.3": @"CN", @"2.5.4.6": @"C", @"2.5.4.7": @"L",
            @"2.5.4.8": @"ST", @"2.5.4.10": @"O", @"2.5.4.11": @"OU",
            @"2.5.4.5": @"serialNumber", @"2.5.4.9": @"street",
            @"2.5.4.17": @"postalCode", @"1.2.840.113549.1.9.1": @"emailAddress",
            @"0.9.2342.19200300.100.1.25": @"DC", @"0.9.2342.19200300.100.1.1": @"UID"
        };
    });
    return labels[oid] ?: oid;
}

static NSString *TSStringFromDERString(const TSDERTLV *value) {
    if (!value || !value->bytes || value->length == 0) return @"";
    NSString *result = nil;
    switch (value->tag) {
        case 0x0c: result = [[NSString alloc] initWithBytes:value->bytes length:value->length encoding:NSUTF8StringEncoding]; break; // UTF8String
        case 0x12: // NumericString
        case 0x13: // PrintableString
        case 0x16: result = [[NSString alloc] initWithBytes:value->bytes length:value->length encoding:NSASCIIStringEncoding]; break; // IA5String
        case 0x14: result = [[NSString alloc] initWithBytes:value->bytes length:value->length encoding:NSISOLatin1StringEncoding]; break; // T61String
        case 0x1e:
            if ((value->length & 1) == 0) result = [[NSString alloc] initWithBytes:value->bytes length:value->length encoding:NSUTF16BigEndianStringEncoding];
            break;
        case 0x1c:
            if ((value->length & 3) == 0) result = [[NSString alloc] initWithBytes:value->bytes length:value->length encoding:NSUTF32BigEndianStringEncoding];
            break;
        default: break;
    }
    if (result.length) return [result stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    return [NSString stringWithFormat:@"0x%@", TSHexString(value->bytes, value->length)];
}

static NSString *TSIssuerFromDERName(const TSDERTLV *name) {
    if (!name || name->tag != 0x30) return @"";
    TSDERReader rdns = { name->bytes, name->length, 0 };
    NSMutableArray<NSString *> *attributes = [NSMutableArray array];
    while (rdns.offset < rdns.length) {
        TSDERTLV set = {0};
        if (!TSReadDERTLV(&rdns, &set) || set.tag != 0x31) return @"";
        TSDERReader members = { set.bytes, set.length, 0 };
        while (members.offset < members.length) {
            TSDERTLV sequence = {0};
            if (!TSReadDERTLV(&members, &sequence) || sequence.tag != 0x30) return @"";
            TSDERReader pair = { sequence.bytes, sequence.length, 0 };
            TSDERTLV oidTLV = {0}, valueTLV = {0};
            if (!TSReadDERTLV(&pair, &oidTLV) || oidTLV.tag != 0x06 || !TSReadDERTLV(&pair, &valueTLV)) continue;
            NSString *oid = TSOIDStringFromDER(oidTLV.bytes, oidTLV.length);
            NSString *label = TSX509NameAttributeLabel(oid ?: @"OID");
            NSString *value = TSStringFromDERString(&valueTLV);
            if (value.length) [attributes addObject:[NSString stringWithFormat:@"%@=%@", label, value]];
        }
    }
    return [attributes componentsJoinedByString:@", "];
}

static NSUInteger TSDecimalValue(const uint8_t *bytes, NSUInteger length) {
    NSUInteger value = 0;
    for (NSUInteger index = 0; index < length; index++) {
        if (!isdigit((unsigned char)bytes[index])) return NSNotFound;
        value = value * 10 + (NSUInteger)(bytes[index] - '0');
    }
    return value;
}

static NSDate *TSDateFromASN1Time(const TSDERTLV *timeTLV) {
    if (!timeTLV || (timeTLV->tag != 0x17 && timeTLV->tag != 0x18) || timeTLV->length == 0) return nil;
    BOOL generalized = timeTLV->tag == 0x18;
    NSUInteger digitCount = 0;
    while (digitCount < timeTLV->length && isdigit((unsigned char)timeTLV->bytes[digitCount])) digitCount++;
    NSUInteger minimumDigits = generalized ? 14 : 10;
    if (digitCount < minimumDigits) return nil;

    NSUInteger year = 0, cursor = 0;
    if (generalized) {
        year = TSDecimalValue(timeTLV->bytes, 4);
        if (year == NSNotFound || year < 1 || year > 9999) return nil;
        cursor = 4;
    } else {
        NSUInteger shortYear = TSDecimalValue(timeTLV->bytes, 2);
        if (shortYear == NSNotFound) return nil;
        year = shortYear >= 50 ? 1900 + shortYear : 2000 + shortYear;
        cursor = 2;
    }
    NSUInteger month = TSDecimalValue(timeTLV->bytes + cursor, 2); cursor += 2;
    NSUInteger day = TSDecimalValue(timeTLV->bytes + cursor, 2); cursor += 2;
    NSUInteger hour = TSDecimalValue(timeTLV->bytes + cursor, 2); cursor += 2;
    NSUInteger minute = TSDecimalValue(timeTLV->bytes + cursor, 2); cursor += 2;
    NSUInteger second = 0;
    if (generalized || digitCount >= cursor + 2) { second = TSDecimalValue(timeTLV->bytes + cursor, 2); cursor += 2; }
    if (month == NSNotFound || day == NSNotFound || hour == NSNotFound || minute == NSNotFound || second == NSNotFound || month < 1 || month > 12 || day < 1 || day > 31 || hour > 23 || minute > 59 || second > 60) return nil;

    NSTimeInterval fraction = 0;
    NSUInteger suffix = digitCount;
    if (suffix < timeTLV->length && (timeTLV->bytes[suffix] == '.' || timeTLV->bytes[suffix] == ',')) {
        suffix++;
        NSUInteger fractionStart = suffix;
        double place = 0.1;
        while (suffix < timeTLV->length && isdigit((unsigned char)timeTLV->bytes[suffix])) {
            fraction += (double)(timeTLV->bytes[suffix] - '0') * place;
            place *= 0.1;
            suffix++;
        }
        if (suffix == fractionStart) return nil;
    }

    NSInteger timezoneOffset = 0;
    if (suffix < timeTLV->length && timeTLV->bytes[suffix] == 'Z') {
        suffix++;
    } else if (suffix < timeTLV->length && (timeTLV->bytes[suffix] == '+' || timeTLV->bytes[suffix] == '-')) {
        int sign = timeTLV->bytes[suffix++] == '+' ? 1 : -1;
        if (timeTLV->length - suffix != 4) return nil;
        NSUInteger offsetHour = TSDecimalValue(timeTLV->bytes + suffix, 2);
        NSUInteger offsetMinute = TSDecimalValue(timeTLV->bytes + suffix + 2, 2);
        if (offsetHour == NSNotFound || offsetMinute == NSNotFound || offsetHour > 23 || offsetMinute > 59) return nil;
        timezoneOffset = sign * (NSInteger)(offsetHour * 3600 + offsetMinute * 60);
        suffix += 4;
    }
    if (suffix != timeTLV->length) return nil;

    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    calendar.timeZone = [NSTimeZone timeZoneForSecondsFromGMT:0];
    NSDateComponents *components = [NSDateComponents new];
    components.year = (NSInteger)year;
    components.month = (NSInteger)month;
    components.day = (NSInteger)day;
    components.hour = (NSInteger)hour;
    components.minute = (NSInteger)minute;
    components.second = (NSInteger)MIN(second, 59);
    NSDate *date = [calendar dateFromComponents:components];
    if (!date) return nil;
    return [date dateByAddingTimeInterval:(fraction - timezoneOffset)];
}

static NSString *TSDisplayDate(NSDate *date) {
    if (![date isKindOfClass:NSDate.class]) return NSLocalizedString(@"Unavailable", nil);
    NSDateFormatter *formatter = [NSDateFormatter new];
    formatter.locale = [NSLocale localeWithLocaleIdentifier:@"en_US_POSIX"];
    formatter.timeZone = NSTimeZone.localTimeZone;
    formatter.dateFormat = @"yyyy-MM-dd HH:mm:ss z";
    return [formatter stringFromDate:date] ?: NSLocalizedString(@"Unavailable", nil);
}

static void TSCollectX509ExtensionOIDs(const TSDERTLV *tbs, NSMutableSet<NSString *> *oids) {
    if (!tbs || tbs->tag != 0x30 || !oids) return;
    TSDERReader fields = { tbs->bytes, tbs->length, 0 };
    while (fields.offset < fields.length) {
        TSDERTLV field = {0};
        if (!TSReadDERTLV(&fields, &field)) return;
        if (field.tag != 0xa3) continue; // [3] EXPLICIT Extensions

        TSDERReader explicitValue = { field.bytes, field.length, 0 };
        TSDERTLV extensions = {0};
        if (!TSReadDERTLV(&explicitValue, &extensions) || extensions.tag != 0x30) return;
        TSDERReader extensionList = { extensions.bytes, extensions.length, 0 };
        while (extensionList.offset < extensionList.length) {
            TSDERTLV extension = {0};
            if (!TSReadDERTLV(&extensionList, &extension) || extension.tag != 0x30) return;
            TSDERReader extensionFields = { extension.bytes, extension.length, 0 };
            TSDERTLV oid = {0};
            if (!TSReadDERTLV(&extensionFields, &oid) || oid.tag != 0x06) continue;
            NSString *oidString = TSOIDStringFromDER(oid.bytes, oid.length);
            if (oidString.length) [oids addObject:oidString];

            TSDERTLV next = {0};
            if (!TSReadDERTLV(&extensionFields, &next)) continue;
            if (next.tag == 0x01) { // Optional critical BOOLEAN.
                if (!TSReadDERTLV(&extensionFields, &next)) continue;
            }
            if (next.tag == 0x04) {
                // extnValue is itself DER-encoded per RFC 5280. Parse only this
                // known wrapper rather than treating arbitrary OCTET STRINGs as DER.
                TSCollectDEROIDs(next.bytes, next.length, oids, 0);
            }
        }
    }
}

static BOOL TSCertificateFieldsFromDER(NSData *der, NSString **issuerOut, NSDate **notBeforeOut, NSDate **notAfterOut, NSArray<NSString *> **oidsOut) {
    if (issuerOut) *issuerOut = @"";
    if (notBeforeOut) *notBeforeOut = nil;
    if (notAfterOut) *notAfterOut = nil;
    if (oidsOut) *oidsOut = @[];
    if (![der isKindOfClass:NSData.class] || der.length == 0) return NO;

    TSDERReader root = { der.bytes, der.length, 0 };
    TSDERTLV certificate = {0};
    if (!TSReadDERTLV(&root, &certificate) || certificate.tag != 0x30 || root.offset != root.length) return NO;

    NSMutableSet<NSString *> *oidSet = [NSMutableSet set];
    BOOL oidScanOK = TSCollectDEROIDs(certificate.bytes, certificate.length, oidSet, 0);
    if (oidsOut && oidScanOK) *oidsOut = [[oidSet allObjects] sortedArrayUsingSelector:@selector(compare:)];

    TSDERReader certificateReader = { certificate.bytes, certificate.length, 0 };
    TSDERTLV tbs = {0};
    if (!TSReadDERTLV(&certificateReader, &tbs) || tbs.tag != 0x30) return NO;
    TSCollectX509ExtensionOIDs(&tbs, oidSet);
    if (oidsOut) *oidsOut = [[oidSet allObjects] sortedArrayUsingSelector:@selector(compare:)];

    TSDERReader fields = { tbs.bytes, tbs.length, 0 };
    TSDERTLV item = {0};
    if (!TSReadDERTLV(&fields, &item)) return NO;
    if (item.tag == 0xa0) { // Optional explicit version.
        if (!TSReadDERTLV(&fields, &item)) return NO;
    }
    if (item.tag != 0x02) return NO; // serialNumber
    TSDERTLV signature = {0}, issuer = {0}, validity = {0};
    if (!TSReadDERTLV(&fields, &signature) || signature.tag != 0x30 ||
        !TSReadDERTLV(&fields, &issuer) || issuer.tag != 0x30 ||
        !TSReadDERTLV(&fields, &validity) || validity.tag != 0x30) return NO;

    if (issuerOut) *issuerOut = TSIssuerFromDERName(&issuer);
    TSDERReader validityReader = { validity.bytes, validity.length, 0 };
    TSDERTLV before = {0}, after = {0};
    if (TSReadDERTLV(&validityReader, &before) && TSReadDERTLV(&validityReader, &after)) {
        if (notBeforeOut) *notBeforeOut = TSDateFromASN1Time(&before);
        if (notAfterOut) *notAfterOut = TSDateFromASN1Time(&after);
    }
    return YES;
}

static NSDictionary *TSMetadataForCertificate(SecCertificateRef certificate, NSData **certificateDEROut) {
    if (!certificate) return @{};
    // SecCertificateCopyValues is macOS-only. On iOS, read the public DER
    // representation and decode the RFC 5280 fields needed by the identity UI.
    CFDataRef copiedData = SecCertificateCopyData(certificate);
    NSData *der = copiedData ? CFBridgingRelease(copiedData) : [NSData data];
    if (certificateDEROut) *certificateDEROut = der;

    NSString *issuer = @"";
    NSDate *notBeforeDate = nil;
    NSDate *notAfterDate = nil;
    NSArray<NSString *> *oids = @[];
    TSCertificateFieldsFromDER(der, &issuer, &notBeforeDate, &notAfterDate, &oids);

    CFStringRef summaryRef = SecCertificateCopySubjectSummary(certificate);
    NSString *subject = summaryRef ? CFBridgingRelease(summaryRef) : @"";
    unsigned char digest[CC_SHA256_DIGEST_LENGTH] = {0};
    if (der.length) CC_SHA256(der.bytes, (CC_LONG)der.length, digest);

    return @{
        @"label": subject.length ? subject : NSLocalizedString(@"Unnamed Certificate", nil),
        @"subject": subject ?: @"",
        @"issuer": issuer.length ? issuer : NSLocalizedString(@"Unavailable", nil),
        @"notBefore": TSDisplayDate(notBeforeDate),
        @"notAfter": TSDisplayDate(notAfterDate),
        @"oids": oids ?: @[],
        @"sha256": TSHexString(digest, sizeof(digest)),
        @"certificateDER": der ?: [NSData data]
    };
}

// Provisioning profiles are CMS SignedData containers whose encapsulated content
// is an XML/binary property list. CMSDecoder is not part of the iOS SDK, so extract the
// encapsulated OCTET STRING using the DER reader above. This parses the container;
// it deliberately does not claim to verify the CMS signature or Apple's trust chain.
static BOOL TSReadExpectedDERTLV(TSDERReader *reader, uint8_t expectedTag, TSDERTLV *tlv) {
    return TSReadDERTLV(reader, tlv) && tlv->tag == expectedTag;
}

static BOOL TSAppendCMSOctetString(TSDERTLV node, NSMutableData *output, NSUInteger depth) {
    if (!output || depth > 16) return NO;
    if (node.tag == 0x04) {
        [output appendBytes:node.bytes length:node.length];
        return YES;
    }
    // BER permits a constructed OCTET STRING. Apple provisioning profiles are
    // normally DER encoded, but accepting nested constructed segments is cheap.
    if (node.tag != 0x24) return NO;
    TSDERReader children = { node.bytes, node.length, 0 };
    while (children.offset < children.length) {
        TSDERTLV child = {0};
        if (!TSReadDERTLV(&children, &child) || !TSAppendCMSOctetString(child, output, depth + 1)) return NO;
    }
    return output.length > 0;
}

static NSData *TSExtractProvisioningProfileCMSContent(NSData *data, NSUInteger *signerCountOut) {
    if (signerCountOut) *signerCountOut = 0;
    if (!data.length) return nil;

    static const uint8_t signedDataOID[] = { 0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x07, 0x02 };
    static const uint8_t dataContentOID[] = { 0x2a, 0x86, 0x48, 0x86, 0xf7, 0x0d, 0x01, 0x07, 0x01 };
    TSDERReader outer = { data.bytes, data.length, 0 };
    TSDERTLV contentInfo = {0};
    if (!TSReadExpectedDERTLV(&outer, 0x30, &contentInfo) || outer.offset != outer.length) return nil;

    TSDERReader contentInfoReader = { contentInfo.bytes, contentInfo.length, 0 };
    TSDERTLV contentType = {0}, signedDataWrapper = {0};
    if (!TSReadExpectedDERTLV(&contentInfoReader, 0x06, &contentType) ||
        contentType.length != sizeof(signedDataOID) || memcmp(contentType.bytes, signedDataOID, sizeof(signedDataOID)) != 0 ||
        !TSReadExpectedDERTLV(&contentInfoReader, 0xA0, &signedDataWrapper) || contentInfoReader.offset != contentInfoReader.length) return nil;

    TSDERReader explicitSignedData = { signedDataWrapper.bytes, signedDataWrapper.length, 0 };
    TSDERTLV signedDataSequence = {0};
    if (!TSReadExpectedDERTLV(&explicitSignedData, 0x30, &signedDataSequence) || explicitSignedData.offset != explicitSignedData.length) return nil;

    TSDERReader signedData = { signedDataSequence.bytes, signedDataSequence.length, 0 };
    TSDERTLV version = {0}, digestAlgorithms = {0}, encapContentInfo = {0};
    if (!TSReadExpectedDERTLV(&signedData, 0x02, &version) ||
        !TSReadExpectedDERTLV(&signedData, 0x31, &digestAlgorithms) ||
        !TSReadExpectedDERTLV(&signedData, 0x30, &encapContentInfo)) return nil;

    TSDERReader encapsulated = { encapContentInfo.bytes, encapContentInfo.length, 0 };
    TSDERTLV encapsulatedType = {0}, eContentWrapper = {0};
    if (!TSReadExpectedDERTLV(&encapsulated, 0x06, &encapsulatedType) ||
        encapsulatedType.length != sizeof(dataContentOID) || memcmp(encapsulatedType.bytes, dataContentOID, sizeof(dataContentOID)) != 0 ||
        !TSReadExpectedDERTLV(&encapsulated, 0xA0, &eContentWrapper) || encapsulated.offset != encapsulated.length) return nil;

    TSDERReader explicitContent = { eContentWrapper.bytes, eContentWrapper.length, 0 };
    NSMutableData *content = [NSMutableData data];
    while (explicitContent.offset < explicitContent.length) {
        TSDERTLV octetNode = {0};
        if (!TSReadDERTLV(&explicitContent, &octetNode) || !TSAppendCMSOctetString(octetNode, content, 0)) return nil;
    }
    if (!content.length) return nil;

    // The signerInfos SET follows optional certificates and CRLs in SignedData.
    // Count entries for display only; cryptographic signature/trust evaluation is
    // intentionally left to Apple's provisioning/install services.
    NSUInteger signerCount = 0;
    while (signedData.offset < signedData.length) {
        TSDERTLV optionalField = {0};
        if (!TSReadDERTLV(&signedData, &optionalField)) return nil;
        if (optionalField.tag == 0x31) {
            TSDERReader signerInfos = { optionalField.bytes, optionalField.length, 0 };
            while (signerInfos.offset < signerInfos.length) {
                TSDERTLV signerInfo = {0};
                if (!TSReadDERTLV(&signerInfos, &signerInfo) || signerInfo.tag != 0x30) return nil;
                signerCount++;
            }
        }
    }
    if (signerCount == 0) return nil; // provisioning profiles must carry at least one CMS signer
    if (signerCountOut) *signerCountOut = signerCount;
    return content;
}

static NSDictionary *TSDecodeProvisioningProfile(NSData *data, NSUInteger *signerCountOut, NSError **error) {
    if (signerCountOut) *signerCountOut = 0;
    if (![data isKindOfClass:NSData.class] || data.length == 0) {
        if (error) *error = TSSigningError(7, NSLocalizedString(@"The provisioning profile is empty.", nil));
        return nil;
    }

    NSData *content = TSExtractProvisioningProfileCMSContent(data, signerCountOut);
    if (!content) {
        if (error) *error = TSSigningError(8, NSLocalizedString(@"The selected file is not a valid CMS-wrapped Apple provisioning profile.", nil));
        return nil;
    }
    NSError *contentError = nil;
    id parsed = [NSPropertyListSerialization propertyListWithData:content options:NSPropertyListImmutable format:nil error:&contentError];
    if ([parsed isKindOfClass:NSDictionary.class] && [parsed[@"Entitlements"] isKindOfClass:NSDictionary.class]) {
        return parsed;
    }
    if (error) {
        *error = TSSigningError(8, [NSString stringWithFormat:NSLocalizedString(@"The provisioning profile content is not a valid property list: %@", nil), contentError.localizedDescription ?: @"missing Entitlements dictionary"]);
    }
    return nil;
}

static NSMutableArray<NSDictionary *> *TSMutableCredentialRecords(void) {
    NSArray *saved = [trollStoreUserDefaults() arrayForKey:TSSigningCredentialsDefaultsKey];
    NSMutableArray *records = [NSMutableArray array];
    for (id item in saved) if ([item isKindOfClass:NSDictionary.class]) [records addObject:[item mutableCopy]];
    return records;
}

static NSString *TSCredentialFolder(NSString *identifier) {
    return [[TSSigningManager signingDirectoryPath] stringByAppendingPathComponent:identifier];
}

static NSData *TSCertificateDERForCredentialRecord(NSDictionary *record) {
    NSString *derPath = [record[@"certificateDERPath"] isKindOfClass:NSString.class] ? record[@"certificateDERPath"] : nil;
    NSString *certificatePath = [record[@"certificatePath"] isKindOfClass:NSString.class] ? record[@"certificatePath"] : nil;
    NSData *data = derPath.length ? [NSData dataWithContentsOfFile:derPath] : nil;
    if (!data.length && certificatePath.length) data = [NSData dataWithContentsOfFile:certificatePath];
    if (data.length && [certificatePath.pathExtension.lowercaseString isEqualToString:@"pem"]) {
        NSData *decoded = TSDERFromPEM(data);
        if (decoded.length) data = decoded;
    }
    if (data.length && [data rangeOfData:[NSData dataWithBytes:"-----BEGIN CERTIFICATE-----" length:27] options:0 range:NSMakeRange(0, data.length)].location != NSNotFound) {
        NSData *decoded = TSDERFromPEM(data);
        if (decoded.length) data = decoded;
    }
    return data;
}

static NSString *TSProfileDistributionType(NSDictionary *profile) {
    NSDictionary *entitlements = [profile[@"Entitlements"] isKindOfClass:NSDictionary.class] ? profile[@"Entitlements"] : @{};
    BOOL getTaskAllow = [entitlements[@"get-task-allow"] respondsToSelector:@selector(boolValue)] && [entitlements[@"get-task-allow"] boolValue];
    BOOL allDevices = [profile[@"ProvisionsAllDevices"] respondsToSelector:@selector(boolValue)] && [profile[@"ProvisionsAllDevices"] boolValue];
    NSUInteger deviceCount = [profile[@"ProvisionedDevices"] isKindOfClass:NSArray.class] ? [profile[@"ProvisionedDevices"] count] : 0;
    if (allDevices) return NSLocalizedString(@"Enterprise / In-House", nil);
    if (getTaskAllow) return NSLocalizedString(@"Development", nil);
    if (deviceCount) return NSLocalizedString(@"Ad Hoc", nil);
    return NSLocalizedString(@"App Store Distribution", nil);
}

static NSDictionary *TSProfileDetailsFromDictionary(NSDictionary *profile, NSDictionary *credentialRecord, NSUInteger cmsSignerCount) {
    NSDictionary *entitlements = [profile[@"Entitlements"] isKindOfClass:NSDictionary.class] ? profile[@"Entitlements"] : @{};
    NSData *selectedDER = TSCertificateDERForCredentialRecord(credentialRecord);
    NSArray *rawCertificates = [profile[@"DeveloperCertificates"] isKindOfClass:NSArray.class] ? profile[@"DeveloperCertificates"] : @[];
    NSMutableArray<NSDictionary *> *certificateDetails = [NSMutableArray array];
    BOOL selectedCertificateMatches = NO;

    for (id certificateData in rawCertificates) {
        if (![certificateData isKindOfClass:NSData.class] || [certificateData length] == 0) continue;
        SecCertificateRef certificate = SecCertificateCreateWithData(NULL, (__bridge CFDataRef)certificateData);
        if (!certificate) continue;
        NSData *canonicalDER = nil;
        NSDictionary *metadata = TSMetadataForCertificate(certificate, &canonicalDER);
        CFRelease(certificate);
        BOOL matches = selectedDER.length && [canonicalDER isEqualToData:selectedDER];
        selectedCertificateMatches = selectedCertificateMatches || matches;
        NSMutableDictionary *summary = [metadata mutableCopy];
        [summary removeObjectForKey:@"certificateDER"];
        summary[@"matchesImportedIdentity"] = @(matches);
        [certificateDetails addObject:summary];
    }

    NSDate *creationDate = [profile[@"CreationDate"] isKindOfClass:NSDate.class] ? profile[@"CreationDate"] : nil;
    NSDate *expirationDate = [profile[@"ExpirationDate"] isKindOfClass:NSDate.class] ? profile[@"ExpirationDate"] : nil;
    NSArray *teams = [profile[@"TeamIdentifier"] isKindOfClass:NSArray.class] ? profile[@"TeamIdentifier"] : @[];
    NSArray *prefixes = [profile[@"ApplicationIdentifierPrefix"] isKindOfClass:NSArray.class] ? profile[@"ApplicationIdentifierPrefix"] : @[];
    NSArray *platforms = [profile[@"Platform"] isKindOfClass:NSArray.class] ? profile[@"Platform"] : @[];
    NSArray *devices = [profile[@"ProvisionedDevices"] isKindOfClass:NSArray.class] ? profile[@"ProvisionedDevices"] : @[];
    NSString *appIdentifier = [entitlements[@"application-identifier"] isKindOfClass:NSString.class] ? entitlements[@"application-identifier"] : @"";
    BOOL allDevices = [profile[@"ProvisionsAllDevices"] respondsToSelector:@selector(boolValue)] && [profile[@"ProvisionsAllDevices"] boolValue];
    BOOL getTaskAllow = [entitlements[@"get-task-allow"] respondsToSelector:@selector(boolValue)] && [entitlements[@"get-task-allow"] boolValue];
    BOOL expired = expirationDate ? ([expirationDate compare:NSDate.date] != NSOrderedDescending) : NO;

    return @{
        @"name": [profile[@"Name"] isKindOfClass:NSString.class] ? profile[@"Name"] : NSLocalizedString(@"Unnamed Provisioning Profile", nil),
        @"uuid": [profile[@"UUID"] isKindOfClass:NSString.class] ? profile[@"UUID"] : @"",
        @"teamName": [profile[@"TeamName"] isKindOfClass:NSString.class] ? profile[@"TeamName"] : @"",
        @"teamIdentifier": teams.firstObject ?: @"",
        @"applicationIdentifierPrefix": prefixes.firstObject ?: @"",
        @"applicationIdentifier": appIdentifier,
        @"creationDate": TSDisplayDate(creationDate),
        @"expirationDate": TSDisplayDate(expirationDate),
        @"expired": @(expired),
        @"profileType": TSProfileDistributionType(profile),
        @"platform": [platforms componentsJoinedByString:@", "],
        @"provisionsAllDevices": @(allDevices),
        @"provisionedDeviceCount": @(devices.count),
        @"getTaskAllow": @(getTaskAllow),
        @"isXcodeManaged": @([profile[@"IsXcodeManaged"] respondsToSelector:@selector(boolValue)] && [profile[@"IsXcodeManaged"] boolValue]),
        @"entitlements": entitlements,
        @"developerCertificates": certificateDetails,
        @"developerCertificateCount": @(certificateDetails.count),
        @"certificateMatch": @(selectedCertificateMatches),
        @"hasSelectedCertificateData": @(selectedDER.length > 0),
        @"cmsSignerCount": @(cmsSignerCount),
        @"appleInternalProfile": @([profile[@"AppleInternalProfile"] respondsToSelector:@selector(boolValue)] && [profile[@"AppleInternalProfile"] boolValue]),
        @"hasDEREncodedProfile": @(profile[@"DER-Encoded-Profile"] != nil),
        @"appIDName": [profile[@"AppIDName"] isKindOfClass:NSString.class] ? profile[@"AppIDName"] : @""
    };
}

static BOOL TSWriteProtectedData(NSData *data, NSString *path, NSError **error) {
    NSFileManager *fm = NSFileManager.defaultManager;
    NSString *parent = path.stringByDeletingLastPathComponent;
    if (![fm createDirectoryAtPath:parent withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0700} error:error]) return NO;
    BOOL written = [data writeToFile:path options:NSDataWritingFileProtectionCompleteUntilFirstUserAuthentication | NSDataWritingAtomic error:error];
    if (written) chmod(path.fileSystemRepresentation, 0600);
    return written;
}

static BOOL TSKeychainStore(NSData *data, NSString *account, NSError **error) {
    NSDictionary *query = @{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: TSSigningKeychainService,
        (__bridge id)kSecAttrAccount: account
    };
    SecItemDelete((__bridge CFDictionaryRef)query);
    NSMutableDictionary *item = [query mutableCopy];
    item[(__bridge id)kSecValueData] = data;
    item[(__bridge id)kSecAttrAccessible] = (__bridge id)kSecAttrAccessibleWhenUnlockedThisDeviceOnly;
    OSStatus status = SecItemAdd((__bridge CFDictionaryRef)item, NULL);
    if (status == errSecSuccess) return YES;
    if (error) *error = TSSigningError(status, [NSString stringWithFormat:@"Could not store signing material in Keychain (OSStatus %d).", (int)status]);
    return NO;
}

static NSData *TSKeychainCopy(NSString *account, NSError **error) {
    NSDictionary *query = @{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: TSSigningKeychainService,
        (__bridge id)kSecAttrAccount: account,
        (__bridge id)kSecReturnData: @YES,
        (__bridge id)kSecMatchLimit: (__bridge id)kSecMatchLimitOne
    };
    CFTypeRef result = NULL;
    OSStatus status = SecItemCopyMatching((__bridge CFDictionaryRef)query, &result);
    if (status == errSecSuccess && result) return CFBridgingRelease(result);
    if (error) *error = TSSigningError(status, [NSString stringWithFormat:@"Could not read signing material from Keychain (OSStatus %d).", (int)status]);
    return nil;
}

static void TSKeychainDelete(NSString *account) {
    NSDictionary *query = @{
        (__bridge id)kSecClass: (__bridge id)kSecClassGenericPassword,
        (__bridge id)kSecAttrService: TSSigningKeychainService,
        (__bridge id)kSecAttrAccount: account
    };
    SecItemDelete((__bridge CFDictionaryRef)query);
}

static NSData *TSDERFromPEM(NSData *pemData) {
    NSString *text = [[NSString alloc] initWithData:pemData encoding:NSASCIIStringEncoding];
    if (!text) return nil;
    NSRange begin = [text rangeOfString:@"-----BEGIN CERTIFICATE-----"];
    NSRange end = [text rangeOfString:@"-----END CERTIFICATE-----" options:0 range:NSMakeRange(begin.location == NSNotFound ? 0 : NSMaxRange(begin), begin.location == NSNotFound ? text.length : text.length - NSMaxRange(begin))];
    if (begin.location == NSNotFound || end.location == NSNotFound || end.location <= begin.location) return nil;
    NSString *base64 = [text substringWithRange:NSMakeRange(NSMaxRange(begin), end.location - NSMaxRange(begin))];
    NSMutableString *compact = [NSMutableString string];
    for (NSUInteger index = 0; index < base64.length; index++) {
        unichar c = [base64 characterAtIndex:index];
        if (![[NSCharacterSet whitespaceAndNewlineCharacterSet] characterIsMember:c]) [compact appendFormat:@"%C", c];
    }
    return [[NSData alloc] initWithBase64EncodedString:compact options:0];
}

@implementation TSSigningManager

+ (NSString *)signingDirectoryPath {
    NSString *support = [NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES) firstObject];
    return [support stringByAppendingPathComponent:@"TSSigning"];
}

+ (NSArray<NSDictionary *> *)credentialRecords { return [TSMutableCredentialRecords() copy]; }

+ (NSDictionary *)credentialRecordForIdentifier:(NSString *)identifier {
    if (!identifier.length) return nil;
    for (NSDictionary *record in [self credentialRecords]) if ([record[@"id"] isEqualToString:identifier]) return record;
    return nil;
}

+ (NSString *)defaultCredentialIdentifier { return [trollStoreUserDefaults() stringForKey:@"TSSigningDefaultCredentialID"]; }
+ (void)setDefaultCredentialIdentifier:(NSString *)identifier {
    if (identifier.length) [trollStoreUserDefaults() setObject:identifier forKey:@"TSSigningDefaultCredentialID"];
    else [trollStoreUserDefaults() removeObjectForKey:@"TSSigningDefaultCredentialID"];
}
+ (NSString *)signingMode {
    NSString *mode = [trollStoreUserDefaults() stringForKey:@"TSSigningMode"];
    return ([mode isEqualToString:@"real"] || [mode isEqualToString:@"troll"]) ? mode : @"troll";
}
+ (void)setSigningMode:(NSString *)mode {
    BOOL real = [mode isEqualToString:@"real"];
    [trollStoreUserDefaults() setObject:real ? @"real" : @"troll" forKey:@"TSSigningMode"];
    if (!real) [trollStoreUserDefaults() removeObjectForKey:@"TSSigningTrollTemplate"];
}
+ (NSString *)selectedTemplateForMode:(NSString *)mode {
    // TrollStore signing is always ad-hoc and has one internal default profile.
    // Never consult the legacy user-selectable TrollStore template preference.
    if (![mode isEqualToString:@"real"]) {
        [trollStoreUserDefaults() removeObjectForKey:@"TSSigningTrollTemplate"];
        return @"trollstore-default";
    }
    NSString *value = [trollStoreUserDefaults() stringForKey:@"TSSigningRealTemplate"];
    return value.length ? value : @"app-store-managed";
}
+ (void)setSelectedTemplate:(NSString *)templateName forMode:(NSString *)mode {
    if (![mode isEqualToString:@"real"]) {
        [trollStoreUserDefaults() removeObjectForKey:@"TSSigningTrollTemplate"];
        return;
    }
    if (!templateName.length) return;
    [trollStoreUserDefaults() setObject:templateName forKey:@"TSSigningRealTemplate"];
}

+ (NSArray<NSDictionary *> *)templateDefinitionsForMode:(NSString *)mode {
    if ([mode isEqualToString:@"real"]) return @[
        @{@"id":@"app-store-managed", @"title":NSLocalizedString(@"App Store", nil), @"jobs":@8, @"hashType":@"sha256", @"profileRequired":@YES, @"profileType":NSLocalizedString(@"App Store Connect distribution profile", nil), @"description":NSLocalizedString(@"For App Store release signing. A matching App Store Connect distribution provisioning profile is required for the Apple distribution workflow. This preset only selects SHA-256 and up to eight ldid jobs; it does not create the certificate, profile, App Store Connect record, review approval or distribution authorization.", nil)},
        @{@"id":@"app-store-connect", @"title":NSLocalizedString(@"App Store Connect", nil), @"jobs":@8, @"hashType":@"sha256", @"profileRequired":@YES, @"profileType":NSLocalizedString(@"App Store Connect distribution profile", nil), @"description":NSLocalizedString(@"For uploads to App Store Connect. A matching App Store Connect distribution provisioning profile and Apple Distribution identity are required for the Apple signing workflow. Selecting this ldid preset alone grants no upload or distribution permissions.", nil)},
        @{@"id":@"testflight", @"title":NSLocalizedString(@"TestFlight", nil), @"jobs":@4, @"hashType":@"sha256", @"profileRequired":@YES, @"profileType":NSLocalizedString(@"App Store Connect distribution profile", nil), @"description":NSLocalizedString(@"For TestFlight builds delivered through App Store Connect. Use the matching App Store Connect distribution provisioning profile and Apple Distribution identity. TestFlight processing and acceptance are controlled by Apple, not by this template.", nil)},
        @{@"id":@"development", @"title":NSLocalizedString(@"Apple Development", nil), @"jobs":@4, @"hashType":@"sha256", @"profileRequired":@YES, @"profileType":NSLocalizedString(@"iOS App Development profile (registered devices)", nil), @"description":NSLocalizedString(@"For on-device development and debugging. A matching iOS App Development provisioning profile is required and normally contains the devices registered to the developer team. The imported identity and profile must permit the requested entitlements; this template does not add debug entitlements automatically.", nil)},
        @{@"id":@"developer-distribution", @"title":NSLocalizedString(@"Developer Distribution", nil), @"jobs":@8, @"hashType":@"sha256", @"profileRequired":@YES, @"profileType":NSLocalizedString(@"App Store Connect distribution profile", nil), @"description":NSLocalizedString(@"For Apple distribution signing through App Store Connect. A valid Apple Distribution identity and matching App Store Connect distribution provisioning profile are required. This option does not perform certificate-chain or notarization checks.", nil)},
        @{@"id":@"ad-hoc", @"title":NSLocalizedString(@"Ad Hoc", nil), @"jobs":@2, @"hashType":@"sha256", @"profileRequired":@YES, @"profileType":NSLocalizedString(@"Ad Hoc distribution profile (target device UDIDs)", nil), @"description":NSLocalizedString(@"For Ad Hoc distribution to registered devices. A matching Ad Hoc provisioning profile is required and must include every target device UDID, the App ID and the signing certificate. The two-job limit reduces peak resource use; it does not bypass provisioning restrictions.", nil)},
        @{@"id":@"enterprise", @"title":NSLocalizedString(@"Enterprise / In-House", nil), @"jobs":@4, @"hashType":@"sha256", @"profileRequired":@YES, @"profileType":NSLocalizedString(@"In-House distribution profile", nil), @"description":NSLocalizedString(@"For organization-authorized In-House distribution. A matching In-House provisioning profile and Apple Developer Enterprise Program distribution identity are required. Enterprise profiles are not limited to a list of registered test-device UDIDs; organizational distribution rules still apply.", nil)},
        @{@"id":@"apple-internal-profile", @"title":NSLocalizedString(@"Apple Internal Development", nil), @"jobs":@1, @"hashType":@"sha256", @"profileRequired":@YES, @"appleInternal":@YES, @"profileType":NSLocalizedString(@"Apple-issued Apple Internal profile (AppleInternalProfile=true)", nil), @"description":NSLocalizedString(@"Special-purpose Apple internal signing policy. Requires a genuine Apple-issued CMS-signed provisioning profile containing the boolean AppleInternalProfile=true. The profile must be current, list the selected certificate in DeveloperCertificates, match the app Team ID and application identifier, and authorize the requested Entitlements. This is not a normal public Apple Development profile, and an ordinary profile cannot be converted by editing its plist because doing so invalidates its CMS signature. Every .appex must carry its own matching Apple Internal profile. The policy additionally checks CMS mathematics, the configured signer certificate chain to a trusted root, and post-signing signer/profile consistency; it does not create Apple-internal credentials or grant platform trust on public devices.", nil), @"caveat":NSLocalizedString(@"Apple Internal signing requires a real Apple-issued internal provisioning profile and matching certificate/private key. The profile must contain AppleInternalProfile=true, be unexpired, include the selected DER certificate in DeveloperCertificates, and have TeamIdentifier plus Entitlements.application-identifier. The internal signing certificate chain must validate to a trusted root. Every app extension must already contain its own matching Apple Internal profile. Public Apple Developer accounts normally cannot issue this profile; a regular Development profile or a manually edited plist is not a substitute.", nil)}
    ];
    // There is deliberately no user-selectable template for TrollStore mode.
    // Its internal signing profile is fixed below in prepareRootHelperSigningConfiguration.
    return @[];
}

+ (NSDictionary *)certificateDetailsForCredentialIdentifier:(NSString *)identifier {
    NSDictionary *record = [self credentialRecordForIdentifier:identifier];
    if (!record) return nil;
    NSMutableDictionary *details = [NSMutableDictionary dictionary];
    for (NSString *key in @[@"issuer", @"notBefore", @"notAfter", @"oids", @"sha256", @"subject", @"label"]) if (record[key]) details[key] = record[key];
    return details;
}

+ (BOOL)importPKCS12Data:(NSData *)data fileName:(NSString *)fileName password:(NSString *)password error:(NSError **)error {
    if (data.length == 0) { if (error) *error = TSSigningError(1, NSLocalizedString(@"The selected P12 file is empty.", nil)); return NO; }
    CFArrayRef importedRaw = NULL;
    NSDictionary *options = @{(__bridge id)kSecImportExportPassphrase:password ?: @""};
    OSStatus status = SecPKCS12Import((__bridge CFDataRef)data, (__bridge CFDictionaryRef)options, &importedRaw);
    if (status != errSecSuccess || !importedRaw) {
        if (error) *error = TSSigningError(status, NSLocalizedString(@"Could not import the P12 identity. Check the password and file integrity.", nil));
        return NO;
    }
    NSArray *items = CFBridgingRelease(importedRaw);
    NSDictionary *first = items.firstObject;
    SecIdentityRef identity = (__bridge SecIdentityRef)first[(__bridge id)kSecImportItemIdentity];
    SecCertificateRef certificate = NULL;
    if (!identity || SecIdentityCopyCertificate(identity, &certificate) != errSecSuccess || !certificate) {
        if (certificate) CFRelease(certificate);
        if (error) *error = TSSigningError(2, NSLocalizedString(@"The P12 file does not contain a usable certificate/private-key identity.", nil));
        return NO;
    }
    NSData *certificateDER = nil;
    NSDictionary *metadata = TSMetadataForCertificate(certificate, &certificateDER);
    CFRelease(certificate);

    NSString *identifier = NSUUID.UUID.UUIDString;
    if (!TSKeychainStore(data, [identifier stringByAppendingString:@".identity"], error) ||
        !TSKeychainStore([password dataUsingEncoding:NSUTF8StringEncoding] ?: [NSData data], [identifier stringByAppendingString:@".password"], error)) {
        TSKeychainDelete([identifier stringByAppendingString:@".identity"]);
        return NO;
    }
    NSString *folder = TSCredentialFolder(identifier);
    NSString *certPath = [folder stringByAppendingPathComponent:@"certificate.der"];
    if (!TSWriteProtectedData(certificateDER, certPath, error)) {
        TSKeychainDelete([identifier stringByAppendingString:@".identity"]);
        TSKeychainDelete([identifier stringByAppendingString:@".password"]);
        return NO;
    }
    NSMutableDictionary *record = [metadata mutableCopy];
    [record removeObjectForKey:@"certificateDER"];
    record[@"id"] = identifier; record[@"format"] = @"p12"; record[@"fileName"] = fileName ?: @"identity.p12"; record[@"certificatePath"] = certPath;
    NSMutableArray *records = TSMutableCredentialRecords();
    [records addObject:record];
    [trollStoreUserDefaults() setObject:records forKey:TSSigningCredentialsDefaultsKey];
    if ([self defaultCredentialIdentifier].length == 0) [self setDefaultCredentialIdentifier:identifier];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TSSigningConfigurationChanged" object:nil];
    return YES;
}

+ (BOOL)importPEMCertificateData:(NSData *)certificateData privateKeyData:(NSData *)privateKeyData fileName:(NSString *)fileName password:(NSString *)password error:(NSError **)error {
    NSData *der = TSDERFromPEM(certificateData);
    if (!der) der = certificateData;
    SecCertificateRef certificate = SecCertificateCreateWithData(NULL, (__bridge CFDataRef)der);
    if (!certificate || privateKeyData.length == 0) {
        if (certificate) CFRelease(certificate);
        if (error) *error = TSSigningError(3, NSLocalizedString(@"The PEM certificate or private-key file is invalid.", nil));
        return NO;
    }
    NSDictionary *metadata = TSMetadataForCertificate(certificate, &der);
    CFRelease(certificate);
    NSString *identifier = NSUUID.UUID.UUIDString;
    if (!TSKeychainStore(privateKeyData, [identifier stringByAppendingString:@".identity"], error) ||
        !TSKeychainStore([password dataUsingEncoding:NSUTF8StringEncoding] ?: [NSData data], [identifier stringByAppendingString:@".password"], error)) {
        TSKeychainDelete([identifier stringByAppendingString:@".identity"]);
        return NO;
    }
    NSString *folder = TSCredentialFolder(identifier);
    NSString *certPath = [folder stringByAppendingPathComponent:@"certificate.pem"];
    if (!TSWriteProtectedData(certificateData, certPath, error)) {
        TSKeychainDelete([identifier stringByAppendingString:@".identity"]);
        TSKeychainDelete([identifier stringByAppendingString:@".password"]);
        return NO;
    }
    NSString *derPath = [folder stringByAppendingPathComponent:@"certificate.der"];
    if (!TSWriteProtectedData(der, derPath, error)) {
        TSKeychainDelete([identifier stringByAppendingString:@".identity"]);
        TSKeychainDelete([identifier stringByAppendingString:@".password"]);
        [[NSFileManager defaultManager] removeItemAtPath:folder error:nil];
        return NO;
    }
    NSMutableDictionary *record = [metadata mutableCopy];
    [record removeObjectForKey:@"certificateDER"];
    record[@"id"] = identifier; record[@"format"] = @"pem"; record[@"fileName"] = fileName ?: @"certificate.pem"; record[@"certificatePath"] = certPath; record[@"certificateDERPath"] = derPath;
    NSMutableArray *records = TSMutableCredentialRecords();
    [records addObject:record];
    [trollStoreUserDefaults() setObject:records forKey:TSSigningCredentialsDefaultsKey];
    if ([self defaultCredentialIdentifier].length == 0) [self setDefaultCredentialIdentifier:identifier];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TSSigningConfigurationChanged" object:nil];
    return YES;
}

+ (BOOL)importProvisioningProfileData:(NSData *)data forCredentialIdentifier:(NSString *)identifier fileName:(NSString *)fileName error:(NSError **)error {
    NSDictionary *credential = [self credentialRecordForIdentifier:identifier];
    if (!data.length || !credential) { if (error) *error = TSSigningError(4, NSLocalizedString(@"Select a certificate before importing a provisioning profile.", nil)); return NO; }

    NSUInteger signerCount = 0;
    NSDictionary *profile = TSDecodeProvisioningProfile(data, &signerCount, error);
    if (!profile) return NO;
    NSString *path = [TSCredentialFolder(identifier) stringByAppendingPathComponent:@"embedded.mobileprovision"];
    if (!TSWriteProtectedData(data, path, error)) return NO;

    NSMutableArray *records = TSMutableCredentialRecords();
    for (NSMutableDictionary *record in records) {
        if (![record[@"id"] isEqualToString:identifier]) continue;
        record[@"profilePath"] = path;
        record[@"profileFileName"] = fileName ?: @"embedded.mobileprovision";
        record[@"profileName"] = [profile[@"Name"] isKindOfClass:NSString.class] ? profile[@"Name"] : @"";
        record[@"profileUUID"] = [profile[@"UUID"] isKindOfClass:NSString.class] ? profile[@"UUID"] : @"";
    }
    [trollStoreUserDefaults() setObject:records forKey:TSSigningCredentialsDefaultsKey];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TSSigningConfigurationChanged" object:nil];
    return YES;
}

+ (NSDictionary *)provisioningProfileDetailsForCredentialIdentifier:(NSString *)identifier {
    NSDictionary *record = [self credentialRecordForIdentifier:identifier];
    NSString *path = [record[@"profilePath"] isKindOfClass:NSString.class] ? record[@"profilePath"] : nil;
    if (!path.length) return nil;
    NSData *data = [NSData dataWithContentsOfFile:path];
    if (!data.length) return nil;
    NSUInteger signerCount = 0;
    NSError *decodeError = nil;
    NSDictionary *profile = TSDecodeProvisioningProfile(data, &signerCount, &decodeError);
    if (!profile) {
        NSLog(@"[Signing] could not decode stored provisioning profile %@: %@", path, decodeError);
        return nil;
    }
    return TSProfileDetailsFromDictionary(profile, record, signerCount);
}

+ (void)deleteCredentialWithIdentifier:(NSString *)identifier {
    if (!identifier.length) return;
    TSKeychainDelete([identifier stringByAppendingString:@".identity"]);
    TSKeychainDelete([identifier stringByAppendingString:@".password"]);
    [[NSFileManager defaultManager] removeItemAtPath:TSCredentialFolder(identifier) error:nil];
    NSMutableArray *records = TSMutableCredentialRecords();
    NSIndexSet *matches = [records indexesOfObjectsPassingTest:^BOOL(NSDictionary *record, NSUInteger idx, BOOL *stop) { return [record[@"id"] isEqualToString:identifier]; }];
    [records removeObjectsAtIndexes:matches];
    [trollStoreUserDefaults() setObject:records forKey:TSSigningCredentialsDefaultsKey];
    if ([[self defaultCredentialIdentifier] isEqualToString:identifier]) [self setDefaultCredentialIdentifier:records.firstObject[@"id"]];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TSSigningConfigurationChanged" object:nil];
}

+ (NSString *)prepareRootHelperSigningConfiguration:(NSError **)error {
    NSString *mode = [self signingMode];
#ifdef TROLLSTORE_LITE
    if ([mode isEqualToString:@"real"]) { if (error) *error = TSSigningError(190, NSLocalizedString(@"Real signing is not available in TrollStore Lite builds.", nil)); return nil; }
#endif
    BOOL realSigning = [mode isEqualToString:@"real"];
    NSString *templateName = realSigning ? [self selectedTemplateForMode:mode] : @"trollstore-default";
    NSDictionary *template = nil;
    if (realSigning) {
        for (NSDictionary *candidate in [self templateDefinitionsForMode:@"real"]) {
            if ([candidate[@"id"] isEqualToString:templateName]) { template = candidate; break; }
        }
        if (!template) { if (error) *error = TSSigningError(5, NSLocalizedString(@"The selected signing template is unavailable.", nil)); return nil; }
    } else {
        // Fixed internal TrollStore ad-hoc defaults: SHA-256 and four ldid workers.
        // These values are not exposed as a selectable signing template.
        template = @{@"id":@"trollstore-default", @"hashType":@"sha256", @"jobs":@4};
    }
    NSString *ldidConfigPath = nil;

    NSString *runtime = [[self signingDirectoryPath] stringByAppendingPathComponent:@"Runtime"];
    if (![[NSFileManager defaultManager] createDirectoryAtPath:runtime withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0700} error:error]) return nil;
    chmod(runtime.fileSystemRepresentation, 0700);
    NSString *uuid = NSUUID.UUID.UUIDString;
    NSMutableArray<NSString *> *temporaryFiles = [NSMutableArray array];
    NSMutableDictionary *configuration = [@{
        @"mode":mode,
        @"jobs":template[@"jobs"] ?: @1,
        @"templateName":templateName,
        @"profileName":templateName,
        @"temporaryFiles":temporaryFiles
    } mutableCopy];

    if ([mode isEqualToString:@"real"]) {
        NSString *identifier = [self defaultCredentialIdentifier];
        NSDictionary *record = [self credentialRecordForIdentifier:identifier];
        if (!record) { if (error) *error = TSSigningError(190, NSLocalizedString(@"Real signing requires an imported P12 identity or PEM certificate/private-key pair. Import one in Signing Settings first.", nil)); return nil; }
        NSError *secretError = nil;
        NSData *identityData = TSKeychainCopy([identifier stringByAppendingString:@".identity"], &secretError);
        NSData *passwordData = TSKeychainCopy([identifier stringByAppendingString:@".password"], &secretError);
        if (!identityData) { if (error) *error = secretError ?: TSSigningError(6, NSLocalizedString(@"The selected signing identity is unavailable in Keychain.", nil)); return nil; }
        NSString *password = [[NSString alloc] initWithData:passwordData ?: [NSData data] encoding:NSUTF8StringEncoding] ?: @"";
        NSString *credentialPath = [runtime stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.%@", uuid, [record[@"format"] isEqualToString:@"pem"] ? @"key.pem" : @"p12"]];
        if (!TSWriteProtectedData(identityData, credentialPath, error)) return nil;
        [temporaryFiles addObject:credentialPath];
        configuration[@"credentialFormat"] = record[@"format"] ?: @"p12";
        configuration[@"credentialPath"] = credentialPath;
        configuration[@"password"] = password;
        configuration[@"certificatePath"] = record[@"certificatePath"] ?: @"";
        if ([record[@"format"] isEqualToString:@"pem"]) configuration[@"privateKeyPath"] = credentialPath;
        NSString *profilePath = record[@"profilePath"];
        BOOL appleInternalTemplate = [templateName isEqualToString:@"apple-internal-profile"];
        if (appleInternalTemplate && (![profilePath isKindOfClass:NSString.class] || !profilePath.length || ![[NSFileManager defaultManager] fileExistsAtPath:profilePath])) {
            if (error) *error = TSSigningError(190, NSLocalizedString(@"Apple Internal Development requires a genuine Apple-issued .mobileprovision profile. A normal Apple Development profile is not sufficient.", nil));
            for (NSString *path in temporaryFiles) [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
            return nil;
        }
        if ([profilePath isKindOfClass:NSString.class] && profilePath.length) {
            NSDictionary *profileDetails = [self provisioningProfileDetailsForCredentialIdentifier:identifier];
            if (!profileDetails) {
                if (error) *error = TSSigningError(9, NSLocalizedString(@"The attached provisioning profile is unreadable or invalid. Re-import the profile for this certificate.", nil));
                for (NSString *path in temporaryFiles) [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
                return nil;
            }
            if ([profileDetails[@"expired"] boolValue]) {
                if (error) *error = TSSigningError(10, NSLocalizedString(@"The attached provisioning profile has expired. Import a current profile before Real Signing.", nil));
                for (NSString *path in temporaryFiles) [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
                return nil;
            }
            if (appleInternalTemplate) {
                BOOL internalMarker = [profileDetails[@"appleInternalProfile"] boolValue];
                BOOL hasCertificate = [profileDetails[@"hasSelectedCertificateData"] boolValue];
                BOOL certificateMatches = [profileDetails[@"certificateMatch"] boolValue];
                BOOL hasCMS = [profileDetails[@"cmsSignerCount"] unsignedIntegerValue] > 0;
                BOOL hasTeam = [profileDetails[@"teamIdentifier"] isKindOfClass:NSString.class] && [profileDetails[@"teamIdentifier"] length] > 0;
                BOOL hasAppID = [profileDetails[@"applicationIdentifier"] isKindOfClass:NSString.class] && [profileDetails[@"applicationIdentifier"] length] > 0;
                if (!internalMarker) {
                    if (error) *error = TSSigningError(190, NSLocalizedString(@"The selected profile is not an Apple Internal profile. This template requires the boolean AppleInternalProfile=true in an Apple-issued CMS-signed profile; a standard development profile cannot be converted.", nil));
                    for (NSString *path in temporaryFiles) [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
                    return nil;
                }
                if (!hasCertificate || !certificateMatches || ![profileDetails[@"developerCertificateCount"] unsignedIntegerValue]) {
                    if (error) *error = TSSigningError(190, NSLocalizedString(@"Apple Internal signing requires the selected identity's exact DER certificate in the profile DeveloperCertificates list.", nil));
                    for (NSString *path in temporaryFiles) [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
                    return nil;
                }
                if (!hasCMS) {
                    if (error) *error = TSSigningError(190, NSLocalizedString(@"Apple Internal signing requires a CMS-signed provisioning profile with at least one signer.", nil));
                    for (NSString *path in temporaryFiles) [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
                    return nil;
                }
                if (!hasTeam || !hasAppID) {
                    if (error) *error = TSSigningError(190, NSLocalizedString(@"Apple Internal signing requires TeamIdentifier and Entitlements.application-identifier in the profile.", nil));
                    for (NSString *path in temporaryFiles) [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
                    return nil;
                }
                NSString *bundledTemplatePath = [[NSBundle mainBundle] pathForResource:@"apple-internal-profile-template" ofType:@"json" inDirectory:@"SigningTemplates"];
                NSData *templateData = bundledTemplatePath.length ? [NSData dataWithContentsOfFile:bundledTemplatePath] : nil;
                if (!templateData.length) {
                    if (error) *error = TSSigningError(190, NSLocalizedString(@"Apple Internal signing template resource is missing from this TrollStore build.", nil));
                    for (NSString *path in temporaryFiles) [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
                    return nil;
                }
                NSString *runtimeTemplatePath = [runtime stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.apple-internal-template.json", uuid]];
                if (!TSWriteProtectedData(templateData, runtimeTemplatePath, error)) {
                    for (NSString *path in temporaryFiles) [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
                    return nil;
                }
                [temporaryFiles addObject:runtimeTemplatePath];
                configuration[@"customSignatureTemplatePath"] = runtimeTemplatePath;
                configuration[@"appleInternalProfileTemplate"] = @YES;
            }
            if ([profileDetails[@"hasSelectedCertificateData"] boolValue] && ![profileDetails[@"certificateMatch"] boolValue]) {
                if (error) *error = TSSigningError(11, NSLocalizedString(@"The attached provisioning profile does not contain the selected certificate. Attach a profile that includes this signing identity.", nil));
                for (NSString *path in temporaryFiles) [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
                return nil;
            }
            configuration[@"provisioningProfilePath"] = profilePath;
        }
        configuration[@"hasProvisioningProfile"] = @([profilePath isKindOfClass:NSString.class] && profilePath.length > 0);
        configuration[@"credentialIdentifier"] = identifier;
    } else {
        configuration[@"credentialFormat"] = @"adhoc";
        configuration[@"hasProvisioningProfile"] = @YES;
    }

    // Build an ldidrc file using the exact option names supported by the 2026-10-30 ldid.
    // Identity material is referenced by short-lived protected paths; it is never put in preferences.
    NSMutableDictionary *ldidProfile = [@{
        @"adhoc": @(![mode isEqualToString:@"real"]),
        @"preserveEntitlements": @YES,
        @"mergeDeep": @YES,
        @"deep": @NO,
        @"superDeep": @NO,
        @"hashType": template[@"hashType"] ?: @"sha256",
        @"jobs": template[@"jobs"] ?: @4,
        @"verifyChain": @NO,
        @"verifyChainRoot": @NO
    } mutableCopy];
    if ([mode isEqualToString:@"real"]) {
        if ([configuration[@"credentialFormat"] isEqualToString:@"p12"]) {
            ldidProfile[@"p12"] = configuration[@"credentialPath"];
        } else {
            ldidProfile[@"certificate"] = configuration[@"certificatePath"];
            ldidProfile[@"privateKey"] = configuration[@"privateKeyPath"];
        }
        ldidProfile[@"password"] = configuration[@"password"] ?: @"";
    }
    // ldidrc profiles control real signing behavior (identity, CMS/ad-hoc mode,
    // hash type, entitlement policy and parallelism). The UI's distribution label
    // is descriptive only; certificate/profile evidence determines actual identity.
    NSDictionary *ldidRoot = @{
        @"defaults": @{ @"hashType": @"sha256", @"preserveEntitlements": @YES, @"mergeDeep": @YES },
        @"profiles": @{ templateName: ldidProfile }
    };
    NSData *ldidJSON = [NSJSONSerialization dataWithJSONObject:ldidRoot options:NSJSONWritingPrettyPrinted error:error];
    if (!ldidJSON) { for (NSString *path in temporaryFiles) [[NSFileManager defaultManager] removeItemAtPath:path error:nil]; return nil; }
    ldidConfigPath = [runtime stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.ldid.json", uuid]];
    if (!TSWriteProtectedData(ldidJSON, ldidConfigPath, error)) { for (NSString *path in temporaryFiles) [[NSFileManager defaultManager] removeItemAtPath:path error:nil]; return nil; }
    [temporaryFiles addObject:ldidConfigPath];
    configuration[@"ldidConfigPath"] = ldidConfigPath;
    configuration[@"profileName"] = templateName;

    NSString *configPath = [runtime stringByAppendingPathComponent:[NSString stringWithFormat:@"%@.plist", uuid]];
    NSData *plist = [NSPropertyListSerialization dataWithPropertyList:configuration format:NSPropertyListXMLFormat_v1_0 options:0 error:error];
    if (!plist || !TSWriteProtectedData(plist, configPath, error)) {
        for (NSString *path in temporaryFiles) [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
        return nil;
    }
    chmod(configPath.fileSystemRepresentation, 0600);
    return configPath;
}

+ (void)cleanupRootHelperSigningConfiguration:(NSString *)configurationPath {
    if (!configurationPath.length) return;
    NSDictionary *configuration = [NSDictionary dictionaryWithContentsOfFile:configurationPath];
    for (NSString *path in configuration[@"temporaryFiles"]) if ([path isKindOfClass:NSString.class]) [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
    [[NSFileManager defaultManager] removeItemAtPath:configurationPath error:nil];
}

@end
