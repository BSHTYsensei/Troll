#import <TSUtil.h>
#import <errno.h>

// Invoked only by the App Intent. This is intentionally the narrow `refresh`
// operation: it re-registers TrollStore apps without clearing icon caches
// or terminating SpringBoard processes.
int TSRunRefreshAppRegistrationsShortcut(void)
{
    NSString *helper = rootHelperPath();
    if (![helper isKindOfClass:NSString.class] || helper.length == 0) return ENOENT;
    return spawnRoot(helper, @[@"refresh"], nil, nil);
}
