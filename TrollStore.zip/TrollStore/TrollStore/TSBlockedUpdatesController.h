#import <UIKit/UIKit.h>
@interface TSBlockedUpdatesController : UITableViewController
@end
