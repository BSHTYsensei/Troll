#import <UIKit/UIKit.h>
@interface TSAppCollectionViewController : UICollectionViewController <UISearchResultsUpdating>
@property(nonatomic, assign) NSInteger sourceCategory;
@property(nonatomic, copy) NSString *initialSearchText;
@end
