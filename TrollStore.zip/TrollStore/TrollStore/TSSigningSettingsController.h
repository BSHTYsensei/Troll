#import <UIKit/UIKit.h>

@interface TSSigningSettingsController : UITableViewController
@end
