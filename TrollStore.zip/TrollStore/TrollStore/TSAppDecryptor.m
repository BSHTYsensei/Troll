#import "TSAppDecryptor.h"
#import "TSIPAPackageStore.h"
#import <TSUtil.h>
#import <TSPresentationDelegate.h>

@implementation TSAppDecryptor
+ (void)presentForBundleIdentifier:(NSString *)bundleIdentifier displayName:(NSString *)displayName fromViewController:(UIViewController *)viewController {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Decrypt & Export IPA", nil)
        message:NSLocalizedString(@"Open the target application and leave it running, then continue. The helper reads decrypted Mach-O pages from the live process. iOS may deny task_for_pid; in that case no IPA is produced.", nil)
        preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Decrypt", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        NSString *rawName = displayName.length ? displayName : (bundleIdentifier ?: @"DecryptedApp");
        NSString *safeName = [[rawName componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"/\\:\n\r"]] componentsJoinedByString:@"_"];
        if (!safeName.length) safeName = @"DecryptedApp";
        NSString *output = [[TSIPAPackageStore packageDirectoryPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"%@-%@-decrypted.ipa", safeName, [NSUUID.UUID.UUIDString substringToIndex:8]]];
        [TSPresentationDelegate startActivity:NSLocalizedString(@"Decrypting Running Application", nil)];
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
            NSString *log = nil;
            int result = spawnRoot(rootHelperPath(), @[@"decrypt", bundleIdentifier ?: @"", output], nil, &log);
            dispatch_async(dispatch_get_main_queue(), ^{
                [TSPresentationDelegate stopActivityWithCompletion:^{
                    NSString *message = log.length ? log : (result == 0 ? output.lastPathComponent : [NSString stringWithFormat:NSLocalizedString(@"Decryption failed with code %d.", nil), result]);
                    UIAlertController *resultAlert = [UIAlertController alertControllerWithTitle:result == 0 ? NSLocalizedString(@"Decryption Complete", nil) : NSLocalizedString(@"Decryption Failed", nil) message:message preferredStyle:UIAlertControllerStyleAlert];
                    if (result == 0) {
                        [resultAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Share IPA", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
                            UIActivityViewController *activity = [[UIActivityViewController alloc] initWithActivityItems:@[[NSURL fileURLWithPath:output]] applicationActivities:nil];
                            activity.popoverPresentationController.sourceView = viewController.view;
                            activity.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(viewController.view.bounds), CGRectGetMidY(viewController.view.bounds), 1, 1);
                            [TSPresentationDelegate presentViewController:activity animated:YES completion:nil];
                        }]];
                    }
                    [resultAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Copy Debug Log", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { UIPasteboard.generalPasteboard.string = log ?: message; }]];
                    [resultAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
                    [TSPresentationDelegate presentViewController:resultAlert animated:YES completion:nil];
                }];
            });
        });
    }]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}
@end
