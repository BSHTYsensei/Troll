#import "TSAppCollectionViewController.h"
#import "TSAppInfo.h"
#import "TSApplicationsManager.h"
#import "TSAppTableViewController.h"
#import "TSAppDecryptor.h"
#import "TSTweakInjector.h"
#import "TSIPAPackageStore.h"
#import "TSAppRepackager.h"
#import "TSInstallationController.h"
#import "TSAppUpdateManager.h"
#import "TSThemeManager.h"
#import <TSUtil.h>
#import <TSPresentationDelegate.h>
#import <CoreServices.h>
@import UniformTypeIdentifiers;

@interface TSGridAppCell : UICollectionViewCell
@property(nonatomic,strong) UIImageView *iconView;
@property(nonatomic,strong) UILabel *nameLabel;
@property(nonatomic,strong) UILabel *bundleLabel;
@property(nonatomic,strong) UILabel *sourceLabel;
@property(nonatomic,copy) NSString *representedBundleIdentifier;
@end
@implementation TSGridAppCell
- (instancetype)initWithFrame:(CGRect)frame {
    if ((self=[super initWithFrame:frame])) {
        self.contentView.backgroundColor = UIColor.secondarySystemBackgroundColor;
        self.contentView.layer.cornerRadius = 18; self.contentView.layer.cornerCurve = kCACornerCurveContinuous;
        self.contentView.layer.borderWidth = 0.0;
        _iconView=[UIImageView new]; _iconView.contentMode=UIViewContentModeScaleAspectFit; _iconView.translatesAutoresizingMaskIntoConstraints=NO; _iconView.layer.cornerRadius=13; _iconView.clipsToBounds=YES;
        _nameLabel=[UILabel new]; _nameLabel.font=[UIFont preferredFontForTextStyle:UIFontTextStyleSubheadline]; _nameLabel.font=[UIFont systemFontOfSize:14 weight:UIFontWeightSemibold]; _nameLabel.textAlignment=NSTextAlignmentCenter; _nameLabel.numberOfLines=2;
        _bundleLabel=[UILabel new]; _bundleLabel.font=[UIFont monospacedSystemFontOfSize:9 weight:UIFontWeightRegular]; _bundleLabel.textColor=UIColor.secondaryLabelColor; _bundleLabel.textAlignment=NSTextAlignmentCenter; _bundleLabel.numberOfLines=2; _bundleLabel.lineBreakMode=NSLineBreakByTruncatingMiddle;
        _sourceLabel=[UILabel new]; _sourceLabel.font=[UIFont systemFontOfSize:10 weight:UIFontWeightSemibold]; _sourceLabel.textAlignment=NSTextAlignmentCenter; _sourceLabel.layer.cornerRadius=7; _sourceLabel.clipsToBounds=YES;
        UIStackView *stack=[[UIStackView alloc] initWithArrangedSubviews:@[_iconView,_nameLabel,_bundleLabel,_sourceLabel]]; stack.translatesAutoresizingMaskIntoConstraints=NO; stack.axis=UILayoutConstraintAxisVertical; stack.alignment=UIStackViewAlignmentFill; stack.spacing=7;
        [_iconView.heightAnchor constraintEqualToConstant:68].active=YES; [_sourceLabel.heightAnchor constraintEqualToConstant:20].active=YES;
        [self.contentView addSubview:stack]; [NSLayoutConstraint activateConstraints:@[[stack.topAnchor constraintEqualToAnchor:self.contentView.topAnchor constant:14],[stack.leadingAnchor constraintEqualToAnchor:self.contentView.leadingAnchor constant:9],[stack.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor constant:-9],[stack.bottomAnchor constraintLessThanOrEqualToAnchor:self.contentView.bottomAnchor constant:-10]]];
    }
    return self;
}
@end

@interface TSAppCollectionViewController () <UIDocumentPickerDelegate>
@property(nonatomic,strong) NSArray<TSAppInfo*> *items;
@property(nonatomic,strong) NSArray<TSAppInfo*> *catalog;
@property(nonatomic,strong) UISearchController *searchController;
@property(nonatomic,strong) UISegmentedControl *categoryControl;
@property(nonatomic,strong) UIView *categoryHeaderView;
@property(nonatomic,strong) NSLayoutConstraint *categoryHeaderHeightConstraint;
@property(nonatomic,copy) NSString *searchKey;
@property(nonatomic,assign) NSUInteger reloadGeneration;
@property(nonatomic,assign) NSUInteger searchGeneration;
@property(nonatomic,copy) NSSet<NSString *> *blockedUpdateBundleIdentifiers;
@property(nonatomic,strong) NSCache<NSString *, UIImage *> *iconCache;
@property(nonatomic,strong) NSMutableSet<NSString *> *pendingIconLoads;
@property(nonatomic,strong) NSOperationQueue *iconLoadQueue;
@property(nonatomic,strong) NSOperationQueue *catalogQueue;
@property(nonatomic,strong) NSOperationQueue *searchQueue;
@end

static NSInteger TSGridLoadAppSourceCategoryPreference(void)
{
    NSUserDefaults *defaults = trollStoreUserDefaults();
    if (![defaults boolForKey:@"TSAppSourceCategoryV2"]) {
        id oldValue = [defaults objectForKey:@"TSAppSourceCategory"];
        if (oldValue) {
            NSInteger oldCategory = [oldValue integerValue];
            NSInteger migrated = oldCategory == 0 ? 2 : (oldCategory == 1 ? 1 : (oldCategory == 2 ? 3 : 0));
            [defaults setInteger:migrated forKey:@"TSAppSourceCategory"];
        } else {
            [defaults setInteger:0 forKey:@"TSAppSourceCategory"];
        }
        [defaults setBool:YES forKey:@"TSAppSourceCategoryV2"];
    }
    return MAX(0, MIN(3, [defaults integerForKey:@"TSAppSourceCategory"]));
}

static NSCache<NSString *, NSNumber *> *TSGridManagedContainerCache(void)
{
    static NSCache<NSString *, NSNumber *> *cache;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        cache = [NSCache new];
        cache.countLimit = 1024;
    });
    return cache;
}

static BOOL TSGridIsTrollStoreAppPath(NSString *path)
{
    if (!path.length) return NO;
    NSString *container = path.stringByDeletingLastPathComponent;
    NSNumber *cached = [TSGridManagedContainerCache() objectForKey:container];
    if (cached) return cached.boolValue;
    NSFileManager *fm = NSFileManager.defaultManager;
    BOOL managed = [fm fileExistsAtPath:[container stringByAppendingPathComponent:TS_MARKER]] || [fm fileExistsAtPath:[container stringByAppendingPathComponent:TS_LITE_MARKER]];
    [TSGridManagedContainerCache() setObject:@(managed) forKey:container];
    return managed;
}

static BOOL TSGridIsUserAppContainerPath(NSString *path)
{
    NSString *normalized = path.stringByStandardizingPath;
    return [normalized hasPrefix:@"/private/var/containers/Bundle/Application/"] || [normalized hasPrefix:@"/var/containers/Bundle/Application/"];
}

static BOOL TSGridBoolPreference(NSString *key, BOOL defaultValue)
{
    id value = [trollStoreUserDefaults() objectForKey:key];
    return value ? [value boolValue] : defaultValue;
}

@implementation TSAppCollectionViewController
- (instancetype)init {
    UICollectionViewCompositionalLayout *layout=[[self class] makeLayout];
    if ((self=[super initWithCollectionViewLayout:layout])) { _items=@[]; _catalog=@[]; _searchKey=@""; _iconCache=[NSCache new]; _iconCache.countLimit=300; _iconCache.totalCostLimit=24 * 1024 * 1024; _pendingIconLoads=[NSMutableSet set]; _iconLoadQueue=[NSOperationQueue new]; _iconLoadQueue.name=@"com.opa334.TrollStore.app-icon-loader"; _iconLoadQueue.maxConcurrentOperationCount=2; _iconLoadQueue.qualityOfService=NSQualityOfServiceUtility; _catalogQueue=[NSOperationQueue new]; _catalogQueue.name=@"com.opa334.TrollStore.app-catalog"; _catalogQueue.maxConcurrentOperationCount=1; _catalogQueue.qualityOfService=NSQualityOfServiceUtility; _searchQueue=[NSOperationQueue new]; _searchQueue.name=@"com.opa334.TrollStore.app-search"; _searchQueue.maxConcurrentOperationCount=1; _searchQueue.qualityOfService=NSQualityOfServiceUtility; }
    return self;
}
+ (UICollectionViewCompositionalLayout *)makeLayout {
    NSCollectionLayoutSize *itemSize=[NSCollectionLayoutSize sizeWithWidthDimension:[NSCollectionLayoutDimension fractionalWidthDimension:0.5] heightDimension:[NSCollectionLayoutDimension estimatedDimension:190]];
    NSCollectionLayoutItem *item=[NSCollectionLayoutItem itemWithLayoutSize:itemSize]; item.contentInsets=NSDirectionalEdgeInsetsMake(6,6,6,6);
    NSCollectionLayoutSize *groupSize=[NSCollectionLayoutSize sizeWithWidthDimension:[NSCollectionLayoutDimension fractionalWidthDimension:1.0] heightDimension:[NSCollectionLayoutDimension estimatedDimension:202]];
    NSCollectionLayoutGroup *group=[NSCollectionLayoutGroup horizontalGroupWithLayoutSize:groupSize repeatingSubitem:item count:2];
    NSCollectionLayoutSection *section=[NSCollectionLayoutSection sectionWithGroup:group]; section.contentInsets=NSDirectionalEdgeInsetsMake(8,8,20,8);
    return [[UICollectionViewCompositionalLayout alloc] initWithSection:section];
}
- (void)viewDidLoad {
    [super viewDidLoad]; self.title=NSLocalizedString(@"Apps",nil); self.navigationItem.largeTitleDisplayMode=UINavigationItemLargeTitleDisplayModeAlways; self.collectionView.backgroundColor=UIColor.clearColor;
    self.blockedUpdateBundleIdentifiers = [NSSet set];
    [self.collectionView registerClass:TSGridAppCell.class forCellWithReuseIdentifier:@"GridApp"];
    self.navigationItem.leftBarButtonItem=[[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"list.bullet"] style:UIBarButtonItemStylePlain target:self action:@selector(switchToList)];
    __weak typeof(self) weakSelf = self;
    UIAction *installFromFile = [UIAction actionWithTitle:NSLocalizedString(@"Install IPA File", nil) image:[UIImage systemImageNamed:@"doc.badge.plus"] identifier:@"InstallIPAFile" handler:^(__kindof UIAction *action) {
        UTType *dataType = [UTType typeWithIdentifier:@"public.data"];
        if (!dataType) return;
        UTType *ipaType = [UTType typeWithFilenameExtension:@"ipa" conformingToType:dataType] ?: dataType;
        UTType *tipaType = [UTType typeWithFilenameExtension:@"tipa" conformingToType:dataType] ?: dataType;
        UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:@[ipaType, tipaType]];
        picker.allowsMultipleSelection = NO;
        picker.delegate = weakSelf;
        [TSPresentationDelegate presentViewController:picker animated:YES completion:nil];
    }];
    UIAction *installFromURL = [UIAction actionWithTitle:NSLocalizedString(@"Install from URL", nil) image:[UIImage systemImageNamed:@"link.badge.plus"] identifier:@"InstallFromURL" handler:^(__kindof UIAction *action) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Install from URL", nil) message:@"" preferredStyle:UIAlertControllerStyleAlert];
        [alert addTextFieldWithConfigurationHandler:^(UITextField *textField) { textField.placeholder = NSLocalizedString(@"IPA URL", nil); textField.keyboardType = UIKeyboardTypeURL; textField.autocapitalizationType = UITextAutocapitalizationTypeNone; }];
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Install", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *confirm) {
            NSURL *remoteURL = [NSURL URLWithString:alert.textFields.firstObject.text ?: @""];
            [TSInstallationController handleAppInstallFromRemoteURL:remoteURL completion:nil];
        }]];
        [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
    }];
    UIAction *searchAppsAction = [UIAction actionWithTitle:NSLocalizedString(@"Search Apps", nil) image:[UIImage systemImageNamed:@"magnifyingglass"] identifier:@"SearchApps" handler:^(__kindof UIAction *action) {
        [weakSelf presentSearchPrompt];
    }];
    UIAction *switchToListAction = [UIAction actionWithTitle:NSLocalizedString(@"Switch to List Layout", nil) image:[UIImage systemImageNamed:@"list.bullet"] identifier:@"SwitchToListLayout" handler:^(__kindof UIAction *action) {
        [weakSelf switchToList];
    }];
    UIMenu *installMenu = [UIMenu menuWithChildren:@[installFromFile, installFromURL, searchAppsAction, switchToListAction]];
    self.navigationItem.rightBarButtonItem=[[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"plus.circle.fill"] menu:installMenu];
    _searchController=[[UISearchController alloc] initWithSearchResultsController:nil]; _searchController.searchResultsUpdater=self; _searchController.obscuresBackgroundDuringPresentation=NO; _searchController.searchBar.searchBarStyle=UISearchBarStyleMinimal; _searchController.searchBar.tintColor=[TSThemeManager accentColor]; _searchController.searchBar.searchTextField.backgroundColor=UIColor.secondarySystemBackgroundColor;
    // Keep the reference layout free of a permanently visible search bar; the
    // same search function is available from the plus menu.
    self.definesPresentationContext=YES;
    _sourceCategory = TSGridLoadAppSourceCategoryPreference();
    _categoryControl=[[UISegmentedControl alloc] initWithItems:@[NSLocalizedString(@"All",nil),NSLocalizedString(@"User",nil),NSLocalizedString(@"Troll",nil),NSLocalizedString(@"System",nil)]]; _categoryControl.selectedSegmentIndex=_sourceCategory; _categoryControl.backgroundColor=UIColor.secondarySystemBackgroundColor; _categoryControl.selectedSegmentTintColor=UIColor.tertiarySystemFillColor; _categoryControl.tintColor=UIColor.secondaryLabelColor; [_categoryControl setTitleTextAttributes:@{NSForegroundColorAttributeName:UIColor.secondaryLabelColor,NSFontAttributeName:[UIFont systemFontOfSize:13 weight:UIFontWeightMedium]} forState:UIControlStateNormal]; [_categoryControl setTitleTextAttributes:@{NSForegroundColorAttributeName:UIColor.labelColor,NSFontAttributeName:[UIFont systemFontOfSize:13 weight:UIFontWeightSemibold]} forState:UIControlStateSelected]; [_categoryControl addTarget:self action:@selector(categoryChanged:) forControlEvents:UIControlEventValueChanged];
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, 48)];
    _categoryHeaderView = header;
    _categoryControl.frame = CGRectMake(16, 6, header.bounds.size.width - 32, 34);
    _categoryControl.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [header addSubview:_categoryControl];
    [self.view addSubview:header];
    header.translatesAutoresizingMaskIntoConstraints = NO;
    _categoryHeaderHeightConstraint = [header.heightAnchor constraintEqualToConstant:48];
    [NSLayoutConstraint activateConstraints:@[[header.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],[header.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],[header.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],_categoryHeaderHeightConstraint]];
    [self updateCategoryControlAppearance];
    if (_initialSearchText.length) { _searchController.searchBar.text=_initialSearchText; _searchKey=_initialSearchText; }
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationsChanged) name:@"ApplicationsChanged" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(themeChanged) name:@"TSAppearanceChanged" object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(appAppearanceSettingsChanged) name:@"TSAppAppearanceSettingsChanged" object:nil];
    [TSThemeManager applyToViewController:self]; [self reloadApps];
}
- (void)dealloc { [self.iconLoadQueue cancelAllOperations]; [self.catalogQueue cancelAllOperations]; [self.searchQueue cancelAllOperations]; [[NSNotificationCenter defaultCenter] removeObserver:self]; }
- (void)applicationsChanged {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self applicationsChanged]; });
        return;
    }
    [self.iconCache removeAllObjects];
    [TSGridManagedContainerCache() removeAllObjects];
    [self reloadApps];
}
- (void)themeChanged {
    [TSThemeManager applyToViewController:self];
    [self updateCategoryControlAppearance];
    [self.collectionView reloadData];
}
- (void)appAppearanceSettingsChanged {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self appAppearanceSettingsChanged]; });
        return;
    }
    if (!TSGridBoolPreference(@"TSShowAppFilter", YES) || (!TSGridBoolPreference(@"TSShowSystemApps", YES) && _sourceCategory == 3)) {
        _sourceCategory = 0;
        [trollStoreUserDefaults() setInteger:0 forKey:@"TSAppSourceCategory"];
    }
    [self.catalogQueue cancelAllOperations];
    [self.searchQueue cancelAllOperations];
    self.catalog = @[];
    self.items = @[];
    [self updateCategoryControlAppearance];
    [self reloadApps];
}
- (void)updateCategoryControlAppearance {
    if (!_categoryControl || !_categoryHeaderHeightConstraint) return;
    BOOL showFilter = TSGridBoolPreference(@"TSShowAppFilter", YES);
    BOOL showSystemApps = TSGridBoolPreference(@"TSShowSystemApps", YES);
    [_categoryControl setEnabled:showSystemApps forSegmentAtIndex:3];
    if (!showSystemApps && _sourceCategory == 3) {
        _sourceCategory = 0;
        [trollStoreUserDefaults() setInteger:0 forKey:@"TSAppSourceCategory"];
    }
    _categoryControl.selectedSegmentIndex = _sourceCategory;
    _categoryControl.hidden = !showFilter;
    _categoryHeaderHeightConstraint.constant = showFilter ? 48.0 : 0.0;
    UIEdgeInsets targetInsets = UIEdgeInsetsMake(showFilter ? 48.0 : 0.0, 0, 0, 0);
    if (!UIEdgeInsetsEqualToEdgeInsets(self.collectionView.contentInset, targetInsets)) {
        self.collectionView.contentInset = targetInsets;
        self.collectionView.scrollIndicatorInsets = targetInsets;
    }
    [_categoryHeaderView setNeedsLayout];
}
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    [self updateCategoryControlAppearance];
}
- (void)switchToList {
    TSAppTableViewController *list = [TSAppTableViewController new];
    list.title = NSLocalizedString(@"Apps", nil);
    list.sourceCategory = self.sourceCategory;
    list.initialSearchText = self.searchKey ?: @"";
    [self.navigationController setViewControllers:@[list] animated:YES];
    [trollStoreUserDefaults() setInteger:0 forKey:@"TSAppListLayout"];
}
- (void)presentSearchPrompt {
    UIAlertController *prompt = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Search Apps", nil) message:nil preferredStyle:UIAlertControllerStyleAlert];
    [prompt addTextFieldWithConfigurationHandler:^(UITextField *textField) {
        textField.text = self.searchKey ?: @"";
        textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        textField.autocapitalizationType = UITextAutocapitalizationTypeNone;
    }];
    [prompt addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [prompt addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Search", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        self.searchKey = prompt.textFields.firstObject.text ?: @"";
        self.searchController.searchBar.text = self.searchKey;
        [self applySearch];
    }]];
    [self presentViewController:prompt animated:YES completion:nil];
}
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSString *path = urls.firstObject.path;
    if (path.length) [TSInstallationController presentInstallationAlertIfEnabledForFile:path isRemoteInstall:NO completion:nil];
}
- (void)categoryChanged:(UISegmentedControl *)sender {
    _sourceCategory = MAX(0, MIN(3, sender.selectedSegmentIndex));
    if (_sourceCategory == 3 && !TSGridBoolPreference(@"TSShowSystemApps", YES)) _sourceCategory = 0;
    sender.selectedSegmentIndex = _sourceCategory;
    [trollStoreUserDefaults() setInteger:_sourceCategory forKey:@"TSAppSourceCategory"];
    [self reloadApps];
}
- (NSArray<TSAppInfo*> *)buildCatalogForCategory:(NSInteger)category operation:(NSOperation *)operation {
    NSMutableOrderedSet<NSString*> *paths=[NSMutableOrderedSet orderedSet]; NSFileManager *fm=NSFileManager.defaultManager;
    if (category==0 || category==2) [paths addObjectsFromArray:[[TSApplicationsManager sharedInstance] installedAppPaths] ?: @[]];
    if (category==0 || category==1 || category==3) {
        void (^add)(LSApplicationProxy*)=^(LSApplicationProxy *proxy){
            if (operation.isCancelled) return;
            if(!proxy.installed || !proxy.bundleIdentifier.length || !proxy.bundleURL.path.length) return;
            NSString *path=proxy.bundleURL.path; NSString *container=path.stringByDeletingLastPathComponent;
            if([fm fileExistsAtPath:[container stringByAppendingPathComponent:TS_MARKER]] || [fm fileExistsAtPath:[container stringByAppendingPathComponent:TS_LITE_MARKER]]) return;
            if([path.lastPathComponent isEqualToString:@"TrollStorePersistenceHelper.app"]) return;
            if([fm fileExistsAtPath:path]) [paths addObject:path];
        };
        if (category==0 || category==1) [[LSApplicationWorkspace defaultWorkspace] enumerateApplicationsOfType:0 block:add];
        if ((category==0 || category==3) && TSGridBoolPreference(@"TSShowSystemApps", YES)) [[LSApplicationWorkspace defaultWorkspace] enumerateApplicationsOfType:1 block:add];
    }
    NSMutableArray *items=[NSMutableArray array];
    for (NSString *path in paths) {
        if (operation.isCancelled) return @[];
        @autoreleasepool {
            TSAppInfo *info = [[TSAppInfo alloc] initWithAppBundlePath:path];
            if ([info sync_loadBasicInfo] == nil) [items addObject:info];
        }
    }
    if (operation.isCancelled) return @[];
    [items sortUsingComparator:^NSComparisonResult(TSAppInfo *a, TSAppInfo *b){ return [[a displayName] localizedStandardCompare:[b displayName]]; }]; return items.copy;
}
- (void)reloadApps {
    if (!NSThread.isMainThread) {
        dispatch_async(dispatch_get_main_queue(), ^{ [self reloadApps]; });
        return;
    }
    NSUInteger generation = ++_reloadGeneration;
    NSInteger category = _sourceCategory;
    self.searchGeneration++;
    [self.catalogQueue cancelAllOperations];
    [self.searchQueue cancelAllOperations];

    __weak typeof(self) weakSelf = self;
    __block __weak NSBlockOperation *weakOperation = nil;
    NSBlockOperation *operation = [NSBlockOperation blockOperationWithBlock:^{
        typeof(self) strongSelf = weakSelf;
        NSOperation *currentOperation = weakOperation;
        if (!strongSelf || !currentOperation || currentOperation.isCancelled) return;

        NSArray<TSAppInfo *> *catalog = [strongSelf buildCatalogForCategory:category operation:currentOperation];
        if (currentOperation.isCancelled) return;
        dispatch_async(dispatch_get_main_queue(), ^{
            typeof(self) strongSelf = weakSelf;
            if (!strongSelf || generation != strongSelf->_reloadGeneration || category != strongSelf->_sourceCategory) return;
            strongSelf.catalog = catalog;
            [strongSelf applySearch];
        });
    }];
    weakOperation = operation;
    [self.catalogQueue addOperation:operation];
}
- (void)applySearch {
    NSString *key = [_searchKey copy] ?: @"";
    NSArray<TSAppInfo *> *catalog = self.catalog ?: @[];
    NSUInteger generation = ++self.searchGeneration;
    if (key.length == 0) {
        [self.searchQueue cancelAllOperations];
        self.items = catalog;
        [self.collectionView reloadData];
        return;
    }
    [self.searchQueue cancelAllOperations];
    __weak typeof(self) weakSelf = self;
    __block __weak NSBlockOperation *weakOperation = nil;
    NSBlockOperation *operation = [NSBlockOperation blockOperationWithBlock:^{
        typeof(self) strongSelf = weakSelf;
        NSOperation *currentOperation = weakOperation;
        if (!strongSelf || !currentOperation || currentOperation.isCancelled) return;

        NSMutableArray<TSAppInfo *> *filtered = [NSMutableArray array];
        for (TSAppInfo *info in catalog) {
            if (currentOperation.isCancelled) return;
            NSString *name = info.displayName ?: @"";
            NSString *identifier = info.bundleIdentifier ?: @"";
            if ([name rangeOfString:key options:NSCaseInsensitiveSearch].location != NSNotFound ||
                [identifier rangeOfString:key options:NSCaseInsensitiveSearch].location != NSNotFound) {
                [filtered addObject:info];
            }
        }
        if (currentOperation.isCancelled) return;
        NSArray<TSAppInfo *> *result = filtered.copy;
        dispatch_async(dispatch_get_main_queue(), ^{
            typeof(self) strongSelf = weakSelf;
            if (!strongSelf || generation != strongSelf.searchGeneration || ![key isEqualToString:strongSelf.searchKey ?: @""]) return;
            strongSelf.items = result;
            [strongSelf.collectionView reloadData];
        });
    }];
    weakOperation = operation;
    [self.searchQueue addOperation:operation];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [TSAppUpdateManager copyBlockedBundleIdentifiersWithCompletion:^(NSSet<NSString *> *identifiers, NSError *error) {
        if (!error) {
            NSSet<NSString *> *updated = identifiers ?: [NSSet set];
            if (![self.blockedUpdateBundleIdentifiers isEqualToSet:updated]) {
                self.blockedUpdateBundleIdentifiers = updated;
                [self.collectionView reloadData];
            }
        }
    }];
}
- (void)updateSearchResultsForSearchController:(UISearchController *)searchController { _searchKey=searchController.searchBar.text ?: @""; [self applySearch]; }
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section { return _items.count; }
- (__kindof UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    TSGridAppCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"GridApp" forIndexPath:indexPath]; TSAppInfo *info=_items[indexPath.item]; cell.nameLabel.text=info.displayName ?: info.bundleIdentifier; cell.bundleLabel.text=info.bundleIdentifier;
    BOOL trollManaged = TSGridIsTrollStoreAppPath(info.bundlePath);
    BOOL userContainer = TSGridIsUserAppContainerPath(info.bundlePath) && !trollManaged;
    UIColor *sourceColor = trollManaged ? UIColor.systemGreenColor : (userContainer ? UIColor.systemBlueColor : UIColor.systemGrayColor);
    NSString *sourceText = trollManaged ? NSLocalizedString(@"Troll",nil) : (userContainer ? NSLocalizedString(@"User",nil) : NSLocalizedString(@"System App",nil));
    if (_sourceCategory == 1) { sourceText = NSLocalizedString(@"User", nil); sourceColor = UIColor.systemBlueColor; }
    if (_sourceCategory == 2) { sourceText = NSLocalizedString(@"Troll", nil); sourceColor = UIColor.systemGreenColor; }
    if (_sourceCategory == 3) { sourceText = NSLocalizedString(@"System App", nil); sourceColor = UIColor.systemGrayColor; }
    BOOL updateBlocked = [self.blockedUpdateBundleIdentifiers containsObject:info.bundleIdentifier];
    BOOL showAppType = TSGridBoolPreference(@"TSShowAppTypeInGrid", NO);
    BOOL showTrollBadge = TSGridBoolPreference(@"TSShowTrollStoreBadge", YES);
    BOOL showSourceLabel = updateBlocked || showAppType || (trollManaged && showTrollBadge);
    if (updateBlocked) sourceText = NSLocalizedString(@"Updates Blocked", nil);
    else if (!showAppType && trollManaged && showTrollBadge) sourceText = NSLocalizedString(@"Troll", nil);
    cell.sourceLabel.text = showSourceLabel ? sourceText : @"";
    cell.sourceLabel.hidden = !showSourceLabel;
    cell.sourceLabel.backgroundColor=[sourceColor colorWithAlphaComponent:0.16]; cell.sourceLabel.textColor=sourceColor;

    // Icon lookup enumerates bundle files and may touch hundreds of filesystem
    // entries. Keep cell creation cheap and decode icons away from the main queue.
    NSString *cacheKey = info.bundleIdentifier.length ? info.bundleIdentifier : info.bundlePath;
    cell.representedBundleIdentifier = cacheKey;
    UIImage *cachedIcon = cacheKey.length ? [self.iconCache objectForKey:cacheKey] : nil;
    cell.iconView.image = cachedIcon ?: [UIImage systemImageNamed:@"app.fill"];
    if (!cachedIcon && cacheKey.length && ![self.pendingIconLoads containsObject:cacheKey]) {
        [self.pendingIconLoads addObject:cacheKey];
        __weak typeof(self) weakSelf = self;
        __weak TSGridAppCell *weakCell = cell;
        NSCache<NSString *, UIImage *> *iconCache = self.iconCache;
        [self.iconLoadQueue addOperationWithBlock:^{
            @autoreleasepool {
                UIImage *icon = [info iconForSize:CGSizeMake(72,72)];
                if (icon) {
                    NSUInteger cost = (NSUInteger)(icon.size.width * icon.size.height * icon.scale * icon.scale * 4.0);
                    [iconCache setObject:icon forKey:cacheKey cost:cost];
                }
                dispatch_async(dispatch_get_main_queue(), ^{
                    TSAppCollectionViewController *strongSelf = weakSelf;
                    if (!strongSelf) return;
                    [strongSelf.pendingIconLoads removeObject:cacheKey];
                    TSGridAppCell *visibleCell = weakCell;
                    if (icon && visibleCell && [visibleCell.representedBundleIdentifier isEqualToString:cacheKey]) {
                        visibleCell.iconView.image = icon;
                    }
                });
            }
        }];
    }
    return cell;
}
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath { [self showActionsForApp:_items[indexPath.item] indexPath:indexPath]; [collectionView deselectItemAtIndexPath:indexPath animated:YES]; }
- (void)showActionsForApp:(TSAppInfo *)info indexPath:(NSIndexPath *)indexPath {
    BOOL trollManaged = TSGridIsTrollStoreAppPath(info.bundlePath);
    BOOL userContainer = TSGridIsUserAppContainerPath(info.bundlePath) && !trollManaged;
    BOOL systemApp = !trollManaged && !userContainer;
    UIAlertController *actions=[UIAlertController alertControllerWithTitle:info.displayName?:@"" message:info.bundleIdentifier preferredStyle:UIAlertControllerStyleActionSheet];
    [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Open",nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){ [[TSApplicationsManager sharedInstance] openApplicationWithBundleID:info.bundleIdentifier]; }]];
    if (!systemApp) {
        [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Decrypt & Export IPA",nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){ [TSAppDecryptor presentForBundleIdentifier:info.bundleIdentifier displayName:info.displayName fromViewController:self]; }]];
        [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Clear Cache",nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){ [self confirmMaintenance:@"clear-cache" app:info]; }]];
        [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Clear App Data",nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a){ [self confirmMaintenance:@"clear-data" app:info]; }]];
    }
    if (trollManaged) {
        [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Export IPA",nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){ [self exportManagedAppInfo:info forRepackaging:NO]; }]];
        [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Modify / Duplicate",nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){ [self exportManagedAppInfo:info forRepackaging:YES]; }]];
        [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Inject Tweak",nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){ [TSTweakInjector presentForBundleIdentifier:info.bundleIdentifier displayName:info.displayName fromViewController:self]; }]];
    } else if (userContainer) {
        BOOL isBlocked = [self.blockedUpdateBundleIdentifiers containsObject:info.bundleIdentifier];
        [actions addAction:[UIAlertAction actionWithTitle:isBlocked ? NSLocalizedString(@"Allow App Updates",nil) : NSLocalizedString(@"Block App Updates",nil) style:isBlocked ? UIAlertActionStyleDefault : UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a){ [self toggleUpdateLockForApp:info blocked:!isBlocked]; }]];
        [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Inject Tweak",nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){ [TSTweakInjector presentForBundleIdentifier:info.bundleIdentifier displayName:info.displayName fromViewController:self]; }]];
    }
    [actions addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel",nil) style:UIAlertActionStyleCancel handler:nil]];
    actions.popoverPresentationController.sourceView=self.collectionView; UICollectionViewLayoutAttributes *attrs=[self.collectionView layoutAttributesForItemAtIndexPath:indexPath]; actions.popoverPresentationController.sourceRect=attrs ? attrs.frame : CGRectMake(CGRectGetMidX(self.collectionView.bounds), CGRectGetMidY(self.collectionView.bounds), 1, 1); [TSPresentationDelegate presentViewController:actions animated:YES completion:nil];
}
- (void)exportManagedAppInfo:(TSAppInfo *)info forRepackaging:(BOOL)repackage {
    [TSPresentationDelegate startActivity:repackage ? NSLocalizedString(@"Modify / Duplicate", nil) : NSLocalizedString(@"Export IPA", nil)];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        NSError *error = nil;
        NSURL *url = [TSIPAPackageStore exportInstalledAppAtPath:info.bundlePath error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            [TSPresentationDelegate stopActivityWithCompletion:^{
                if (!url) {
                    [self showMessage:error.localizedDescription ?: NSLocalizedString(@"Export failed", nil) title:NSLocalizedString(@"Export Failed", nil)];
                    return;
                }
                if (repackage) {
                    [TSAppRepackager presentFromViewController:self sourceIPA:url.path completion:^(NSString *outputPath, NSError *repackError) {
                        if (outputPath) [TSInstallationController presentInstallationAlertIfEnabledForFile:outputPath isRemoteInstall:NO completion:nil];
                        else if (repackError) [self showMessage:repackError.localizedDescription title:NSLocalizedString(@"Repackage Failed", nil)];
                    }];
                } else {
                    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
                    share.popoverPresentationController.sourceView = self.view;
                    share.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds), 1, 1);
                    [TSPresentationDelegate presentViewController:share animated:YES completion:nil];
                }
            }];
        });
    });
}

- (void)toggleUpdateLockForApp:(TSAppInfo *)info blocked:(BOOL)blocked {
    NSString *title = blocked ? NSLocalizedString(@"Block App Updates?",nil) : NSLocalizedString(@"Allow App Updates?",nil);
    NSString *message = blocked ? NSLocalizedString(@"This hides the App Store metadata file for this app and refreshes LaunchServices. You can restore updates at any time from Settings. Keep the device unlocked while the App Store refreshes. This affects App Store app updates only; iOS system updates are not affected.",nil) : NSLocalizedString(@"Restore the original App Store metadata file and allow this app to update again?",nil);
    UIAlertController *confirm=[UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel",nil) style:UIAlertActionStyleCancel handler:nil]];
    [confirm addAction:[UIAlertAction actionWithTitle:blocked?NSLocalizedString(@"Block Updates",nil):NSLocalizedString(@"Allow Updates",nil) style:blocked?UIAlertActionStyleDestructive:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){
        [TSPresentationDelegate startActivity:NSLocalizedString(@"Refreshing App Store Metadata",nil)];
        [TSAppUpdateManager setUpdatesBlocked:blocked forBundleIdentifier:info.bundleIdentifier completion:^(BOOL success, NSString *result){
            [TSPresentationDelegate stopActivityWithCompletion:^{ if(success){ NSMutableSet *set=[self.blockedUpdateBundleIdentifiers mutableCopy]?:[NSMutableSet set]; if(blocked)[set addObject:info.bundleIdentifier]; else [set removeObject:info.bundleIdentifier]; self.blockedUpdateBundleIdentifiers=set.copy; [self.collectionView reloadData]; } [self showMessage:result title:success?NSLocalizedString(@"Completed",nil):NSLocalizedString(@"Operation Failed",nil)]; }];
        }];
    }]];
    [TSPresentationDelegate presentViewController:confirm animated:YES completion:nil];
}
- (void)confirmMaintenance:(NSString *)command app:(TSAppInfo *)info {
    BOOL data=[command isEqualToString:@"clear-data"];
    UIAlertController *confirm=[UIAlertController alertControllerWithTitle:data?NSLocalizedString(@"Clear App Data",nil):NSLocalizedString(@"Clear Cache",nil) message:data?NSLocalizedString(@"This deletes the application's entire data container, including documents, preferences, databases and caches. Quit the app first; iOS will be asked to create an empty container. This cannot be undone.",nil):NSLocalizedString(@"This removes Library/Caches contents. Other application data is preserved.",nil) preferredStyle:UIAlertControllerStyleAlert];
    [confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel",nil) style:UIAlertActionStyleCancel handler:nil]];
    [confirm addAction:[UIAlertAction actionWithTitle:data?NSLocalizedString(@"Delete Data",nil):NSLocalizedString(@"Clear Cache",nil) style:data?UIAlertActionStyleDestructive:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a){
        [TSPresentationDelegate startActivity:data?NSLocalizedString(@"Clearing App Data",nil):NSLocalizedString(@"Clearing Cache",nil)];
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED,0),^{ NSString *log=nil; int result=spawnRoot(rootHelperPath(),@[command,info.bundleIdentifier],nil,&log); dispatch_async(dispatch_get_main_queue(),^{ [TSPresentationDelegate stopActivityWithCompletion:^{ [self showMessage:log.length?log:[NSString stringWithFormat:NSLocalizedString(@"Operation failed with code %d.",nil),result] title:result==0?NSLocalizedString(@"Completed",nil):NSLocalizedString(@"Operation Failed",nil)]; }]; }); });
    }]];
    [TSPresentationDelegate presentViewController:confirm animated:YES completion:nil];
}
- (void)showMessage:(NSString *)message title:(NSString *)title { UIAlertController *a=[UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert]; [a addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK",nil) style:UIAlertActionStyleCancel handler:nil]]; [TSPresentationDelegate presentViewController:a animated:YES completion:nil]; }
@end
