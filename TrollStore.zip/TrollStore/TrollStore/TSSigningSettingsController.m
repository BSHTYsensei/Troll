#import "TSSigningSettingsController.h"
#import "TSSigningManager.h"
#import <TSPresentationDelegate.h>
@import UniformTypeIdentifiers;

@interface TSSigningSettingsController () <UIDocumentPickerDelegate>
@property(nonatomic, copy) NSString *pendingImportKind;
@property(nonatomic, strong) NSData *pendingCertificateData;
@property(nonatomic, copy) NSString *pendingCertificateName;
@property(nonatomic, copy) NSString *pendingProfileCredentialID;
@end

@interface TSSigningCertificateDetailController : UITableViewController
@property(nonatomic, copy) NSString *credentialIdentifier;
@end

@implementation TSSigningSettingsController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Signing Method", nil);
    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleInsetGrouped];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItem.done target:self action:@selector(donePressed)];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadSigningData) name:@"TSSigningConfigurationChanged" object:nil];
    [self reloadSigningData];
}
- (void)dealloc { [[NSNotificationCenter defaultCenter] removeObserver:self]; }
- (void)donePressed { [self dismissViewControllerAnimated:YES completion:nil]; }
- (void)reloadSigningData { dispatch_async(dispatch_get_main_queue(), ^{ [self.tableView reloadData]; }); }

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 3; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSString *mode = [TSSigningManager signingMode];
    if (section == 0) return 2;
    if (section == 1) return [mode isEqualToString:@"real"] ? [TSSigningManager credentialRecords].count + 3 : 0;
    return [TSSigningManager templateDefinitionsForMode:mode].count;
}
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section == 0) return NSLocalizedString(@"Signing Method", nil);
    if (section == 1) return [[TSSigningManager signingMode] isEqualToString:@"real"] ? NSLocalizedString(@"Certificates and Identities", nil) : nil;
    return [TSSigningManager signingMode].length && [[TSSigningManager signingMode] isEqualToString:@"real"] ? NSLocalizedString(@"Real Signing Template", nil) : NSLocalizedString(@"TrollStore Signing Template", nil);
}
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    if (section == 0) return NSLocalizedString(@"Real signing creates a CMS signature with your imported certificate and private key. TrollStore signing uses ad-hoc signing and the TrollStore CoreTrust path.", nil);
    if (section == 1) return [[TSSigningManager signingMode] isEqualToString:@"real"] ? NSLocalizedString(@"The first imported identity becomes the default. P12 stores the certificate and private key together; PEM imports require a certificate PEM and its matching private-key PEM. Provisioning profiles are optional and must match the identity, app identifier, device and entitlements.", nil) : nil;
    return NSLocalizedString(@"Templates select ldid hash and parallel-signing options. The certificate and provisioning profile determine the actual signing identity and distribution permissions. Choosing App Store does not create an Apple-issued certificate, profile, review approval, or distribution authorization.", nil);
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SigningCell"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"SigningCell"];
    cell.accessoryType = UITableViewCellAccessoryNone; cell.accessoryView = nil; cell.detailTextLabel.text = nil; cell.textLabel.textColor = UIColor.labelColor;
    NSString *mode = [TSSigningManager signingMode];
    if (indexPath.section == 0) {
        BOOL real = indexPath.row == 0;
        cell.textLabel.text = real ? NSLocalizedString(@"Real Signing", nil) : NSLocalizedString(@"TrollStore Signing", nil);
        cell.detailTextLabel.text = real ? NSLocalizedString(@"CMS / certificate identity", nil) : NSLocalizedString(@"Ad-hoc / CoreTrust", nil);
        if (!real) cell.textLabel.textColor = UIColor.systemRedColor;
        if ((real && [mode isEqualToString:@"real"]) || (!real && [mode isEqualToString:@"troll"])) cell.accessoryType = UITableViewCellAccessoryCheckmark;
        return cell;
    }
    if (indexPath.section == 1) {
        NSArray *records = [TSSigningManager credentialRecords];
        if (indexPath.row < records.count) {
            NSDictionary *record = records[indexPath.row];
            NSString *identifier = record[@"id"];
            cell.textLabel.text = record[@"label"] ?: record[@"fileName"] ?: NSLocalizedString(@"Unnamed Certificate", nil);
            NSString *format = [record[@"format"] isEqualToString:@"pem"] ? @"PEM + KEY" : @"P12";
            cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ · %@", format, record[@"issuer"] ?: NSLocalizedString(@"Issuer unavailable", nil)];
            if ([[TSSigningManager defaultCredentialIdentifier] isEqualToString:identifier]) cell.accessoryType = UITableViewCellAccessoryCheckmark;
        } else {
            NSArray *titles = @[NSLocalizedString(@"Import P12 Identity…", nil), NSLocalizedString(@"Import PEM Certificate + Key…", nil), NSLocalizedString(@"Import Provisioning Profile…", nil)];
            cell.textLabel.text = titles[indexPath.row - records.count];
            cell.textLabel.textColor = UIColor.systemBlueColor;
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
        return cell;
    }
    NSArray *templates = [TSSigningManager templateDefinitionsForMode:mode];
    NSDictionary *item = templates[indexPath.row];
    cell.textLabel.text = item[@"title"];
    cell.detailTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"SHA-256 · %lu parallel jobs", nil), [item[@"jobs"] unsignedIntegerValue]];
    if ([[TSSigningManager selectedTemplateForMode:mode] isEqualToString:item[@"id"]]) cell.accessoryType = UITableViewCellAccessoryCheckmark;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        [TSSigningManager setSigningMode:indexPath.row == 0 ? @"real" : @"troll"];
        [tableView reloadData]; return;
    }
    if (indexPath.section == 2) {
        NSArray *items = [TSSigningManager templateDefinitionsForMode:[TSSigningManager signingMode]];
        [TSSigningManager setSelectedTemplate:items[indexPath.row][@"id"] forMode:[TSSigningManager signingMode]];
        [tableView reloadData]; return;
    }
    NSArray *records = [TSSigningManager credentialRecords];
    if (indexPath.row < records.count) { [self showCredentialActions:records[indexPath.row]]; return; }
    NSInteger action = indexPath.row - records.count;
    if (action == 0) [self pickDocumentForKind:@"p12"];
    else if (action == 1) [self pickDocumentForKind:@"pem-cert"];
    else [self selectCredentialForProfile];
}

- (void)pickDocumentForKind:(NSString *)kind {
    self.pendingImportKind = kind;
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:@[UTType.data] asCopy:YES];
    picker.delegate = self;
    [self presentViewController:picker animated:YES completion:nil];
}
- (void)documentPickerWasCancelled:(UIDocumentPickerViewController *)controller { self.pendingImportKind = nil; }
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSURL *url = urls.firstObject; if (!url) return;
    BOOL scoped = [url startAccessingSecurityScopedResource];
    NSData *data = [NSData dataWithContentsOfURL:url options:NSDataReadingMappedIfSafe error:nil];
    if (scoped) [url stopAccessingSecurityScopedResource];
    if (!data.length) { [self showMessage:NSLocalizedString(@"The selected file could not be read.", nil)]; return; }
    NSString *kind = self.pendingImportKind; self.pendingImportKind = nil;
    if ([kind isEqualToString:@"p12"]) { [self promptForPasswordForP12:data fileName:url.lastPathComponent]; return; }
    if ([kind isEqualToString:@"pem-cert"]) { self.pendingCertificateData = data; self.pendingCertificateName = url.lastPathComponent; [self pickDocumentForKind:@"pem-key"]; return; }
    if ([kind isEqualToString:@"pem-key"]) { [self promptForPasswordForPEMKey:data fileName:self.pendingCertificateName]; return; }
    if ([kind isEqualToString:@"profile"]) {
        NSError *error = nil;
        BOOL success = [TSSigningManager importProvisioningProfileData:data forCredentialIdentifier:self.pendingProfileCredentialID fileName:url.lastPathComponent error:&error];
        [self showMessage:success ? NSLocalizedString(@"Provisioning profile imported.", nil) : error.localizedDescription];
    }
}
- (void)promptForPasswordForP12:(NSData *)data fileName:(NSString *)name {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"P12 Password", nil) message:NSLocalizedString(@"Enter the password protecting this P12 identity. Leave empty when it has no password.", nil) preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) { field.secureTextEntry = YES; field.placeholder = NSLocalizedString(@"Password", nil); }];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Import", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        NSError *error = nil; BOOL success = [TSSigningManager importPKCS12Data:data fileName:name password:alert.textFields.firstObject.text ?: @"" error:&error];
        [self showMessage:success ? NSLocalizedString(@"Certificate identity imported. It is the default when this is the first identity.", nil) : error.localizedDescription];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)promptForPasswordForPEMKey:(NSData *)keyData fileName:(NSString *)name {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"PEM Private Key Password", nil) message:NSLocalizedString(@"Enter the password for an encrypted PEM private key, or leave empty for an unencrypted key.", nil) preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) { field.secureTextEntry = YES; field.placeholder = NSLocalizedString(@"Password", nil); }];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Import", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        NSError *error = nil; BOOL success = [TSSigningManager importPEMCertificateData:self.pendingCertificateData privateKeyData:keyData fileName:name password:alert.textFields.firstObject.text ?: @"" error:&error];
        self.pendingCertificateData = nil; self.pendingCertificateName = nil;
        [self showMessage:success ? NSLocalizedString(@"PEM certificate and private key imported.", nil) : error.localizedDescription];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)selectCredentialForProfile {
    NSArray *records = [TSSigningManager credentialRecords];
    if (!records.count) { [self showMessage:NSLocalizedString(@"Import a certificate identity first.", nil)]; return; }
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Attach Provisioning Profile", nil) message:NSLocalizedString(@"Choose the identity that this profile belongs to.", nil) preferredStyle:UIAlertControllerStyleActionSheet];
    for (NSDictionary *record in records) [alert addAction:[UIAlertAction actionWithTitle:record[@"label"] ?: record[@"fileName"] style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { self.pendingProfileCredentialID = record[@"id"]; [self pickDocumentForKind:@"profile"]; }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    alert.popoverPresentationController.sourceView = self.view; alert.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width/2, self.view.bounds.size.height/2, 1, 1);
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)showCredentialActions:(NSDictionary *)record {
    NSString *identifier = record[@"id"];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:record[@"label"] message:record[@"issuer"] preferredStyle:UIAlertControllerStyleActionSheet];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"View Certificate Details", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { TSSigningCertificateDetailController *details = [TSSigningCertificateDetailController new]; details.credentialIdentifier = identifier; [self.navigationController pushViewController:details animated:YES]; }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Set as Default", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [TSSigningManager setDefaultCredentialIdentifier:identifier]; [self.tableView reloadData]; }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Certificate", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) { [self confirmDeleteCredential:identifier]; }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    alert.popoverPresentationController.sourceView = self.view; alert.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width/2, self.view.bounds.size.height/2, 1, 1);
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)confirmDeleteCredential:(NSString *)identifier {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Delete Certificate?", nil) message:NSLocalizedString(@"The certificate identity and its stored private-key material will be deleted from TrollStore.", nil) preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) { [TSSigningManager deleteCredentialWithIdentifier:identifier]; [self.tableView reloadData]; }]];
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)showMessage:(NSString *)message {
    if (!message.length) message = NSLocalizedString(@"Completed.", nil);
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Signing", nil) message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:^{ [self.tableView reloadData]; }];
}
@end

@implementation TSSigningCertificateDetailController
- (void)viewDidLoad { [super viewDidLoad]; self.title = NSLocalizedString(@"Certificate Details", nil); self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleInsetGrouped]; }
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 3; }
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return @[NSLocalizedString(@"Issuer", nil), NSLocalizedString(@"Validity Period", nil), NSLocalizedString(@"OIDs", nil)][section];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSDictionary *d = [TSSigningManager certificateDetailsForCredentialIdentifier:self.credentialIdentifier] ?: @{};
    if (section == 0) return 1;
    if (section == 1) return 2;
    return [d[@"oids"] count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CertificateDetail"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"CertificateDetail"];
    NSDictionary *d = [TSSigningManager certificateDetailsForCredentialIdentifier:self.credentialIdentifier] ?: @{};
    if (indexPath.section == 0) { cell.textLabel.text = NSLocalizedString(@"Issuer", nil); cell.detailTextLabel.text = d[@"issuer"]; }
    else if (indexPath.section == 1) { BOOL before = indexPath.row == 0; cell.textLabel.text = before ? NSLocalizedString(@"Valid From", nil) : NSLocalizedString(@"Valid Until", nil); cell.detailTextLabel.text = d[before ? @"notBefore" : @"notAfter"]; }
    else { NSString *oid = d[@"oids"][indexPath.row]; cell.textLabel.text = oid; cell.detailTextLabel.text = NSLocalizedString(@"Certificate Extension / Field OID", nil); cell.textLabel.font = [UIFont monospacedSystemFontOfSize:13 weight:UIFontWeightRegular]; }
    cell.textLabel.numberOfLines = 0; cell.detailTextLabel.numberOfLines = 0; cell.selectionStyle = UITableViewCellSelectionStyleNone; return cell;
}
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section { return section == 2 ? NSLocalizedString(@"OID list is read from the certificate extension/field dictionary. A certificate signature alone does not guarantee app installation or launch authorization.", nil) : nil; }
@end
