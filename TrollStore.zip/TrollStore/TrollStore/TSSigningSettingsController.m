#import "TSSigningSettingsController.h"
#import "TSSigningManager.h"
#import "TSThemeManager.h"
#import <TSPresentationDelegate.h>
@import UniformTypeIdentifiers;

extern NSUserDefaults *trollStoreUserDefaults(void);

static NSString * const TSCodeDirectoryFlagsDefaultsKey = @"TSSigningCodeDirectoryFlags";
static NSArray<NSDictionary *> *TSOptionalCodeDirectoryFlags(void) {
    return @[
        @{@"name": @"hard", @"title": @"CS_HARD (Require strict code-page validation)", @"detail": @"Requests stricter integrity checks for executable code pages."},
        @{@"name": @"kill", @"title": @"CS_KILL (Terminate when validation fails)", @"detail": @"Terminates the process when code-signature validation fails; a wrong setting can prevent launch."},
        @{@"name": @"check-expiration", @"title": @"CS_CHECK_EXPIRATION (Check signature expiration)", @"detail": @"Enables signature-expiration checks; expired signing material may affect launch."},
        @{@"name": @"restrict", @"title": @"CS_RESTRICT (Restricted execution)", @"detail": @"Marks restricted code and may trigger additional system security policy."},
        @{@"name": @"enforcement", @"title": @"CS_ENFORCEMENT (Enforce code-signing policy)", @"detail": @"Requests enforcement of code-signing policy; do not add casually to third-party apps."},
        @{@"name": @"get-task-allow", @"title": @"CS_GET_TASK_ALLOW (Allow debugger attachment)", @"detail": @"Allows debugger task access; it does not itself grant debugging entitlements."},
        @{@"name": @"require-lv", @"title": @"CS_REQUIRE_LV (Require library validation)", @"detail": @"Requires dynamic libraries to pass library validation; may block unvalidated injected libraries."},
        @{@"name": @"runtime", @"title": @"CS_RUNTIME (Hardened runtime)", @"detail": @"Enables hardened-runtime semantics and may require a compatible CodeDirectory version and runtime configuration."},
        @{@"name": @"linker-signed", @"title": @"CS_LINKER_SIGNED (Linker-signed code)", @"detail": @"Marks code signed with linker participation; normally determined by the build/signing pipeline."},
        @{@"name": @"nvram-unrestricted", @"title": @"CS_NVRAM_UNRESTRICTED (Privileged NVRAM entitlement)", @"detail": @"System/entitlement-derived privilege bit. Locked: adding the bit alone does not grant the required entitlement." , @"locked": @YES}
    ];
}


@interface TSSigningSettingsController () <UIDocumentPickerDelegate>
@property(nonatomic, copy) NSString *pendingImportKind;
@property(nonatomic, strong) NSData *pendingCertificateData;
@property(nonatomic, copy) NSString *pendingCertificateName;
@property(nonatomic, copy) NSString *pendingProfileCredentialID;
@end

@interface TSSigningCertificateDetailController : UITableViewController
@property(nonatomic, copy) NSString *credentialIdentifier;
@end

@interface TSSigningTemplateDetailController : UITableViewController
@property(nonatomic, copy) NSString *mode;
@property(nonatomic, copy) NSDictionary *templateDefinition;
@end

@interface TSSigningProvisioningProfileDetailController : UITableViewController
@property(nonatomic, copy) NSString *credentialIdentifier;
@property(nonatomic, copy) NSDictionary *profileDetails;
@end

@implementation TSSigningSettingsController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Signing Method", nil);
    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleInsetGrouped];
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 68.0;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", nil) style:UIBarButtonItemStyleDone target:self action:@selector(donePressed)];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadSigningData) name:@"TSSigningConfigurationChanged" object:nil];
    [self reloadSigningData];
}
- (void)dealloc { [[NSNotificationCenter defaultCenter] removeObserver:self]; }
- (void)donePressed { [self dismissViewControllerAnimated:YES completion:nil]; }
- (void)reloadSigningData { dispatch_async(dispatch_get_main_queue(), ^{ [self.tableView reloadData]; }); }

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    NSString *mode = [TSSigningManager signingMode];
    if ([mode isEqualToString:@"real"]) return 4;
    if ([mode isEqualToString:@"certificate-only"]) return 3;
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSString *mode = [TSSigningManager signingMode];
    NSInteger flagSection = [mode isEqualToString:@"real"] ? 3 : ([mode isEqualToString:@"certificate-only"] ? 2 : 1);
    if (section == flagSection) {
        BOOL certificateMode = [mode isEqualToString:@"real"] || [mode isEqualToString:@"certificate-only"];
        return (NSInteger)TSOptionalCodeDirectoryFlags().count + 1 + (certificateMode ? 1 : 0);
    }
    if (section == 0) return 3;
    if (section == 1) {
        NSUInteger importActions = [mode isEqualToString:@"real"] ? 3 : 2;
        return [TSSigningManager credentialRecords].count + importActions;
    }
    return [mode isEqualToString:@"real"] ? [TSSigningManager templateDefinitionsForMode:mode].count : 0;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    NSString *mode = [TSSigningManager signingMode];
    if (section == 0) return NSLocalizedString(@"Signing Method", nil);
    if (section == 1 && ([mode isEqualToString:@"real"] || [mode isEqualToString:@"certificate-only"])) return NSLocalizedString(@"Certificates and Identities", nil);
    if (section == 2 && [mode isEqualToString:@"real"]) return NSLocalizedString(@"Real Signing Template", nil);
    if (section == ([mode isEqualToString:@"real"] ? 3 : ([mode isEqualToString:@"certificate-only"] ? 2 : 1))) return NSLocalizedString(@"CodeDirectory Flags", nil);
    return nil;
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    NSString *mode = [TSSigningManager signingMode];
    if (section == 0) {
        return NSLocalizedString(@"Pure Certificate Signing creates a genuine CMS signature with your certificate and private key but deliberately embeds no provisioning profile. Real Signing uses a matching Apple provisioning profile. TrollStore Signing uses the TrollStore CoreTrust path and does not need a certificate or profile. A CMS signature alone does not guarantee installation or launch on ordinary iOS devices.", nil);
    }
    if (section == 1 && [mode isEqualToString:@"certificate-only"]) {
        return NSLocalizedString(@"Import a P12 identity or a matching PEM certificate/private-key pair. Pure Certificate Signing uses this identity to generate CMS signatures and removes embedded.mobileprovision from the app and nested extensions. Any profile stored on the identity is ignored in this mode.", nil);
    }
    if (section == 1 && [mode isEqualToString:@"real"]) {
        return NSLocalizedString(@"The first imported identity becomes the default. P12 stores the certificate and private key together; PEM imports require a certificate PEM and its matching private-key PEM. Attach a current provisioning profile that matches the selected certificate, App ID and target distribution method.", nil);
    }
    if (section == 2 && [mode isEqualToString:@"real"]) {
        return NSLocalizedString(@"Every Real Signing template requires a matching .mobileprovision. Most presets select ldid hash and worker settings; Apple Internal Development additionally runs the strict AppleInternalProfile CMS and trusted-root policy. No template creates Apple certificates, private keys or provisioning profiles.", nil);
    }
    if (section == ([mode isEqualToString:@"real"] ? 3 : ([mode isEqualToString:@"certificate-only"] ? 2 : 1))) {
        return NSLocalizedString(@"For Real Signing and Pure Certificate Signing, ldid --deep always signs nested code and the Super Deep switch enables unlimited-depth recursive signing. Ad-hoc and CodeDirectory flags are managed independently. Some flags can prevent launch or weaken compatibility; enable only when the target binary requires them.", nil);
    }
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView estimatedHeightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return indexPath.section == 1 ? 82.0 : 64.0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SigningCell"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"SigningCell"];
    cell.accessoryType = UITableViewCellAccessoryNone;
    cell.accessoryView = nil;
    cell.detailTextLabel.text = nil;
    cell.detailTextLabel.textColor = UIColor.secondaryLabelColor;
    cell.detailTextLabel.numberOfLines = 0;
    cell.detailTextLabel.lineBreakMode = NSLineBreakByWordWrapping;
    cell.textLabel.numberOfLines = 2;
    cell.textLabel.lineBreakMode = NSLineBreakByTruncatingMiddle;
    cell.textLabel.adjustsFontForContentSizeCategory = YES;
    cell.textLabel.font = [UIFont systemFontOfSize:16.0 weight:UIFontWeightMedium];
    cell.detailTextLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleCaption1];
    cell.contentView.layoutMargins = UIEdgeInsetsMake(8.0, 16.0, 8.0, 16.0);
    cell.textLabel.textColor = UIColor.labelColor;
    NSString *mode = [TSSigningManager signingMode];
    if (indexPath.section == 0) {
        NSArray<NSString *> *titles = @[
            NSLocalizedString(@"Pure Certificate Signing", nil),
            NSLocalizedString(@"Real Signing", nil),
            NSLocalizedString(@"TrollStore Signing", nil)
        ];
        NSArray<NSString *> *details = @[
            NSLocalizedString(@"Genuine CMS · No provisioning profile", nil),
            NSLocalizedString(@"Genuine CMS · Matching profile required", nil),
            NSLocalizedString(@"Ad-hoc / CoreTrust · No profile needed", nil)
        ];
        cell.textLabel.text = titles[indexPath.row];
        cell.detailTextLabel.text = details[indexPath.row];
        if (indexPath.row == 2) cell.textLabel.textColor = UIColor.systemRedColor;
        NSString *rowMode = @[@"certificate-only", @"real", @"troll"][indexPath.row];
        if ([mode isEqualToString:rowMode]) cell.accessoryType = UITableViewCellAccessoryCheckmark;
        return cell;
    }

    if (indexPath.section == 1 && ([mode isEqualToString:@"real"] || [mode isEqualToString:@"certificate-only"])) {
        NSArray *records = [TSSigningManager credentialRecords];
        if (indexPath.row < records.count) {
            NSDictionary *record = records[indexPath.row];
            NSString *identifier = record[@"id"];
            cell.textLabel.text = record[@"label"] ?: record[@"fileName"] ?: NSLocalizedString(@"Unnamed Certificate", nil);
            NSString *format = [record[@"format"] isEqualToString:@"pem"] ? @"PEM + KEY" : @"P12";
            NSMutableString *detail = [NSMutableString stringWithFormat:@"%@ · %@", format, record[@"issuer"] ?: NSLocalizedString(@"Issuer unavailable", nil)];
            NSDictionary *profile = [TSSigningManager provisioningProfileDetailsForCredentialIdentifier:identifier];
            if (profile) {
                [detail appendFormat:@"\n%@ · %@ · %@", profile[@"profileType"] ?: NSLocalizedString(@"Profile attached", nil), [profile[@"entitlements"] count] ? [NSString stringWithFormat:NSLocalizedString(@"%lu Entitlements", nil), (unsigned long)[profile[@"entitlements"] count]] : NSLocalizedString(@"No Entitlements", nil), [profile[@"certificateMatch"] boolValue] ? NSLocalizedString(@"Certificate matched", nil) : NSLocalizedString(@"Certificate mismatch", nil)];
                if ([mode isEqualToString:@"certificate-only"]) [detail appendFormat:@"\n%@", NSLocalizedString(@"Stored profile is ignored in Pure Certificate Signing", nil)];
                if ([profile[@"appleInternalProfile"] boolValue]) [detail appendFormat:@"\n%@", NSLocalizedString(@"Apple Internal Profile marker detected", nil)];
            }
            cell.detailTextLabel.text = detail;
            if ([[TSSigningManager defaultCredentialIdentifier] isEqualToString:identifier]) cell.accessoryType = UITableViewCellAccessoryCheckmark;
        } else {
            NSUInteger action = indexPath.row - records.count;
            NSArray<NSString *> *titles = [mode isEqualToString:@"real"]
                ? @[NSLocalizedString(@"Import P12 Identity…", nil), NSLocalizedString(@"Import PEM Certificate + Key…", nil), NSLocalizedString(@"Import Provisioning Profile…", nil)]
                : @[NSLocalizedString(@"Import P12 Identity…", nil), NSLocalizedString(@"Import PEM Certificate + Key…", nil)];
            cell.textLabel.text = titles[action];
            cell.textLabel.textColor = [TSThemeManager accentColor];
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
        return cell;
    }

    NSInteger flagSection = [mode isEqualToString:@"real"] ? 3 : ([mode isEqualToString:@"certificate-only"] ? 2 : 1);
    if (indexPath.section == flagSection) {
        BOOL certificateMode = [mode isEqualToString:@"real"] || [mode isEqualToString:@"certificate-only"];
        if (indexPath.row == 0) {
            BOOL adhocRequired = [mode isEqualToString:@"troll"];
            cell.textLabel.text = NSLocalizedString(@"CS_ADHOC (Ad-hoc signature)", nil);
            cell.detailTextLabel.text = adhocRequired ? NSLocalizedString(@"Required by TrollStore Signing; managed automatically by ldid.", nil) : NSLocalizedString(@"Not used for certificate-based CMS signing; managed automatically by ldid.", nil);
            UISwitch *managedSwitch = [UISwitch new];
            managedSwitch.on = adhocRequired;
            managedSwitch.enabled = NO;
            cell.accessoryView = managedSwitch;
            return cell;
        }
        if (certificateMode && indexPath.row == 1) {
            cell.textLabel.text = NSLocalizedString(@"ldid Super Deep Signing", nil);
            cell.detailTextLabel.text = NSLocalizedString(@"Recursively signs nested apps, extensions, frameworks and embedded code at every discovered depth. Enabled by default for Real Signing and Pure Certificate Signing.", nil);
            UISwitch *toggle = [UISwitch new];
            id storedValue = [trollStoreUserDefaults() objectForKey:@"TSSigningSuperDeepEnabled"];
            toggle.on = storedValue ? [storedValue boolValue] : YES;
            toggle.accessibilityLabel = cell.textLabel.text;
            [toggle addTarget:self action:@selector(superDeepSigningChanged:) forControlEvents:UIControlEventValueChanged];
            cell.accessoryView = toggle;
            return cell;
        }
        NSInteger flagsOffset = certificateMode ? 2 : 1;
        NSInteger flagIndex = indexPath.row - flagsOffset;
        if (flagIndex < 0 || flagIndex >= (NSInteger)TSOptionalCodeDirectoryFlags().count) return cell;
        NSDictionary *flag = TSOptionalCodeDirectoryFlags()[(NSUInteger)flagIndex];
        cell.textLabel.text = NSLocalizedString(flag[@"title"], nil);
        cell.detailTextLabel.text = NSLocalizedString(flag[@"detail"], nil);
        UISwitch *toggle = [UISwitch new];
        NSDictionary *stored = [trollStoreUserDefaults() dictionaryForKey:TSCodeDirectoryFlagsDefaultsKey] ?: @{};
        toggle.on = [stored[flag[@"name"]] boolValue];
        toggle.accessibilityLabel = NSLocalizedString(flag[@"title"], nil);
        toggle.tag = (NSInteger)flagIndex;
        toggle.enabled = ![flag[@"locked"] boolValue];
        if (toggle.enabled) [toggle addTarget:self action:@selector(codeDirectoryFlagChanged:) forControlEvents:UIControlEventValueChanged];
        cell.accessoryView = toggle;
        return cell;
    }

    NSArray *templates = [TSSigningManager templateDefinitionsForMode:mode];
    NSDictionary *item = templates[indexPath.row];
    cell.textLabel.text = item[@"title"];
    if ([item[@"appleInternal"] boolValue]) {
        cell.detailTextLabel.text = NSLocalizedString(@"Apple Internal profile required · CMS signer and trusted-root validation", nil);
        cell.detailTextLabel.textColor = UIColor.systemOrangeColor;
    } else {
        cell.detailTextLabel.text = [NSString stringWithFormat:NSLocalizedString(@"Profile required · SHA-256 · up to %lu ldid jobs · view details", nil), [item[@"jobs"] unsignedIntegerValue]];
    }
    if ([[TSSigningManager selectedTemplateForMode:mode] isEqualToString:item[@"id"]]) cell.accessoryType = UITableViewCellAccessoryCheckmark;
    return cell;
}

- (void)superDeepSigningChanged:(UISwitch *)sender {
    [trollStoreUserDefaults() setBool:sender.isOn forKey:@"TSSigningSuperDeepEnabled"];
    [trollStoreUserDefaults() synchronize];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TSSigningConfigurationChanged" object:nil];
}

- (void)codeDirectoryFlagChanged:(UISwitch *)sender {
    NSArray *flags = TSOptionalCodeDirectoryFlags();
    if (sender.tag < 0 || sender.tag >= (NSInteger)flags.count) return;
    NSMutableDictionary *stored = [[trollStoreUserDefaults() dictionaryForKey:TSCodeDirectoryFlagsDefaultsKey] mutableCopy] ?: [NSMutableDictionary new];
    NSDictionary *flag = flags[(NSUInteger)sender.tag];
    if ([flag[@"locked"] boolValue]) return;
    NSString *name = flag[@"name"];
    if (sender.isOn) stored[name] = @YES; else [stored removeObjectForKey:name];
    [trollStoreUserDefaults() setObject:stored forKey:TSCodeDirectoryFlagsDefaultsKey];
    [trollStoreUserDefaults() synchronize];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSString *mode = [TSSigningManager signingMode];
    NSInteger flagSection = [mode isEqualToString:@"real"] ? 3 : ([mode isEqualToString:@"certificate-only"] ? 2 : 1);
    if (indexPath.section == flagSection) return;
    if (indexPath.section == 0) {
        NSArray<NSString *> *modes = @[@"certificate-only", @"real", @"troll"];
        [TSSigningManager setSigningMode:modes[indexPath.row]];
        [tableView reloadData];
        return;
    }
    if (indexPath.section == 2 && [mode isEqualToString:@"real"]) {
        NSArray *items = [TSSigningManager templateDefinitionsForMode:@"real"];
        TSSigningTemplateDetailController *detail = [TSSigningTemplateDetailController new];
        detail.mode = mode;
        detail.templateDefinition = items[indexPath.row];
        [self.navigationController pushViewController:detail animated:YES];
        return;
    }
    NSArray *records = [TSSigningManager credentialRecords];
    if (indexPath.row < records.count) { [self showCredentialActions:records[indexPath.row]]; return; }
    NSInteger action = indexPath.row - records.count;
    if (action == 0) [self pickDocumentForKind:@"p12"];
    else if (action == 1) [self pickDocumentForKind:@"pem-cert"];
    else if ([mode isEqualToString:@"real"] && action == 2) [self selectCredentialForProfile];
}

- (void)pickDocumentForKind:(NSString *)kind {
    self.pendingImportKind = kind;
    UTType *itemType = [UTType typeWithIdentifier:@"public.item"];
    UTType *dataType = [UTType typeWithIdentifier:@"public.data"];
    if (!itemType && !dataType) {
        self.pendingImportKind = nil;
        [self showMessage:NSLocalizedString(@"The system file type registry is unavailable. Restart the device or update iOS before importing signing files.", nil)];
        return;
    }

    // File Providers frequently expose .p12/.pem/.key as a generic item (or
    // vendor-specific UTType), not as public.data. Include the broad item type
    // and validate the selected file's actual bytes after the picker returns.
    NSMutableArray<UTType *> *contentTypes = [NSMutableArray array];
    for (NSString *identifier in @[@"public.item", @"public.content", @"public.data", @"public.text", @"public.plain-text"]) {
        UTType *type = [UTType typeWithIdentifier:identifier];
        if (type && ![contentTypes containsObject:type]) [contentTypes addObject:type];
    }
    NSArray<NSString *> *extensions = [kind isEqualToString:@"p12"] ? @[@"p12", @"pfx"] :
        ([kind isEqualToString:@"profile"] ? @[@"mobileprovision"] :
        ([kind isEqualToString:@"pem-key"] ? @[@"key", @"pem", @"p8"] : @[@"pem", @"cer", @"crt"]));
    for (NSString *extension in extensions) {
        UTType *type = [UTType typeWithFilenameExtension:extension conformingToType:(dataType ?: itemType)];
        if (type && ![contentTypes containsObject:type]) [contentTypes addObject:type];
    }
    if ([kind isEqualToString:@"p12"]) {
        UTType *pkcs12 = [UTType typeWithIdentifier:@"com.rsa.pkcs-12"];
        if (pkcs12 && ![contentTypes containsObject:pkcs12]) [contentTypes insertObject:pkcs12 atIndex:0];
    }
    if (dataType && ![contentTypes containsObject:dataType]) [contentTypes addObject:dataType];
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:contentTypes asCopy:YES];
    picker.delegate = self;
    picker.allowsMultipleSelection = NO;
    [self presentViewController:picker animated:YES completion:nil];
}
- (void)documentPickerWasCancelled:(UIDocumentPickerViewController *)controller {
    if ([self.pendingImportKind isEqualToString:@"pem-key"]) {
        self.pendingCertificateData = nil;
        self.pendingCertificateName = nil;
    }
    self.pendingImportKind = nil;
}
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSURL *url = urls.firstObject;
    if (!url) return;
    NSString *kind = [self.pendingImportKind copy];
    self.pendingImportKind = nil;
    NSString *credentialID = [self.pendingProfileCredentialID copy];
    BOOL scoped = [url startAccessingSecurityScopedResource];
    [TSPresentationDelegate startActivity:NSLocalizedString(@"Reading Signing File", nil)];

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        __block NSError *readError = nil;
        __block NSData *data = nil;
        NSFileCoordinator *coordinator = [[NSFileCoordinator alloc] initWithFilePresenter:nil];
        BOOL coordinated = [coordinator coordinateReadingItemAtURL:url options:NSFileCoordinatorReadingWithoutChanges error:&readError byAccessor:^(NSURL *coordinatedURL) {
            struct stat fileStat;
            if (!coordinatedURL.isFileURL || stat(coordinatedURL.fileSystemRepresentation, &fileStat) != 0 || !S_ISREG(fileStat.st_mode)) {
                readError = [NSError errorWithDomain:@"com.opa334.TrollStore.SigningImport" code:2 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"The selected item is not an accessible regular file. In Files, download it locally and try again.", nil)}];
                return;
            }
            if (fileStat.st_size > 64LL * 1024LL * 1024LL) {
                readError = [NSError errorWithDomain:@"com.opa334.TrollStore.SigningImport" code:1 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"The selected signing file exceeds the 64 MiB import limit.", nil)}];
                return;
            }
            NSError *resourceError = nil;
            NSNumber *fileSize = nil;
            [coordinatedURL getResourceValue:&fileSize forKey:NSURLFileSizeKey error:&resourceError];
            if (fileSize && fileSize.unsignedLongLongValue > 64ULL * 1024ULL * 1024ULL) {
                readError = [NSError errorWithDomain:@"com.opa334.TrollStore.SigningImport" code:1 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"The selected signing file exceeds the 64 MiB import limit.", nil)}];
                return;
            }
            data = [NSData dataWithContentsOfURL:coordinatedURL options:0 error:&readError];
            if (data.length > 64ULL * 1024ULL * 1024ULL) {
                data = nil;
                readError = [NSError errorWithDomain:@"com.opa334.TrollStore.SigningImport" code:1 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"The selected signing file exceeds the 64 MiB import limit.", nil)}];
            }
        }];

        // Some third-party File Providers reject NSFileCoordinator even for a
        // local copied URL. If coordination failed, make one bounded direct-read
        // attempt while the security-scoped resource is still active.
        if ((!coordinated || !data.length) && url.isFileURL) {
            struct stat fileStat;
            if (stat(url.fileSystemRepresentation, &fileStat) == 0 && S_ISREG(fileStat.st_mode) &&
                fileStat.st_size >= 0 && fileStat.st_size <= 64LL * 1024LL * 1024LL) {
                NSError *directReadError = nil;
                NSData *directData = [NSData dataWithContentsOfURL:url options:0 error:&directReadError];
                if (directData.length && directData.length <= 64ULL * 1024ULL * 1024ULL) {
                    data = directData;
                    readError = nil;
                } else if (directReadError) {
                    readError = directReadError;
                }
            }
        }

        NSError *error = readError;
        BOOL profileImported = NO;
        if (data.length && [kind isEqualToString:@"profile"]) {
            profileImported = [TSSigningManager importProvisioningProfileData:data forCredentialIdentifier:credentialID fileName:url.lastPathComponent error:&error];
        }
        if (scoped) [url stopAccessingSecurityScopedResource];

        dispatch_async(dispatch_get_main_queue(), ^{
            [TSPresentationDelegate stopActivityWithCompletion:^{
                if (!data.length) {
                    if ([kind isEqualToString:@"pem-key"]) {
                        self.pendingCertificateData = nil;
                        self.pendingCertificateName = nil;
                    }
                    NSString *message = error.localizedDescription ?: NSLocalizedString(@"The file provider returned no readable bytes. Save the file to On My iPhone and retry.", nil);
                    [self showMessage:message];
                    return;
                }
                if ([kind isEqualToString:@"p12"]) {
                    [self promptForPasswordForP12:data fileName:url.lastPathComponent];
                } else if ([kind isEqualToString:@"pem-cert"]) {
                    self.pendingCertificateData = data;
                    self.pendingCertificateName = url.lastPathComponent;
                    [self pickDocumentForKind:@"pem-key"];
                } else if ([kind isEqualToString:@"pem-key"]) {
                    [self promptForPasswordForPEMKey:data fileName:self.pendingCertificateName];
                } else if ([kind isEqualToString:@"profile"]) {
                    if (profileImported) {
                        [self.tableView reloadData];
                        [self showProvisioningProfileDetailsForCredentialIdentifier:credentialID];
                    } else {
                        [self showMessage:error.localizedDescription ?: NSLocalizedString(@"The provisioning profile could not be imported.", nil)];
                    }
                }
            }];
        });
    });
}

- (void)promptForPasswordForP12:(NSData *)data fileName:(NSString *)name {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"P12 Password", nil) message:NSLocalizedString(@"Enter the password protecting this P12 identity. Leave empty when it has no password.", nil) preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) { field.secureTextEntry = YES; field.placeholder = NSLocalizedString(@"Password", nil); }];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Import", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        NSString *password = alert.textFields.firstObject.text ?: @"";
        [TSPresentationDelegate startActivity:NSLocalizedString(@"Importing Certificate", nil)];
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            NSError *error = nil;
            BOOL success = [TSSigningManager importPKCS12Data:data fileName:name password:password error:&error];
            dispatch_async(dispatch_get_main_queue(), ^{
                [TSPresentationDelegate stopActivityWithCompletion:^{
                    [self showMessage:success ? NSLocalizedString(@"Certificate identity imported. It is the default when this is the first identity.", nil) : error.localizedDescription];
                }];
            });
        });
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)promptForPasswordForPEMKey:(NSData *)keyData fileName:(NSString *)name {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"PEM Private Key Password", nil) message:NSLocalizedString(@"Enter the password for an encrypted PEM private key, or leave empty for an unencrypted key.", nil) preferredStyle:UIAlertControllerStyleAlert];
    [alert addTextFieldWithConfigurationHandler:^(UITextField *field) { field.secureTextEntry = YES; field.placeholder = NSLocalizedString(@"Password", nil); }];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *a) {
        self.pendingCertificateData = nil;
        self.pendingCertificateName = nil;
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Import", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        NSData *certificateData = self.pendingCertificateData;
        NSString *password = alert.textFields.firstObject.text ?: @"";
        [TSPresentationDelegate startActivity:NSLocalizedString(@"Importing Certificate", nil)];
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            NSError *error = nil;
            BOOL success = [TSSigningManager importPEMCertificateData:certificateData privateKeyData:keyData fileName:name password:password error:&error];
            dispatch_async(dispatch_get_main_queue(), ^{
                self.pendingCertificateData = nil;
                self.pendingCertificateName = nil;
                [TSPresentationDelegate stopActivityWithCompletion:^{
                    [self showMessage:success ? NSLocalizedString(@"PEM certificate and private key imported.", nil) : error.localizedDescription];
                }];
            });
        });
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)selectCredentialForProfile {
    NSArray *records = [TSSigningManager credentialRecords];
    if (!records.count) { [self showMessage:NSLocalizedString(@"Import a certificate identity first.", nil)]; return; }
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Attach Provisioning Profile", nil) message:NSLocalizedString(@"Choose the identity that this profile belongs to.", nil) preferredStyle:UIAlertControllerStyleActionSheet];
    for (NSDictionary *record in records) [alert addAction:[UIAlertAction actionWithTitle:record[@"label"] ?: record[@"fileName"] style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { self.pendingProfileCredentialID = record[@"id"]; [self pickDocumentForKind:@"profile"]; }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    alert.popoverPresentationController.sourceView = self.view; alert.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width/2, self.view.bounds.size.height/2, 1, 1);
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)showProvisioningProfileDetailsForCredentialIdentifier:(NSString *)identifier {
    TSSigningProvisioningProfileDetailController *details = [TSSigningProvisioningProfileDetailController new];
    details.credentialIdentifier = identifier;
    [self.navigationController pushViewController:details animated:YES];
}

- (void)showCredentialActions:(NSDictionary *)record {
    NSString *identifier = record[@"id"];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:record[@"label"] message:record[@"issuer"] preferredStyle:UIAlertControllerStyleActionSheet];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"View Certificate Details", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { TSSigningCertificateDetailController *details = [TSSigningCertificateDetailController new]; details.credentialIdentifier = identifier; [self.navigationController pushViewController:details animated:YES]; }]];
    if (![[TSSigningManager signingMode] isEqualToString:@"certificate-only"] && [record[@"profilePath"] isKindOfClass:NSString.class] && [record[@"profilePath"] length]) {
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"View Provisioning Profile Details", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [self showProvisioningProfileDetailsForCredentialIdentifier:identifier]; }]];
    }
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Set as Default", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [TSSigningManager setDefaultCredentialIdentifier:identifier]; [self.tableView reloadData]; }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Certificate", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) { [self confirmDeleteCredential:identifier]; }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    alert.popoverPresentationController.sourceView = self.view; alert.popoverPresentationController.sourceRect = CGRectMake(self.view.bounds.size.width/2, self.view.bounds.size.height/2, 1, 1);
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)confirmDeleteCredential:(NSString *)identifier {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Delete Certificate?", nil) message:NSLocalizedString(@"The certificate identity and its stored private-key material will be deleted from TrollStore.", nil) preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) { [TSSigningManager deleteCredentialWithIdentifier:identifier]; [self.tableView reloadData]; }]];
    [self presentViewController:alert animated:YES completion:nil];
}
- (void)showMessage:(NSString *)message {
    if (!message.length) message = NSLocalizedString(@"Completed.", nil);
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Signing", nil) message:message preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleDefault handler:nil]];
    [self presentViewController:alert animated:YES completion:^{ [self.tableView reloadData]; }];
}
@end

@implementation TSSigningCertificateDetailController
- (void)viewDidLoad { [super viewDidLoad]; self.title = NSLocalizedString(@"Certificate Details", nil); self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleInsetGrouped]; self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", nil) style:UIBarButtonItemStyleDone target:self action:@selector(donePressed)]; }
- (void)donePressed { [self.navigationController popViewControllerAnimated:YES]; }
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return [[TSSigningManager signingMode] isEqualToString:@"troll"] ? 2 : 3; }
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return @[NSLocalizedString(@"Issuer", nil), NSLocalizedString(@"Validity Period", nil), NSLocalizedString(@"OIDs", nil)][section];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSDictionary *d = [TSSigningManager certificateDetailsForCredentialIdentifier:self.credentialIdentifier] ?: @{};
    if (section == 0) return 1;
    if (section == 1) return 2;
    return [d[@"oids"] count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CertificateDetail"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"CertificateDetail"];
    NSDictionary *d = [TSSigningManager certificateDetailsForCredentialIdentifier:self.credentialIdentifier] ?: @{};
    if (indexPath.section == 0) { cell.textLabel.text = NSLocalizedString(@"Issuer", nil); cell.detailTextLabel.text = d[@"issuer"]; }
    else if (indexPath.section == 1) { BOOL before = indexPath.row == 0; cell.textLabel.text = before ? NSLocalizedString(@"Valid From", nil) : NSLocalizedString(@"Valid Until", nil); cell.detailTextLabel.text = d[before ? @"notBefore" : @"notAfter"]; }
    else { NSString *oid = d[@"oids"][indexPath.row]; cell.textLabel.text = oid; cell.detailTextLabel.text = NSLocalizedString(@"Certificate Extension / Field OID", nil); cell.textLabel.font = [UIFont monospacedSystemFontOfSize:13 weight:UIFontWeightRegular]; }
    cell.textLabel.numberOfLines = 0; cell.detailTextLabel.numberOfLines = 0; cell.selectionStyle = UITableViewCellSelectionStyleNone; return cell;
}
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section { return section == 2 ? NSLocalizedString(@"OID list is read from the certificate extension/field dictionary. A certificate signature alone does not guarantee app installation or launch authorization.", nil) : nil; }
@end

@implementation TSSigningProvisioningProfileDetailController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Provisioning Profile Details", nil);
    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleInsetGrouped];
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 58.0;
    self.profileDetails = [TSSigningManager provisioningProfileDetailsForCredentialIdentifier:self.credentialIdentifier] ?: @{};
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", nil) style:UIBarButtonItemStyleDone target:self action:@selector(donePressed)];
}
- (void)donePressed { [self.navigationController popViewControllerAnimated:YES]; }
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 4; }
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return @[NSLocalizedString(@"Profile Information", nil), NSLocalizedString(@"Distribution & Device Access", nil), NSLocalizedString(@"Certificates Included in Profile", nil), NSLocalizedString(@"Profile Entitlements", nil)][section];
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) return 8;
    if (section == 1) return 10;
    if (section == 2) return MAX(1, [self.profileDetails[@"developerCertificates"] count]);
    return MAX(1, [self.profileDetails[@"entitlements"] count]);
}
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    if (section == 1) return NSLocalizedString(@"Profile metadata is descriptive. Device registration, App ID and entitlement restrictions are enforced by Apple's provisioning and installation services.", nil);
    if (section == 2) return NSLocalizedString(@"Certificate matching compares the imported identity's DER certificate with the DeveloperCertificates embedded in this profile. The profile's CMS container is parsed for display, but this screen does not cryptographically verify the CMS signature or Apple's certificate trust chain.", nil);
    if (section == 3) return NSLocalizedString(@"These are the Entitlements authorized by the provisioning profile, not a guarantee that every capability will be usable on every device or iOS version.", nil);
    return nil;
}
- (NSString *)formattedValue:(id)value {
    if (!value || value == NSNull.null) return NSLocalizedString(@"Unavailable", nil);
    if ([value isKindOfClass:NSString.class]) return [value length] ? value : NSLocalizedString(@"Unavailable", nil);
    if ([NSJSONSerialization isValidJSONObject:value]) {
        NSData *json = [NSJSONSerialization dataWithJSONObject:value options:NSJSONWritingPrettyPrinted error:nil];
        NSString *text = json ? [[NSString alloc] initWithData:json encoding:NSUTF8StringEncoding] : nil;
        if (text.length) return text;
    }
    return [value description] ?: NSLocalizedString(@"Unavailable", nil);
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ProvisioningProfileDetail"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"ProvisioningProfileDetail"];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.textLabel.numberOfLines = 0;
    cell.detailTextLabel.numberOfLines = 0;
    cell.detailTextLabel.textColor = UIColor.secondaryLabelColor;
    NSDictionary *d = self.profileDetails ?: @{};
    if (indexPath.section == 0) {
        NSArray *titles = @[NSLocalizedString(@"Profile Name", nil), NSLocalizedString(@"UUID", nil), NSLocalizedString(@"App ID Name", nil), NSLocalizedString(@"Team Name", nil), NSLocalizedString(@"Team Identifier", nil), NSLocalizedString(@"Application Identifier", nil), NSLocalizedString(@"Created", nil), NSLocalizedString(@"Expires", nil)];
        NSArray *keys = @[@"name", @"uuid", @"appIDName", @"teamName", @"teamIdentifier", @"applicationIdentifier", @"creationDate", @"expirationDate"];
        cell.textLabel.text = titles[indexPath.row];
        cell.detailTextLabel.text = [self formattedValue:d[keys[indexPath.row]]];
        if (indexPath.row == 7 && [d[@"expired"] boolValue]) cell.detailTextLabel.textColor = UIColor.systemRedColor;
    } else if (indexPath.section == 1) {
        NSArray *titles = @[NSLocalizedString(@"Profile Type", nil), NSLocalizedString(@"Platform", nil), NSLocalizedString(@"Application Identifier Prefix", nil), NSLocalizedString(@"Registered Devices", nil), NSLocalizedString(@"All Devices", nil), NSLocalizedString(@"get-task-allow", nil), NSLocalizedString(@"Xcode Managed", nil), NSLocalizedString(@"CMS Signers", nil), NSLocalizedString(@"Apple Internal Profile", nil), NSLocalizedString(@"DER-Encoded-Profile", nil)];
        NSArray *values = @[d[@"profileType"] ?: @"", d[@"platform"] ?: @"", d[@"applicationIdentifierPrefix"] ?: @"", [NSString stringWithFormat:@"%@ (%lu)", [d[@"provisionedDeviceCount"] unsignedIntegerValue] ? NSLocalizedString(@"Device limited", nil) : NSLocalizedString(@"No device list", nil), (unsigned long)[d[@"provisionedDeviceCount"] unsignedIntegerValue]], [d[@"provisionsAllDevices"] boolValue] ? NSLocalizedString(@"Yes", nil) : NSLocalizedString(@"No", nil), [d[@"getTaskAllow"] boolValue] ? NSLocalizedString(@"Enabled", nil) : NSLocalizedString(@"Disabled", nil), [d[@"isXcodeManaged"] boolValue] ? NSLocalizedString(@"Yes", nil) : NSLocalizedString(@"No", nil), [NSString stringWithFormat:@"%lu", (unsigned long)[d[@"cmsSignerCount"] unsignedIntegerValue]], [d[@"appleInternalProfile"] boolValue] ? NSLocalizedString(@"Yes — AppleInternalProfile = true", nil) : NSLocalizedString(@"No — standard provisioning profile", nil), [d[@"hasDEREncodedProfile"] boolValue] ? NSLocalizedString(@"Present", nil) : NSLocalizedString(@"Not present (optional)", nil)];
        cell.textLabel.text = titles[indexPath.row];
        cell.detailTextLabel.text = [self formattedValue:values[indexPath.row]];
        if ((indexPath.row == 5 && [d[@"getTaskAllow"] boolValue]) || (indexPath.row == 6 && [d[@"isXcodeManaged"] boolValue])) cell.detailTextLabel.textColor = UIColor.systemYellowColor;
        if (indexPath.row == 8) cell.detailTextLabel.textColor = [d[@"appleInternalProfile"] boolValue] ? UIColor.systemGreenColor : UIColor.secondaryLabelColor;
        if (indexPath.row == 9) cell.detailTextLabel.textColor = [d[@"hasDEREncodedProfile"] boolValue] ? UIColor.systemGreenColor : UIColor.secondaryLabelColor;
    } else if (indexPath.section == 2) {
        NSArray *certificates = [d[@"developerCertificates"] isKindOfClass:NSArray.class] ? d[@"developerCertificates"] : @[];
        if (!certificates.count) {
            cell.textLabel.text = NSLocalizedString(@"No developer certificates were found in this profile.", nil);
            cell.detailTextLabel.text = nil;
        } else {
            NSDictionary *cert = certificates[indexPath.row];
            BOOL matched = [cert[@"matchesImportedIdentity"] boolValue];
            cell.textLabel.text = cert[@"label"] ?: cert[@"subject"] ?: NSLocalizedString(@"Unnamed Certificate", nil);
            NSMutableArray<NSString *> *certificateLines = [NSMutableArray array];
            [certificateLines addObject:matched ? NSLocalizedString(@"Selected identity · MATCH", nil) : NSLocalizedString(@"Other profile certificate", nil)];
            [certificateLines addObject:[NSString stringWithFormat:NSLocalizedString(@"Subject: %@", nil), cert[@"subject"] ?: @""]];
            [certificateLines addObject:[NSString stringWithFormat:NSLocalizedString(@"Issuer: %@", nil), cert[@"issuer"] ?: @""]];
            [certificateLines addObject:[NSString stringWithFormat:NSLocalizedString(@"Valid From: %@", nil), cert[@"notBefore"] ?: @""]];
            [certificateLines addObject:[NSString stringWithFormat:NSLocalizedString(@"Valid Until: %@", nil), cert[@"notAfter"] ?: @""]];
            [certificateLines addObject:[NSString stringWithFormat:NSLocalizedString(@"SHA-256: %@", nil), cert[@"sha256"] ?: @""]];
            NSArray *oids = [cert[@"oids"] isKindOfClass:NSArray.class] ? cert[@"oids"] : @[];
            if (oids.count) [certificateLines addObject:[NSString stringWithFormat:NSLocalizedString(@"Extensions / OIDs: %@", nil), [oids componentsJoinedByString:@", "]]];
            cell.detailTextLabel.text = [certificateLines componentsJoinedByString:@"\n"];
            cell.detailTextLabel.textColor = matched ? UIColor.systemGreenColor : UIColor.secondaryLabelColor;
        }
    } else {
        NSDictionary *entitlements = [d[@"entitlements"] isKindOfClass:NSDictionary.class] ? d[@"entitlements"] : @{};
        NSArray *keys = [[entitlements allKeys] sortedArrayUsingComparator:^NSComparisonResult(id a, id b) { return [[a description] compare:[b description]]; }];
        if (!keys.count) {
            cell.textLabel.text = NSLocalizedString(@"No profile Entitlements were found.", nil);
            cell.detailTextLabel.text = nil;
        } else {
            NSString *key = [keys[indexPath.row] description];
            cell.textLabel.text = key;
            cell.textLabel.font = [UIFont monospacedSystemFontOfSize:12 weight:UIFontWeightSemibold];
            cell.detailTextLabel.text = [self formattedValue:entitlements[keys[indexPath.row]]];
        }
    }
    return cell;
}
@end

@implementation TSSigningTemplateDetailController
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = self.templateDefinition[@"title"] ?: NSLocalizedString(@"Signing Template", nil);
    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleInsetGrouped];
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 64.0;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", nil) style:UIBarButtonItemStyleDone target:self action:@selector(donePressed)];
}
- (void)donePressed { [self.navigationController popViewControllerAnimated:YES]; }
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 2; }
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return section == 0 ? ([self.templateDefinition[@"appleInternal"] boolValue] ? 5 : 4) : 2; }
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return section == 0 ? NSLocalizedString(@"Template Configuration", nil) : NSLocalizedString(@"What This Template Means", nil);
}
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    if (section == 0) return NSLocalizedString(@"The profile type shown here must match the selected distribution method, App ID and signing certificate. The jobs value is a concurrency ceiling, not a promise that the device will run that many workers. SHA-256 is the selected CodeDirectory hash preference.", nil);
    return nil;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SigningTemplateDetail"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"SigningTemplateDetail"];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.textLabel.textColor = UIColor.labelColor;
    cell.detailTextLabel.textColor = UIColor.secondaryLabelColor;
    cell.detailTextLabel.numberOfLines = 0;
    if (indexPath.section == 0) {
        NSMutableArray *titles = [NSMutableArray arrayWithArray:@[NSLocalizedString(@"Hash Algorithm", nil), NSLocalizedString(@"Requested ldid Jobs", nil), NSLocalizedString(@"Preset Identifier", nil), NSLocalizedString(@"Provisioning Profile", nil)]];
        NSMutableArray *values = [NSMutableArray arrayWithArray:@[self.templateDefinition[@"hashType"] ?: @"sha256", [NSString stringWithFormat:@"%lu", [self.templateDefinition[@"jobs"] unsignedIntegerValue]], self.templateDefinition[@"id"] ?: @"", self.templateDefinition[@"profileType"] ?: NSLocalizedString(@"Matching profile required", nil)]];
        if ([self.templateDefinition[@"appleInternal"] boolValue]) {
            [titles addObject:NSLocalizedString(@"Required Profile Marker", nil)];
            [values addObject:@"AppleInternalProfile = true (boolean)"];
        }
        cell.textLabel.text = titles[indexPath.row];
        cell.detailTextLabel.numberOfLines = 0;
        cell.detailTextLabel.text = values[indexPath.row];
        if (indexPath.row == 3 || indexPath.row == 4) cell.detailTextLabel.textColor = UIColor.systemOrangeColor;
    } else {
        cell.textLabel.numberOfLines = 0;
        cell.detailTextLabel.text = nil;
        if (indexPath.row == 0) {
            cell.textLabel.text = self.templateDefinition[@"description"] ?: NSLocalizedString(@"No additional description is available.", nil);
        } else {
            cell.textLabel.text = self.templateDefinition[@"caveat"] ?: NSLocalizedString(@"A template is a signing configuration preset only. It cannot mint an Apple certificate, change a provisioning profile, grant entitlements, enable App Store distribution, perform notarization, or validate a certificate chain.", nil);
            cell.textLabel.textColor = UIColor.secondaryLabelColor;
        }
    }
    return cell;
}
- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section {
    if (section != 1) return nil;
    UIButton *use = [UIButton buttonWithType:UIButtonTypeSystem];
    [use setTitle:NSLocalizedString(@"Use This Template", nil) forState:UIControlStateNormal];
    use.titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleHeadline];
    [use addTarget:self action:@selector(useTemplatePressed) forControlEvents:UIControlEventTouchUpInside];
    UIView *container = [[UIView alloc] initWithFrame:CGRectMake(0, 0, CGRectGetWidth(tableView.bounds), 68)];
    use.translatesAutoresizingMaskIntoConstraints = NO; [container addSubview:use];
    [NSLayoutConstraint activateConstraints:@[[use.centerXAnchor constraintEqualToAnchor:container.centerXAnchor], [use.centerYAnchor constraintEqualToAnchor:container.centerYAnchor]]];
    return container;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section { return section == 1 ? 68 : UITableViewAutomaticDimension; }
- (void)useTemplatePressed {
    [TSSigningManager setSelectedTemplate:self.templateDefinition[@"id"] forMode:self.mode];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TSSigningConfigurationChanged" object:nil];
    [self.navigationController popViewControllerAnimated:YES];
}
@end

