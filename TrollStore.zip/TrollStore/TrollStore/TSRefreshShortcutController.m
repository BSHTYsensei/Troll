#import "TSRefreshShortcutController.h"
#import <TrollStore-Swift.h>

@implementation TSRefreshShortcutController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Refresh Shortcut", nil);
    self.view.backgroundColor = UIColor.systemGroupedBackgroundColor;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", nil) style:UIBarButtonItemStyleDone target:self action:@selector(donePressed)];

    UILabel *description = [UILabel new];
    description.translatesAutoresizingMaskIntoConstraints = NO;
    description.numberOfLines = 0;
    description.textAlignment = NSTextAlignmentCenter;
    description.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    description.textColor = UIColor.secondaryLabelColor;
    description.text = NSLocalizedString(@"Add TrollStore's Refresh Apps shortcut in Apple Shortcuts. Shortcuts remains a normal, separate app; TrollStore never injects the Persistence Helper into it. After adding the shortcut, create a Personal Automation (for example, Time of Day). The shortcut runs the registration refresh directly without opening the Persistence Helper or respringing.", nil);

    [self.view addSubview:description];
    [NSLayoutConstraint activateConstraints:@[
        [description.leadingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.leadingAnchor constant:24],
        [description.trailingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.trailingAnchor constant:-24],
        [description.centerYAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.centerYAnchor constant:-36]
    ]];

    UIViewController *linkController = [TSRefreshShortcutsLinkFactory makeViewController];
    if (linkController) {
        [self addChildViewController:linkController];
        UIView *linkView = linkController.view;
        linkView.translatesAutoresizingMaskIntoConstraints = NO;
        linkView.backgroundColor = UIColor.clearColor;
        [self.view addSubview:linkView];
        [NSLayoutConstraint activateConstraints:@[
            [linkView.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
            [linkView.topAnchor constraintEqualToAnchor:description.bottomAnchor constant:26],
            [linkView.heightAnchor constraintGreaterThanOrEqualToConstant:44],
            [linkView.widthAnchor constraintGreaterThanOrEqualToConstant:220]
        ]];
        [linkController didMoveToParentViewController:self];
    } else {
        UILabel *unsupported = [UILabel new];
        unsupported.translatesAutoresizingMaskIntoConstraints = NO;
        unsupported.text = NSLocalizedString(@"App Shortcuts require iOS 16 or later.", nil);
        unsupported.textColor = UIColor.secondaryLabelColor;
        [self.view addSubview:unsupported];
        [NSLayoutConstraint activateConstraints:@[
            [unsupported.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
            [unsupported.topAnchor constraintEqualToAnchor:description.bottomAnchor constant:26]
        ]];
    }
}

- (void)donePressed
{
    if (self.navigationController.presentingViewController) [self.navigationController dismissViewControllerAnimated:YES completion:nil];
    else [self.navigationController popViewControllerAnimated:YES];
}

@end
