#import "TSRefreshShortcutController.h"
#import <TrollStore-Swift.h>

@implementation TSRefreshShortcutController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Refresh Shortcut", nil);
    self.view.backgroundColor = UIColor.systemGroupedBackgroundColor;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", nil) style:UIBarButtonItemStyleDone target:self action:@selector(donePressed)];

    UILabel *description = [UILabel new];
    description.translatesAutoresizingMaskIntoConstraints = NO;
    description.numberOfLines = 0;
    description.textAlignment = NSTextAlignmentCenter;
    description.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    description.textColor = UIColor.secondaryLabelColor;
    description.text = NSLocalizedString(@"Add TrollStore's Refresh Apps shortcut in Apple Shortcuts. After adding it, create a Personal Automation (for example, Time of Day). The shortcut runs the registration refresh directly; it does not open the injected persistence helper or respring.", nil);

    [self.view addSubview:description];
    [NSLayoutConstraint activateConstraints:@[
        [description.leadingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.leadingAnchor constant:24],
        [description.trailingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.trailingAnchor constant:-24],
        [description.centerYAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.centerYAnchor constant:-36]
    ]];

    UIButton *addButton = [TSRefreshShortcutsButtonFactory makeButton];
    if (addButton) {
        addButton.translatesAutoresizingMaskIntoConstraints = NO;
        [self.view addSubview:addButton];
        [NSLayoutConstraint activateConstraints:@[
            [addButton.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
            [addButton.topAnchor constraintEqualToAnchor:description.bottomAnchor constant:26]
        ]];
    } else {
        UILabel *unsupported = [UILabel new];
        unsupported.translatesAutoresizingMaskIntoConstraints = NO;
        unsupported.text = NSLocalizedString(@"App Shortcuts require iOS 16 or later.", nil);
        unsupported.textColor = UIColor.secondaryLabelColor;
        [self.view addSubview:unsupported];
        [NSLayoutConstraint activateConstraints:@[
            [unsupported.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
            [unsupported.topAnchor constraintEqualToAnchor:description.bottomAnchor constant:26]
        ]];
    }
}

- (void)donePressed
{
    if (self.navigationController.presentingViewController) [self.navigationController dismissViewControllerAnimated:YES completion:nil];
    else [self.navigationController popViewControllerAnimated:YES];
}

@end
