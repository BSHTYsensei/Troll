#import "TSRefreshShortcutController.h"

@implementation TSRefreshShortcutController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Refresh Shortcut", nil);
    self.view.backgroundColor = UIColor.systemGroupedBackgroundColor;
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:NSLocalizedString(@"Done", nil) style:UIBarButtonItemStyleDone target:self action:@selector(donePressed)];

    UILabel *description = [UILabel new];
    description.translatesAutoresizingMaskIntoConstraints = NO;
    description.numberOfLines = 0;
    description.textAlignment = NSTextAlignmentCenter;
    description.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    description.textColor = UIColor.secondaryLabelColor;
    description.text = NSLocalizedString(@"Refresh Apps is provided by TrollStore as an App Shortcut as soon as TrollStore is installed. Tap Open Shortcuts, go to App Shortcuts, select TrollStore, then choose Refresh Apps. From there, use it in a new shortcut or create a Personal Automation. Shortcuts remains a separate system app; TrollStore never injects the Persistence Helper into it.", nil);

    UIButton *openButton = [UIButton buttonWithType:UIButtonTypeSystem];
    openButton.translatesAutoresizingMaskIntoConstraints = NO;
    if (@available(iOS 15.0, *)) {
        UIButtonConfiguration *configuration = [UIButtonConfiguration filledButtonConfiguration];
        configuration.title = NSLocalizedString(@"Open Shortcuts", nil);
        configuration.image = [UIImage systemImageNamed:@"arrow.up.forward.app"];
        configuration.imagePadding = 8.0;
        openButton.configuration = configuration;
    } else {
        [openButton setTitle:NSLocalizedString(@"Open Shortcuts", nil) forState:UIControlStateNormal];
    }
    [openButton addTarget:self action:@selector(openShortcutsPressed) forControlEvents:UIControlEventTouchUpInside];

    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:@[description, openButton]];
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    stack.axis = UILayoutConstraintAxisVertical;
    stack.alignment = UIStackViewAlignmentCenter;
    stack.spacing = 24.0;

    [self.view addSubview:stack];
    [NSLayoutConstraint activateConstraints:@[
        [stack.leadingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.leadingAnchor constant:24.0],
        [stack.trailingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.trailingAnchor constant:-24.0],
        [stack.centerYAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.centerYAnchor],
        [description.widthAnchor constraintEqualToAnchor:stack.widthAnchor],
        [openButton.heightAnchor constraintGreaterThanOrEqualToConstant:44.0],
        [openButton.widthAnchor constraintGreaterThanOrEqualToConstant:190.0]
    ]];
}

- (void)openShortcutsPressed
{
    // Apple documents `shortcuts://` as the supported way to open Shortcuts.
    // AppShortcutsProvider makes Refresh Apps discoverable automatically;
    // there is no supported public URL for jumping straight to one app's page.
    NSURL *url = [NSURL URLWithString:@"shortcuts://"];
    if (!url) return;

    [[UIApplication sharedApplication] openURL:url options:@{} completionHandler:^(BOOL success) {
        if (!success) {
            dispatch_async(dispatch_get_main_queue(), ^{
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Unable to Open Shortcuts", nil)
                                                                               message:NSLocalizedString(@"Open the Shortcuts app manually, then choose App Shortcuts and TrollStore.", nil)
                                                                        preferredStyle:UIAlertControllerStyleAlert];
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleDefault handler:nil]];
                [self presentViewController:alert animated:YES completion:nil];
            });
        }
    }];
}

- (void)donePressed
{
    if (self.navigationController.presentingViewController) [self.navigationController dismissViewControllerAnimated:YES completion:nil];
    else [self.navigationController popViewControllerAnimated:YES];
}

@end
