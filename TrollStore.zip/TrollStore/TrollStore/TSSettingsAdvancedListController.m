#import "TSSettingsAdvancedListController.h"
#import <TSUtil.h>
#import "TSThemeManager.h"

extern NSUserDefaults *trollStoreUserDefaults(void);

@interface TSSettingsAdvancedListController () <UITableViewDataSource, UITableViewDelegate>
@end

@implementation TSSettingsAdvancedListController

- (instancetype)init {
    return [super initWithStyle:UITableViewStyleInsetGrouped];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Advanced", nil);
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = UIColor.systemBackgroundColor;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.rowHeight = 64.0;
    self.tableView.sectionHeaderTopPadding = 8.0;
    self.tableView.tableFooterView = [UIView new];
    self.tableView.contentInset = UIEdgeInsetsMake(4.0, 0.0, 12.0, 0.0);
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 3; }

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return 1; }

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section == 2) return NSLocalizedString(@"Special Installation", nil);
    return nil;
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    if (section == 0) return NSLocalizedString(@"Installation Method Explanation", nil);
    if (section == 1) return NSLocalizedString(@"installd (Recommended):\nUninstalls applications using the same API that SpringBoard uses when uninstalling them from the home screen.\n\nCustom:\nUninstalls applications by removing them from icon cache and then deleting their application and data bundles directly.\n\nNOTE: In cases where installd is selected but the stock uninstallation fails, TrollStore automatically falls back to using the Custom method.", nil);
    return NSLocalizedString(@"When enabled, newly installed apps and apps updated through TrollStore are registered as non-deletable from the Home Screen. To remove a protected app, use TrollStore's in-app uninstall action. This is per-app, not a device-wide restriction. Turning this switch off affects future installs; an existing app's protection marker remains across updates until the app is uninstalled.", nil);
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *reuse = @"TSAdvancedNativeCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];
    cell.backgroundColor = UIColor.clearColor;
    cell.contentView.backgroundColor = UIColor.clearColor;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.accessoryView = nil;
    cell.textLabel.font = [UIFont systemFontOfSize:16.5 weight:UIFontWeightMedium];
    cell.textLabel.textColor = UIColor.labelColor;

    if (indexPath.section == 2) {
        cell.textLabel.text = NSLocalizedString(@"Make app undeletable from Home Screen", nil);
        UISwitch *control = [UISwitch new];
        control.onTintColor = TSThemeManager.accentColor;
        id stored = [trollStoreUserDefaults() objectForKey:@"TSProtectHomeScreenDeletionEnabled"];
        control.on = stored ? [stored boolValue] : NO;
        control.tag = 2;
        [control addTarget:self action:@selector(advancedSwitchChanged:) forControlEvents:UIControlEventValueChanged];
        cell.accessoryView = control;
    } else {
        BOOL installation = indexPath.section == 0;
        cell.textLabel.text = installation ? NSLocalizedString(@"Installation Method", nil) : NSLocalizedString(@"Uninstallation Method", nil);
        NSString *key = installation ? @"installationMethod" : @"uninstallationMethod";
        NSInteger fallback = installation ? 1 : 0;
        id stored = [trollStoreUserDefaults() objectForKey:key];
        NSInteger selected = stored ? [stored integerValue] : fallback;
        UISegmentedControl *control = [[UISegmentedControl alloc] initWithItems:@[@"installd", NSLocalizedString(@"Custom", nil)]];
        control.selectedSegmentIndex = selected == 1 ? 1 : 0;
        control.tag = (NSInteger)indexPath.section;
        [control addTarget:self action:@selector(advancedSegmentChanged:) forControlEvents:UIControlEventValueChanged];
        cell.accessoryView = control;
    }
    [TSThemeManager styleCardTableViewCell:cell];
    return cell;
}

- (void)advancedSegmentChanged:(UISegmentedControl *)sender {
    NSString *key = sender.tag == 0 ? @"installationMethod" : @"uninstallationMethod";
    [trollStoreUserDefaults() setInteger:sender.selectedSegmentIndex forKey:key];
}

- (void)advancedSwitchChanged:(UISwitch *)sender {
    [trollStoreUserDefaults() setBool:sender.on forKey:@"TSProtectHomeScreenDeletionEnabled"];
}

@end
