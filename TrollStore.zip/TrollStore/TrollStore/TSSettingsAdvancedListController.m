#import "TSSettingsAdvancedListController.h"
#import <TSUtil.h>
#import "TSThemeManager.h"

extern NSUserDefaults *trollStoreUserDefaults(void);

@interface TSAdvancedSettingCell : UITableViewCell
@property(nonatomic, strong) UILabel *titleLabel;
@property(nonatomic, strong) UISegmentedControl *segmentedControl;
@property(nonatomic, strong) UISwitch *switchControl;
@property(nonatomic, strong) NSLayoutConstraint *titleTopConstraint;
@property(nonatomic, strong) NSLayoutConstraint *titleCenterYConstraint;
@property(nonatomic, strong) NSLayoutConstraint *titleTrailingToSwitchConstraint;
@property(nonatomic, strong) NSArray<NSLayoutConstraint *> *segmentedLayoutConstraints;
@property(nonatomic, strong) NSArray<NSLayoutConstraint *> *switchLayoutConstraints;
- (void)configureAsSegmentedRowWithTitle:(NSString *)title items:(NSArray<NSString *> *)items selectedIndex:(NSInteger)selectedIndex target:(id)target action:(SEL)action;
- (void)configureAsSwitchRowWithTitle:(NSString *)title isOn:(BOOL)isOn target:(id)target action:(SEL)action;
@end

@implementation TSAdvancedSettingCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if ((self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuseIdentifier])) {
        self.backgroundColor = UIColor.clearColor;
        self.contentView.backgroundColor = UIColor.clearColor;
        self.selectionStyle = UITableViewCellSelectionStyleNone;

        _titleLabel = [UILabel new];
        _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _titleLabel.font = [UIFont systemFontOfSize:15.5 weight:UIFontWeightSemibold];
        _titleLabel.textColor = UIColor.labelColor;
        _titleLabel.textAlignment = NSTextAlignmentLeft;
        _titleLabel.numberOfLines = 1;
        _titleLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        [self.contentView addSubview:_titleLabel];

        _segmentedControl = [[UISegmentedControl alloc] initWithItems:@[]];
        _segmentedControl.translatesAutoresizingMaskIntoConstraints = NO;
        _segmentedControl.apportionsSegmentWidthsByContent = NO;
        _segmentedControl.backgroundColor = UIColor.tertiarySystemFillColor;
        _segmentedControl.selectedSegmentTintColor = UIColor.secondarySystemFillColor;
        NSDictionary *normal = @{
            NSForegroundColorAttributeName: UIColor.secondaryLabelColor,
            NSFontAttributeName: [UIFont systemFontOfSize:14.0 weight:UIFontWeightMedium]
        };
        NSDictionary *selected = @{
            NSForegroundColorAttributeName: UIColor.labelColor,
            NSFontAttributeName: [UIFont systemFontOfSize:14.0 weight:UIFontWeightSemibold]
        };
        [_segmentedControl setTitleTextAttributes:normal forState:UIControlStateNormal];
        [_segmentedControl setTitleTextAttributes:selected forState:UIControlStateSelected];
        [self.contentView addSubview:_segmentedControl];

        _switchControl = [UISwitch new];
        _switchControl.translatesAutoresizingMaskIntoConstraints = NO;
        _switchControl.onTintColor = TSThemeManager.accentColor;
        [self.contentView addSubview:_switchControl];

        self.contentView.directionalLayoutMargins = NSDirectionalEdgeInsetsMake(0.0, 16.0, 0.0, 16.0);
        UILayoutGuide *margins = self.contentView.layoutMarginsGuide;
        [NSLayoutConstraint activateConstraints:@[
            [_titleLabel.leadingAnchor constraintEqualToAnchor:margins.leadingAnchor],
            [_titleLabel.trailingAnchor constraintEqualToAnchor:margins.trailingAnchor]
        ]];
        _titleTopConstraint = [_titleLabel.topAnchor constraintEqualToAnchor:self.contentView.topAnchor constant:12.0];
        _titleCenterYConstraint = [_titleLabel.centerYAnchor constraintEqualToAnchor:self.contentView.centerYAnchor];
        _titleTrailingToSwitchConstraint = [_titleLabel.trailingAnchor constraintLessThanOrEqualToAnchor:_switchControl.leadingAnchor constant:-12.0];
        _segmentedLayoutConstraints = @[
            [_segmentedControl.leadingAnchor constraintEqualToAnchor:margins.leadingAnchor],
            [_segmentedControl.trailingAnchor constraintEqualToAnchor:margins.trailingAnchor],
            [_segmentedControl.topAnchor constraintEqualToAnchor:_titleLabel.bottomAnchor constant:10.0],
            [_segmentedControl.heightAnchor constraintEqualToConstant:32.0],
            [_segmentedControl.bottomAnchor constraintEqualToAnchor:self.contentView.bottomAnchor constant:-12.0]
        ];
        _switchLayoutConstraints = @[
            [_switchControl.trailingAnchor constraintEqualToAnchor:margins.trailingAnchor],
            [_switchControl.centerYAnchor constraintEqualToAnchor:self.contentView.centerYAnchor]
        ];
        _segmentedControl.hidden = YES;
        _switchControl.hidden = YES;
    }
    return self;
}

- (void)prepareForReuse {
    [super prepareForReuse];
    [_segmentedControl removeTarget:nil action:NULL forControlEvents:UIControlEventValueChanged];
    [_switchControl removeTarget:nil action:NULL forControlEvents:UIControlEventValueChanged];
}

- (void)configureAsSegmentedRowWithTitle:(NSString *)title items:(NSArray<NSString *> *)items selectedIndex:(NSInteger)selectedIndex target:(id)target action:(SEL)action {
    self.titleLabel.text = title;
    self.segmentedControl.hidden = NO;
    self.switchControl.hidden = YES;
    self.titleTopConstraint.active = YES;
    self.titleCenterYConstraint.active = NO;
    self.titleTrailingToSwitchConstraint.active = NO;
    [NSLayoutConstraint activateConstraints:self.segmentedLayoutConstraints];
    [NSLayoutConstraint deactivateConstraints:self.switchLayoutConstraints];
    [self.segmentedControl removeAllSegments];
    [items enumerateObjectsUsingBlock:^(NSString *item, NSUInteger idx, BOOL *stop) {
        [self.segmentedControl insertSegmentWithTitle:item atIndex:idx animated:NO];
    }];
    self.segmentedControl.selectedSegmentIndex = (selectedIndex >= 0 && selectedIndex < (NSInteger)items.count) ? selectedIndex : 0;
    self.segmentedControl.tag = [title isEqualToString:NSLocalizedString(@"Installation Method", nil)] ? 0 : 1;
    [self.segmentedControl removeTarget:nil action:NULL forControlEvents:UIControlEventValueChanged];
    [self.segmentedControl addTarget:target action:action forControlEvents:UIControlEventValueChanged];
}

- (void)configureAsSwitchRowWithTitle:(NSString *)title isOn:(BOOL)isOn target:(id)target action:(SEL)action {
    self.titleLabel.text = title;
    self.segmentedControl.hidden = YES;
    self.switchControl.hidden = NO;
    self.titleTopConstraint.active = NO;
    self.titleCenterYConstraint.active = YES;
    self.titleTrailingToSwitchConstraint.active = YES;
    [NSLayoutConstraint deactivateConstraints:self.segmentedLayoutConstraints];
    [NSLayoutConstraint activateConstraints:self.switchLayoutConstraints];
    self.switchControl.on = isOn;
    [self.switchControl removeTarget:nil action:NULL forControlEvents:UIControlEventValueChanged];
    [self.switchControl addTarget:target action:action forControlEvents:UIControlEventValueChanged];
}

@end

@interface TSSettingsAdvancedListController () <UITableViewDataSource, UITableViewDelegate>
@end

@implementation TSSettingsAdvancedListController

- (instancetype)init {
    return [super initWithStyle:UITableViewStyleInsetGrouped];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Advanced", nil);
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = UIColor.systemBackgroundColor;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 104.0;
    self.tableView.sectionHeaderTopPadding = 8.0;
    self.tableView.tableFooterView = [UIView new];
    self.tableView.contentInset = UIEdgeInsetsMake(4.0, 0.0, 20.0, 0.0);
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView { return 3; }

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return 1; }

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return indexPath.section == 2 ? 76.0 : 108.0;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    if (section == 2) return NSLocalizedString(@"Special Installation", nil);
    return nil;
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    if (section == 0) return NSLocalizedString(@"Installation Method Explanation", nil);
    if (section == 1) return NSLocalizedString(@"installd (Recommended):\nUninstalls applications using the same API that SpringBoard uses when uninstalling them from the home screen.\n\nCustom:\nUninstalls applications by removing them from icon cache and then deleting their application and data bundles directly.\n\nNOTE: In cases where installd is selected but the stock uninstallation fails, TrollStore automatically falls back to using the Custom method.", nil);
    return NSLocalizedString(@"When enabled, newly installed apps and apps updated through TrollStore are registered as non-deletable from the Home Screen. To remove a protected app, use TrollStore's in-app uninstall action. This is per-app, not a device-wide restriction. Turning this switch off affects future installs; an existing app's protection marker remains across updates until the app is uninstalled.", nil);
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *reuse = @"TSAdvancedNativeCardCell";
    TSAdvancedSettingCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (!cell) cell = [[TSAdvancedSettingCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:reuse];

    if (indexPath.section == 2) {
        id stored = [trollStoreUserDefaults() objectForKey:@"TSProtectHomeScreenDeletionEnabled"];
        [cell configureAsSwitchRowWithTitle:NSLocalizedString(@"Make app undeletable from Home Screen", nil)
                                      isOn:stored ? [stored boolValue] : NO
                                     target:self
                                     action:@selector(advancedSwitchChanged:)];
    } else {
        BOOL installation = indexPath.section == 0;
        NSString *key = installation ? @"installationMethod" : @"uninstallationMethod";
        NSInteger fallback = installation ? 1 : 0;
        id stored = [trollStoreUserDefaults() objectForKey:key];
        NSInteger selected = stored ? [stored integerValue] : fallback;
        [cell configureAsSegmentedRowWithTitle:NSLocalizedString(installation ? @"Installation Method" : @"Uninstallation Method", nil)
                                         items:@[@"installd", NSLocalizedString(@"Custom", nil)]
                                  selectedIndex:selected
                                        target:self
                                        action:@selector(advancedSegmentChanged:)];
    }
    [TSThemeManager styleCardTableViewCell:cell];
    return cell;
}

- (void)advancedSegmentChanged:(UISegmentedControl *)sender {
    NSString *key = sender.tag == 0 ? @"installationMethod" : @"uninstallationMethod";
    [trollStoreUserDefaults() setInteger:sender.selectedSegmentIndex forKey:key];
}

- (void)advancedSwitchChanged:(UISwitch *)sender {
    [trollStoreUserDefaults() setBool:sender.on forKey:@"TSProtectHomeScreenDeletionEnabled"];
}

@end
