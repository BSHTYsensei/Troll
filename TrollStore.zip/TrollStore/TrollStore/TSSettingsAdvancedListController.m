#import "TSSettingsAdvancedListController.h"
#import "TSUtil.h"
#import <Preferences/PSSpecifier.h>

extern NSUserDefaults* trollStoreUserDefaults();
@interface PSSpecifier ()
@property (nonatomic,retain) NSArray* values;
@end

@implementation TSSettingsAdvancedListController

- (NSMutableArray*)specifiers
{
	if(!_specifiers)
	{
		_specifiers = [NSMutableArray new];

		PSSpecifier* installationMethodGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
		//installationMethodGroupSpecifier.name = NSLocalizedString(@"Installation", nil);
		[installationMethodGroupSpecifier setProperty:NSLocalizedString(@"Installation Method Explanation", nil) forKey:@"footerText"];
		[_specifiers addObject:installationMethodGroupSpecifier];

		PSSpecifier* installationMethodSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Installation Method", nil)
											target:self
											set:nil
											get:nil
											detail:nil
											cell:PSStaticTextCell
											edit:nil];
		[installationMethodSpecifier setProperty:@YES forKey:@"enabled"];
		installationMethodSpecifier.identifier = @"installationMethodLabel";
		[_specifiers addObject:installationMethodSpecifier];

		PSSpecifier* installationMethodSegmentSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Installation Method Segment", nil)
											target:self
											set:@selector(setPreferenceValue:specifier:)
											get:@selector(readPreferenceValue:)
											detail:nil
											cell:PSSegmentCell
											edit:nil];
		[installationMethodSegmentSpecifier setProperty:@YES forKey:@"enabled"];
		installationMethodSegmentSpecifier.identifier = @"installationMethodSegment";
		[installationMethodSegmentSpecifier setProperty:APP_ID forKey:@"defaults"];
		[installationMethodSegmentSpecifier setProperty:@"installationMethod" forKey:@"key"];
		installationMethodSegmentSpecifier.values = @[@0, @1];
		installationMethodSegmentSpecifier.titleDictionary = @{@0 : @"installd", @1 : NSLocalizedString(@"Custom", nil)};
		[installationMethodSegmentSpecifier setProperty:@1 forKey:@"default"];
		[_specifiers addObject:installationMethodSegmentSpecifier];

		PSSpecifier* uninstallationMethodGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
		//uninstallationMethodGroupSpecifier.name = NSLocalizedString(@"Uninstallation", nil);
		[uninstallationMethodGroupSpecifier setProperty:NSLocalizedString(@"installd (Recommended):\nUninstalls applications using the same API that SpringBoard uses when uninstalling them from the home screen.\n\nCustom:\nUninstalls applications by removing them from icon cache and then deleting their application and data bundles directly.\n\nNOTE: In cases where installd is selected but the stock uninstallation fails, TrollStore automatically falls back to using the Custom method.", nil) forKey:@"footerText"];
		[_specifiers addObject:uninstallationMethodGroupSpecifier];

		PSSpecifier* uninstallationMethodSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Uninstallation Method", nil)
											target:self
											set:nil
											get:nil
											detail:nil
											cell:PSStaticTextCell
											edit:nil];
		[uninstallationMethodSpecifier setProperty:@YES forKey:@"enabled"];
		uninstallationMethodSpecifier.identifier = @"uninstallationMethodLabel";
		[_specifiers addObject:uninstallationMethodSpecifier];

		PSSpecifier* uninstallationMethodSegmentSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Installation Method Segment", nil)
											target:self
											set:@selector(setPreferenceValue:specifier:)
											get:@selector(readPreferenceValue:)
											detail:nil
											cell:PSSegmentCell
											edit:nil];
		[uninstallationMethodSegmentSpecifier setProperty:@YES forKey:@"enabled"];
		uninstallationMethodSegmentSpecifier.identifier = @"uninstallationMethodSegment";
		[uninstallationMethodSegmentSpecifier setProperty:APP_ID forKey:@"defaults"];
		[uninstallationMethodSegmentSpecifier setProperty:@"uninstallationMethod" forKey:@"key"];
		uninstallationMethodSegmentSpecifier.values = @[@0, @1];
		uninstallationMethodSegmentSpecifier.titleDictionary = @{@0 : @"installd", @1 : NSLocalizedString(@"Custom", nil)};
		[uninstallationMethodSegmentSpecifier setProperty:@0 forKey:@"default"];
		[_specifiers addObject:uninstallationMethodSegmentSpecifier];

		PSSpecifier* homeScreenProtectionGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
		homeScreenProtectionGroupSpecifier.name = NSLocalizedString(@"Special Installation", nil);
		[homeScreenProtectionGroupSpecifier setProperty:NSLocalizedString(@"When enabled, newly installed apps and apps updated through TrollStore are registered as non-deletable from the Home Screen. To remove a protected app, use TrollStore's in-app uninstall action. This is per-app, not a device-wide restriction. Turning this switch off affects future installs; an existing app's protection marker remains across updates until the app is uninstalled.", nil) forKey:@"footerText"];
		[_specifiers addObject:homeScreenProtectionGroupSpecifier];

		PSSpecifier* homeScreenProtectionSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Make app undeletable from Home Screen", nil)
									target:self
									set:@selector(setPreferenceValue:specifier:)
									get:@selector(readPreferenceValue:)
									detail:nil
									cell:PSSwitchCell
									edit:nil];
		homeScreenProtectionSpecifier.identifier = @"protectHomeScreenDeletion";
		[homeScreenProtectionSpecifier setProperty:APP_ID forKey:@"defaults"];
		[homeScreenProtectionSpecifier setProperty:@"TSProtectHomeScreenDeletionEnabled" forKey:@"key"];
		[homeScreenProtectionSpecifier setProperty:@NO forKey:@"default"];
		[_specifiers addObject:homeScreenProtectionSpecifier];
	}

	[(UINavigationItem *)self.navigationItem setTitle:NSLocalizedString(@"Advanced", nil)];
	return _specifiers;
}

- (void)setPreferenceValue:(NSObject*)value specifier:(PSSpecifier*)specifier
{
	NSUserDefaults* tsDefaults = trollStoreUserDefaults();
	[tsDefaults setObject:value forKey:[specifier propertyForKey:@"key"]];
}

- (NSObject*)readPreferenceValue:(PSSpecifier*)specifier
{
	NSUserDefaults* tsDefaults = trollStoreUserDefaults();
	NSObject* toReturn = [tsDefaults objectForKey:[specifier propertyForKey:@"key"]];
	if(!toReturn)
	{
		toReturn = [specifier propertyForKey:@"default"];
	}
	return toReturn;
}

@end
