import AppIntents

private enum TSRefreshAppRegistrationsFailure: LocalizedError {
    case helper(Int32)

    var errorDescription: String? {
        switch self {
        case .helper(let status):
            return "TrollStore could not refresh app registrations (helper status \(status))."
        }
    }
}

@available(iOS 16.0, *)
struct TSRefreshAppRegistrationsIntent: AppIntent {
    static var title: LocalizedStringResource = "Refresh App Registrations"
    static var description = IntentDescription("Refresh TrollStore app registrations. This shortcut is provided by TrollStore itself; Apple Shortcuts remains separate and never hosts the Persistence Helper.")
    // iOS 16-compatible background preference. The system may still choose a
    // foreground host in some contexts; this intent itself never presents UI.
    static var openAppWhenRun: Bool = false

    func perform() async throws -> some IntentResult & ProvidesDialog {
        let status = TSRunRefreshAppRegistrationsShortcut()
        guard status == 0 else { throw TSRefreshAppRegistrationsFailure.helper(status) }
        return .result(dialog: "App registrations refreshed.")
    }
}

@available(iOS 16.0, *)
struct TrollStoreAppShortcuts: AppShortcutsProvider {
    static var appShortcuts: [AppShortcut] {
        AppShortcut(
            intent: TSRefreshAppRegistrationsIntent(),
            phrases: ["Refresh app registrations in \(.applicationName)"],
            shortTitle: "Refresh Apps",
            systemImageName: "arrow.clockwise"
        )
    }
}
