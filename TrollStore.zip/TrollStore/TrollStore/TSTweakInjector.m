#import "TSTweakInjector.h"
#import "TSArchiveExtractor.h"
#import "TSIPAPackageStore.h"
#import "TSPluginStore.h"
#import <TSUtil.h>
#import <TSPresentationDelegate.h>
#import <math.h>
@import UniformTypeIdentifiers;

@interface TSTweakInjector ()
@property(nonatomic, weak) UIViewController *presentingController;
@property(nonatomic, copy) NSString *bundleIdentifier;
@property(nonatomic, copy) NSString *displayName;
- (void)presentBuiltInPresetsAtPath:(NSString *)root names:(NSArray<NSString *> *)names;
- (void)presentStagedImportAtPath:(NSString *)path cleanupRoot:(NSString *)cleanupRoot;
- (void)injectPath:(NSString *)path;
@end

@interface TSPluginLibraryPickerController : UITableViewController
- (instancetype)initWithLibraryPaths:(NSArray<NSString *> *)paths;
@property(nonatomic, copy) NSArray<NSString *> *libraryPaths;
@property(nonatomic, copy) void (^selectionHandler)(NSString *path);
@end

@implementation TSPluginLibraryPickerController
- (instancetype)initWithLibraryPaths:(NSArray<NSString *> *)paths {
    self = [super initWithStyle:UITableViewStyleInsetGrouped];
    if (self) _libraryPaths = [paths copy] ?: @[];
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Plugin Library", nil);
    self.tableView.rowHeight = 64;
    self.tableView.tableFooterView = [UIView new];
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancelPressed)];
    UILabel *note = [UILabel new];
    note.text = NSLocalizedString(@"Choose an installed library to inject. Dependencies inside the same package or the app's bundled runtime are resolved automatically when compatible.", nil);
    note.font = [UIFont preferredFontForTextStyle:UIFontTextStyleFootnote];
    note.textColor = UIColor.secondaryLabelColor;
    note.numberOfLines = 0;
    note.translatesAutoresizingMaskIntoConstraints = NO;
    UIView *header = [UIView new];
    [header addSubview:note];
    [NSLayoutConstraint activateConstraints:@[
        [note.topAnchor constraintEqualToAnchor:header.topAnchor constant:12],
        [note.leadingAnchor constraintEqualToAnchor:header.leadingAnchor constant:18],
        [note.trailingAnchor constraintEqualToAnchor:header.trailingAnchor constant:-18],
        [note.bottomAnchor constraintEqualToAnchor:header.bottomAnchor constant:-12]
    ]];
    header.frame = CGRectMake(0, 0, CGRectGetWidth(self.tableView.bounds), 70);
    self.tableView.tableHeaderView = header;
}
- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    UIView *header = self.tableView.tableHeaderView;
    if (header && fabs(header.bounds.size.width - self.tableView.bounds.size.width) > 0.5) {
        CGRect frame = header.frame;
        frame.size.width = self.tableView.bounds.size.width;
        header.frame = frame;
        CGSize fitting = [header systemLayoutSizeFittingSize:CGSizeMake(frame.size.width, UILayoutFittingCompressedSize.height)];
        frame.size.height = MAX(58, fitting.height);
        header.frame = frame;
        self.tableView.tableHeaderView = header;
    }
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section { return self.libraryPaths.count; }
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TSInstalledPluginChoice"];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"TSInstalledPluginChoice"];
    NSString *path = self.libraryPaths[indexPath.row];
    NSString *root = TSPluginStore.pluginDirectoryPath;
    NSString *relative = [path hasPrefix:[root stringByAppendingString:@"/"]] ? [path substringFromIndex:root.length + 1] : path.lastPathComponent;
    cell.textLabel.text = path.lastPathComponent;
    cell.detailTextLabel.text = relative;
    cell.detailTextLabel.textColor = UIColor.secondaryLabelColor;
    cell.detailTextLabel.lineBreakMode = NSLineBreakByTruncatingMiddle;
    cell.imageView.image = [UIImage systemImageNamed:[path.pathExtension.lowercaseString isEqualToString:@"framework"] ? @"shippingbox" : @"puzzlepiece.extension"];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSString *path = self.libraryPaths[indexPath.row];
    void (^handler)(NSString *) = self.selectionHandler;
    self.selectionHandler = nil;
    [self.navigationController dismissViewControllerAnimated:YES completion:^{ if (handler) handler(path); }];
}
- (void)cancelPressed {
    self.selectionHandler = nil;
    [self.navigationController dismissViewControllerAnimated:YES completion:nil];
}
@end

@implementation TSTweakInjector
+ (void)presentForBundleIdentifier:(NSString *)bundleIdentifier displayName:(NSString *)displayName fromViewController:(UIViewController *)viewController {
    TSTweakInjector *injector = [TSTweakInjector new]; injector.bundleIdentifier = bundleIdentifier; injector.displayName = displayName; injector.presentingController = viewController;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Inject Tweak", nil) message:NSLocalizedString(@"Choose a device-compatible .dylib or .framework, or import a .zip/.deb and extract its dynamic libraries. Injection modifies the installed bundle; keep an original IPA backup. Encrypted App Store apps may not launch after injection.", nil) preferredStyle:UIAlertControllerStyleActionSheet];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Choose File", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [injector chooseFile]; }]];
    NSArray<NSString *> *installedLibraries = [TSPluginStore availableInjectableLibraryPaths];
    if (installedLibraries.count) {
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Choose from Plugin Library", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
            TSPluginLibraryPickerController *picker = [[TSPluginLibraryPickerController alloc] initWithLibraryPaths:installedLibraries];
            picker.selectionHandler = ^(NSString *path) { [injector injectPath:path]; };
            UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:picker];
            [TSPresentationDelegate presentViewController:navigation animated:YES completion:nil];
        }]];
    }
    NSString *presetRoot = [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"TweakPresets"];
    NSArray<NSString *> *presets = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:presetRoot error:nil] ?: @[];
    NSMutableArray<NSString *> *dylibs = [NSMutableArray array];
    for (NSString *name in presets) {
        NSString *path = [presetRoot stringByAppendingPathComponent:name]; BOOL isDirectory = NO;
        if (![[NSFileManager defaultManager] fileExistsAtPath:path isDirectory:&isDirectory]) continue;
        NSString *ext = name.pathExtension.lowercaseString;
        if (([ext isEqualToString:@"framework"] && isDirectory) || ([ext isEqualToString:@"dylib"] && !isDirectory)) [dylibs addObject:name];
    }
    [dylibs sortUsingComparator:^NSComparisonResult(NSString *a, NSString *b) { BOOL af = [a.pathExtension.lowercaseString isEqualToString:@"framework"]; BOOL bf = [b.pathExtension.lowercaseString isEqualToString:@"framework"]; if (af != bf) return af ? NSOrderedAscending : NSOrderedDescending; return [a localizedStandardCompare:b]; }];
    if (dylibs.count) [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Built-in Presets", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [injector presentBuiltInPresetsAtPath:presetRoot names:dylibs]; }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    alert.popoverPresentationController.sourceView = viewController.view; alert.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(viewController.view.bounds), CGRectGetMidY(viewController.view.bounds), 1, 1);
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}
- (void)presentBuiltInPresetsAtPath:(NSString *)root names:(NSArray<NSString *> *)names {
    UIAlertController *picker = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Built-in Presets", nil) message:NSLocalizedString(@"App Lock requires Face ID/Touch ID or the device passcode. Background Assist requests only the finite execution allowance granted by iOS.", nil) preferredStyle:UIAlertControllerStyleActionSheet];
    for (NSString *name in names) [picker addAction:[UIAlertAction actionWithTitle:name.stringByDeletingPathExtension style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [self injectPath:[root stringByAppendingPathComponent:name]]; }]];
    [picker addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    picker.popoverPresentationController.sourceView = self.presentingController.view; picker.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.presentingController.view.bounds), CGRectGetMidY(self.presentingController.view.bounds), 1, 1);
    [TSPresentationDelegate presentViewController:picker animated:YES completion:nil];
}
- (void)chooseFile {
    NSMutableArray<UTType *> *types = [NSMutableArray array];
    UTType *dataType = [UTType typeWithIdentifier:@"public.data"];
    UTType *packageType = [UTType typeWithIdentifier:@"com.apple.package"] ?: dataType;
    UTType *archiveType = [UTType typeWithIdentifier:@"public.archive"] ?: dataType;
    if (!dataType) return;
    for (NSString *extension in @[@"dylib", @"framework", @"zip", @"deb"]) {
        UTType *conformance = [extension isEqualToString:@"framework"] ? packageType : (([extension isEqualToString:@"zip"] || [extension isEqualToString:@"deb"]) ? archiveType : dataType);
        UTType *type = [UTType typeWithFilenameExtension:extension conformingToType:conformance];
        if (!type) type = [UTType typeWithFilenameExtension:extension] ?: dataType;
        if (type) [types addObject:type];
    }
    if (!types.count) [types addObject:dataType];
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:types asCopy:YES];
    picker.delegate = self; picker.allowsMultipleSelection = NO;
    [TSPresentationDelegate presentViewController:picker animated:YES completion:nil];
}
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSURL *url = urls.firstObject; if (!url) return;
    BOOL scoped = [url startAccessingSecurityScopedResource];
    NSString *ext = url.pathExtension.lowercaseString;
    if ([ext isEqualToString:@"zip"] || [ext isEqualToString:@"deb"]) {
        NSString *destination = [[TSIPAPackageStore packageDirectoryPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"Extracted-Tweak-%@", [NSUUID.UUID.UUIDString substringToIndex:8]]];
        NSError *error = nil;
        if (![TSArchiveExtractor extractArchiveAtPath:url.path toDirectory:destination error:&error]) {
            if (scoped) [url stopAccessingSecurityScopedResource]; [self showResult:NO message:error.localizedDescription ?: NSLocalizedString(@"Could not extract the selected package.", nil) log:nil]; return;
        }
        NSArray<NSString *> *libraries = [TSArchiveExtractor dynamicLibrariesUnderDirectory:destination];
        if (scoped) [url stopAccessingSecurityScopedResource];
        if (!libraries.count) {
            UIAlertController *empty = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"No Injectable Libraries", nil) message:NSLocalizedString(@"The archive contains no .dylib or .framework payload.", nil) preferredStyle:UIAlertControllerStyleAlert];
            [empty addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Done", nil) style:UIAlertActionStyleCancel handler:nil]];
            [empty addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Imported Files", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) { [self removeImportedPathSafely:destination]; }]];
            [TSPresentationDelegate presentViewController:empty animated:YES completion:nil]; return;
        }
        UIAlertController *select = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Select Dynamic Library", nil) message:NSLocalizedString(@"Select a .framework or .dylib to inject. Cancel closes this picker and removes the temporary extraction directory.", nil) preferredStyle:UIAlertControllerStyleActionSheet];
        for (NSString *library in libraries) [select addAction:[UIAlertAction actionWithTitle:library.lastPathComponent style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [self presentStagedImportAtPath:library cleanupRoot:destination]; }]];
        [select addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *a) { [self removeImportedPathSafely:destination]; }]];
        select.popoverPresentationController.sourceView = self.presentingController.view; select.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.presentingController.view.bounds), CGRectGetMidY(self.presentingController.view.bounds), 1, 1);
        [TSPresentationDelegate presentViewController:select animated:YES completion:nil]; return;
    }
    // The picker returns a copied file in the app container; import to the persistent package store for repeatable root access.
    NSError *copyError = nil;
    NSString *path = nil;
    if ([ext isEqualToString:@"dylib"] || [ext isEqualToString:@"framework"]) {
        NSString *packageRoot = [[TSIPAPackageStore packageDirectoryPath] stringByAppendingPathComponent:@"Tweaks"];
        [[NSFileManager defaultManager] createDirectoryAtPath:packageRoot withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0755} error:&copyError];
        NSString *base = url.lastPathComponent;
        NSString *destination = [packageRoot stringByAppendingPathComponent:[NSString stringWithFormat:@"%@-%@%@", base.stringByDeletingPathExtension, [NSUUID.UUID.UUIDString substringToIndex:8], ext.length ? [@"." stringByAppendingString:ext] : @""]];
        BOOL isDirectory = NO;
        [[NSFileManager defaultManager] fileExistsAtPath:url.path isDirectory:&isDirectory];
        if (!copyError && (isDirectory == [ext isEqualToString:@"framework"]) && [[NSFileManager defaultManager] copyItemAtPath:url.path toPath:destination error:&copyError]) path = destination;
        if (!copyError && !path.length && !isDirectory) copyError = [NSError errorWithDomain:@"TSTweakInjector" code:10 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"The selected dynamic library is not a valid file or framework bundle.", nil)}];
    } else {
        NSURL *stored = [TSIPAPackageStore importPackageAtURL:url error:&copyError]; path = stored.path;
    }
    if (scoped) [url stopAccessingSecurityScopedResource];
    if (!path.length) { [self showResult:NO message:copyError.localizedDescription ?: NSLocalizedString(@"Could not stage the selected dynamic library.", nil) log:nil]; return; }
    [self presentStagedImportAtPath:path cleanupRoot:path];
}
- (BOOL)removeImportedPathSafely:(NSString *)path {
    if (!path.length) return NO;
    NSString *root = [TSIPAPackageStore packageDirectoryPath].stringByResolvingSymlinksInPath.stringByStandardizingPath;
    NSString *resolved = path.stringByResolvingSymlinksInPath.stringByStandardizingPath;
    if ([resolved isEqualToString:root] || ![resolved hasPrefix:[root stringByAppendingString:@"/"]]) return NO;
    NSError *error = nil;
    BOOL ok = [[NSFileManager defaultManager] removeItemAtPath:path error:&error];
    if (!ok) [self showResult:NO message:error.localizedDescription ?: NSLocalizedString(@"Could not delete imported files.", nil) log:nil];
    return ok;
}
- (void)presentStagedImportAtPath:(NSString *)path cleanupRoot:(NSString *)cleanupRoot {
    UIAlertController *staged = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Imported Tweak", nil) message:[NSString stringWithFormat:NSLocalizedString(@"%@ has been copied into TrollStore's local package store. Continue to the injection confirmation, delete the imported files, or cancel and keep the staged copy for later.", nil), path.lastPathComponent] preferredStyle:UIAlertControllerStyleAlert];
    [staged addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [staged addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Delete Imported Files", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) { [self removeImportedPathSafely:cleanupRoot ?: path]; }]];
    [staged addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Continue", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [self injectPath:path]; }]];
    [TSPresentationDelegate presentViewController:staged animated:YES completion:nil];
}
- (void)injectPath:(NSString *)path {
    UIAlertController *confirm = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Inject Tweak", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Inject %@ into %@? The application bundle will be modified and resigned. Keep a backup so you can reinstall the original IPA if the app crashes.", nil), path.lastPathComponent, self.displayName ?: self.bundleIdentifier] preferredStyle:UIAlertControllerStyleAlert];
    [confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Inject", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) {
        [TSPresentationDelegate startActivity:NSLocalizedString(@"Injecting Tweak", nil)];
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
            NSString *log = nil; int result = spawnRoot(rootHelperPath(), @[@"inject-dylib", self.bundleIdentifier ?: @"", path], nil, &log);
            dispatch_async(dispatch_get_main_queue(), ^{ [TSPresentationDelegate stopActivityWithCompletion:^{ [self showResult:result == 0 message:log.length ? log : [NSString stringWithFormat:NSLocalizedString(@"Injection failed with code %d.", nil), result] log:log]; }]; });
        });
    }]];
    [TSPresentationDelegate presentViewController:confirm animated:YES completion:nil];
}
- (void)showResult:(BOOL)success message:(NSString *)message log:(NSString *)log {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:success ? NSLocalizedString(@"Injection Complete", nil) : NSLocalizedString(@"Injection Failed", nil) message:message preferredStyle:UIAlertControllerStyleAlert];
    if (log.length) [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Copy Debug Log", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { UIPasteboard.generalPasteboard.string = log; }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}
@end
