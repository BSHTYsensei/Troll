#import "TSTweakInjector.h"
#import "TSArchiveExtractor.h"
#import "TSIPAPackageStore.h"
#import <TSUtil.h>
#import <TSPresentationDelegate.h>
@import UniformTypeIdentifiers;

@interface TSTweakInjector ()
@property(nonatomic, weak) UIViewController *presentingController;
@property(nonatomic, copy) NSString *bundleIdentifier;
@property(nonatomic, copy) NSString *displayName;
- (void)presentBuiltInPresetsAtPath:(NSString *)root names:(NSArray<NSString *> *)names;
@end
@implementation TSTweakInjector
+ (void)presentForBundleIdentifier:(NSString *)bundleIdentifier displayName:(NSString *)displayName fromViewController:(UIViewController *)viewController {
    TSTweakInjector *injector = [TSTweakInjector new]; injector.bundleIdentifier = bundleIdentifier; injector.displayName = displayName; injector.presentingController = viewController;
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Inject Tweak", nil) message:NSLocalizedString(@"Choose a device-compatible .dylib or .framework, or import a .zip/.deb and extract its dynamic libraries. Injection modifies the installed bundle; keep an original IPA backup. Encrypted App Store apps may not launch after injection.", nil) preferredStyle:UIAlertControllerStyleActionSheet];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Choose File", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [injector chooseFile]; }]];
    NSString *presetRoot = [[NSBundle mainBundle].resourcePath stringByAppendingPathComponent:@"TweakPresets"];
    NSArray<NSString *> *presets = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:presetRoot error:nil] ?: @[];
    NSMutableArray<NSString *> *dylibs = [NSMutableArray array];
    for (NSString *name in presets) if ([name.pathExtension.lowercaseString isEqualToString:@"dylib"] && [[NSFileManager defaultManager] fileExistsAtPath:[presetRoot stringByAppendingPathComponent:name]]) [dylibs addObject:name];
    if (dylibs.count) [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Built-in Presets", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [injector presentBuiltInPresetsAtPath:presetRoot names:dylibs]; }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Prevent Uninstall Limitations", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) {
        UIAlertController *info = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Requires SpringBoard or MDM", nil) message:NSLocalizedString(@"A dylib injected into an application cannot prevent SpringBoard from uninstalling it. This requires supervised-device management or a jailbreak tweak loaded into SpringBoard; no fake app-level preset is provided.", nil) preferredStyle:UIAlertControllerStyleAlert];
        [info addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]]; [TSPresentationDelegate presentViewController:info animated:YES completion:nil];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    alert.popoverPresentationController.sourceView = viewController.view; alert.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(viewController.view.bounds), CGRectGetMidY(viewController.view.bounds), 1, 1);
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}
- (void)presentBuiltInPresetsAtPath:(NSString *)root names:(NSArray<NSString *> *)names {
    UIAlertController *picker = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Built-in Presets", nil) message:NSLocalizedString(@"App Lock requires Face ID/Touch ID or the device passcode. Background Assist requests only the finite execution allowance granted by iOS.", nil) preferredStyle:UIAlertControllerStyleActionSheet];
    for (NSString *name in names) [picker addAction:[UIAlertAction actionWithTitle:name.stringByDeletingPathExtension style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [self injectPath:[root stringByAppendingPathComponent:name]]; }]];
    [picker addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    picker.popoverPresentationController.sourceView = self.presentingController.view; picker.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.presentingController.view.bounds), CGRectGetMidY(self.presentingController.view.bounds), 1, 1);
    [TSPresentationDelegate presentViewController:picker animated:YES completion:nil];
}
- (void)chooseFile {
    NSMutableArray<UTType *> *types = [NSMutableArray array];
    for (NSString *extension in @[@"dylib", @"framework", @"zip", @"deb"]) {
        UTType *conformance = ([extension isEqualToString:@"framework"] ? UTType.package : (([extension isEqualToString:@"zip"] || [extension isEqualToString:@"deb"]) ? UTType.archive : UTType.data));
        UTType *type = [UTType typeWithFilenameExtension:extension conformingToType:conformance];
        if (type) [types addObject:type];
    }
    if (!types.count) [types addObject:UTType.data];
    UIDocumentPickerViewController *picker = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:types asCopy:YES];
    picker.delegate = self; picker.allowsMultipleSelection = NO;
    [TSPresentationDelegate presentViewController:picker animated:YES completion:nil];
}
- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls {
    NSURL *url = urls.firstObject; if (!url) return;
    BOOL scoped = [url startAccessingSecurityScopedResource];
    NSString *ext = url.pathExtension.lowercaseString;
    if ([ext isEqualToString:@"zip"] || [ext isEqualToString:@"deb"]) {
        NSString *destination = [[TSIPAPackageStore packageDirectoryPath] stringByAppendingPathComponent:[NSString stringWithFormat:@"Extracted-Tweak-%@", [NSUUID.UUID.UUIDString substringToIndex:8]]];
        NSError *error = nil;
        if (![TSArchiveExtractor extractArchiveAtPath:url.path toDirectory:destination error:&error]) {
            if (scoped) [url stopAccessingSecurityScopedResource]; [self showResult:NO message:error.localizedDescription ?: NSLocalizedString(@"Could not extract the selected package.", nil) log:nil]; return;
        }
        NSArray<NSString *> *libraries = [TSArchiveExtractor dynamicLibrariesUnderDirectory:destination];
        if (!libraries.count) { if (scoped) [url stopAccessingSecurityScopedResource]; [self showResult:NO message:NSLocalizedString(@"No .dylib files were found in the archive.", nil) log:nil]; return; }
        UIAlertController *select = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Select Dynamic Library", nil) message:NSLocalizedString(@"Select one .dylib to inject. If the package contains several libraries, inject related dependencies separately.", nil) preferredStyle:UIAlertControllerStyleActionSheet];
        for (NSString *library in libraries) [select addAction:[UIAlertAction actionWithTitle:library.lastPathComponent style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { [self injectPath:library]; }]];
        [select addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
        select.popoverPresentationController.sourceView = self.presentingController.view; select.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.presentingController.view.bounds), CGRectGetMidY(self.presentingController.view.bounds), 1, 1);
        if (scoped) [url stopAccessingSecurityScopedResource];
        [TSPresentationDelegate presentViewController:select animated:YES completion:nil]; return;
    }
    // The picker returns a copied file in the app container; import to the persistent package store for repeatable root access.
    NSError *copyError = nil;
    NSString *path = nil;
    if ([ext isEqualToString:@"dylib"] || [ext isEqualToString:@"framework"]) {
        NSString *packageRoot = [[TSIPAPackageStore packageDirectoryPath] stringByAppendingPathComponent:@"Tweaks"];
        [[NSFileManager defaultManager] createDirectoryAtPath:packageRoot withIntermediateDirectories:YES attributes:@{NSFilePosixPermissions:@0755} error:&copyError];
        NSString *base = url.lastPathComponent;
        NSString *destination = [packageRoot stringByAppendingPathComponent:[NSString stringWithFormat:@"%@-%@%@", base.stringByDeletingPathExtension, [NSUUID.UUID.UUIDString substringToIndex:8], ext.length ? [@"." stringByAppendingString:ext] : @""]];
        BOOL isDirectory = NO;
        [[NSFileManager defaultManager] fileExistsAtPath:url.path isDirectory:&isDirectory];
        if (!copyError && (isDirectory == [ext isEqualToString:@"framework"]) && [[NSFileManager defaultManager] copyItemAtPath:url.path toPath:destination error:&copyError]) path = destination;
        if (!copyError && !path.length && !isDirectory) copyError = [NSError errorWithDomain:@"TSTweakInjector" code:10 userInfo:@{NSLocalizedDescriptionKey:NSLocalizedString(@"The selected dynamic library is not a valid file or framework bundle.", nil)}];
    } else {
        NSURL *stored = [TSIPAPackageStore importPackageAtURL:url error:&copyError]; path = stored.path;
    }
    if (scoped) [url stopAccessingSecurityScopedResource];
    if (!path.length) { [self showResult:NO message:copyError.localizedDescription ?: NSLocalizedString(@"Could not stage the selected dynamic library.", nil) log:nil]; return; }
    [self injectPath:path];
}
- (void)injectPath:(NSString *)path {
    UIAlertController *confirm = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Inject Tweak", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Inject %@ into %@? The application bundle will be modified and resigned. Keep a backup so you can reinstall the original IPA if the app crashes.", nil), path.lastPathComponent, self.displayName ?: self.bundleIdentifier] preferredStyle:UIAlertControllerStyleAlert];
    [confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Inject", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *a) {
        [TSPresentationDelegate startActivity:NSLocalizedString(@"Injecting Tweak", nil)];
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
            NSString *log = nil; int result = spawnRoot(rootHelperPath(), @[@"inject-dylib", self.bundleIdentifier ?: @"", path], nil, &log);
            dispatch_async(dispatch_get_main_queue(), ^{ [TSPresentationDelegate stopActivityWithCompletion:^{ [self showResult:result == 0 message:log.length ? log : [NSString stringWithFormat:NSLocalizedString(@"Injection failed with code %d.", nil), result] log:log]; }]; });
        });
    }]];
    [TSPresentationDelegate presentViewController:confirm animated:YES completion:nil];
}
- (void)showResult:(BOOL)success message:(NSString *)message log:(NSString *)log {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:success ? NSLocalizedString(@"Injection Complete", nil) : NSLocalizedString(@"Injection Failed", nil) message:message preferredStyle:UIAlertControllerStyleAlert];
    if (log.length) [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Copy Debug Log", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *a) { UIPasteboard.generalPasteboard.string = log; }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}
@end
