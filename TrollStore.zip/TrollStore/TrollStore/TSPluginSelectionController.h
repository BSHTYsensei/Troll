#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN
@interface TSPluginSelectionController : UITableViewController
@property(nonatomic, copy, nullable) void (^completion)(NSArray<NSString *> *selectedPaths, BOOL cancelled);
- (instancetype)initWithLibraryPaths:(NSArray<NSString *> *)libraryPaths;
@end
NS_ASSUME_NONNULL_END
