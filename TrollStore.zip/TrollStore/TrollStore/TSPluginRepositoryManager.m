#import "TSPluginRepositoryManager.h"
#import "TSPluginStore.h"
#import <CommonCrypto/CommonDigest.h>

static NSString * const TSPluginRepositoryDefaultsKey = @"TSPluginRepositories";
static NSString * const TSPluginRepositoryErrorDomain = @"com.opa334.TrollStore.PluginRepository";
static const NSUInteger TSPluginRepositoryMaximumManifestBytes = 8 * 1024 * 1024;
static const long long TSPluginRepositoryMaximumPackageBytes = 128LL * 1024LL * 1024LL;

static NSError *TSPluginRepoError(NSInteger code, NSString *message) {
    return [NSError errorWithDomain:TSPluginRepositoryErrorDomain code:code userInfo:@{NSLocalizedDescriptionKey: message ?: NSLocalizedString(@"Plugin repository request failed.", nil)}];
}

static NSString *TSPluginRepoNormalizedBaseURL(NSString *raw, NSError **error) {
    NSString *text = [raw stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    NSURLComponents *components = [NSURLComponents componentsWithString:text];
    if (!components || ![components.scheme.lowercaseString isEqualToString:@"https"] || !components.host.length || components.user.length || components.password.length || components.query.length || components.fragment.length) {
        if (error) *error = TSPluginRepoError(1, NSLocalizedString(@"Repository URLs must use HTTPS and must not contain credentials, query strings or fragments.", nil));
        return nil;
    }
    NSString *path = components.path ?: @"";
    while ([path hasSuffix:@"/"] && path.length > 1) path = [path substringToIndex:path.length - 1];
    if ([path hasSuffix:@"/trollpackages.json"]) path = [path stringByDeletingLastPathComponent];
    components.path = path;
    components.query = nil; components.fragment = nil;
    return components.URL.absoluteString;
}

static NSString *TSPluginRepoSHA256(NSURL *url, NSError **error) {
    NSInputStream *stream = [NSInputStream inputStreamWithURL:url];
    [stream open];
    CC_SHA256_CTX context; CC_SHA256_Init(&context);
    uint8_t buffer[64 * 1024];
    NSInteger readCount = 0;
    while ((readCount = [stream read:buffer maxLength:sizeof(buffer)]) > 0) CC_SHA256_Update(&context, buffer, (CC_LONG)readCount);
    NSError *streamError = stream.streamError;
    [stream close];
    if (readCount < 0 || streamError) { if (error) *error = streamError ?: TSPluginRepoError(2, @"Could not verify the downloaded file."); return nil; }
    unsigned char digest[CC_SHA256_DIGEST_LENGTH]; CC_SHA256_Final(digest, &context);
    NSMutableString *hex = [NSMutableString stringWithCapacity:CC_SHA256_DIGEST_LENGTH * 2];
    for (NSUInteger i = 0; i < sizeof(digest); i++) [hex appendFormat:@"%02x", digest[i]];
    return hex;
}

@implementation TSPluginRepositoryManager

+ (NSArray<NSString *> *)repositoryURLs {
    id value = [NSUserDefaults.standardUserDefaults objectForKey:TSPluginRepositoryDefaultsKey];
    if (![value isKindOfClass:NSArray.class]) return @[];
    NSMutableArray *valid = [NSMutableArray array];
    for (id item in (NSArray *)value) if ([item isKindOfClass:NSString.class]) [valid addObject:item];
    return valid.copy;
}

+ (BOOL)addRepositoryURL:(NSString *)url error:(NSError **)error {
    NSString *base = TSPluginRepoNormalizedBaseURL(url, error);
    if (!base) return NO;
    NSMutableArray *sources = [[self repositoryURLs] mutableCopy];
    if ([sources containsObject:base]) { if (error) *error = TSPluginRepoError(3, NSLocalizedString(@"This repository is already added.", nil)); return NO; }
    [sources addObject:base];
    [NSUserDefaults.standardUserDefaults setObject:sources forKey:TSPluginRepositoryDefaultsKey];
    return YES;
}

+ (void)removeRepositoryURL:(NSString *)url {
    NSMutableArray *sources = [[self repositoryURLs] mutableCopy];
    [sources removeObject:url];
    [NSUserDefaults.standardUserDefaults setObject:sources forKey:TSPluginRepositoryDefaultsKey];
}

+ (void)refreshPackagesWithCompletion:(void (^)(NSArray<NSDictionary *> *, NSError *))completion {
    NSArray<NSString *> *sources = [self repositoryURLs];
    if (!sources.count) {
        dispatch_async(dispatch_get_main_queue(), ^{ if (completion) completion(@[], TSPluginRepoError(4, NSLocalizedString(@"No plugin repositories have been added yet.", nil))); });
        return;
    }
    dispatch_group_t group = dispatch_group_create();
    NSMutableArray<NSDictionary *> *allPackages = [NSMutableArray array];
    NSMutableArray<NSError *> *errors = [NSMutableArray array];
    NSLock *lock = [NSLock new];
    for (NSString *base in sources) {
        NSString *manifest = [base stringByAppendingPathComponent:@"trollpackages.json"];
        NSURL *url = [NSURL URLWithString:manifest];
        if (!url || ![url.scheme.lowercaseString isEqualToString:@"https"]) {
            [errors addObject:TSPluginRepoError(5, [NSString stringWithFormat:@"%@ is not a valid HTTPS repository URL.", base])];
            continue;
        }
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:20];
        request.HTTPMethod = @"GET";
        dispatch_group_enter(group);
        [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *networkError) {
            NSError *failure = networkError;
            NSURL *finalURL = response.URL;
            if (!failure && ![finalURL.scheme.lowercaseString isEqualToString:@"https"]) failure = TSPluginRepoError(14, NSLocalizedString(@"Repository redirected away from HTTPS. The response was rejected.", nil));
            if (!failure && [response isKindOfClass:NSHTTPURLResponse.class] && ((NSHTTPURLResponse *)response).statusCode / 100 != 2) failure = TSPluginRepoError(((NSHTTPURLResponse *)response).statusCode, [NSString stringWithFormat:@"Repository %@ returned HTTP %ld.", base, (long)((NSHTTPURLResponse *)response).statusCode]);
            if (!failure && (!data.length || data.length > TSPluginRepositoryMaximumManifestBytes)) failure = TSPluginRepoError(6, [NSString stringWithFormat:@"The repository manifest is empty or larger than 8 MB: %@", base]);
            id json = nil;
            if (!failure) {
                json = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingFragmentsAllowed error:&failure];
                if (![json isKindOfClass:NSDictionary.class]) failure = TSPluginRepoError(7, [NSString stringWithFormat:@"%@ does not contain a valid repository manifest.", base]);
            }
            NSDictionary *root = [json isKindOfClass:NSDictionary.class] ? json : @{};
            id rawPackages = root[@"packages"];
            if (!failure && ![rawPackages isKindOfClass:NSArray.class]) failure = TSPluginRepoError(8, [NSString stringWithFormat:@"%@ has no packages array.", base]);
            NSMutableArray<NSDictionary *> *parsed = [NSMutableArray array];
            if (!failure) {
                NSString *repoName = [root[@"repository_name"] isKindOfClass:NSString.class] ? root[@"repository_name"] : url.host;
                for (id raw in (NSArray *)rawPackages) {
                    if (![raw isKindOfClass:NSDictionary.class]) continue;
                    NSDictionary *item = raw;
                    NSString *name = [item[@"name"] isKindOfClass:NSString.class] ? item[@"name"] : nil;
                    NSString *version = [item[@"version"] isKindOfClass:NSString.class] ? item[@"version"] : nil;
                    NSString *description = [item[@"description"] isKindOfClass:NSString.class] ? item[@"description"] : @"";
                    NSString *file = [item[@"dylib"] isKindOfClass:NSString.class] ? item[@"dylib"] : nil;
                    NSURL *fileURL = file.length ? [NSURL URLWithString:file relativeToURL:url] : nil;
                    if (!name.length || !version.length || !fileURL || ![fileURL.scheme.lowercaseString isEqualToString:@"https"] || !fileURL.host.length) continue;
                    NSString *extension = fileURL.pathExtension.lowercaseString;
                    if (![@[@"dylib", @"deb", @"zip"] containsObject:extension]) continue;
                    NSMutableDictionary *package = [NSMutableDictionary dictionaryWithDictionary:@{
                        @"name": name, @"version": version, @"description": description,
                        @"downloadURL": fileURL.absoluteURL, @"repoURL": base, @"repoName": repoName,
                        @"section": [item[@"section"] isKindOfClass:NSString.class] ? item[@"section"] : @"",
                        @"author": [item[@"author"] isKindOfClass:NSString.class] ? item[@"author"] : @"",
                        @"size": [item[@"size"] isKindOfClass:NSString.class] ? item[@"size"] : @""
                    }];
                    if ([item[@"sha256"] isKindOfClass:NSString.class]) package[@"sha256"] = [item[@"sha256"] lowercaseString];
                    [parsed addObject:package.copy];
                }
            }
            [lock lock];
            if (failure) [errors addObject:failure]; else [allPackages addObjectsFromArray:parsed];
            [lock unlock];
            dispatch_group_leave(group);
        }] resume];
    }
    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
        if (allPackages.count) {
            [allPackages sortUsingComparator:^NSComparisonResult(NSDictionary *a, NSDictionary *b) {
                NSString *sectionA = a[@"section"] ?: @""; NSString *sectionB = b[@"section"] ?: @"";
                NSComparisonResult result = [sectionA localizedStandardCompare:sectionB];
                return result == NSOrderedSame ? [a[@"name"] localizedStandardCompare:b[@"name"]] : result;
            }];
            if (completion) completion(allPackages.copy, nil);
        } else {
            NSString *message = errors.count ? [[errors valueForKey:@"localizedDescription"] componentsJoinedByString:@"\n"] : NSLocalizedString(@"No compatible plugins were found in the configured repositories.", nil);
            if (completion) completion(@[], TSPluginRepoError(9, message));
        }
    });
}

+ (void)downloadPackage:(NSDictionary *)package completion:(void (^)(NSURL *, NSError *))completion {
    NSURL *url = [package[@"downloadURL"] isKindOfClass:NSURL.class] ? package[@"downloadURL"] : nil;
    NSString *extension = url.pathExtension.lowercaseString;
    if (!url || ![url.scheme.lowercaseString isEqualToString:@"https"] || ![@[@"dylib", @"deb", @"zip"] containsObject:extension]) {
        dispatch_async(dispatch_get_main_queue(), ^{ if (completion) completion(nil, TSPluginRepoError(10, NSLocalizedString(@"The repository package URL or file type is not supported.", nil))); });
        return;
    }
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url cachePolicy:NSURLRequestReloadIgnoringLocalCacheData timeoutInterval:60];
    [[NSURLSession sharedSession] downloadTaskWithRequest:request completionHandler:^(NSURL *temporaryURL, NSURLResponse *response, NSError *networkError) {
        NSError *failure = networkError;
        NSURL *finalURL = response.URL;
        if (!failure && ![finalURL.scheme.lowercaseString isEqualToString:@"https"]) failure = TSPluginRepoError(15, NSLocalizedString(@"Plugin download redirected away from HTTPS. The package was rejected.", nil));
        if (!failure && [response isKindOfClass:NSHTTPURLResponse.class] && ((NSHTTPURLResponse *)response).statusCode / 100 != 2) failure = TSPluginRepoError(((NSHTTPURLResponse *)response).statusCode, [NSString stringWithFormat:@"Download returned HTTP %ld.", (long)((NSHTTPURLResponse *)response).statusCode]);
        if (!failure && (!temporaryURL || ![[NSFileManager defaultManager] fileExistsAtPath:temporaryURL.path])) failure = TSPluginRepoError(11, NSLocalizedString(@"The repository returned no package file.", nil));
        NSDictionary *attributes = temporaryURL ? [[NSFileManager defaultManager] attributesOfItemAtPath:temporaryURL.path error:nil] : nil;
        unsigned long long size = [attributes[NSFileSize] unsignedLongLongValue];
        if (!failure && (!size || size > TSPluginRepositoryMaximumPackageBytes)) failure = TSPluginRepoError(12, NSLocalizedString(@"The package is empty or exceeds the 128 MB download limit.", nil));
        NSString *expectedHash = [package[@"sha256"] isKindOfClass:NSString.class] ? package[@"sha256"] : nil;
        if (!failure && expectedHash.length) {
            NSString *actualHash = TSPluginRepoSHA256(temporaryURL, &failure);
            if (!failure && ![actualHash.lowercaseString isEqualToString:expectedHash.lowercaseString]) failure = TSPluginRepoError(13, NSLocalizedString(@"SHA-256 verification failed. The downloaded plugin was rejected.", nil));
        }
        NSURL *imported = nil;
        if (!failure) {
            NSString *staging = [NSTemporaryDirectory() stringByAppendingPathComponent:[NSString stringWithFormat:@"TSPluginDownload-%@.%@", NSUUID.UUID.UUIDString, extension]];
            NSError *moveError = nil;
            [[NSFileManager defaultManager] removeItemAtPath:staging error:nil];
            if (![[NSFileManager defaultManager] copyItemAtURL:temporaryURL toURL:[NSURL fileURLWithPath:staging] error:&moveError]) failure = moveError;
            else {
                imported = [TSPluginStore importPluginAtURL:[NSURL fileURLWithPath:staging] error:&failure];
                [[NSFileManager defaultManager] removeItemAtPath:staging error:nil];
            }
        }
        dispatch_async(dispatch_get_main_queue(), ^{ if (completion) completion(imported, failure); });
    }] resume];
}
@end
