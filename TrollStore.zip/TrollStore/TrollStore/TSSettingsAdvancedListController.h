#import <UIKit/UIKit.h>

@interface TSSettingsAdvancedListController : UITableViewController
@end
