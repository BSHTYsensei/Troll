#import <UIKit/UIKit.h>

/// Owns the complete application shell. The system UITabBarController is not
/// used: a single custom content host and a glass dock avoid the legacy tab bar
/// flashing during launch and give tab changes one deterministic transition path.
@interface TSRootViewController : UIViewController
@property(nonatomic, assign) NSUInteger selectedIndex;
- (void)selectTabAtIndex:(NSUInteger)index animated:(BOOL)animated;
@end
