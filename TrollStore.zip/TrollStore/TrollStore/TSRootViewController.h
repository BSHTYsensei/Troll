#import <UIKit/UIKit.h>

/// Owns the complete application shell. The system UITabBarController is not
/// used: a single custom content host and a native-style bottom bar avoid legacy tab bar
/// flashing during launch and give tab changes one deterministic transition path.
@interface TSRootViewController : UIViewController
@property(nonatomic, assign) NSUInteger selectedIndex;
- (void)selectTabAtIndex:(NSUInteger)index animated:(BOOL)animated;
@end
