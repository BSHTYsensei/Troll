#import "TSSettingsListController.h"
#import <TSUtil.h>
#import <TSPresentationDelegate.h>
#import "TSInstallationController.h"
#import "TSSettingsAdvancedListController.h"
#import "TSThemeManager.h"
#import "TSChoiceListController.h"
#import "TSSigningSettingsController.h"
#import "TSBlockedUpdatesController.h"
#ifdef TS_ENABLE_APP_INTENTS
#import "TSRefreshShortcutController.h"
#endif

#import <QuartzCore/QuartzCore.h>

extern NSUserDefaults *trollStoreUserDefaults(void);

@interface TSSettingsListController () <UIColorPickerViewControllerDelegate, UITableViewDataSource, UITableViewDelegate>
@property(nonatomic, strong) NSArray<NSDictionary *> *settingsSections;
@property(nonatomic, assign) BOOL settingsVisible;
@property(nonatomic, assign) BOOL pendingSettingsReload;
@property(nonatomic, assign) BOOL settingsReloadScheduled;
@property(nonatomic, assign) BOOL didStartExpandedSettingsChecks;
@property(nonatomic, assign) BOOL settingsMetadataLoaded;
@property(nonatomic, assign) BOOL settingsMetadataLoading;
@property(nonatomic, assign) BOOL settingsMetadataRefreshPending;
@property(nonatomic, assign) NSUInteger settingsMetadataGeneration;
@property(nonatomic, assign) NSUInteger inactiveAppCount;
@property(nonatomic, assign) BOOL persistenceHelperFound;
@property(nonatomic, copy) NSString *persistenceHelperName;
@property(nonatomic, copy) NSString *newerVersion;
@property(nonatomic, assign) BOOL devModeEnabled;
- (void)settingsDidReceiveReloadNotification:(NSNotification *)notification;
- (void)startExpandedSettingsChecksIfNeeded;
- (void)loadSettingsRuntimeMetadataIfNeeded;
- (void)refreshSettingsRuntimeMetadata;
- (void)requestSettingsReload;
- (void)performPendingSettingsReload;
- (void)rebuildNativeSettingsSections;
- (void)showOtherSettingsPressed;
- (void)hideOtherSettingsPressed;
- (void)installAlertConfigurationPressed;
- (void)pushPersonalizationChoiceWithTitle:(NSString *)title options:(NSArray<NSString *> *)options key:(NSString *)key selectedIndex:(NSInteger)selectedIndex notification:(NSString *)notification;
- (void)appListLayoutPressed;
- (void)bottomBarStylePressed;
- (void)animationEffectPressed;
- (void)changeThemeColorPressed;
- (void)changeAppIconPressed;
- (void)setThemeMode:(NSInteger)mode;
- (void)clearAllAppCachesPressed;
- (NSArray *)installationConfirmationNames;
- (void)respringButtonPressed;
- (void)initializeBundledLdidPressed;
- (void)enableDevModePressed;
- (void)installPersistenceHelperPressed;
- (void)transferAppsPressed;
- (void)signingMethodAndCertificatesPressed;
- (void)manageBlockedAppUpdatesPressed;
- (void)updateTrollStorePressed;
- (void)rebuildIconCachePressed;
- (void)refreshAppRegistrationsPressed;
- (void)uninstallPersistenceHelperPressed;
- (void)uninstallTrollStorePressed;
- (NSMutableArray *)argsForUninstallingTrollStore;
- (NSNumber *)getURLSchemeEnabled;
- (void)setURLSchemeEnabled:(id)value;
- (void)setAutoInitializeLdid:(id)value;
- (void)setStealthInstallEnabled:(id)value;
- (void)setPluginInjectionEnabled:(id)value;
@end

@implementation TSSettingsListController

- (instancetype)init {
    return [super initWithStyle:UITableViewStyleInsetGrouped];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = NSLocalizedString(@"Settings", nil);
#ifndef TROLLSTORE_LITE
    self.devModeEnabled = YES;
#endif
    self.navigationItem.largeTitleDisplayMode = UINavigationItemLargeTitleDisplayModeNever;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = UIColor.systemBackgroundColor;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    // These rows are single-line controls with fixed system sizing. A fixed
    // height avoids repeated Auto Layout measurement while fast-scrolling.
    self.tableView.rowHeight = 60.0;
    self.tableView.estimatedRowHeight = 0.0;
    self.tableView.sectionHeaderTopPadding = 8.0;
    self.tableView.contentInset = UIEdgeInsetsMake(4.0, 0.0, 12.0, 0.0);
    self.tableView.tableFooterView = [UIView new];
    __weak typeof(self) weakSelf = self;
    UIAction *followSystem = [UIAction actionWithTitle:NSLocalizedString(@"System", nil) image:[UIImage systemImageNamed:@"gearshape"] identifier:@"ThemeSystem" handler:^(__kindof UIAction *action) {
        [weakSelf setThemeMode:0];
    }];
    UIAction *lightMode = [UIAction actionWithTitle:NSLocalizedString(@"Light", nil) image:[UIImage systemImageNamed:@"sun.max.fill"] identifier:@"ThemeLight" handler:^(__kindof UIAction *action) {
        [weakSelf setThemeMode:1];
    }];
    UIAction *darkMode = [UIAction actionWithTitle:NSLocalizedString(@"Dark", nil) image:[UIImage systemImageNamed:@"moon.fill"] identifier:@"ThemeDark" handler:^(__kindof UIAction *action) {
        [weakSelf setThemeMode:2];
    }];
    UIMenu *appearanceMenu = [UIMenu menuWithTitle:NSLocalizedString(@"Appearance", nil) children:@[followSystem, lightMode, darkMode]];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"paintbrush.pointed.fill"] menu:appearanceMenu];
    self.navigationItem.rightBarButtonItem.accessibilityLabel = NSLocalizedString(@"Appearance", nil);

    NSNotificationCenter *center = NSNotificationCenter.defaultCenter;
    [center addObserver:self selector:@selector(settingsDidReceiveReloadNotification:) name:UIApplicationWillEnterForegroundNotification object:nil];
    [center addObserver:self selector:@selector(settingsDidReceiveReloadNotification:) name:@"TrollStoreReloadSettingsNotification" object:nil];
    [center addObserver:self selector:@selector(settingsDidReceiveReloadNotification:) name:@"TSAppearanceChanged" object:nil];
    [self rebuildNativeSettingsSections];
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    self.settingsVisible = YES;
    [self performPendingSettingsReload];
    [self startExpandedSettingsChecksIfNeeded];
}

- (void)viewWillDisappear:(BOOL)animated {
    self.settingsVisible = NO;
    [super viewWillDisappear:animated];
}

- (void)dealloc {
    [NSNotificationCenter.defaultCenter removeObserver:self];
}

- (void)settingsDidReceiveReloadNotification:(NSNotification *)notification {
    [self requestSettingsReload];
    BOOL shouldRefreshRuntimeMetadata =
        [notification.name isEqualToString:UIApplicationWillEnterForegroundNotification] ||
        [notification.name isEqualToString:@"TrollStoreReloadSettingsNotification"];
    if (shouldRefreshRuntimeMetadata && self.settingsVisible && [trollStoreUserDefaults() boolForKey:@"TSShowOtherSettings"]) {
        [self refreshSettingsRuntimeMetadata];
    }
}

- (void)requestSettingsReload {
    self.pendingSettingsReload = YES;
    [self performPendingSettingsReload];
}

- (void)performPendingSettingsReload {
    if (self.settingsReloadScheduled || !self.settingsVisible || !self.isViewLoaded) return;
    self.settingsReloadScheduled = YES;
    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) return;
        strongSelf.settingsReloadScheduled = NO;
        if (!strongSelf.settingsVisible || !strongSelf.view.window) return;
        if (!strongSelf.pendingSettingsReload) return;
        strongSelf.pendingSettingsReload = NO;
        [strongSelf rebuildNativeSettingsSections];
        UIView.performWithoutAnimation(^{
            [strongSelf.tableView reloadData];
        });
    });
}

- (void)startExpandedSettingsChecksIfNeeded {
    if (![trollStoreUserDefaults() boolForKey:@"TSShowOtherSettings"]) return;
    [self loadSettingsRuntimeMetadataIfNeeded];
    if (self.didStartExpandedSettingsChecks) return;
    self.didStartExpandedSettingsChecks = YES;
#ifndef TROLLSTORE_LITE
    __weak typeof(self) weakSelf = self;
    fetchLatestTrollStoreVersion(^(NSString *latestVersion) {
        if (![latestVersion isKindOfClass:NSString.class] || latestVersion.length == 0) return;
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (!strongSelf) return;
            NSString *currentVersion = [strongSelf getTrollStoreVersion];
            if (![currentVersion isKindOfClass:NSString.class] || currentVersion.length == 0) return;
            if ([currentVersion compare:latestVersion options:NSNumericSearch] == NSOrderedAscending) {
                strongSelf->_newerVersion = latestVersion;
                [strongSelf requestSettingsReload];
            }
        });
    });
    if (@available(iOS 16, *)) {
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            BOOL enabled = spawnRoot(rootHelperPath(), @[@"check-dev-mode"], nil, nil) == 0;
            dispatch_async(dispatch_get_main_queue(), ^{
                __strong typeof(weakSelf) strongSelf = weakSelf;
                if (!strongSelf || strongSelf->_devModeEnabled == enabled) return;
                strongSelf->_devModeEnabled = enabled;
                [strongSelf requestSettingsReload];
            });
        });
    }
#endif
}

- (void)loadSettingsRuntimeMetadataIfNeeded {
    if (self.settingsMetadataLoaded || self.settingsMetadataLoading) return;
    [self refreshSettingsRuntimeMetadata];
}

- (void)refreshSettingsRuntimeMetadata {
    if (![trollStoreUserDefaults() boolForKey:@"TSShowOtherSettings"]) return;
    if (self.settingsMetadataLoading) {
        self.settingsMetadataRefreshPending = YES;
        return;
    }

    self.settingsMetadataLoading = YES;
    self.settingsMetadataLoaded = NO;
    NSUInteger generation = ++self.settingsMetadataGeneration;
    __weak typeof(self) weakSelf = self;

    // Launch Services enumeration and marker-directory scans can involve
    // hundreds of installed apps. Keep both off the main thread; only pass
    // the small display values back to UIKit.
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        NSUInteger inactiveCount = trollStoreInactiveInstalledAppBundlePaths().count;
#ifndef TROLLSTORE_LITE
        LSApplicationProxy *persistenceApp = findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_ALL);
        BOOL persistenceFound = persistenceApp != nil;
        NSString *persistenceName = persistenceApp.localizedName ?: persistenceApp.bundleIdentifier;
#else
        BOOL persistenceFound = NO;
        NSString *persistenceName = nil;
#endif

        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (!strongSelf || generation != strongSelf.settingsMetadataGeneration) return;
            strongSelf.settingsMetadataLoading = NO;
            strongSelf.settingsMetadataLoaded = YES;
            strongSelf.inactiveAppCount = inactiveCount;
            strongSelf.persistenceHelperFound = persistenceFound;
            strongSelf.persistenceHelperName = persistenceName;
            [strongSelf requestSettingsReload];
            if (strongSelf.settingsMetadataRefreshPending) {
                strongSelf.settingsMetadataRefreshPending = NO;
                [strongSelf refreshSettingsRuntimeMetadata];
            }
        });
    });
}

- (NSDictionary *)row:(NSString *)title type:(NSString *)type key:(NSString *)key defaultValue:(id)defaultValue icon:(NSString *)icon action:(NSString *)action detail:(NSString *)detail {
    NSMutableDictionary *item = [NSMutableDictionary dictionary];
    if (title) item[@"title"] = title;
    if (type) item[@"type"] = type;
    if (key) item[@"key"] = key;
    if (defaultValue) item[@"default"] = defaultValue;
    if (icon) item[@"icon"] = icon;
    if (action) item[@"action"] = action;
    if (detail) item[@"detail"] = detail;
    return item;
}

- (void)addSection:(NSMutableArray *)sections title:(NSString *)title footer:(NSString *)footer rows:(NSArray<NSDictionary *> *)rows {
    if (rows.count == 0) return;
    [sections addObject:@{@"title": title ?: @"", @"footer": footer ?: @"", @"rows": rows}];
}

- (void)rebuildNativeSettingsSections {
    NSUserDefaults *defaults = trollStoreUserDefaults();
    NSMutableArray<NSDictionary *> *sections = [NSMutableArray array];
    [self addSection:sections title:NSLocalizedString(@"Personalization", nil)
              footer:NSLocalizedString(@"Customize the app list, navigation bar and theme.", nil)
                rows:@[
        [self row:NSLocalizedString(@"Show System Apps", nil) type:@"switch" key:@"TSShowSystemApps" defaultValue:@YES icon:@"iphone.gen3" action:nil detail:nil],
        [self row:NSLocalizedString(@"Show App Filter", nil) type:@"switch" key:@"TSShowAppFilter" defaultValue:@YES icon:@"line.3.horizontal.decrease.circle" action:nil detail:nil],
        [self row:NSLocalizedString(@"Show TrollStore App Badge", nil) type:@"switch" key:@"TSShowTrollStoreBadge" defaultValue:@YES icon:@"seal.fill" action:nil detail:nil],
        [self row:NSLocalizedString(@"Show App Type in Grid Layout", nil) type:@"switch" key:@"TSShowAppTypeInGrid" defaultValue:@NO icon:@"tag.fill" action:nil detail:nil],
        [self row:NSLocalizedString(@"App List Layout", nil) type:@"button" key:nil defaultValue:nil icon:@"list.bullet.rectangle" action:@"appListLayoutPressed" detail:nil],
        [self row:NSLocalizedString(@"Choose Bottom Bar Style", nil) type:@"button" key:nil defaultValue:nil icon:@"rectangle.bottomthird.inset.filled" action:@"bottomBarStylePressed" detail:nil],
        [self row:NSLocalizedString(@"Change Theme Color", nil) type:@"button" key:nil defaultValue:nil icon:@"paintbrush.pointed.fill" action:@"changeThemeColorPressed" detail:nil],
        [self row:NSLocalizedString(@"Change App Icon", nil) type:@"button" key:nil defaultValue:nil icon:@"app.badge" action:@"changeAppIconPressed" detail:nil],
        [self row:NSLocalizedString(@"Change In-App Animation Effect", nil) type:@"button" key:nil defaultValue:nil icon:@"sparkles" action:@"animationEffectPressed" detail:nil]
    ]];

    if (![defaults boolForKey:@"TSShowOtherSettings"]) {
        [self addSection:sections title:NSLocalizedString(@"Other Settings", nil)
                  footer:NSLocalizedString(@"Tap to expand Other Settings.", nil)
                    rows:@[[self row:NSLocalizedString(@"Show Other Settings", nil) type:@"button" key:nil defaultValue:nil icon:@"chevron.down.circle" action:@"showOtherSettingsPressed" detail:nil]]];
        self.settingsSections = sections;
        return;
    }

#ifndef TROLLSTORE_LITE
    if (_newerVersion.length) {
        [self addSection:sections title:NSLocalizedString(@"Update Available", nil) footer:nil rows:@[[self row:[NSString stringWithFormat:NSLocalizedString(@"Update TrollStore to %@", nil), _newerVersion] type:@"button" key:nil defaultValue:nil icon:@"arrow.down.circle.fill" action:@"updateTrollStorePressed" detail:nil]]];
    }
    if (!_devModeEnabled) {
        [self addSection:sections title:NSLocalizedString(@"Developer Mode", nil)
                  footer:NSLocalizedString(@"Some apps require developer mode enabled to launch. This requires a reboot to take effect.", nil)
                    rows:@[[self row:NSLocalizedString(@"Enable Developer Mode", nil) type:@"button" key:nil defaultValue:nil icon:@"wrench.and.screwdriver.fill" action:@"enableDevModePressed" detail:nil]]];
    }
#endif

    NSString *utilitiesDescription = @"";
#ifdef TROLLSTORE_LITE
    if (shouldRegisterAsUserByDefault()) utilitiesDescription = NSLocalizedString(@"Apps will be registered as User by default since AppSync Unified is installed.\n\n", nil);
    else utilitiesDescription = NSLocalizedString(@"Apps will be registered as System by default since AppSync Unified is not installed. When apps loose their System registration and stop working, press \"Refresh App Registrations\" here to fix them.\n\n", nil);
#endif
    utilitiesDescription = [utilitiesDescription stringByAppendingString:NSLocalizedString(@"If an app does not immediately appear after installation, respring here and it should appear afterwards.", nil)];
    [self addSection:sections title:NSLocalizedString(@"Utilities", nil) footer:utilitiesDescription rows:@[
        [self row:NSLocalizedString(@"Respring", nil) type:@"button" key:nil defaultValue:nil icon:@"power" action:@"respringButtonPressed" detail:nil],
        [self row:NSLocalizedString(@"Refresh App Registrations", nil) type:@"button" key:nil defaultValue:nil icon:@"arrow.clockwise" action:@"refreshAppRegistrationsPressed" detail:nil],
        [self row:NSLocalizedString(@"Clear All App Caches", nil) type:@"button" key:nil defaultValue:nil icon:@"trash.fill" action:@"clearAllAppCachesPressed" detail:nil],
        [self row:NSLocalizedString(@"Blocked App Updates", nil) type:@"button" key:nil defaultValue:nil icon:@"hand.raised.fill" action:@"manageBlockedAppUpdatesPressed" detail:nil]
    ]];

#ifdef TROLLSTORE_LITE
    NSString *pluginFooter = NSLocalizedString(@"The Plugins tab stores .dylib, .framework and DEB/ZIP files locally. Install-time dynamic-library injection is not available in TrollStore Lite.", nil);
#else
    NSString *pluginFooter = NSLocalizedString(@"The Plugins tab stores .dylib, .framework and DEB/ZIP packages locally. When enabled, IPA installation asks which extracted dynamic libraries to inject. No library is injected when the selection is empty. System tweaks that require MobileSubstrate still need a compatible tweak loader.", nil);
#endif
#ifndef TROLLSTORE_LITE
    [self addSection:sections title:NSLocalizedString(@"Plugins", nil) footer:pluginFooter rows:@[[self row:NSLocalizedString(@"Enable Plugin Injection on Install", nil) type:@"switch" key:@"TSPluginInjectionEnabled" defaultValue:@NO icon:@"puzzlepiece.extension.fill" action:nil detail:nil]]];
#else
    [self addSection:sections title:NSLocalizedString(@"Plugins", nil) footer:pluginFooter rows:@[]];
#endif

    NSMutableArray *cacheRows = [NSMutableArray arrayWithObject:[self row:NSLocalizedString(@"Rebuild Icon Cache", nil) type:@"button" key:nil defaultValue:nil icon:@"square.grid.2x2.fill" action:@"rebuildIconCachePressed" detail:nil]];
    if (self.inactiveAppCount > 0) {
        NSString *count = [NSString stringWithFormat:NSLocalizedString(@"Transfer %zu ", nil), self.inactiveAppCount];
        count = [count stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
        NSString *word = self.inactiveAppCount > 1 ? NSLocalizedString(@"Apps", nil) : NSLocalizedString(@"App", nil);
        NSString *title = [NSString stringWithFormat:@"%@ %@ %@", count, OTHER_APP_NAME, word];
        [cacheRows addObject:[self row:title type:@"button" key:nil defaultValue:nil icon:@"arrow.left.arrow.right" action:@"transferAppsPressed" detail:nil]];
    }
    [self addSection:sections title:NSLocalizedString(@"App Registration", nil) footer:nil rows:cacheRows];

#ifndef TROLLSTORE_LITE
    [self addSection:sections title:NSLocalizedString(@"Signing", nil)
              footer:NSLocalizedString(@"This build uses the bundled custom ldid binary. No upstream version checks or downloads are performed.", nil)
                rows:@[
        [self row:NSLocalizedString(@"Auto-initialize bundled ldid", nil) type:@"switch" key:@"AutoInitializeBundledLdid" defaultValue:@NO icon:@"signature" action:nil detail:nil],
        [self row:NSLocalizedString(@"Initialize bundled ldid", nil) type:@"button" key:nil defaultValue:nil icon:@"arrow.clockwise.circle" action:@"initializeBundledLdidPressed" detail:nil],
        [self row:NSLocalizedString(@"Signing Method & Certificates", nil) type:@"button" key:nil defaultValue:nil icon:@"signature" action:@"signingMethodAndCertificatesPressed" detail:nil]
    ]];

    NSString *persistenceFooter = nil;
    NSMutableArray *persistenceRows = [NSMutableArray array];
    if (!self.settingsMetadataLoaded) {
        persistenceFooter = NSLocalizedString(@"Checking persistence helper status…", nil);
        [persistenceRows addObject:[self row:NSLocalizedString(@"Checking…", nil) type:@"static" key:nil defaultValue:nil icon:@"hourglass" action:nil detail:nil]];
    } else if ([[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/TrollStorePersistenceHelper.app"]) {
        persistenceFooter = NSLocalizedString(@"When iOS rebuilds the icon cache, all TrollStore apps including TrollStore itself will be reverted to \"User\" state and either disappear or no longer launch. If that happens, you can use the TrollHelper app on the home screen to refresh the app registrations, which will make them work again.", nil);
        [persistenceRows addObject:[self row:NSLocalizedString(@"Helper Installed as Standalone App", nil) type:@"static" key:nil defaultValue:nil icon:@"checkmark.shield.fill" action:nil detail:nil]];
    } else if (self.persistenceHelperFound) {
        NSString *appName = self.persistenceHelperName ?: @"";
        persistenceFooter = [NSString stringWithFormat:NSLocalizedString(@"When iOS rebuilds the icon cache, all TrollStore apps including TrollStore itself will be reverted to \"User\" state and either disappear or no longer launch. If that happens, you can use the persistence helper installed into %@ to refresh the app registrations, which will make them work again.", nil), appName];
        [persistenceRows addObject:[self row:[NSString stringWithFormat:NSLocalizedString(@"Helper Installed into %@", nil), appName] type:@"static" key:nil defaultValue:nil icon:@"checkmark.shield.fill" action:nil detail:nil]];
#ifdef TS_ENABLE_APP_INTENTS
        [persistenceRows addObject:[self row:NSLocalizedString(@"Add Refresh Shortcut", nil) type:@"button" key:nil defaultValue:nil icon:@"arrow.clockwise" action:@"addRefreshShortcutPressed" detail:nil]];
#endif
        [persistenceRows addObject:[self row:NSLocalizedString(@"Uninstall Persistence Helper", nil) type:@"destructive" key:nil defaultValue:nil icon:@"trash.fill" action:@"uninstallPersistenceHelperPressed" detail:nil]];
    } else {
        persistenceFooter = NSLocalizedString(@"When iOS rebuilds the icon cache, all TrollStore apps including TrollStore itself will be reverted to \"User\" state and either disappear or no longer launch. The only way to have persistence in a rootless environment is to replace a system application, here you can select a system app to replace with a persistence helper that can be used to refresh the registrations of all TrollStore related apps in case they disappear or no longer launch.", nil);
        [persistenceRows addObject:[self row:NSLocalizedString(@"Install Persistence Helper", nil) type:@"button" key:nil defaultValue:nil icon:@"shield.lefthalf.filled" action:@"installPersistenceHelperPressed" detail:nil]];
    }
    [self addSection:sections title:NSLocalizedString(@"Persistence", nil) footer:persistenceFooter rows:persistenceRows];
#endif

    [self addSection:sections title:NSLocalizedString(@"Entitlements Editor", nil)
              footer:NSLocalizedString(@"When enabled, opening an IPA for installation first opens its original main-app Entitlements for editing. Done proceeds to the normal installation confirmation; Cancel cancels the entire installation and returns to the previous page. The edited Entitlements apply only to this installation, and app extensions keep their own original Entitlements.", nil)
                rows:@[[self row:NSLocalizedString(@"Edit Entitlements Before Install", nil) type:@"switch" key:@"TSEditEntitlementsBeforeInstallEnabled" defaultValue:@NO icon:@"lock.fill" action:nil detail:nil]]];

    [self addSection:sections title:NSLocalizedString(@"Security", nil)
              footer:NSLocalizedString(@"The URL Scheme, when enabled, will allow apps and websites to trigger TrollStore installations through the apple-magnifier://install?url=<IPA_URL> URL scheme and enable JIT through the apple-magnifier://enable-jit?bundle-id=<BUNDLE_ID> URL scheme.", nil)
                rows:@[[self row:NSLocalizedString(@"URL Scheme Enabled", nil) type:@"urlSwitch" key:nil defaultValue:@NO icon:@"link" action:nil detail:nil]]];

    [self addSection:sections title:NSLocalizedString(@"TrollStore Stealth Install", nil)
              footer:NSLocalizedString(@"For future IPA installs only: randomizes the installed bundle ID and removes URL schemes to reduce detection based on fixed identifiers. This is not a system-wide jailbreak hide and cannot defeat every detection method. URL callbacks, deep links, sign-in, keychain, app groups, push notifications, or extensions may stop working.", nil)
                rows:@[[self row:NSLocalizedString(@"Enable stealth install for new IPAs", nil) type:@"switch" key:@"TSStealthInstallEnabled" defaultValue:@NO icon:@"eye.slash.fill" action:nil detail:nil]]];

    [self addSection:sections title:NSLocalizedString(@"Installation Confirmation", nil) footer:nil rows:@[[self row:NSLocalizedString(@"Show Install Confirmation Alert", nil) type:@"button" key:nil defaultValue:nil icon:@"checkmark.bubble.fill" action:@"installAlertConfigurationPressed" detail:nil]]];

    NSString *about = [NSString stringWithFormat:NSLocalizedString(@"%@ %@\n\n© 2022-2026 Lars Fröder (opa334)\n\nTrollStore is NOT for piracy!\n\nCredits:\nGoogle TAG, @alfiecg_dev: CoreTrust bug\n@lunotech11, @SerenaKit, @tylinux, @TheRealClarity, @dhinakg, @khanhduytran0: Various contributions\n@ProcursusTeam: uicache, ldid\n@cstar_ow: uicache\n@saurik: ldid", nil), APP_NAME, [self getTrollStoreVersion] ?: @""];
    [self addSection:sections title:@"" footer:about rows:@[
        [self row:NSLocalizedString(@"Advanced", nil) type:@"button" key:nil defaultValue:nil icon:@"gearshape.2.fill" action:@"advancedPressed" detail:nil],
#ifndef TROLLSTORE_LITE
        [self row:NSLocalizedString(@"Uninstall TrollStore", nil) type:@"destructive" key:nil defaultValue:nil icon:@"trash.fill" action:@"uninstallTrollStorePressed" detail:nil],
#endif
        [self row:NSLocalizedString(@"Hide Other Settings", nil) type:@"button" key:nil defaultValue:nil icon:@"chevron.up.circle" action:@"hideOtherSettingsPressed" detail:nil]
    ]];
    self.settingsSections = sections;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.settingsSections.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.settingsSections[section][@"rows"] count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    NSString *title = self.settingsSections[section][@"title"];
    return title.length ? title : nil;
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    NSString *footer = self.settingsSections[section][@"footer"];
    return footer.length ? footer : nil;
}

- (BOOL)boolValueForRow:(NSDictionary *)row {
    NSString *type = row[@"type"];
    if ([type isEqualToString:@"urlSwitch"]) return [self getURLSchemeEnabled].boolValue;
    NSString *key = row[@"key"];
    id value = key.length ? [trollStoreUserDefaults() objectForKey:key] : nil;
    if (!value) value = row[@"default"];
    return [value boolValue];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *row = self.settingsSections[indexPath.section][@"rows"][indexPath.row];
    static NSString *reuse = @"TSNativeSettingsCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:reuse];
    cell.textLabel.text = row[@"title"];
    cell.textLabel.font = [UIFont systemFontOfSize:16.5 weight:UIFontWeightMedium];
    cell.detailTextLabel.text = row[@"detail"];
    cell.detailTextLabel.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightRegular];
    cell.detailTextLabel.textColor = UIColor.secondaryLabelColor;
    cell.backgroundColor = UIColor.clearColor;
    cell.contentView.backgroundColor = UIColor.clearColor;
    cell.selectionStyle = [row[@"type"] isEqualToString:@"static"] ? UITableViewCellSelectionStyleNone : UITableViewCellSelectionStyleDefault;
    NSString *type = row[@"type"];
    BOOL isSwitch = [type isEqualToString:@"switch"] || [type isEqualToString:@"urlSwitch"];
    BOOL destructive = [type isEqualToString:@"destructive"];
    UIColor *titleColor = destructive ? UIColor.systemRedColor : (isSwitch || [type isEqualToString:@"static"] ? UIColor.labelColor : TSThemeManager.accentColor);
    cell.textLabel.textColor = titleColor;
    NSString *symbol = row[@"icon"];
    static UIImageSymbolConfiguration *symbolConfig;
    static dispatch_once_t symbolConfigOnce;
    dispatch_once(&symbolConfigOnce, ^{
        symbolConfig = [UIImageSymbolConfiguration configurationWithPointSize:16.0 weight:UIImageSymbolWeightRegular];
    });
    cell.imageView.image = symbol.length ? [UIImage systemImageNamed:symbol withConfiguration:symbolConfig] : nil;
    cell.imageView.tintColor = destructive ? UIColor.systemRedColor : TSThemeManager.accentColor;
    cell.imageView.contentMode = UIViewContentModeScaleAspectFit;
    cell.accessoryType = UITableViewCellAccessoryNone;

    if (isSwitch) {
        UISwitch *control = [cell.accessoryView isKindOfClass:UISwitch.class] ? (UISwitch *)cell.accessoryView : [UISwitch new];
        [control removeTarget:self action:@selector(settingsSwitchChanged:) forControlEvents:UIControlEventValueChanged];
        [control setOn:[self boolValueForRow:row] animated:NO];
        control.onTintColor = TSThemeManager.accentColor;
        control.accessibilityIdentifier = [type isEqualToString:@"urlSwitch"] ? @"urlSwitch" : row[@"key"];
        [control addTarget:self action:@selector(settingsSwitchChanged:) forControlEvents:UIControlEventValueChanged];
        cell.accessoryView = control;
    } else {
        cell.accessoryView = nil;
    }
    if ([type isEqualToString:@"button"] || destructive) {
        if ([row[@"action"] isEqualToString:@"advancedPressed"] || [row[@"action"] isEqualToString:@"installAlertConfigurationPressed"]) {
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
    }
    if ([type isEqualToString:@"static"]) cell.textLabel.textColor = UIColor.secondaryLabelColor;
    [TSThemeManager styleCardTableViewCell:cell];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary *row = self.settingsSections[indexPath.section][@"rows"][indexPath.row];
    NSString *action = row[@"action"];
    if (action.length) [self invokeSettingsAction:action];
}

- (void)settingsSwitchChanged:(UISwitch *)sender {
    NSString *key = sender.accessibilityIdentifier;
    if (!key.length) return;
    if ([key isEqualToString:@"AutoInitializeBundledLdid"]) {
        [self setAutoInitializeLdid:@(sender.on)];
    } else if ([key isEqualToString:@"TSStealthInstallEnabled"]) {
        [self setStealthInstallEnabled:@(sender.on)];
    } else if ([key isEqualToString:@"TSPluginInjectionEnabled"]) {
        [self setPluginInjectionEnabled:@(sender.on)];
    } else if ([key isEqualToString:@"urlSwitch"]) {
        [self setURLSchemeEnabled:@(sender.on)];
    } else {
        [trollStoreUserDefaults() setBool:sender.on forKey:key];
        [[NSNotificationCenter defaultCenter] postNotificationName:@"TSAppAppearanceSettingsChanged" object:nil];
    }
}

- (void)invokeSettingsAction:(NSString *)action {
    if ([action isEqualToString:@"appListLayoutPressed"]) [self appListLayoutPressed];
    else if ([action isEqualToString:@"bottomBarStylePressed"]) [self bottomBarStylePressed];
    else if ([action isEqualToString:@"changeThemeColorPressed"]) [self changeThemeColorPressed];
    else if ([action isEqualToString:@"changeAppIconPressed"]) [self changeAppIconPressed];
    else if ([action isEqualToString:@"animationEffectPressed"]) [self animationEffectPressed];
    else if ([action isEqualToString:@"showOtherSettingsPressed"]) [self showOtherSettingsPressed];
    else if ([action isEqualToString:@"hideOtherSettingsPressed"]) [self hideOtherSettingsPressed];
    else if ([action isEqualToString:@"updateTrollStorePressed"]) [self updateTrollStorePressed];
    else if ([action isEqualToString:@"enableDevModePressed"]) [self enableDevModePressed];
    else if ([action isEqualToString:@"respringButtonPressed"]) [self respringButtonPressed];
    else if ([action isEqualToString:@"refreshAppRegistrationsPressed"]) [self refreshAppRegistrationsPressed];
    else if ([action isEqualToString:@"clearAllAppCachesPressed"]) [self clearAllAppCachesPressed];
    else if ([action isEqualToString:@"manageBlockedAppUpdatesPressed"]) [self manageBlockedAppUpdatesPressed];
    else if ([action isEqualToString:@"rebuildIconCachePressed"]) [self rebuildIconCachePressed];
    else if ([action isEqualToString:@"transferAppsPressed"]) [self transferAppsPressed];
    else if ([action isEqualToString:@"initializeBundledLdidPressed"]) [self initializeBundledLdidPressed];
    else if ([action isEqualToString:@"signingMethodAndCertificatesPressed"]) [self signingMethodAndCertificatesPressed];
    else if ([action isEqualToString:@"addRefreshShortcutPressed"]) {
#ifdef TS_ENABLE_APP_INTENTS
        [self addRefreshShortcutPressed];
#endif
    }
    else if ([action isEqualToString:@"uninstallPersistenceHelperPressed"]) [self uninstallPersistenceHelperPressed];
    else if ([action isEqualToString:@"installPersistenceHelperPressed"]) [self installPersistenceHelperPressed];
    else if ([action isEqualToString:@"advancedPressed"]) {
        TSSettingsAdvancedListController *controller = [TSSettingsAdvancedListController new];
        [self.navigationController pushViewController:controller animated:YES];
    }
    else if ([action isEqualToString:@"uninstallTrollStorePressed"]) [self uninstallTrollStorePressed];
    else if ([action isEqualToString:@"installAlertConfigurationPressed"]) [self installAlertConfigurationPressed];
}

- (void)signingMethodAndCertificatesPressed
{
	TSSigningSettingsController *controller = [TSSigningSettingsController new];
	UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
	[TSPresentationDelegate presentViewController:navigation animated:YES completion:nil];
}


- (void)showOtherSettingsPressed {
    [trollStoreUserDefaults() setBool:YES forKey:@"TSShowOtherSettings"];
    [self requestSettingsReload];
    [self startExpandedSettingsChecksIfNeeded];
}

- (void)hideOtherSettingsPressed {
    [trollStoreUserDefaults() setBool:NO forKey:@"TSShowOtherSettings"];
    // Invalidate any in-flight enumeration. A later expansion will get a
    // fresh snapshot instead of rendering stale install/helper information.
    self.settingsMetadataGeneration++;
    self.settingsMetadataLoading = NO;
    self.settingsMetadataLoaded = NO;
    self.settingsMetadataRefreshPending = NO;
    [self requestSettingsReload];
}

- (void)installAlertConfigurationPressed {
    NSInteger selected = [trollStoreUserDefaults() objectForKey:@"installAlertConfiguration"] ? [trollStoreUserDefaults() integerForKey:@"installAlertConfiguration"] : 0;
    [self pushPersonalizationChoiceWithTitle:NSLocalizedString(@"Show Install Confirmation Alert", nil)
                                    options:[self installationConfirmationNames]
                                       key:@"installAlertConfiguration"
                              selectedIndex:selected
                                notification:nil];
}

- (void)pushPersonalizationChoiceWithTitle:(NSString *)title options:(NSArray<NSString *> *)options key:(NSString *)key selectedIndex:(NSInteger)selectedIndex notification:(NSString *)notification {
    __weak typeof(self) weakSelf = self;
    TSChoiceListController *controller = [[TSChoiceListController alloc] initWithTitle:title options:options selectedIndex:selectedIndex selectionHandler:^(NSInteger index) {
        NSUserDefaults *defaults = trollStoreUserDefaults();
        [defaults setInteger:index forKey:key];
        if ([key isEqualToString:@"TSFloatingBarStyle"]) {
            [defaults setBool:(index != 1) forKey:@"TSFloatingTabBarEnabled"];
        }
        if (notification.length) [[NSNotificationCenter defaultCenter] postNotificationName:notification object:nil];
    }];
    [weakSelf.navigationController pushViewController:controller animated:YES];
}

- (void)appListLayoutPressed {
    NSInteger selected = [trollStoreUserDefaults() integerForKey:@"TSAppListLayout"] == 1 ? 1 : 0;
    [self pushPersonalizationChoiceWithTitle:NSLocalizedString(@"App List Layout", nil)
                                    options:@[NSLocalizedString(@"List", nil), NSLocalizedString(@"Grid", nil)]
                                       key:@"TSAppListLayout" selectedIndex:selected notification:@"TSAppListLayoutChanged"];
}

- (void)bottomBarStylePressed {
    NSInteger selected = [TSThemeManager floatingBarStyle];
    [self pushPersonalizationChoiceWithTitle:NSLocalizedString(@"Choose Bottom Bar Style", nil)
                                    options:@[NSLocalizedString(@"Floating", nil), NSLocalizedString(@"Standard", nil), NSLocalizedString(@"Floating 2", nil)]
                                       key:@"TSFloatingBarStyle" selectedIndex:selected notification:@"TSAppearanceChanged"];
}

- (void)animationEffectPressed {
    NSInteger selected = [trollStoreUserDefaults() integerForKey:@"TSNavigationTransitionStyle"] == 1 ? 1 : 0;
    [self pushPersonalizationChoiceWithTitle:NSLocalizedString(@"Choose Animation Effect", nil)
                                    options:@[NSLocalizedString(@"Fade In/Out (Default)", nil), NSLocalizedString(@"Standard", nil)]
                                       key:@"TSNavigationTransitionStyle" selectedIndex:selected notification:nil];
}

- (void)changeThemeColorPressed {
    UIColorPickerViewController *picker = [UIColorPickerViewController new];
    picker.delegate = self;
    picker.supportsAlpha = YES;
    picker.selectedColor = [TSThemeManager accentColor];
    picker.title = NSLocalizedString(@"Change Theme Color", nil);
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)colorPickerViewControllerDidSelectColor:(UIColorPickerViewController *)viewController {
    UIColor *color = [viewController.selectedColor resolvedColorWithTraitCollection:self.traitCollection];
    CGFloat red = 0, green = 0, blue = 0, alpha = 1;
    if (![color getRed:&red green:&green blue:&blue alpha:&alpha]) {
        CGColorRef cgColor = color.CGColor;
        size_t componentCount = CGColorGetNumberOfComponents(cgColor);
        const CGFloat *components = CGColorGetComponents(cgColor);
        if (!components || (componentCount != 2 && componentCount < 4)) return;
        if (componentCount == 2) {
            red = green = blue = components[0];
            alpha = components[1];
        } else {
            red = components[0]; green = components[1]; blue = components[2]; alpha = components[3];
        }
    }
    [trollStoreUserDefaults() setObject:@{@"red":@(red), @"green":@(green), @"blue":@(blue), @"alpha":@(alpha)} forKey:@"TSThemeAccentCustomColor"];
    [trollStoreUserDefaults() removeObjectForKey:@"TSThemeAccent"];
    [TSThemeManager applyAppearance];
}

- (void)changeAppIconPressed {
    NSDictionary *info = NSBundle.mainBundle.infoDictionary;
    NSDictionary *icons = info[@"CFBundleIcons"] ?: info[@"CFBundleIcons~ipad"];
    NSDictionary *alternateIcons = icons[@"CFBundleAlternateIcons"];
    if (!UIApplication.sharedApplication.supportsAlternateIcons || alternateIcons.count == 0) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Change App Icon", nil) message:NSLocalizedString(@"This build does not include alternate app icons.", nil) preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    UIAlertController *menu = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Change App Icon", nil) message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    [menu addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Default", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        [UIApplication.sharedApplication setAlternateIconName:nil completionHandler:nil];
    }]];
    for (NSString *name in [[alternateIcons allKeys] sortedArrayUsingSelector:@selector(localizedStandardCompare:)]) {
        [menu addAction:[UIAlertAction actionWithTitle:name style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            [UIApplication.sharedApplication setAlternateIconName:name completionHandler:nil];
        }]];
    }
    [menu addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:menu animated:YES completion:nil];
}

- (void)setThemeMode:(NSInteger)mode
{
	[trollStoreUserDefaults() setInteger:MAX(0, MIN(2, mode)) forKey:@"TSThemeMode"];
	[TSThemeManager applyAppearance];
}

- (void)clearAllAppCachesPressed
{
	UIAlertController *confirm = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Clear All App Caches", nil) message:NSLocalizedString(@"Clear Library/Caches contents for user applications. System app containers and non-standard data containers are skipped. Other app data is preserved.", nil) preferredStyle:UIAlertControllerStyleAlert];
	[confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
	[confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Clear Caches", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
		[TSPresentationDelegate startActivity:NSLocalizedString(@"Clearing Application Caches", nil)];
		dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
			NSString *log = nil; int result = spawnRoot(rootHelperPath(), @[@"clear-cache-all"], nil, &log);
			dispatch_async(dispatch_get_main_queue(), ^{ [TSPresentationDelegate stopActivityWithCompletion:^{
				UIAlertController *resultAlert = [UIAlertController alertControllerWithTitle:result == 0 ? NSLocalizedString(@"Completed", nil) : NSLocalizedString(@"Completed With Warnings", nil) message:log.length ? log : [NSString stringWithFormat:NSLocalizedString(@"Cache cleanup returned code %d.", nil), result] preferredStyle:UIAlertControllerStyleAlert];
				[resultAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
				[TSPresentationDelegate presentViewController:resultAlert animated:YES completion:nil];
			}]; });
		});
	}]];
	[TSPresentationDelegate presentViewController:confirm animated:YES completion:nil];
}

- (NSArray*)installationConfirmationValues
{
	return @[@0, @1, @2];
}

- (NSArray*)installationConfirmationNames
{
	return @[NSLocalizedString(@"Always (Recommended)", nil), NSLocalizedString(@"Only on Remote URL Installs", nil), NSLocalizedString(@"Never (Not Recommeded)", nil)];
}

- (void)respringButtonPressed
{
	respring();
}

- (void)initializeBundledLdidPressed
{
	[TSInstallationController initializeBundledLdid];
}

- (id)getAutoInitializeLdid
{
	id value = [trollStoreUserDefaults() objectForKey:@"AutoInitializeBundledLdid"];
	return value ?: @NO;
}

- (void)setAutoInitializeLdid:(id)value
{
	BOOL enabled = [value boolValue];
	[trollStoreUserDefaults() setBool:enabled forKey:@"AutoInitializeBundledLdid"];
	if(enabled)
	{
		// Enabling the option immediately initializes the binary shipped in this build.
		[TSInstallationController initializeBundledLdid];
	}
}

- (id)getStealthInstallEnabled
{
	return @([trollStoreUserDefaults() boolForKey:@"TSStealthInstallEnabled"]);
}

- (void)setStealthInstallEnabled:(id)value
{
	// This preference only affects future installs; existing apps are never modified in place.
	[trollStoreUserDefaults() setBool:[value boolValue] forKey:@"TSStealthInstallEnabled"];
}

- (void)enableDevModePressed
{
	int ret = spawnRoot(rootHelperPath(), @[@"arm-dev-mode"], nil, nil);

	if (ret == 0) {
		UIAlertController* rebootNotification = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Reboot Required", nil)
			message:NSLocalizedString(@"After rebooting, select \"Turn On\" to enable developer mode.", nil)
			preferredStyle:UIAlertControllerStyleAlert
		];
		UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:^(UIAlertAction* action)
		{
			[self requestSettingsReload];
		}];
		[rebootNotification addAction:closeAction];

		UIAlertAction* rebootAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Reboot Now", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
		{
			spawnRoot(rootHelperPath(), @[@"reboot"], nil, nil);
		}];
		[rebootNotification addAction:rebootAction];

		[TSPresentationDelegate presentViewController:rebootNotification animated:YES completion:nil];
	} else {
		UIAlertController* errorAlert = [UIAlertController alertControllerWithTitle:[NSString stringWithFormat:NSLocalizedString(@"Error %d", nil), ret] message:NSLocalizedString(@"Failed to enable developer mode.", nil) preferredStyle:UIAlertControllerStyleAlert];
		UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];
		[errorAlert addAction:closeAction];

		[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:nil];
	}
}

#ifdef TS_ENABLE_APP_INTENTS
- (void)addRefreshShortcutPressed
{
	if (!findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_ALL)) return;
	TSRefreshShortcutController *controller = [TSRefreshShortcutController new];
	UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
	[TSPresentationDelegate presentViewController:navigation animated:YES completion:nil];
}
#endif

- (void)installPersistenceHelperPressed {
    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        NSMutableArray<NSDictionary<NSString *, NSString *> *> *appCandidates = [NSMutableArray new];
        [[LSApplicationWorkspace defaultWorkspace] enumerateApplicationsOfType:1 block:^(LSApplicationProxy *appProxy) {
            NSString *bundleIdentifier = appProxy.bundleIdentifier;
            if (!appProxy.installed || appProxy.restricted || [bundleIdentifier isEqualToString:@"com.apple.shortcuts"] || bundleIdentifier.length == 0) return;

            NSString *signaturePath = [@"/System/Library/AppSignatures" stringByAppendingPathComponent:bundleIdentifier];
            if (![[NSFileManager defaultManager] fileExistsAtPath:signaturePath]) return;

            NSURL *markerURL = [appProxy.bundleURL.URLByDeletingLastPathComponent URLByAppendingPathComponent:TS_ACTIVE_MARKER];
            if ([markerURL checkResourceIsReachableAndReturnError:nil]) return;

            [appCandidates addObject:@{
                @"bundleIdentifier": bundleIdentifier,
                @"name": appProxy.localizedName ?: bundleIdentifier
            }];
        }];

        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (!strongSelf || !strongSelf.view.window) return;

            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Select App", nil)
                message:NSLocalizedString(@"Select a system app to install the TrollStore Persistence Helper into. The normal function of the app will not be available, so it is recommended to pick something useless like the Tips app.", nil)
                preferredStyle:UIAlertControllerStyleActionSheet];

            for (NSDictionary<NSString *, NSString *> *candidate in appCandidates) {
                NSString *bundleIdentifier = candidate[@"bundleIdentifier"];
                NSString *name = candidate[@"name"];
                [alert addAction:[UIAlertAction actionWithTitle:name style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
                    [TSPresentationDelegate startActivity:NSLocalizedString(@"Installing Persistence Helper", nil)];
                    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
                        int result = spawnRoot(rootHelperPath(), @[@"install-persistence-helper", bundleIdentifier], nil, nil);
                        dispatch_async(dispatch_get_main_queue(), ^{
                            [TSPresentationDelegate stopActivityWithCompletion:^{
                                [strongSelf refreshSettingsRuntimeMetadata];
                                if (result != 0) {
                                    UIAlertController *error = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil)
                                        message:[NSString stringWithFormat:NSLocalizedString(@"Failed to install Persistence Helper (error %d).", nil), result]
                                        preferredStyle:UIAlertControllerStyleAlert];
                                    [error addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:nil]];
                                    [TSPresentationDelegate presentViewController:error animated:YES completion:nil];
                                }
                            }];
                        });
                    });
                }]];
            }

            if (appCandidates.count == 0) {
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"No Eligible Apps", nil) style:UIAlertActionStyleDefault handler:nil]];
            }
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];

            UIPopoverPresentationController *popover = alert.popoverPresentationController;
            if (popover) {
                popover.sourceView = strongSelf.view;
                popover.sourceRect = CGRectMake(CGRectGetMidX(strongSelf.view.bounds), CGRectGetMidY(strongSelf.view.bounds), 1.0, 1.0);
            }
            [strongSelf presentViewController:alert animated:YES completion:nil];
        });
    });
}

- (void)transferAppsPressed
{
	UIAlertController *confirmationAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Transfer Apps", nil) message:[NSString stringWithFormat:NSLocalizedString(@"This option will transfer %zu apps from %@ to %@. Continue?", nil), self.inactiveAppCount, OTHER_APP_NAME, APP_NAME] preferredStyle:UIAlertControllerStyleAlert];
	
	UIAlertAction* transferAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Transfer", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
	{
		[TSPresentationDelegate startActivity:NSLocalizedString(@"Transfering", nil)];
		dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^
		{
			NSString *log;
			int transferRet = spawnRoot(rootHelperPath(), @[@"transfer-apps"], nil, &log);
			NSUInteger remainingCount = transferRet == 0 ? 0 : trollStoreInactiveInstalledAppBundlePaths().count;

			dispatch_async(dispatch_get_main_queue(), ^
			{
				[TSPresentationDelegate stopActivityWithCompletion:^
				{
                    [self refreshSettingsRuntimeMetadata];

					if (transferRet != 0) {
						UIAlertController *errorAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Transfer Failed", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Failed to transfer %zu apps", nil), remainingCount] preferredStyle:UIAlertControllerStyleAlert];

						UIAlertAction* copyLogAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Copy Debug Log", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
						{
							UIPasteboard* pasteboard = [UIPasteboard generalPasteboard];
							pasteboard.string = log;
						}];
						[errorAlert addAction:copyLogAction];

						UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];
						[errorAlert addAction:closeAction];

						[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:nil];
					}
				}];
			});
		});
	}];
	[confirmationAlert addAction:transferAction];

	UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil];
	[confirmationAlert addAction:cancelAction];

	[TSPresentationDelegate presentViewController:confirmationAlert animated:YES completion:nil];
}

- (NSNumber *)getURLSchemeEnabled
{
    id URLSchemeTypes = [NSBundle.mainBundle objectForInfoDictionaryKey:@"CFBundleURLTypes"];
    return @(URLSchemeTypes != nil && URLSchemeTypes != NSNull.null);
}

- (void)setURLSchemeEnabled:(id)value
{
	NSNumber* newValue = value;
	NSString* newStateString = [newValue boolValue] ? @"enable" : @"disable";
	spawnRoot(rootHelperPath(), @[@"url-scheme", newStateString], nil, nil);

	UIAlertController* rebuildNoticeAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"URL Scheme Changed", nil) message:NSLocalizedString(@"In order to properly apply the change of the URL scheme setting, rebuilding the icon cache is needed.", nil) preferredStyle:UIAlertControllerStyleAlert];
	UIAlertAction* rebuildNowAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Rebuild Now", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
	{
		[self rebuildIconCachePressed];
	}];
	[rebuildNoticeAlert addAction:rebuildNowAction];

	UIAlertAction* rebuildLaterAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Rebuild Later", nil) style:UIAlertActionStyleCancel handler:nil];
	[rebuildNoticeAlert addAction:rebuildLaterAction];

	[TSPresentationDelegate presentViewController:rebuildNoticeAlert animated:YES completion:nil];
}

- (void)doTheDashPressed
{
	spawnRoot(rootHelperPath(), @[@"dash"], nil, nil);
}

- (NSMutableArray*)argsForUninstallingTrollStore
{
	NSMutableArray* args = @[@"uninstall-trollstore"].mutableCopy;

	NSNumber* uninstallationMethodToUseNum = [trollStoreUserDefaults() objectForKey:@"uninstallationMethod"];
    int uninstallationMethodToUse = uninstallationMethodToUseNum ? uninstallationMethodToUseNum.intValue : 0;
    if(uninstallationMethodToUse == 1)
    {
        [args addObject:@"custom"];
    }

	return args;
}


- (void)manageBlockedAppUpdatesPressed
{
    TSBlockedUpdatesController *controller = [TSBlockedUpdatesController new];
    [self.navigationController pushViewController:controller animated:YES];
}

- (void)setPluginInjectionEnabled:(id)value
{
    [trollStoreUserDefaults() setBool:[value boolValue] forKey:@"TSPluginInjectionEnabled"];
}

- (id)getPluginInjectionEnabled
{
    NSNumber *stored = [trollStoreUserDefaults() objectForKey:@"TSPluginInjectionEnabled"];
    return stored ?: @NO;
}



- (BOOL)isTrollStore { return YES; }

- (NSString *)getTrollStoreVersion {
    return [NSBundle.mainBundle objectForInfoDictionaryKey:@"CFBundleVersion"];
}

- (void)downloadTrollStoreAndRun:(void (^)(NSString *localTrollStoreTarPath))doHandler {
    NSURL *url = [NSURL URLWithString:@"https://github.com/opa334/TrollStore/releases/latest/download/TrollStore.tar"];
    NSURLSessionDownloadTask *task = [NSURLSession.sharedSession downloadTaskWithURL:url completionHandler:^(NSURL *location, NSURLResponse *response, NSError *error) {
        if (error || !location.path.length) {
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Error downloading TrollStore: %@", nil), error ?: @"Unknown error"] preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil]];
            dispatch_async(dispatch_get_main_queue(), ^{ [TSPresentationDelegate stopActivityWithCompletion:^{ [TSPresentationDelegate presentViewController:alert animated:YES completion:nil]; }]; });
            return;
        }
        NSString *target = [NSTemporaryDirectory() stringByAppendingPathComponent:@"TrollStore.tar"];
        [[NSFileManager defaultManager] removeItemAtPath:target error:nil];
        NSError *copyError = nil;
        if (![[NSFileManager defaultManager] copyItemAtPath:location.path toPath:target error:&copyError]) {
            UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil) message:copyError.localizedDescription ?: @"Unable to prepare update archive." preferredStyle:UIAlertControllerStyleAlert];
            [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil]];
            dispatch_async(dispatch_get_main_queue(), ^{ [TSPresentationDelegate stopActivityWithCompletion:^{ [TSPresentationDelegate presentViewController:alert animated:YES completion:nil]; }]; });
            return;
        }
        doHandler(target);
    }];
    [task resume];
}

- (void)_installTrollStoreComingFromUpdateFlow:(BOOL)update {
    [TSPresentationDelegate startActivity:update ? NSLocalizedString(@"Updating TrollStore", nil) : NSLocalizedString(@"Installing TrollStore", nil)];
    [self downloadTrollStoreAndRun:^(NSString *tarPath) {
        int result = spawnRoot(rootHelperPath(), @[@"install-trollstore", tarPath], nil, nil);
        [[NSFileManager defaultManager] removeItemAtPath:tarPath error:nil];
        if (result == 0) {
            respring();
            exit(0);
        }
        dispatch_async(dispatch_get_main_queue(), ^{
            [TSPresentationDelegate stopActivityWithCompletion:^{
                UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Error installing TrollStore: trollstorehelper returned %d", nil), result] preferredStyle:UIAlertControllerStyleAlert];
                [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil]];
                [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
            }];
        });
    }];
}

- (void)updateTrollStorePressed { [self _installTrollStoreComingFromUpdateFlow:YES]; }

- (void)rebuildIconCachePressed {
    [TSPresentationDelegate startActivity:NSLocalizedString(@"Rebuilding Icon Cache", nil)];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_DEFAULT, 0), ^{
        spawnRoot(rootHelperPath(), @[@"refresh-all"], nil, nil);
        dispatch_async(dispatch_get_main_queue(), ^{ [TSPresentationDelegate stopActivityWithCompletion:nil]; });
    });
}

- (void)refreshAppRegistrationsPressed {
    [TSPresentationDelegate startActivity:NSLocalizedString(@"Refreshing", nil)];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_DEFAULT, 0), ^{
        spawnRoot(rootHelperPath(), @[@"refresh"], nil, nil);
        respring();
        dispatch_async(dispatch_get_main_queue(), ^{ [TSPresentationDelegate stopActivityWithCompletion:nil]; });
    });
}

- (void)uninstallPersistenceHelperPressed {
    spawnRoot(rootHelperPath(), @[@"uninstall-persistence-helper"], nil, nil);
    [self refreshSettingsRuntimeMetadata];
}

- (void)handleUninstallation { exit(0); }

- (void)uninstallTrollStorePressed {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Uninstall", nil) message:NSLocalizedString(@"You are about to uninstall TrollStore, do you want to preserve the apps installed by it?", nil) preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Uninstall TrollStore, Uninstall Apps", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
        spawnRoot(rootHelperPath(), [self argsForUninstallingTrollStore], nil, nil);
        [self handleUninstallation];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Uninstall TrollStore, Preserve Apps", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
        NSMutableArray *args = [self argsForUninstallingTrollStore];
        [args addObject:@"preserve-apps"];
        spawnRoot(rootHelperPath(), args, nil, nil);
        [self handleUninstallation];
    }]];
    [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}


@end
