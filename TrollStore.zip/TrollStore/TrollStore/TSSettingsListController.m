#import "TSSettingsListController.h"
#import <TSUtil.h>
#import <Preferences/PSSpecifier.h>
#import <Preferences/PSListItemsController.h>
#import <TSPresentationDelegate.h>
#import "TSInstallationController.h"
#import "TSSettingsAdvancedListController.h"
#import "TSEntitlementsEditorViewController.h"

@interface NSUserDefaults (Private)
- (instancetype)_initWithSuiteName:(NSString *)suiteName container:(NSURL *)container;
@end
extern NSUserDefaults* trollStoreUserDefaults(void);

@implementation TSSettingsListController

- (void)viewDidLoad
{
	[super viewDidLoad];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadSpecifiers) name:UIApplicationWillEnterForegroundNotification object:nil];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadSpecifiers) name:@"TrollStoreReloadSettingsNotification" object:nil];

#ifndef TROLLSTORE_LITE
	fetchLatestTrollStoreVersion(^(NSString* latestVersion)
	{
		NSString* currentVersion = [self getTrollStoreVersion];
		NSComparisonResult result = [currentVersion compare:latestVersion options:NSNumericSearch];
		if(result == NSOrderedAscending)
		{
			_newerVersion = latestVersion;
			dispatch_async(dispatch_get_main_queue(), ^
			{
				[self reloadSpecifiers];
			});
		}
	});

	if (@available(iOS 16, *))
	{
		_devModeEnabled = spawnRoot(rootHelperPath(), @[@"check-dev-mode"], nil, nil) == 0;
	}
	else
	{
		_devModeEnabled = YES;
	}
#endif
	[self reloadSpecifiers];
}

- (NSMutableArray*)specifiers
{
	if(!_specifiers)
	{
		_specifiers = [NSMutableArray new];

#ifndef TROLLSTORE_LITE
		if(_newerVersion)
		{
			PSSpecifier* updateTrollStoreGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
			updateTrollStoreGroupSpecifier.name = NSLocalizedString(@"Update Available", nil);
			[_specifiers addObject:updateTrollStoreGroupSpecifier];

			PSSpecifier* updateTrollStoreSpecifier = [PSSpecifier preferenceSpecifierNamed:[NSString stringWithFormat:NSLocalizedString(@"Update TrollStore to %@", nil), _newerVersion]
										target:self
										set:nil
										get:nil
										detail:nil
										cell:PSButtonCell
										edit:nil];
			updateTrollStoreSpecifier.identifier = @"updateTrollStore";
			[updateTrollStoreSpecifier setProperty:@YES forKey:@"enabled"];
			updateTrollStoreSpecifier.buttonAction = @selector(updateTrollStorePressed);
			[_specifiers addObject:updateTrollStoreSpecifier];
		}

		if(!_devModeEnabled)
		{
			PSSpecifier* enableDevModeGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
			enableDevModeGroupSpecifier.name = NSLocalizedString(@"Developer Mode", nil);
			[enableDevModeGroupSpecifier setProperty:NSLocalizedString(@"Some apps require developer mode enabled to launch. This requires a reboot to take effect.", nil) forKey:@"footerText"];
			[_specifiers addObject:enableDevModeGroupSpecifier];

			PSSpecifier* enableDevModeSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Enable Developer Mode", nil)
										target:self
										set:nil
										get:nil
										detail:nil
										cell:PSButtonCell
										edit:nil];
			enableDevModeSpecifier.identifier = @"enableDevMode";
			[enableDevModeSpecifier setProperty:@YES forKey:@"enabled"];
			enableDevModeSpecifier.buttonAction = @selector(enableDevModePressed);
			[_specifiers addObject:enableDevModeSpecifier];
		}
#endif

		PSSpecifier* utilitiesGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
		utilitiesGroupSpecifier.name = NSLocalizedString(@"Utilities", nil);

		NSString *utilitiesDescription = @"";
#ifdef TROLLSTORE_LITE
		if (shouldRegisterAsUserByDefault()) {
			utilitiesDescription = NSLocalizedString(@"Apps will be registered as User by default since AppSync Unified is installed.\n\n", nil);
		}
		else {
			utilitiesDescription = NSLocalizedString(@"Apps will be registered as System by default since AppSync Unified is not installed. When apps loose their System registration and stop working, press \"Refresh App Registrations\" here to fix them.\n\n", nil);
		}
#endif
		utilitiesDescription = [utilitiesDescription stringByAppendingString:NSLocalizedString(@"If an app does not immediately appear after installation, respring here and it should appear afterwards.", nil)];

		[utilitiesGroupSpecifier setProperty:utilitiesDescription forKey:@"footerText"];
		[_specifiers addObject:utilitiesGroupSpecifier];

		PSSpecifier* respringButtonSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Respring", nil)
											target:self
											set:nil
											get:nil
											detail:nil
											cell:PSButtonCell
											edit:nil];
		 respringButtonSpecifier.identifier = @"respring";
		[respringButtonSpecifier setProperty:@YES forKey:@"enabled"];
		respringButtonSpecifier.buttonAction = @selector(respringButtonPressed);

		[_specifiers addObject:respringButtonSpecifier];

		PSSpecifier* refreshAppRegistrationsSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Refresh App Registrations", nil)
											target:self
											set:nil
											get:nil
											detail:nil
											cell:PSButtonCell
											edit:nil];
		refreshAppRegistrationsSpecifier.identifier = @"refreshAppRegistrations";
		[refreshAppRegistrationsSpecifier setProperty:@YES forKey:@"enabled"];
		refreshAppRegistrationsSpecifier.buttonAction = @selector(refreshAppRegistrationsPressed);

		[_specifiers addObject:refreshAppRegistrationsSpecifier];

		PSSpecifier* rebuildIconCacheSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Rebuild Icon Cache", nil)
											target:self
											set:nil
											get:nil
											detail:nil
											cell:PSButtonCell
											edit:nil];
		 rebuildIconCacheSpecifier.identifier = @"uicache";
		[rebuildIconCacheSpecifier setProperty:@YES forKey:@"enabled"];
		rebuildIconCacheSpecifier.buttonAction = @selector(rebuildIconCachePressed);

		[_specifiers addObject:rebuildIconCacheSpecifier];

		NSArray *inactiveBundlePaths = trollStoreInactiveInstalledAppBundlePaths();
		if (inactiveBundlePaths.count > 0) {
			NSString *transferCountTitle = [NSString stringWithFormat:NSLocalizedString(@"Transfer %zu ", nil), inactiveBundlePaths.count];
			transferCountTitle = [transferCountTitle stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
			NSString *transferAppWord = inactiveBundlePaths.count > 1 ? NSLocalizedString(@"Apps", nil) : NSLocalizedString(@"App", nil);
			NSString *transferTitle = [NSString stringWithFormat:@"%@ %@ %@", transferCountTitle, OTHER_APP_NAME, transferAppWord];
			PSSpecifier* transferAppsSpecifier = [PSSpecifier preferenceSpecifierNamed:transferTitle
											target:self
											set:nil
											get:nil
											detail:nil
											cell:PSButtonCell
											edit:nil];
			transferAppsSpecifier.identifier = @"transferApps";
			[transferAppsSpecifier setProperty:@YES forKey:@"enabled"];
			transferAppsSpecifier.buttonAction = @selector(transferAppsPressed);

			[_specifiers addObject:transferAppsSpecifier];
		}

#ifndef TROLLSTORE_LITE
		//if (@available(iOS 16, *)) { } else {
			PSSpecifier* signingGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
			signingGroupSpecifier.name = NSLocalizedString(@"Signing", nil);
			[signingGroupSpecifier setProperty:NSLocalizedString(@"This build uses the bundled custom ldid binary. No upstream version checks or downloads are performed.", nil) forKey:@"footerText"];
			[_specifiers addObject:signingGroupSpecifier];

			PSSpecifier* autoInitializeLdidSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Auto-initialize bundled ldid", nil)
										target:self
										set:@selector(setAutoInitializeLdid:forSpecifier:)
										get:@selector(getAutoInitializeLdidForSpecifier:)
									detail:nil
										cell:PSSwitchCell
										edit:nil];
			autoInitializeLdidSpecifier.identifier = @"autoInitializeBundledLdid";
			[autoInitializeLdidSpecifier setProperty:@"AutoInitializeBundledLdid" forKey:@"key"];
			[autoInitializeLdidSpecifier setProperty:@NO forKey:@"default"];
			[_specifiers addObject:autoInitializeLdidSpecifier];

			PSSpecifier* initializeLdidSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Initialize bundled ldid", nil)
										target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
			initializeLdidSpecifier.identifier = @"initializeBundledLdid";
			[initializeLdidSpecifier setProperty:@YES forKey:@"enabled"];
			initializeLdidSpecifier.buttonAction = @selector(initializeBundledLdidPressed);
			[_specifiers addObject:initializeLdidSpecifier];

		PSSpecifier* persistenceGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
		persistenceGroupSpecifier.name = NSLocalizedString(@"Persistence", nil);
		[_specifiers addObject:persistenceGroupSpecifier];

		if([[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/TrollStorePersistenceHelper.app"])
		{
			[persistenceGroupSpecifier setProperty:NSLocalizedString(@"When iOS rebuilds the icon cache, all TrollStore apps including TrollStore itself will be reverted to \"User\" state and either disappear or no longer launch. If that happens, you can use the TrollHelper app on the home screen to refresh the app registrations, which will make them work again.", nil) forKey:@"footerText"];
			PSSpecifier* installedPersistenceHelperSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Helper Installed as Standalone App", nil)
											target:self
											set:nil
											get:nil
											detail:nil
											cell:PSStaticTextCell
											edit:nil];
			[installedPersistenceHelperSpecifier setProperty:@NO forKey:@"enabled"];
			installedPersistenceHelperSpecifier.identifier = @"persistenceHelperInstalled";
			[_specifiers addObject:installedPersistenceHelperSpecifier];
		}
		else
		{
			LSApplicationProxy* persistenceApp = findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_ALL);
			if(persistenceApp)
			{
				NSString* appName = [persistenceApp localizedName];

				[persistenceGroupSpecifier setProperty:[NSString stringWithFormat:NSLocalizedString(@"When iOS rebuilds the icon cache, all TrollStore apps including TrollStore itself will be reverted to \"User\" state and either disappear or no longer launch. If that happens, you can use the persistence helper installed into %@ to refresh the app registrations, which will make them work again.", nil), appName] forKey:@"footerText"];
				PSSpecifier* installedPersistenceHelperSpecifier = [PSSpecifier preferenceSpecifierNamed:[NSString stringWithFormat:NSLocalizedString(@"Helper Installed into %@", nil), appName]
												target:self
												set:nil
												get:nil
												detail:nil
												cell:PSStaticTextCell
												edit:nil];
				[installedPersistenceHelperSpecifier setProperty:@NO forKey:@"enabled"];
				installedPersistenceHelperSpecifier.identifier = @"persistenceHelperInstalled";
				[_specifiers addObject:installedPersistenceHelperSpecifier];

				PSSpecifier* uninstallPersistenceHelperSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Uninstall Persistence Helper", nil)
												target:self
												set:nil
												get:nil
												detail:nil
												cell:PSButtonCell
												edit:nil];

				uninstallPersistenceHelperSpecifier.identifier = @"uninstallPersistenceHelper";
				[uninstallPersistenceHelperSpecifier setProperty:@YES forKey:@"enabled"];
				[uninstallPersistenceHelperSpecifier setProperty:NSClassFromString(@"PSDeleteButtonCell") forKey:@"cellClass"];
				uninstallPersistenceHelperSpecifier.buttonAction = @selector(uninstallPersistenceHelperPressed);
				[_specifiers addObject:uninstallPersistenceHelperSpecifier];
			}
			else
			{
				[persistenceGroupSpecifier setProperty:NSLocalizedString(@"When iOS rebuilds the icon cache, all TrollStore apps including TrollStore itself will be reverted to \"User\" state and either disappear or no longer launch. The only way to have persistence in a rootless environment is to replace a system application, here you can select a system app to replace with a persistence helper that can be used to refresh the registrations of all TrollStore related apps in case they disappear or no longer launch.", nil) forKey:@"footerText"];

				_installPersistenceHelperSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Install Persistence Helper", nil)
												target:self
												set:nil
												get:nil
												detail:nil
												cell:PSButtonCell
												edit:nil];
				_installPersistenceHelperSpecifier.identifier = @"installPersistenceHelper";
				[_installPersistenceHelperSpecifier setProperty:@YES forKey:@"enabled"];
				_installPersistenceHelperSpecifier.buttonAction = @selector(installPersistenceHelperPressed);
				[_specifiers addObject:_installPersistenceHelperSpecifier];
			}
		}
#endif

		// Compact in-app Entitlements controls: the toggle is a one-install override,
		// while the editor stores a reusable plist in Application Support.
		PSSpecifier* customEntitlementsGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
		customEntitlementsGroupSpecifier.name = NSLocalizedString(@"Custom Entitlements", nil);
		[customEntitlementsGroupSpecifier setProperty:NSLocalizedString(@"Saved custom Entitlements are applied to the next IPA installation only. Use Edit Entitlements to create or modify the plist. This option is off by default.", nil) forKey:@"footerText"];
		[_specifiers addObject:customEntitlementsGroupSpecifier];

		PSSpecifier* customEntitlementsEnabledSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Apply saved Entitlements on next install", nil)
											target:self
											set:@selector(setCustomEntitlementsEnabled:forSpecifier:)
											get:@selector(getCustomEntitlementsEnabledForSpecifier:)
											detail:nil
											cell:PSSwitchCell
											edit:nil];
		customEntitlementsEnabledSpecifier.identifier = @"customEntitlementsEnabled";
		[customEntitlementsEnabledSpecifier setProperty:@"TSCustomEntitlementsOverrideEnabled" forKey:@"key"];
		[customEntitlementsEnabledSpecifier setProperty:@NO forKey:@"default"];
		[_specifiers addObject:customEntitlementsEnabledSpecifier];

		PSSpecifier* editCustomEntitlementsSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Edit Entitlements", nil)
											target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
		editCustomEntitlementsSpecifier.identifier = @"editCustomEntitlements";
		[editCustomEntitlementsSpecifier setProperty:@YES forKey:@"enabled"];
		editCustomEntitlementsSpecifier.buttonAction = @selector(editCustomEntitlementsPressed);
		[_specifiers addObject:editCustomEntitlementsSpecifier];

		PSSpecifier* installationSettingsGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
		installationSettingsGroupSpecifier.name = NSLocalizedString(@"Security", nil);
		[installationSettingsGroupSpecifier setProperty:NSLocalizedString(@"The URL Scheme, when enabled, will allow apps and websites to trigger TrollStore installations through the apple-magnifier://install?url=<IPA_URL> URL scheme and enable JIT through the apple-magnifier://enable-jit?bundle-id=<BUNDLE_ID> URL scheme.", nil) forKey:@"footerText"];

		[_specifiers addObject:installationSettingsGroupSpecifier];

		PSSpecifier* URLSchemeToggle = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"URL Scheme Enabled", nil)
										target:self
										set:@selector(setURLSchemeEnabled:forSpecifier:)
										get:@selector(getURLSchemeEnabledForSpecifier:)
										detail:nil
										cell:PSSwitchCell
										edit:nil];

		[_specifiers addObject:URLSchemeToggle];

		PSSpecifier* stealthInstallGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
		stealthInstallGroupSpecifier.name = NSLocalizedString(@"TrollStore Stealth Install", nil);
		[stealthInstallGroupSpecifier setProperty:NSLocalizedString(@"For future IPA installs only: randomizes the installed bundle ID and removes URL schemes to reduce detection based on fixed identifiers. This is not a system-wide jailbreak hide and cannot defeat every detection method. URL callbacks, deep links, sign-in, keychain, app groups, push notifications, or extensions may stop working.", nil) forKey:@"footerText"];
		[_specifiers addObject:stealthInstallGroupSpecifier];

		PSSpecifier* stealthInstallSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Enable stealth install for new IPAs", nil)
										target:self
										set:@selector(setStealthInstallEnabled:forSpecifier:)
										get:@selector(getStealthInstallEnabledForSpecifier:)
									detail:nil
										cell:PSSwitchCell
										edit:nil];
		stealthInstallSpecifier.identifier = @"stealthInstallEnabled";
		[stealthInstallSpecifier setProperty:@"TSStealthInstallEnabled" forKey:@"key"];
		[stealthInstallSpecifier setProperty:@NO forKey:@"default"];
		[_specifiers addObject:stealthInstallSpecifier];

		PSSpecifier* installAlertConfigurationSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Show Install Confirmation Alert", nil)
										target:self
										set:@selector(setPreferenceValue:specifier:)
										get:@selector(readPreferenceValue:)
										detail:nil
										cell:PSLinkListCell
										edit:nil];

		installAlertConfigurationSpecifier.detailControllerClass = [PSListItemsController class];
		[installAlertConfigurationSpecifier setProperty:@"installationConfirmationValues" forKey:@"valuesDataSource"];
        [installAlertConfigurationSpecifier setProperty:@"installationConfirmationNames" forKey:@"titlesDataSource"];
		[installAlertConfigurationSpecifier setProperty:APP_ID forKey:@"defaults"];
		[installAlertConfigurationSpecifier setProperty:@"installAlertConfiguration" forKey:@"key"];
        [installAlertConfigurationSpecifier setProperty:@0 forKey:@"default"];

		[_specifiers addObject:installAlertConfigurationSpecifier];

		PSSpecifier* otherGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
		[otherGroupSpecifier setProperty:[NSString stringWithFormat:NSLocalizedString(@"%@ %@\n\n© 2022-2026 Lars Fröder (opa334)\n\nTrollStore is NOT for piracy!\n\nCredits:\nGoogle TAG, @alfiecg_dev: CoreTrust bug\n@lunotech11, @SerenaKit, @tylinux, @TheRealClarity, @dhinakg, @khanhduytran0: Various contributions\n@ProcursusTeam: uicache, ldid\n@cstar_ow: uicache\n@saurik: ldid", nil), APP_NAME, [self getTrollStoreVersion]] forKey:@"footerText"];
		[_specifiers addObject:otherGroupSpecifier];


		PSSpecifier* advancedLinkSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Advanced", nil)
										target:self
										set:nil
										get:nil
										detail:nil
										cell:PSLinkListCell
										edit:nil];
		advancedLinkSpecifier.detailControllerClass = [TSSettingsAdvancedListController class];
		[advancedLinkSpecifier setProperty:@YES forKey:@"enabled"];
		[_specifiers addObject:advancedLinkSpecifier];


#ifndef TROLLSTORE_LITE
		// Uninstall TrollStore
		PSSpecifier* uninstallTrollStoreSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Uninstall TrollStore", nil)
										target:self
										set:nil
										get:nil
										detail:nil
										cell:PSButtonCell
										edit:nil];
		uninstallTrollStoreSpecifier.identifier = @"uninstallTrollStore";
		[uninstallTrollStoreSpecifier setProperty:@YES forKey:@"enabled"];
		[uninstallTrollStoreSpecifier setProperty:NSClassFromString(@"PSDeleteButtonCell") forKey:@"cellClass"];
		uninstallTrollStoreSpecifier.buttonAction = @selector(uninstallTrollStorePressed);
		[_specifiers addObject:uninstallTrollStoreSpecifier];
#endif
		/*PSSpecifier* doTheDashSpecifier = [PSSpecifier preferenceSpecifierNamed:@"Do the Dash"
										target:self
										set:nil
										get:nil
										detail:nil
										cell:PSButtonCell
										edit:nil];
		doTheDashSpecifier.identifier = @"doTheDash";
		[doTheDashSpecifier setProperty:@YES forKey:@"enabled"];
		uninstallTrollStoreSpecifier.buttonAction = @selector(doTheDashPressed);
		[_specifiers addObject:doTheDashSpecifier];*/
	}

	[(UINavigationItem *)self.navigationItem setTitle:NSLocalizedString(@"Settings", nil)];
	return _specifiers;
}

- (NSArray*)installationConfirmationValues
{
	return @[@0, @1, @2];
}

- (NSArray*)installationConfirmationNames
{
	return @[NSLocalizedString(@"Always (Recommended)", nil), NSLocalizedString(@"Only on Remote URL Installs", nil), NSLocalizedString(@"Never (Not Recommeded)", nil)];
}

- (void)respringButtonPressed
{
	respring();
}

- (id)getCustomEntitlementsEnabledForSpecifier:(PSSpecifier*)specifier
{
	return @([trollStoreUserDefaults() boolForKey:@"TSCustomEntitlementsOverrideEnabled"]);
}

- (void)setCustomEntitlementsEnabled:(id)value forSpecifier:(PSSpecifier*)specifier
{
	[trollStoreUserDefaults() setBool:[value boolValue] forKey:@"TSCustomEntitlementsOverrideEnabled"];
}

- (void)editCustomEntitlementsPressed
{
	TSEntitlementsEditorViewController* editor = [TSEntitlementsEditorViewController new];
	UINavigationController* navigationController = [[UINavigationController alloc] initWithRootViewController:editor];
	[TSPresentationDelegate presentViewController:navigationController animated:YES completion:nil];
}

- (void)initializeBundledLdidPressed
{
	[TSInstallationController initializeBundledLdid];
}

- (id)getAutoInitializeLdidForSpecifier:(PSSpecifier*)specifier
{
	id value = [trollStoreUserDefaults() objectForKey:@"AutoInitializeBundledLdid"];
	return value ?: @NO;
}

- (void)setAutoInitializeLdid:(id)value forSpecifier:(PSSpecifier*)specifier
{
	BOOL enabled = [value boolValue];
	[trollStoreUserDefaults() setBool:enabled forKey:@"AutoInitializeBundledLdid"];
	if(enabled)
	{
		// Enabling the option immediately initializes the binary shipped in this build.
		[TSInstallationController initializeBundledLdid];
	}
}

- (id)getStealthInstallEnabledForSpecifier:(PSSpecifier*)specifier
{
	return @([trollStoreUserDefaults() boolForKey:@"TSStealthInstallEnabled"]);
}

- (void)setStealthInstallEnabled:(id)value forSpecifier:(PSSpecifier*)specifier
{
	// This preference only affects future installs; existing apps are never modified in place.
	[trollStoreUserDefaults() setBool:[value boolValue] forKey:@"TSStealthInstallEnabled"];
}

- (void)enableDevModePressed
{
	int ret = spawnRoot(rootHelperPath(), @[@"arm-dev-mode"], nil, nil);

	if (ret == 0) {
		UIAlertController* rebootNotification = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Reboot Required", nil)
			message:NSLocalizedString(@"After rebooting, select \"Turn On\" to enable developer mode.", nil)
			preferredStyle:UIAlertControllerStyleAlert
		];
		UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:^(UIAlertAction* action)
		{
			[self reloadSpecifiers];
		}];
		[rebootNotification addAction:closeAction];

		UIAlertAction* rebootAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Reboot Now", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
		{
			spawnRoot(rootHelperPath(), @[@"reboot"], nil, nil);
		}];
		[rebootNotification addAction:rebootAction];

		[TSPresentationDelegate presentViewController:rebootNotification animated:YES completion:nil];
	} else {
		UIAlertController* errorAlert = [UIAlertController alertControllerWithTitle:[NSString stringWithFormat:NSLocalizedString(@"Error %d", nil), ret] message:NSLocalizedString(@"Failed to enable developer mode.", nil) preferredStyle:UIAlertControllerStyleAlert];
		UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];
		[errorAlert addAction:closeAction];

		[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:nil];
	}
}

- (void)installPersistenceHelperPressed
{
	NSMutableArray* appCandidates = [NSMutableArray new];
	[[LSApplicationWorkspace defaultWorkspace] enumerateApplicationsOfType:1 block:^(LSApplicationProxy* appProxy)
	{
		if(appProxy.installed && !appProxy.restricted)
		{
			if([[NSFileManager defaultManager] fileExistsAtPath:[@"/System/Library/AppSignatures" stringByAppendingPathComponent:appProxy.bundleIdentifier]])
			{
				NSURL* trollStoreMarkURL = [appProxy.bundleURL.URLByDeletingLastPathComponent URLByAppendingPathComponent:TS_ACTIVE_MARKER];
				if(![trollStoreMarkURL checkResourceIsReachableAndReturnError:nil])
				{
					[appCandidates addObject:appProxy];
				}
			}
		}
	}];

	UIAlertController* selectAppAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Select App", nil) message:NSLocalizedString(@"Select a system app to install the TrollStore Persistence Helper into. The normal function of the app will not be available, so it is recommended to pick something useless like the Tips app.", nil) preferredStyle:UIAlertControllerStyleActionSheet];
	for(LSApplicationProxy* appProxy in appCandidates)
	{
		UIAlertAction* installAction = [UIAlertAction actionWithTitle:[appProxy localizedName] style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
		{
			spawnRoot(rootHelperPath(), @[@"install-persistence-helper", appProxy.bundleIdentifier], nil, nil);
			[self reloadSpecifiers];
		}];

		[selectAppAlert addAction:installAction];
	}

	NSIndexPath* indexPath = [self indexPathForSpecifier:_installPersistenceHelperSpecifier];
	UITableView* tableView = [self valueForKey:@"_table"];
	selectAppAlert.popoverPresentationController.sourceView = tableView;
	selectAppAlert.popoverPresentationController.sourceRect = [tableView rectForRowAtIndexPath:indexPath];

	UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil];
	[selectAppAlert addAction:cancelAction];

	[TSPresentationDelegate presentViewController:selectAppAlert animated:YES completion:nil];
}

- (void)transferAppsPressed
{
	UIAlertController *confirmationAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Transfer Apps", nil) message:[NSString stringWithFormat:NSLocalizedString(@"This option will transfer %zu apps from %@ to %@. Continue?", nil), trollStoreInactiveInstalledAppBundlePaths().count, OTHER_APP_NAME, APP_NAME] preferredStyle:UIAlertControllerStyleAlert];
	
	UIAlertAction* transferAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Transfer", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
	{
		[TSPresentationDelegate startActivity:NSLocalizedString(@"Transfering", nil)];
		dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^
		{
			NSString *log;
			int transferRet = spawnRoot(rootHelperPath(), @[@"transfer-apps"], nil, &log);

			dispatch_async(dispatch_get_main_queue(), ^
			{
				[TSPresentationDelegate stopActivityWithCompletion:^
				{
					[self reloadSpecifiers];

					if (transferRet != 0) {
						NSArray *remainingApps = trollStoreInactiveInstalledAppBundlePaths();
						UIAlertController *errorAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Transfer Failed", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Failed to transfer %zu apps", nil), remainingApps.count] preferredStyle:UIAlertControllerStyleAlert];

						UIAlertAction* copyLogAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Copy Debug Log", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
						{
							UIPasteboard* pasteboard = [UIPasteboard generalPasteboard];
							pasteboard.string = log;
						}];
						[errorAlert addAction:copyLogAction];

						UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];
						[errorAlert addAction:closeAction];

						[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:nil];
					}
				}];
			});
		});
	}];
	[confirmationAlert addAction:transferAction];

	UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil];
	[confirmationAlert addAction:cancelAction];

	[TSPresentationDelegate presentViewController:confirmationAlert animated:YES completion:nil];
}

- (id)getURLSchemeEnabledForSpecifier:(PSSpecifier*)specifier
{
	BOOL URLSchemeActive = (BOOL)[NSBundle.mainBundle objectForInfoDictionaryKey:@"CFBundleURLTypes"];
	return @(URLSchemeActive);
}

- (void)setURLSchemeEnabled:(id)value forSpecifier:(PSSpecifier*)specifier
{
	NSNumber* newValue = value;
	NSString* newStateString = [newValue boolValue] ? @"enable" : @"disable";
	spawnRoot(rootHelperPath(), @[@"url-scheme", newStateString], nil, nil);

	UIAlertController* rebuildNoticeAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"URL Scheme Changed", nil) message:NSLocalizedString(@"In order to properly apply the change of the URL scheme setting, rebuilding the icon cache is needed.", nil) preferredStyle:UIAlertControllerStyleAlert];
	UIAlertAction* rebuildNowAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Rebuild Now", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
	{
		[self rebuildIconCachePressed];
	}];
	[rebuildNoticeAlert addAction:rebuildNowAction];

	UIAlertAction* rebuildLaterAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Rebuild Later", nil) style:UIAlertActionStyleCancel handler:nil];
	[rebuildNoticeAlert addAction:rebuildLaterAction];

	[TSPresentationDelegate presentViewController:rebuildNoticeAlert animated:YES completion:nil];
}

- (void)doTheDashPressed
{
	spawnRoot(rootHelperPath(), @[@"dash"], nil, nil);
}

- (void)setPreferenceValue:(NSObject*)value specifier:(PSSpecifier*)specifier
{
	NSUserDefaults* tsDefaults = trollStoreUserDefaults();
	[tsDefaults setObject:value forKey:[specifier propertyForKey:@"key"]];
}

- (NSObject*)readPreferenceValue:(PSSpecifier*)specifier
{
	NSUserDefaults* tsDefaults = trollStoreUserDefaults();
	NSObject* toReturn = [tsDefaults objectForKey:[specifier propertyForKey:@"key"]];
	if(!toReturn)
	{
		toReturn = [specifier propertyForKey:@"default"];
	}
	return toReturn;
}

- (NSMutableArray*)argsForUninstallingTrollStore
{
	NSMutableArray* args = @[@"uninstall-trollstore"].mutableCopy;

	NSNumber* uninstallationMethodToUseNum = [trollStoreUserDefaults() objectForKey:@"uninstallationMethod"];
    int uninstallationMethodToUse = uninstallationMethodToUseNum ? uninstallationMethodToUseNum.intValue : 0;
    if(uninstallationMethodToUse == 1)
    {
        [args addObject:@"custom"];
    }

	return args;
}

@end