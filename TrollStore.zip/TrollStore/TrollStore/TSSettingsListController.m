#import "TSSettingsListController.h"
#import <TSUtil.h>
#import <Preferences/PSSpecifier.h>
#import <Preferences/PSListItemsController.h>
#import <TSPresentationDelegate.h>
#import "TSInstallationController.h"
#import "TSSettingsAdvancedListController.h"
#import "TSThemeManager.h"
#import "TSChoiceListController.h"
#import "TSSigningSettingsController.h"
#ifdef TS_ENABLE_APP_INTENTS
#import "TSRefreshShortcutController.h"
#endif
#import "TSBlockedUpdatesController.h"

@interface NSUserDefaults (Private)
- (instancetype)_initWithSuiteName:(NSString *)suiteName container:(NSURL *)container;
@end
extern NSUserDefaults* trollStoreUserDefaults(void);

@interface TSSettingsListController () <UIColorPickerViewControllerDelegate>
@property(nonatomic, assign) BOOL settingsVisible;
@property(nonatomic, assign) BOOL pendingSettingsReload;
@property(nonatomic, assign) BOOL pendingSpecifierRebuild;
@property(nonatomic, assign) BOOL settingsReloadScheduled;
@property(nonatomic, assign) BOOL didStartExpandedSettingsChecks;
- (void)setThemeMode:(NSInteger)mode;
- (void)settingsDidReceiveReloadNotification:(NSNotification *)notification;
- (void)startExpandedSettingsChecksIfNeeded;
- (void)requestSettingsReloadRebuildingSpecifiers:(BOOL)rebuild;
- (void)performPendingSettingsReload;
@end

@implementation TSSettingsListController

- (void)viewDidLoad
{
#ifndef TROLLSTORE_LITE
    // PSListController may request specifiers from inside [super viewDidLoad].
    // Initialize the status before that happens so the first table snapshot is
    // deterministic instead of depending on the zero-initialized ivar value.
    _devModeEnabled = YES;
#endif
    [super viewDidLoad];

    __weak typeof(self) weakSelf = self;
    UIAction *followSystem = [UIAction actionWithTitle:NSLocalizedString(@"System", nil) image:[UIImage systemImageNamed:@"gearshape"] identifier:@"ThemeSystem" handler:^(__kindof UIAction *action) {
        [weakSelf setThemeMode:0];
    }];
    UIAction *lightMode = [UIAction actionWithTitle:NSLocalizedString(@"Light", nil) image:[UIImage systemImageNamed:@"sun.max.fill"] identifier:@"ThemeLight" handler:^(__kindof UIAction *action) {
        [weakSelf setThemeMode:1];
    }];
    UIAction *darkMode = [UIAction actionWithTitle:NSLocalizedString(@"Dark", nil) image:[UIImage systemImageNamed:@"moon.fill"] identifier:@"ThemeDark" handler:^(__kindof UIAction *action) {
        [weakSelf setThemeMode:2];
    }];
    UIMenu *appearanceMenu = [UIMenu menuWithTitle:NSLocalizedString(@"Appearance", nil) children:@[followSystem, lightMode, darkMode]];
    // Let UIKit choose the normal navigation-bar symbol metrics. A fixed large
    // point-size configuration made this item look oversized across devices.
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"paintbrush.pointed.fill"] menu:appearanceMenu];
    self.navigationItem.rightBarButtonItem.accessibilityLabel = NSLocalizedString(@"Appearance", nil);

    NSNotificationCenter *center = NSNotificationCenter.defaultCenter;
    [center addObserver:self selector:@selector(settingsDidReceiveReloadNotification:) name:UIApplicationWillEnterForegroundNotification object:nil];
    [center addObserver:self selector:@selector(settingsDidReceiveReloadNotification:) name:@"TrollStoreReloadSettingsNotification" object:nil];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    self.settingsVisible = YES;
    [self performPendingSettingsReload];
    [self startExpandedSettingsChecksIfNeeded];
}

- (void)viewWillDisappear:(BOOL)animated
{
    self.settingsVisible = NO;
    [super viewWillDisappear:animated];
}

- (void)dealloc
{
    [NSNotificationCenter.defaultCenter removeObserver:self];
}

- (void)settingsDidReceiveReloadNotification:(NSNotification *)notification
{
    [self requestSettingsReloadRebuildingSpecifiers:NO];
}

- (void)requestSettingsReloadRebuildingSpecifiers:(BOOL)rebuild
{
    if (rebuild) self.pendingSpecifierRebuild = YES;
    self.pendingSettingsReload = YES;
    [self performPendingSettingsReload];
}

- (void)performPendingSettingsReload
{
    // PSListController's table is managed by the private Preferences framework.
    // Never reload it synchronously from a PSSpecifier action: doing so can
    // mutate the row model while the framework is still processing selection.
    // Coalesce notifications and action callbacks onto the next main-loop turn.
    if (self.settingsReloadScheduled || !self.settingsVisible || !self.isViewLoaded) return;
    self.settingsReloadScheduled = YES;

    __weak typeof(self) weakSelf = self;
    dispatch_async(dispatch_get_main_queue(), ^{
        __strong typeof(weakSelf) strongSelf = weakSelf;
        if (!strongSelf) return;
        strongSelf.settingsReloadScheduled = NO;

        // A hidden tab is retained by the custom root. Keep the request pending
        // until it becomes visible again rather than touching an off-screen table.
        if (!strongSelf.settingsVisible || !strongSelf.view.window) return;

        BOOL shouldRebuild = strongSelf.pendingSpecifierRebuild;
        BOOL shouldReload = strongSelf.pendingSettingsReload;
        strongSelf.pendingSpecifierRebuild = NO;
        strongSelf.pendingSettingsReload = NO;
        if (shouldRebuild) strongSelf->_specifiers = nil;
        if (shouldReload) [strongSelf reloadSpecifiers];
    });
}

- (void)startExpandedSettingsChecksIfNeeded
{
    if (self.didStartExpandedSettingsChecks || ![trollStoreUserDefaults() boolForKey:@"TSShowOtherSettings"]) return;
    self.didStartExpandedSettingsChecks = YES;

#ifndef TROLLSTORE_LITE
    __weak typeof(self) weakSelf = self;
    fetchLatestTrollStoreVersion(^(NSString *latestVersion) {
        if (![latestVersion isKindOfClass:NSString.class] || latestVersion.length == 0) return;
        dispatch_async(dispatch_get_main_queue(), ^{
            __strong typeof(weakSelf) strongSelf = weakSelf;
            if (!strongSelf) return;
            NSString *currentVersion = [strongSelf getTrollStoreVersion];
            if (![currentVersion isKindOfClass:NSString.class] || currentVersion.length == 0) return;
            if ([currentVersion compare:latestVersion options:NSNumericSearch] == NSOrderedAscending) {
                strongSelf->_newerVersion = latestVersion;
                [strongSelf requestSettingsReloadRebuildingSpecifiers:YES];
            }
        });
    });

    if (@available(iOS 16, *)) {
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            BOOL enabled = spawnRoot(rootHelperPath(), @[@"check-dev-mode"], nil, nil) == 0;
            dispatch_async(dispatch_get_main_queue(), ^{
                __strong typeof(weakSelf) strongSelf = weakSelf;
                if (!strongSelf || strongSelf->_devModeEnabled == enabled) return;
                strongSelf->_devModeEnabled = enabled;
                [strongSelf requestSettingsReloadRebuildingSpecifiers:YES];
            });
        });
    }
#endif
}

- (NSMutableArray*)specifiers
{
	if(!_specifiers)
	{
		_specifiers = [NSMutableArray new];

        // Personalization controls mirror the compact card-based settings
        // section from the supplied UI recording. The original TrollStore
        // settings remain available below the collapsible Other Settings row.
        PSSpecifier *personalizationGroup = [PSSpecifier emptyGroupSpecifier];
        personalizationGroup.name = NSLocalizedString(@"Personalization", nil);
        [personalizationGroup setProperty:NSLocalizedString(@"Customize the app list, navigation bar and theme.", nil) forKey:@"footerText"];
        [_specifiers addObject:personalizationGroup];

        NSArray<NSDictionary *> *personalizationSwitches = @[
            @{@"title": NSLocalizedString(@"Show System Apps", nil), @"key": @"TSShowSystemApps", @"default": @YES},
            @{@"title": NSLocalizedString(@"Show App Filter", nil), @"key": @"TSShowAppFilter", @"default": @YES},
            @{@"title": NSLocalizedString(@"Show TrollStore App Badge", nil), @"key": @"TSShowTrollStoreBadge", @"default": @YES},
            @{@"title": NSLocalizedString(@"Show App Type in Grid Layout", nil), @"key": @"TSShowAppTypeInGrid", @"default": @NO}
        ];
        for (NSDictionary *entry in personalizationSwitches) {
            PSSpecifier *toggle = [PSSpecifier preferenceSpecifierNamed:entry[@"title"] target:self set:@selector(setAppearancePreference:forSpecifier:) get:@selector(getAppearancePreferenceForSpecifier:) detail:nil cell:PSSwitchCell edit:nil];
            toggle.identifier = entry[@"key"];
            [toggle setProperty:entry[@"key"] forKey:@"key"];
            [toggle setProperty:entry[@"default"] forKey:@"default"];
            [_specifiers addObject:toggle];
        }

        NSArray<NSDictionary *> *personalizationActions = @[
            @{@"title": NSLocalizedString(@"App List Layout", nil), @"action": NSStringFromSelector(@selector(appListLayoutPressed))},
            @{@"title": NSLocalizedString(@"App Bottom Bar Style", nil), @"action": NSStringFromSelector(@selector(bottomBarStylePressed))},
            @{@"title": NSLocalizedString(@"Change Theme Color", nil), @"action": NSStringFromSelector(@selector(changeThemeColorPressed))},
            @{@"title": NSLocalizedString(@"Change App Icon", nil), @"action": NSStringFromSelector(@selector(changeAppIconPressed))},
            @{@"title": NSLocalizedString(@"Change In-App Animation Effect", nil), @"action": NSStringFromSelector(@selector(animationEffectPressed))}
        ];
        for (NSDictionary *entry in personalizationActions) {
            PSSpecifier *actionSpecifier = [PSSpecifier preferenceSpecifierNamed:entry[@"title"] target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
            actionSpecifier.identifier = entry[@"action"];
            [actionSpecifier setProperty:@YES forKey:@"enabled"];
            actionSpecifier.buttonAction = NSSelectorFromString(entry[@"action"]);
            [_specifiers addObject:actionSpecifier];
        }

        PSSpecifier *otherSettingsGroup = [PSSpecifier emptyGroupSpecifier];
        otherSettingsGroup.name = NSLocalizedString(@"Other Settings", nil);
        BOOL showOtherSettings = [trollStoreUserDefaults() boolForKey:@"TSShowOtherSettings"];
        [otherSettingsGroup setProperty:NSLocalizedString(showOtherSettings ? @"Tap to collapse Other Settings." : @"Tap to expand Other Settings.", nil) forKey:@"footerText"];
        [_specifiers addObject:otherSettingsGroup];
        if (!showOtherSettings) {
            PSSpecifier *showOtherSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Show Other Settings", nil) target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
            showOtherSpecifier.identifier = @"showOtherSettings";
            [showOtherSpecifier setProperty:@YES forKey:@"enabled"];
            showOtherSpecifier.buttonAction = @selector(showOtherSettingsPressed);
            [_specifiers addObject:showOtherSpecifier];
            [(UINavigationItem *)self.navigationItem setTitle:NSLocalizedString(@"Settings", nil)];
            return _specifiers;
        }

#ifndef TROLLSTORE_LITE
		if(_newerVersion)
		{
			PSSpecifier* updateTrollStoreGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
			updateTrollStoreGroupSpecifier.name = NSLocalizedString(@"Update Available", nil);
			[_specifiers addObject:updateTrollStoreGroupSpecifier];

			PSSpecifier* updateTrollStoreSpecifier = [PSSpecifier preferenceSpecifierNamed:[NSString stringWithFormat:NSLocalizedString(@"Update TrollStore to %@", nil), _newerVersion]
										target:self
										set:nil
										get:nil
										detail:nil
										cell:PSButtonCell
										edit:nil];
			updateTrollStoreSpecifier.identifier = @"updateTrollStore";
			[updateTrollStoreSpecifier setProperty:@YES forKey:@"enabled"];
			updateTrollStoreSpecifier.buttonAction = @selector(updateTrollStorePressed);
			[_specifiers addObject:updateTrollStoreSpecifier];
		}

		if(!_devModeEnabled)
		{
			PSSpecifier* enableDevModeGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
			enableDevModeGroupSpecifier.name = NSLocalizedString(@"Developer Mode", nil);
			[enableDevModeGroupSpecifier setProperty:NSLocalizedString(@"Some apps require developer mode enabled to launch. This requires a reboot to take effect.", nil) forKey:@"footerText"];
			[_specifiers addObject:enableDevModeGroupSpecifier];

			PSSpecifier* enableDevModeSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Enable Developer Mode", nil)
										target:self
										set:nil
										get:nil
										detail:nil
										cell:PSButtonCell
										edit:nil];
			enableDevModeSpecifier.identifier = @"enableDevMode";
			[enableDevModeSpecifier setProperty:@YES forKey:@"enabled"];
			enableDevModeSpecifier.buttonAction = @selector(enableDevModePressed);
			[_specifiers addObject:enableDevModeSpecifier];
		}
#endif

		PSSpecifier* utilitiesGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
		utilitiesGroupSpecifier.name = NSLocalizedString(@"Utilities", nil);

		NSString *utilitiesDescription = @"";
#ifdef TROLLSTORE_LITE
		if (shouldRegisterAsUserByDefault()) {
			utilitiesDescription = NSLocalizedString(@"Apps will be registered as User by default since AppSync Unified is installed.\n\n", nil);
		}
		else {
			utilitiesDescription = NSLocalizedString(@"Apps will be registered as System by default since AppSync Unified is not installed. When apps loose their System registration and stop working, press \"Refresh App Registrations\" here to fix them.\n\n", nil);
		}
#endif
		utilitiesDescription = [utilitiesDescription stringByAppendingString:NSLocalizedString(@"If an app does not immediately appear after installation, respring here and it should appear afterwards.", nil)];

		[utilitiesGroupSpecifier setProperty:utilitiesDescription forKey:@"footerText"];
		[_specifiers addObject:utilitiesGroupSpecifier];

		PSSpecifier* respringButtonSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Respring", nil)
											target:self
											set:nil
											get:nil
											detail:nil
											cell:PSButtonCell
											edit:nil];
		 respringButtonSpecifier.identifier = @"respring";
		[respringButtonSpecifier setProperty:@YES forKey:@"enabled"];
		respringButtonSpecifier.buttonAction = @selector(respringButtonPressed);

		[_specifiers addObject:respringButtonSpecifier];

		PSSpecifier* refreshAppRegistrationsSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Refresh App Registrations", nil)
											target:self
											set:nil
											get:nil
											detail:nil
											cell:PSButtonCell
											edit:nil];
		refreshAppRegistrationsSpecifier.identifier = @"refreshAppRegistrations";
		[refreshAppRegistrationsSpecifier setProperty:@YES forKey:@"enabled"];
		refreshAppRegistrationsSpecifier.buttonAction = @selector(refreshAppRegistrationsPressed);

		[_specifiers addObject:refreshAppRegistrationsSpecifier];

		PSSpecifier* clearAllCachesSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Clear All App Caches", nil)
									target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
		clearAllCachesSpecifier.identifier = @"clearAllAppCaches";
		[clearAllCachesSpecifier setProperty:@YES forKey:@"enabled"];
		clearAllCachesSpecifier.buttonAction = @selector(clearAllAppCachesPressed);
		[_specifiers addObject:clearAllCachesSpecifier];

        PSSpecifier* blockedUpdatesSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Blocked App Updates", nil)
                                    target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
        blockedUpdatesSpecifier.identifier = @"blockedAppUpdates";
        [blockedUpdatesSpecifier setProperty:@YES forKey:@"enabled"];
        blockedUpdatesSpecifier.buttonAction = @selector(manageBlockedAppUpdatesPressed);
        [_specifiers addObject:blockedUpdatesSpecifier];

        PSSpecifier *pluginsGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
        pluginsGroupSpecifier.name = NSLocalizedString(@"Plugins", nil);
#ifdef TROLLSTORE_LITE
        [pluginsGroupSpecifier setProperty:NSLocalizedString(@"The Plugins tab stores .dylib, .framework and DEB/ZIP files locally. Install-time dynamic-library injection is not available in TrollStore Lite.", nil) forKey:@"footerText"];
#else
        [pluginsGroupSpecifier setProperty:NSLocalizedString(@"The Plugins tab stores .dylib, .framework and DEB/ZIP packages locally. When enabled, IPA installation asks which extracted dynamic libraries to inject. No library is injected when the selection is empty. System tweaks that require MobileSubstrate still need a compatible tweak loader.", nil) forKey:@"footerText"];
#endif
        [_specifiers addObject:pluginsGroupSpecifier];

#ifndef TROLLSTORE_LITE
        PSSpecifier *pluginInjectionSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Enable Plugin Injection on Install", nil)
                                    target:self set:@selector(setPluginInjectionEnabled:forSpecifier:) get:@selector(getPluginInjectionEnabledForSpecifier:) detail:nil cell:PSSwitchCell edit:nil];
        pluginInjectionSpecifier.identifier = @"pluginInjectionEnabled";
        [pluginInjectionSpecifier setProperty:@"TSPluginInjectionEnabled" forKey:@"key"];
        [pluginInjectionSpecifier setProperty:@NO forKey:@"default"];
        [_specifiers addObject:pluginInjectionSpecifier];
#endif

		PSSpecifier* rebuildIconCacheSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Rebuild Icon Cache", nil)
											target:self
											set:nil
											get:nil
											detail:nil
											cell:PSButtonCell
											edit:nil];
		 rebuildIconCacheSpecifier.identifier = @"uicache";
		[rebuildIconCacheSpecifier setProperty:@YES forKey:@"enabled"];
		rebuildIconCacheSpecifier.buttonAction = @selector(rebuildIconCachePressed);

		[_specifiers addObject:rebuildIconCacheSpecifier];

		NSArray *inactiveBundlePaths = trollStoreInactiveInstalledAppBundlePaths();
		if (inactiveBundlePaths.count > 0) {
			NSString *transferCountTitle = [NSString stringWithFormat:NSLocalizedString(@"Transfer %zu ", nil), inactiveBundlePaths.count];
			transferCountTitle = [transferCountTitle stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
			NSString *transferAppWord = inactiveBundlePaths.count > 1 ? NSLocalizedString(@"Apps", nil) : NSLocalizedString(@"App", nil);
			NSString *transferTitle = [NSString stringWithFormat:@"%@ %@ %@", transferCountTitle, OTHER_APP_NAME, transferAppWord];
			PSSpecifier* transferAppsSpecifier = [PSSpecifier preferenceSpecifierNamed:transferTitle
											target:self
											set:nil
											get:nil
											detail:nil
											cell:PSButtonCell
											edit:nil];
			transferAppsSpecifier.identifier = @"transferApps";
			[transferAppsSpecifier setProperty:@YES forKey:@"enabled"];
			transferAppsSpecifier.buttonAction = @selector(transferAppsPressed);

			[_specifiers addObject:transferAppsSpecifier];
		}

#ifndef TROLLSTORE_LITE
		//if (@available(iOS 16, *)) { } else {
			PSSpecifier* signingGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
			signingGroupSpecifier.name = NSLocalizedString(@"Signing", nil);
			[signingGroupSpecifier setProperty:NSLocalizedString(@"This build uses the bundled custom ldid binary. No upstream version checks or downloads are performed.", nil) forKey:@"footerText"];
			[_specifiers addObject:signingGroupSpecifier];

			PSSpecifier* autoInitializeLdidSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Auto-initialize bundled ldid", nil)
										target:self
										set:@selector(setAutoInitializeLdid:forSpecifier:)
										get:@selector(getAutoInitializeLdidForSpecifier:)
									detail:nil
										cell:PSSwitchCell
										edit:nil];
			autoInitializeLdidSpecifier.identifier = @"autoInitializeBundledLdid";
			[autoInitializeLdidSpecifier setProperty:@"AutoInitializeBundledLdid" forKey:@"key"];
			[autoInitializeLdidSpecifier setProperty:@NO forKey:@"default"];
			[_specifiers addObject:autoInitializeLdidSpecifier];

			PSSpecifier* initializeLdidSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Initialize bundled ldid", nil)
										target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
			initializeLdidSpecifier.identifier = @"initializeBundledLdid";
			[initializeLdidSpecifier setProperty:@YES forKey:@"enabled"];
			initializeLdidSpecifier.buttonAction = @selector(initializeBundledLdidPressed);
			[_specifiers addObject:initializeLdidSpecifier];

			PSSpecifier* signingOptionsSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Signing Method & Certificates", nil)
									target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
			signingOptionsSpecifier.identifier = @"signingMethodAndCertificates";
			[signingOptionsSpecifier setProperty:@YES forKey:@"enabled"];
			signingOptionsSpecifier.buttonAction = @selector(signingMethodAndCertificatesPressed);
			[_specifiers addObject:signingOptionsSpecifier];

		PSSpecifier* persistenceGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
		persistenceGroupSpecifier.name = NSLocalizedString(@"Persistence", nil);
		[_specifiers addObject:persistenceGroupSpecifier];

		if([[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/TrollStorePersistenceHelper.app"])
		{
			[persistenceGroupSpecifier setProperty:NSLocalizedString(@"When iOS rebuilds the icon cache, all TrollStore apps including TrollStore itself will be reverted to \"User\" state and either disappear or no longer launch. If that happens, you can use the TrollHelper app on the home screen to refresh the app registrations, which will make them work again.", nil) forKey:@"footerText"];
			PSSpecifier* installedPersistenceHelperSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Helper Installed as Standalone App", nil)
											target:self
											set:nil
											get:nil
											detail:nil
											cell:PSStaticTextCell
											edit:nil];
			[installedPersistenceHelperSpecifier setProperty:@NO forKey:@"enabled"];
			installedPersistenceHelperSpecifier.identifier = @"persistenceHelperInstalled";
			[_specifiers addObject:installedPersistenceHelperSpecifier];
		}
		else
		{
			LSApplicationProxy* persistenceApp = findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_ALL);
			if(persistenceApp)
			{
				NSString* appName = [persistenceApp localizedName];

				[persistenceGroupSpecifier setProperty:[NSString stringWithFormat:NSLocalizedString(@"When iOS rebuilds the icon cache, all TrollStore apps including TrollStore itself will be reverted to \"User\" state and either disappear or no longer launch. If that happens, you can use the persistence helper installed into %@ to refresh the app registrations, which will make them work again.", nil), appName] forKey:@"footerText"];
				PSSpecifier* installedPersistenceHelperSpecifier = [PSSpecifier preferenceSpecifierNamed:[NSString stringWithFormat:NSLocalizedString(@"Helper Installed into %@", nil), appName]
												target:self
												set:nil
												get:nil
												detail:nil
												cell:PSStaticTextCell
												edit:nil];
				[installedPersistenceHelperSpecifier setProperty:@NO forKey:@"enabled"];
				installedPersistenceHelperSpecifier.identifier = @"persistenceHelperInstalled";
				[_specifiers addObject:installedPersistenceHelperSpecifier];

#ifdef TS_ENABLE_APP_INTENTS
				PSSpecifier* addRefreshShortcutSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Add Refresh Shortcut", nil)
												target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
				addRefreshShortcutSpecifier.identifier = @"addRefreshShortcut";
				[addRefreshShortcutSpecifier setProperty:@YES forKey:@"enabled"];
				addRefreshShortcutSpecifier.buttonAction = @selector(addRefreshShortcutPressed);
				[_specifiers addObject:addRefreshShortcutSpecifier];
#endif

				PSSpecifier* uninstallPersistenceHelperSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Uninstall Persistence Helper", nil)
												target:self
												set:nil
												get:nil
												detail:nil
												cell:PSButtonCell
												edit:nil];

				uninstallPersistenceHelperSpecifier.identifier = @"uninstallPersistenceHelper";
				[uninstallPersistenceHelperSpecifier setProperty:@YES forKey:@"enabled"];
				[uninstallPersistenceHelperSpecifier setProperty:NSClassFromString(@"PSDeleteButtonCell") forKey:@"cellClass"];
				uninstallPersistenceHelperSpecifier.buttonAction = @selector(uninstallPersistenceHelperPressed);
				[_specifiers addObject:uninstallPersistenceHelperSpecifier];
			}
			else
			{
				[persistenceGroupSpecifier setProperty:NSLocalizedString(@"When iOS rebuilds the icon cache, all TrollStore apps including TrollStore itself will be reverted to \"User\" state and either disappear or no longer launch. The only way to have persistence in a rootless environment is to replace a system application, here you can select a system app to replace with a persistence helper that can be used to refresh the registrations of all TrollStore related apps in case they disappear or no longer launch.", nil) forKey:@"footerText"];

				_installPersistenceHelperSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Install Persistence Helper", nil)
												target:self
												set:nil
												get:nil
												detail:nil
												cell:PSButtonCell
												edit:nil];
				_installPersistenceHelperSpecifier.identifier = @"installPersistenceHelper";
				[_installPersistenceHelperSpecifier setProperty:@YES forKey:@"enabled"];
				_installPersistenceHelperSpecifier.buttonAction = @selector(installPersistenceHelperPressed);
				[_specifiers addObject:_installPersistenceHelperSpecifier];
			}
		}
#endif

		// Optional per-install Entitlements editor. It always starts with the selected IPA's
		// embedded main-executable Entitlements; the edited plist is temporary and scoped
		// to that one installation only.
		PSSpecifier* entitlementsEditorGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
		entitlementsEditorGroupSpecifier.name = NSLocalizedString(@"Entitlements Editor", nil);
		[entitlementsEditorGroupSpecifier setProperty:NSLocalizedString(@"When enabled, opening an IPA for installation first opens its original main-app Entitlements for editing. Done proceeds to the normal installation confirmation; Cancel cancels the entire installation and returns to the previous page. The edited Entitlements apply only to this installation, and app extensions keep their own original Entitlements.", nil) forKey:@"footerText"];
		[_specifiers addObject:entitlementsEditorGroupSpecifier];

		PSSpecifier* editEntitlementsBeforeInstallSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Edit Entitlements Before Install", nil)
								target:self
								set:@selector(setPreferenceValue:specifier:)
								get:@selector(readPreferenceValue:)
								detail:nil
								cell:PSSwitchCell
								edit:nil];
		editEntitlementsBeforeInstallSpecifier.identifier = @"editEntitlementsBeforeInstall";
		[editEntitlementsBeforeInstallSpecifier setProperty:APP_ID forKey:@"defaults"];
		[editEntitlementsBeforeInstallSpecifier setProperty:@"TSEditEntitlementsBeforeInstallEnabled" forKey:@"key"];
		[editEntitlementsBeforeInstallSpecifier setProperty:@NO forKey:@"default"];
		[_specifiers addObject:editEntitlementsBeforeInstallSpecifier];

		PSSpecifier* installationSettingsGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
		installationSettingsGroupSpecifier.name = NSLocalizedString(@"Security", nil);
		[installationSettingsGroupSpecifier setProperty:NSLocalizedString(@"The URL Scheme, when enabled, will allow apps and websites to trigger TrollStore installations through the apple-magnifier://install?url=<IPA_URL> URL scheme and enable JIT through the apple-magnifier://enable-jit?bundle-id=<BUNDLE_ID> URL scheme.", nil) forKey:@"footerText"];

		[_specifiers addObject:installationSettingsGroupSpecifier];

		PSSpecifier* URLSchemeToggle = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"URL Scheme Enabled", nil)
										target:self
										set:@selector(setURLSchemeEnabled:forSpecifier:)
										get:@selector(getURLSchemeEnabledForSpecifier:)
										detail:nil
										cell:PSSwitchCell
										edit:nil];

		[_specifiers addObject:URLSchemeToggle];

		PSSpecifier* stealthInstallGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
		stealthInstallGroupSpecifier.name = NSLocalizedString(@"TrollStore Stealth Install", nil);
		[stealthInstallGroupSpecifier setProperty:NSLocalizedString(@"For future IPA installs only: randomizes the installed bundle ID and removes URL schemes to reduce detection based on fixed identifiers. This is not a system-wide jailbreak hide and cannot defeat every detection method. URL callbacks, deep links, sign-in, keychain, app groups, push notifications, or extensions may stop working.", nil) forKey:@"footerText"];
		[_specifiers addObject:stealthInstallGroupSpecifier];

		PSSpecifier* stealthInstallSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Enable stealth install for new IPAs", nil)
										target:self
										set:@selector(setStealthInstallEnabled:forSpecifier:)
										get:@selector(getStealthInstallEnabledForSpecifier:)
									detail:nil
										cell:PSSwitchCell
										edit:nil];
		stealthInstallSpecifier.identifier = @"stealthInstallEnabled";
		[stealthInstallSpecifier setProperty:@"TSStealthInstallEnabled" forKey:@"key"];
		[stealthInstallSpecifier setProperty:@NO forKey:@"default"];
		[_specifiers addObject:stealthInstallSpecifier];

		PSSpecifier* installAlertConfigurationSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Show Install Confirmation Alert", nil)
										target:self
										set:@selector(setPreferenceValue:specifier:)
										get:@selector(readPreferenceValue:)
										detail:nil
										cell:PSLinkListCell
										edit:nil];

		installAlertConfigurationSpecifier.detailControllerClass = [PSListItemsController class];
		[installAlertConfigurationSpecifier setProperty:@"installationConfirmationValues" forKey:@"valuesDataSource"];
        [installAlertConfigurationSpecifier setProperty:@"installationConfirmationNames" forKey:@"titlesDataSource"];
		[installAlertConfigurationSpecifier setProperty:APP_ID forKey:@"defaults"];
		[installAlertConfigurationSpecifier setProperty:@"installAlertConfiguration" forKey:@"key"];
        [installAlertConfigurationSpecifier setProperty:@0 forKey:@"default"];

		[_specifiers addObject:installAlertConfigurationSpecifier];

		PSSpecifier* otherGroupSpecifier = [PSSpecifier emptyGroupSpecifier];
		[otherGroupSpecifier setProperty:[NSString stringWithFormat:NSLocalizedString(@"%@ %@\n\n© 2022-2026 Lars Fröder (opa334)\n\nTrollStore is NOT for piracy!\n\nCredits:\nGoogle TAG, @alfiecg_dev: CoreTrust bug\n@lunotech11, @SerenaKit, @tylinux, @TheRealClarity, @dhinakg, @khanhduytran0: Various contributions\n@ProcursusTeam: uicache, ldid\n@cstar_ow: uicache\n@saurik: ldid", nil), APP_NAME, [self getTrollStoreVersion]] forKey:@"footerText"];
		[_specifiers addObject:otherGroupSpecifier];


		PSSpecifier* advancedLinkSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Advanced", nil)
										target:self
										set:nil
										get:nil
										detail:nil
										cell:PSLinkListCell
										edit:nil];
		advancedLinkSpecifier.detailControllerClass = [TSSettingsAdvancedListController class];
		[advancedLinkSpecifier setProperty:@YES forKey:@"enabled"];
		[_specifiers addObject:advancedLinkSpecifier];


#ifndef TROLLSTORE_LITE
		// Uninstall TrollStore
		PSSpecifier* uninstallTrollStoreSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Uninstall TrollStore", nil)
										target:self
										set:nil
										get:nil
										detail:nil
										cell:PSButtonCell
										edit:nil];
		uninstallTrollStoreSpecifier.identifier = @"uninstallTrollStore";
		[uninstallTrollStoreSpecifier setProperty:@YES forKey:@"enabled"];
		[uninstallTrollStoreSpecifier setProperty:NSClassFromString(@"PSDeleteButtonCell") forKey:@"cellClass"];
		uninstallTrollStoreSpecifier.buttonAction = @selector(uninstallTrollStorePressed);
		[_specifiers addObject:uninstallTrollStoreSpecifier];
#endif
		/*PSSpecifier* doTheDashSpecifier = [PSSpecifier preferenceSpecifierNamed:@"Do the Dash"
										target:self
										set:nil
										get:nil
										detail:nil
										cell:PSButtonCell
										edit:nil];
		doTheDashSpecifier.identifier = @"doTheDash";
		[doTheDashSpecifier setProperty:@YES forKey:@"enabled"];
		uninstallTrollStoreSpecifier.buttonAction = @selector(doTheDashPressed);
		[_specifiers addObject:doTheDashSpecifier];*/
		// PSListController can ask for this array repeatedly. Keep all mutations
		// inside the one-time build block to avoid duplicate rows and row-count
		// mismatches during table updates.
		PSSpecifier *hideOtherSpecifier = [PSSpecifier preferenceSpecifierNamed:NSLocalizedString(@"Hide Other Settings", nil) target:self set:nil get:nil detail:nil cell:PSButtonCell edit:nil];
		hideOtherSpecifier.identifier = @"hideOtherSettings";
		[hideOtherSpecifier setProperty:@YES forKey:@"enabled"];
		hideOtherSpecifier.buttonAction = @selector(hideOtherSettingsPressed);
		[_specifiers addObject:hideOtherSpecifier];
	}

	[(UINavigationItem *)self.navigationItem setTitle:NSLocalizedString(@"Settings", nil)];
	return _specifiers;
}

- (void)signingMethodAndCertificatesPressed
{
	TSSigningSettingsController *controller = [TSSigningSettingsController new];
	UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
	[TSPresentationDelegate presentViewController:navigation animated:YES completion:nil];
}


- (id)getAppearancePreferenceForSpecifier:(PSSpecifier *)specifier {
    NSString *key = [specifier propertyForKey:@"key"];
    id value = [trollStoreUserDefaults() objectForKey:key];
    return value ?: ([specifier propertyForKey:@"default"] ?: @NO);
}

- (void)setAppearancePreference:(id)value forSpecifier:(PSSpecifier *)specifier {
    NSString *key = [specifier propertyForKey:@"key"];
    if (key.length) [trollStoreUserDefaults() setBool:[value boolValue] forKey:key];
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TSAppAppearanceSettingsChanged" object:nil];
}

- (void)showOtherSettingsPressed {
    [trollStoreUserDefaults() setBool:YES forKey:@"TSShowOtherSettings"];
    [self requestSettingsReloadRebuildingSpecifiers:YES];
    [self startExpandedSettingsChecksIfNeeded];
}

- (void)hideOtherSettingsPressed {
    [trollStoreUserDefaults() setBool:NO forKey:@"TSShowOtherSettings"];
    [self requestSettingsReloadRebuildingSpecifiers:YES];
}

- (void)pushPersonalizationChoiceWithTitle:(NSString *)title options:(NSArray<NSString *> *)options key:(NSString *)key selectedIndex:(NSInteger)selectedIndex notification:(NSString *)notification {
    __weak typeof(self) weakSelf = self;
    TSChoiceListController *controller = [[TSChoiceListController alloc] initWithTitle:title options:options selectedIndex:selectedIndex selectionHandler:^(NSInteger index) {
        NSUserDefaults *defaults = trollStoreUserDefaults();
        [defaults setInteger:index forKey:key];
        if ([key isEqualToString:@"TSFloatingBarStyle"]) {
            [defaults setBool:(index != 1) forKey:@"TSFloatingTabBarEnabled"];
        }
        if (notification.length) [[NSNotificationCenter defaultCenter] postNotificationName:notification object:nil];
    }];
    [weakSelf.navigationController pushViewController:controller animated:YES];
}

- (void)appListLayoutPressed {
    NSInteger selected = [trollStoreUserDefaults() integerForKey:@"TSAppListLayout"] == 1 ? 1 : 0;
    [self pushPersonalizationChoiceWithTitle:NSLocalizedString(@"App List Layout", nil)
                                    options:@[NSLocalizedString(@"List", nil), NSLocalizedString(@"Grid", nil)]
                                       key:@"TSAppListLayout" selectedIndex:selected notification:@"TSAppListLayoutChanged"];
}

- (void)bottomBarStylePressed {
    NSInteger selected = [TSThemeManager floatingBarStyle];
    [self pushPersonalizationChoiceWithTitle:NSLocalizedString(@"Choose Bottom Bar Style", nil)
                                    options:@[NSLocalizedString(@"Floating", nil), NSLocalizedString(@"Standard", nil), NSLocalizedString(@"Floating 2", nil)]
                                       key:@"TSFloatingBarStyle" selectedIndex:selected notification:@"TSAppearanceChanged"];
}

- (void)animationEffectPressed {
    NSInteger selected = [trollStoreUserDefaults() integerForKey:@"TSNavigationTransitionStyle"] == 1 ? 1 : 0;
    [self pushPersonalizationChoiceWithTitle:NSLocalizedString(@"Choose Animation Effect", nil)
                                    options:@[NSLocalizedString(@"Fade In/Out (Default)", nil), NSLocalizedString(@"Standard", nil)]
                                       key:@"TSNavigationTransitionStyle" selectedIndex:selected notification:nil];
}

- (void)changeThemeColorPressed {
    UIColorPickerViewController *picker = [UIColorPickerViewController new];
    picker.delegate = self;
    picker.supportsAlpha = YES;
    picker.selectedColor = [TSThemeManager accentColor];
    picker.title = NSLocalizedString(@"Change Theme Color", nil);
    [self presentViewController:picker animated:YES completion:nil];
}

- (void)colorPickerViewControllerDidSelectColor:(UIColorPickerViewController *)viewController {
    UIColor *color = [viewController.selectedColor resolvedColorWithTraitCollection:self.traitCollection];
    CGFloat red = 0, green = 0, blue = 0, alpha = 1;
    if (![color getRed:&red green:&green blue:&blue alpha:&alpha]) {
        CGColorRef cgColor = color.CGColor;
        size_t componentCount = CGColorGetNumberOfComponents(cgColor);
        const CGFloat *components = CGColorGetComponents(cgColor);
        if (!components || (componentCount != 2 && componentCount < 4)) return;
        if (componentCount == 2) {
            red = green = blue = components[0];
            alpha = components[1];
        } else {
            red = components[0]; green = components[1]; blue = components[2]; alpha = components[3];
        }
    }
    [trollStoreUserDefaults() setObject:@{@"red":@(red), @"green":@(green), @"blue":@(blue), @"alpha":@(alpha)} forKey:@"TSThemeAccentCustomColor"];
    [trollStoreUserDefaults() removeObjectForKey:@"TSThemeAccent"];
    [TSThemeManager applyAppearance];
}

- (void)changeAppIconPressed {
    NSDictionary *info = NSBundle.mainBundle.infoDictionary;
    NSDictionary *icons = info[@"CFBundleIcons"] ?: info[@"CFBundleIcons~ipad"];
    NSDictionary *alternateIcons = icons[@"CFBundleAlternateIcons"];
    if (!UIApplication.sharedApplication.supportsAlternateIcons || alternateIcons.count == 0) {
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Change App Icon", nil) message:NSLocalizedString(@"This build does not include alternate app icons.", nil) preferredStyle:UIAlertControllerStyleAlert];
        [alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:alert animated:YES completion:nil];
        return;
    }
    UIAlertController *menu = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Change App Icon", nil) message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    [menu addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Default", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        [UIApplication.sharedApplication setAlternateIconName:nil completionHandler:nil];
    }]];
    for (NSString *name in [[alternateIcons allKeys] sortedArrayUsingSelector:@selector(localizedStandardCompare:)]) {
        [menu addAction:[UIAlertAction actionWithTitle:name style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            [UIApplication.sharedApplication setAlternateIconName:name completionHandler:nil];
        }]];
    }
    [menu addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:menu animated:YES completion:nil];
}

- (void)setThemeMode:(NSInteger)mode
{
	[trollStoreUserDefaults() setInteger:MAX(0, MIN(2, mode)) forKey:@"TSThemeMode"];
	[TSThemeManager applyAppearance];
}

- (void)clearAllAppCachesPressed
{
	UIAlertController *confirm = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Clear All App Caches", nil) message:NSLocalizedString(@"Clear Library/Caches contents for user applications. System app containers and non-standard data containers are skipped. Other app data is preserved.", nil) preferredStyle:UIAlertControllerStyleAlert];
	[confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
	[confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Clear Caches", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
		[TSPresentationDelegate startActivity:NSLocalizedString(@"Clearing Application Caches", nil)];
		dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
			NSString *log = nil; int result = spawnRoot(rootHelperPath(), @[@"clear-cache-all"], nil, &log);
			dispatch_async(dispatch_get_main_queue(), ^{ [TSPresentationDelegate stopActivityWithCompletion:^{
				UIAlertController *resultAlert = [UIAlertController alertControllerWithTitle:result == 0 ? NSLocalizedString(@"Completed", nil) : NSLocalizedString(@"Completed With Warnings", nil) message:log.length ? log : [NSString stringWithFormat:NSLocalizedString(@"Cache cleanup returned code %d.", nil), result] preferredStyle:UIAlertControllerStyleAlert];
				[resultAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
				[TSPresentationDelegate presentViewController:resultAlert animated:YES completion:nil];
			}]; });
		});
	}]];
	[TSPresentationDelegate presentViewController:confirm animated:YES completion:nil];
}

- (NSArray*)installationConfirmationValues
{
	return @[@0, @1, @2];
}

- (NSArray*)installationConfirmationNames
{
	return @[NSLocalizedString(@"Always (Recommended)", nil), NSLocalizedString(@"Only on Remote URL Installs", nil), NSLocalizedString(@"Never (Not Recommeded)", nil)];
}

- (void)respringButtonPressed
{
	respring();
}

- (void)initializeBundledLdidPressed
{
	[TSInstallationController initializeBundledLdid];
}

- (id)getAutoInitializeLdidForSpecifier:(PSSpecifier*)specifier
{
	id value = [trollStoreUserDefaults() objectForKey:@"AutoInitializeBundledLdid"];
	return value ?: @NO;
}

- (void)setAutoInitializeLdid:(id)value forSpecifier:(PSSpecifier*)specifier
{
	BOOL enabled = [value boolValue];
	[trollStoreUserDefaults() setBool:enabled forKey:@"AutoInitializeBundledLdid"];
	if(enabled)
	{
		// Enabling the option immediately initializes the binary shipped in this build.
		[TSInstallationController initializeBundledLdid];
	}
}

- (id)getStealthInstallEnabledForSpecifier:(PSSpecifier*)specifier
{
	return @([trollStoreUserDefaults() boolForKey:@"TSStealthInstallEnabled"]);
}

- (void)setStealthInstallEnabled:(id)value forSpecifier:(PSSpecifier*)specifier
{
	// This preference only affects future installs; existing apps are never modified in place.
	[trollStoreUserDefaults() setBool:[value boolValue] forKey:@"TSStealthInstallEnabled"];
}

- (void)enableDevModePressed
{
	int ret = spawnRoot(rootHelperPath(), @[@"arm-dev-mode"], nil, nil);

	if (ret == 0) {
		UIAlertController* rebootNotification = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Reboot Required", nil)
			message:NSLocalizedString(@"After rebooting, select \"Turn On\" to enable developer mode.", nil)
			preferredStyle:UIAlertControllerStyleAlert
		];
		UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleCancel handler:^(UIAlertAction* action)
		{
			[self requestSettingsReloadRebuildingSpecifiers:NO];
		}];
		[rebootNotification addAction:closeAction];

		UIAlertAction* rebootAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Reboot Now", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
		{
			spawnRoot(rootHelperPath(), @[@"reboot"], nil, nil);
		}];
		[rebootNotification addAction:rebootAction];

		[TSPresentationDelegate presentViewController:rebootNotification animated:YES completion:nil];
	} else {
		UIAlertController* errorAlert = [UIAlertController alertControllerWithTitle:[NSString stringWithFormat:NSLocalizedString(@"Error %d", nil), ret] message:NSLocalizedString(@"Failed to enable developer mode.", nil) preferredStyle:UIAlertControllerStyleAlert];
		UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];
		[errorAlert addAction:closeAction];

		[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:nil];
	}
}

#ifdef TS_ENABLE_APP_INTENTS
- (void)addRefreshShortcutPressed
{
	if (!findPersistenceHelperApp(PERSISTENCE_HELPER_TYPE_ALL)) return;
	TSRefreshShortcutController *controller = [TSRefreshShortcutController new];
	UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:controller];
	[TSPresentationDelegate presentViewController:navigation animated:YES completion:nil];
}
#endif

- (void)installPersistenceHelperPressed
{
	NSMutableArray* appCandidates = [NSMutableArray new];
	[[LSApplicationWorkspace defaultWorkspace] enumerateApplicationsOfType:1 block:^(LSApplicationProxy* appProxy)
	{
		// Apple Shortcuts must remain a normal, independently usable app.
		// TrollStore's Refresh Apps action is an App Intent; it never requires
		// installing or injecting the Persistence Helper into Shortcuts.app.
		if ([appProxy.bundleIdentifier isEqualToString:@"com.apple.shortcuts"]) return;
		if(appProxy.installed && !appProxy.restricted)
		{
			if([[NSFileManager defaultManager] fileExistsAtPath:[@"/System/Library/AppSignatures" stringByAppendingPathComponent:appProxy.bundleIdentifier]])
			{
				NSURL* trollStoreMarkURL = [appProxy.bundleURL.URLByDeletingLastPathComponent URLByAppendingPathComponent:TS_ACTIVE_MARKER];
				if(![trollStoreMarkURL checkResourceIsReachableAndReturnError:nil])
				{
					[appCandidates addObject:appProxy];
				}
			}
		}
	}];

	UIAlertController* selectAppAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Select App", nil) message:NSLocalizedString(@"Select a system app to install the TrollStore Persistence Helper into. The normal function of the app will not be available, so it is recommended to pick something useless like the Tips app.", nil) preferredStyle:UIAlertControllerStyleActionSheet];
	for(LSApplicationProxy* appProxy in appCandidates)
	{
		UIAlertAction* installAction = [UIAlertAction actionWithTitle:[appProxy localizedName] style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
		{
			spawnRoot(rootHelperPath(), @[@"install-persistence-helper", appProxy.bundleIdentifier], nil, nil);
			[self requestSettingsReloadRebuildingSpecifiers:NO];
		}];

		[selectAppAlert addAction:installAction];
	}

	NSIndexPath* indexPath = [self indexPathForSpecifier:_installPersistenceHelperSpecifier];
	UITableView* tableView = [self valueForKey:@"_table"];
	selectAppAlert.popoverPresentationController.sourceView = tableView;
	selectAppAlert.popoverPresentationController.sourceRect = [tableView rectForRowAtIndexPath:indexPath];

	UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil];
	[selectAppAlert addAction:cancelAction];

	[TSPresentationDelegate presentViewController:selectAppAlert animated:YES completion:nil];
}

- (void)transferAppsPressed
{
	UIAlertController *confirmationAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Transfer Apps", nil) message:[NSString stringWithFormat:NSLocalizedString(@"This option will transfer %zu apps from %@ to %@. Continue?", nil), trollStoreInactiveInstalledAppBundlePaths().count, OTHER_APP_NAME, APP_NAME] preferredStyle:UIAlertControllerStyleAlert];
	
	UIAlertAction* transferAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Transfer", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
	{
		[TSPresentationDelegate startActivity:NSLocalizedString(@"Transfering", nil)];
		dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^
		{
			NSString *log;
			int transferRet = spawnRoot(rootHelperPath(), @[@"transfer-apps"], nil, &log);

			dispatch_async(dispatch_get_main_queue(), ^
			{
				[TSPresentationDelegate stopActivityWithCompletion:^
				{
					[self requestSettingsReloadRebuildingSpecifiers:NO];

					if (transferRet != 0) {
						NSArray *remainingApps = trollStoreInactiveInstalledAppBundlePaths();
						UIAlertController *errorAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Transfer Failed", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Failed to transfer %zu apps", nil), remainingApps.count] preferredStyle:UIAlertControllerStyleAlert];

						UIAlertAction* copyLogAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Copy Debug Log", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
						{
							UIPasteboard* pasteboard = [UIPasteboard generalPasteboard];
							pasteboard.string = log;
						}];
						[errorAlert addAction:copyLogAction];

						UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];
						[errorAlert addAction:closeAction];

						[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:nil];
					}
				}];
			});
		});
	}];
	[confirmationAlert addAction:transferAction];

	UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil];
	[confirmationAlert addAction:cancelAction];

	[TSPresentationDelegate presentViewController:confirmationAlert animated:YES completion:nil];
}

- (id)getURLSchemeEnabledForSpecifier:(PSSpecifier*)specifier
{
	BOOL URLSchemeActive = (BOOL)[NSBundle.mainBundle objectForInfoDictionaryKey:@"CFBundleURLTypes"];
	return @(URLSchemeActive);
}

- (void)setURLSchemeEnabled:(id)value forSpecifier:(PSSpecifier*)specifier
{
	NSNumber* newValue = value;
	NSString* newStateString = [newValue boolValue] ? @"enable" : @"disable";
	spawnRoot(rootHelperPath(), @[@"url-scheme", newStateString], nil, nil);

	UIAlertController* rebuildNoticeAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"URL Scheme Changed", nil) message:NSLocalizedString(@"In order to properly apply the change of the URL scheme setting, rebuilding the icon cache is needed.", nil) preferredStyle:UIAlertControllerStyleAlert];
	UIAlertAction* rebuildNowAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Rebuild Now", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
	{
		[self rebuildIconCachePressed];
	}];
	[rebuildNoticeAlert addAction:rebuildNowAction];

	UIAlertAction* rebuildLaterAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Rebuild Later", nil) style:UIAlertActionStyleCancel handler:nil];
	[rebuildNoticeAlert addAction:rebuildLaterAction];

	[TSPresentationDelegate presentViewController:rebuildNoticeAlert animated:YES completion:nil];
}

- (void)doTheDashPressed
{
	spawnRoot(rootHelperPath(), @[@"dash"], nil, nil);
}

- (void)setPreferenceValue:(NSObject*)value specifier:(PSSpecifier*)specifier
{
	NSUserDefaults* tsDefaults = trollStoreUserDefaults();
	[tsDefaults setObject:value forKey:[specifier propertyForKey:@"key"]];
}

- (NSObject*)readPreferenceValue:(PSSpecifier*)specifier
{
	NSUserDefaults* tsDefaults = trollStoreUserDefaults();
	NSObject* toReturn = [tsDefaults objectForKey:[specifier propertyForKey:@"key"]];
	if(!toReturn)
	{
		toReturn = [specifier propertyForKey:@"default"];
	}
	return toReturn;
}

- (NSMutableArray*)argsForUninstallingTrollStore
{
	NSMutableArray* args = @[@"uninstall-trollstore"].mutableCopy;

	NSNumber* uninstallationMethodToUseNum = [trollStoreUserDefaults() objectForKey:@"uninstallationMethod"];
    int uninstallationMethodToUse = uninstallationMethodToUseNum ? uninstallationMethodToUseNum.intValue : 0;
    if(uninstallationMethodToUse == 1)
    {
        [args addObject:@"custom"];
    }

	return args;
}


- (void)manageBlockedAppUpdatesPressed
{
    TSBlockedUpdatesController *controller = [TSBlockedUpdatesController new];
    [self.navigationController pushViewController:controller animated:YES];
}

- (void)setPluginInjectionEnabled:(id)value forSpecifier:(PSSpecifier *)specifier
{
    [trollStoreUserDefaults() setBool:[value boolValue] forKey:@"TSPluginInjectionEnabled"];
}

- (id)getPluginInjectionEnabledForSpecifier:(PSSpecifier *)specifier
{
    NSNumber *stored = [trollStoreUserDefaults() objectForKey:@"TSPluginInjectionEnabled"];
    return stored ?: @NO;
}

@end