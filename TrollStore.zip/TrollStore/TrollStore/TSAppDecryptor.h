#import <UIKit/UIKit.h>

@interface TSAppDecryptor : NSObject
+ (void)presentForBundleIdentifier:(NSString *)bundleIdentifier displayName:(NSString *)displayName fromViewController:(UIViewController *)viewController;
@end
