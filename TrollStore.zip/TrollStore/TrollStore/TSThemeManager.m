#import "TSThemeManager.h"
#import <TSUtil.h>
#import <objc/runtime.h>

static const void *TSThemeBackgroundKey = &TSThemeBackgroundKey;
static const void *TSCardBackgroundKey = &TSCardBackgroundKey;
static NSUserDefaults *TSThemeDefaults(void) { return trollStoreUserDefaults() ?: NSUserDefaults.standardUserDefaults; }
static UIColor *TSColorForName(NSString *name) {
    NSDictionary *colors=@{@"Blue":UIColor.systemBlueColor,@"Purple":UIColor.systemPurpleColor,@"Teal":UIColor.systemTealColor,@"Orange":UIColor.systemOrangeColor,@"Pink":UIColor.systemPinkColor,@"Green":UIColor.systemGreenColor};
    return colors[name] ?: UIColor.systemBlueColor;
}
static UIUserInterfaceStyle TSStoredInterfaceStyle(void) {
    id savedMode=[TSThemeDefaults() objectForKey:@"TSThemeMode"];
    NSInteger mode=savedMode ? [savedMode integerValue] : 2;
    return mode==1 ? UIUserInterfaceStyleLight : (mode==2 ? UIUserInterfaceStyleDark : UIUserInterfaceStyleUnspecified);
}
static UINavigationBarAppearance *TSCreateNavigationAppearance(void) {
    UINavigationBarAppearance *appearance = [UINavigationBarAppearance new];
    [appearance configureWithTransparentBackground];
    appearance.backgroundEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemChromeMaterial];
    appearance.backgroundColor = [UIColor.systemBackgroundColor colorWithAlphaComponent:0.32];
    // The reference UI uses a clean black canvas; a visible navigation-bar
    // hairline would make every large-title page feel like a separate card.
    appearance.shadowColor = UIColor.clearColor;
    appearance.titleTextAttributes = @{NSForegroundColorAttributeName: UIColor.labelColor};
    appearance.largeTitleTextAttributes = @{NSForegroundColorAttributeName: UIColor.labelColor, NSFontAttributeName: [UIFont systemFontOfSize:34 weight:UIFontWeightBold]};
    return appearance;
}

@interface TSCardCellBackgroundView : UIView
@property(nonatomic, strong) UIView *surfaceView;
- (instancetype)initWithSurfaceColor:(UIColor *)surfaceColor;
@end

@implementation TSCardCellBackgroundView
- (instancetype)initWithSurfaceColor:(UIColor *)surfaceColor {
    if ((self = [super initWithFrame:CGRectZero])) {
        self.backgroundColor = UIColor.clearColor;
        _surfaceView = [UIView new];
        _surfaceView.backgroundColor = surfaceColor;
        _surfaceView.layer.cornerRadius = 18.0;
        _surfaceView.layer.cornerCurve = kCACornerCurveContinuous;
        _surfaceView.userInteractionEnabled = NO;
        [self addSubview:_surfaceView];
    }
    return self;
}
- (void)layoutSubviews {
    [super layoutSubviews];
    // Plain tables need their own side inset; inset-grouped tables already
    // supply it in the cell frame. This keeps the same 18pt visual margin in
    // both cases without double-insetting grouped tables.
    CGFloat horizontalInset = CGRectGetMinX(self.superview.frame) > 8.0 ? 0.0 : 18.0;
    self.surfaceView.frame = CGRectInset(self.bounds, horizontalInset, 3.0);
}
@end
static void TSApplyNavigationAppearance(UIViewController *controller, UINavigationBarAppearance *appearance, UIColor *tint) {
    if (!controller) return;
    if ([controller isKindOfClass:UINavigationController.class]) {
        UINavigationController *navigationController = (UINavigationController *)controller;
        UINavigationBar *bar = navigationController.navigationBar;
        bar.translucent = YES;
        bar.tintColor = tint;
        bar.standardAppearance = appearance;
        bar.scrollEdgeAppearance = appearance;
        bar.compactAppearance = appearance;
        if (@available(iOS 15.0, *)) bar.compactScrollEdgeAppearance = appearance;
    }
    for (UIViewController *child in controller.childViewControllers) {
        TSApplyNavigationAppearance(child, appearance, tint);
    }
    if (controller.presentedViewController) {
        TSApplyNavigationAppearance(controller.presentedViewController, appearance, tint);
    }
}

@implementation TSThemeManager
+ (UIColor *)accentColor {
    NSDictionary *components = [TSThemeDefaults() dictionaryForKey:@"TSThemeAccentCustomColor"];
    NSNumber *red = components[@"red"], *green = components[@"green"], *blue = components[@"blue"], *alpha = components[@"alpha"];
    if (red && green && blue) {
        return [UIColor colorWithRed:MAX(0.0, MIN(1.0, red.doubleValue))
                               green:MAX(0.0, MIN(1.0, green.doubleValue))
                                blue:MAX(0.0, MIN(1.0, blue.doubleValue))
                               alpha:MAX(0.0, MIN(1.0, alpha ? alpha.doubleValue : 1.0))];
    }
    return TSColorForName([TSThemeDefaults() stringForKey:@"TSThemeAccent"] ?: @"Blue");
}
+ (CGFloat)floatingBarHeight { CGFloat n=[TSThemeDefaults() doubleForKey:@"TSFloatingBarHeight"]; return n > 0 ? MAX(48,MIN(82,n)) : 62; }
+ (CGFloat)floatingBarSpacing { id value=[TSThemeDefaults() objectForKey:@"TSFloatingBarSpacing"]; CGFloat n=[value doubleValue]; return value ? MAX(0,MIN(24,n)) : 0; }
+ (CGFloat)floatingBarHorizontalMargin { CGFloat n=[TSThemeDefaults() doubleForKey:@"TSFloatingBarMargin"]; return n > 0 ? MAX(12,MIN(64,n)) : 40; }
+ (CGFloat)floatingBarBottomOffset { id value=[TSThemeDefaults() objectForKey:@"TSFloatingBarBottomOffset"]; if(!value) return 8; CGFloat n=[value doubleValue]; return MAX(0,MIN(28,n)); }
+ (BOOL)floatingBarHidden { return [TSThemeDefaults() boolForKey:@"TSHideFloatingTabBar"]; }
+ (NSInteger)floatingBarStyle {
    id savedStyle = [TSThemeDefaults() objectForKey:@"TSFloatingBarStyle"];
    if (savedStyle) return MAX(0, MIN(2, [savedStyle integerValue]));
    id legacyEnabled = [TSThemeDefaults() objectForKey:@"TSFloatingTabBarEnabled"];
    return legacyEnabled && ![legacyEnabled boolValue] ? 1 : 0;
}
+ (BOOL)floatingBarEnabled { return [self floatingBarStyle] != 1; }
+ (void)styleCardTableView:(UITableView *)tableView {
    if (!tableView) return;
    tableView.backgroundColor = UIColor.systemBackgroundColor;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    tableView.sectionIndexBackgroundColor = UIColor.clearColor;
    if (@available(iOS 15.0, *)) tableView.sectionHeaderTopPadding = 8.0;
}
+ (void)styleCardTableViewCell:(UITableViewCell *)cell {
    if (!cell) return;
    cell.backgroundColor = UIColor.clearColor;
    cell.contentView.backgroundColor = UIColor.clearColor;
    cell.separatorInset = UIEdgeInsetsMake(0, cell.bounds.size.width, 0, 0);
    if (![objc_getAssociatedObject(cell, TSCardBackgroundKey) boolValue]) {
        TSCardCellBackgroundView *background = [[TSCardCellBackgroundView alloc] initWithSurfaceColor:UIColor.secondarySystemBackgroundColor];
        TSCardCellBackgroundView *selected = [[TSCardCellBackgroundView alloc] initWithSurfaceColor:UIColor.tertiarySystemFillColor];
        cell.backgroundView = background;
        cell.selectedBackgroundView = selected;
        objc_setAssociatedObject(cell, TSCardBackgroundKey, @YES, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }
}
+ (void)prepareWindowForLaunch:(UIWindow *)window {
    if (!window) return;
    window.overrideUserInterfaceStyle = TSStoredInterfaceStyle();
    window.tintColor = [self accentColor];
    window.backgroundColor = UIColor.systemBackgroundColor;
}
+ (void)applyNavigationAppearanceToController:(UINavigationController *)navigationController {
    if (!navigationController) return;
    TSApplyNavigationAppearance(navigationController, TSCreateNavigationAppearance(), [self accentColor]);
}
+ (void)applyAppearance {
    UIUserInterfaceStyle style=TSStoredInterfaceStyle();
    UIColor *tint=[self accentColor];
    UINavigationBarAppearance *navigationAppearance = TSCreateNavigationAppearance();

    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        for (UIWindow *window in ((UIWindowScene *)scene).windows) {
            window.overrideUserInterfaceStyle = style;
            window.tintColor = tint;
            TSApplyNavigationAppearance(window.rootViewController, navigationAppearance, tint);
        }
    }
    // Notify screens to refresh their surfaces once. The root controller's
    // observer intentionally does not call applyAppearance again.
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TSAppearanceChanged" object:nil];
}

+ (void)applyToViewController:(UIViewController *)viewController {
    if (!viewController.isViewLoaded) return;
    viewController.view.tintColor=self.accentColor;
    NSString *path=[TSThemeDefaults() stringForKey:@"TSThemeBackgroundPath"];
    UIImage *image=path.length ? [UIImage imageWithContentsOfFile:path] : nil;
    UIImageView *imageView=nil;
    if ([viewController isKindOfClass:UITableViewController.class]) {
        UITableView *table=((UITableViewController *)viewController).tableView;
        imageView=[table.backgroundView isKindOfClass:UIImageView.class] ? (UIImageView *)table.backgroundView : nil;
        table.backgroundColor=UIColor.clearColor; table.backgroundView=imageView;
        table.separatorColor=[UIColor.separatorColor colorWithAlphaComponent:0.6];
    } else if ([viewController isKindOfClass:UICollectionViewController.class]) {
        UICollectionView *collection=((UICollectionViewController *)viewController).collectionView;
        imageView=[collection.backgroundView isKindOfClass:UIImageView.class] ? (UIImageView *)collection.backgroundView : nil;
        collection.backgroundColor=UIColor.clearColor; collection.backgroundView=imageView;
    } else {
        imageView=objc_getAssociatedObject(viewController,TSThemeBackgroundKey);
        if (!imageView) { imageView=[[UIImageView alloc] initWithFrame:viewController.view.bounds]; imageView.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight; imageView.contentMode=UIViewContentModeScaleAspectFill; [viewController.view insertSubview:imageView atIndex:0]; objc_setAssociatedObject(viewController,TSThemeBackgroundKey,imageView,OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
    }
    if (!imageView && ([viewController isKindOfClass:UITableViewController.class] || [viewController isKindOfClass:UICollectionViewController.class])) {
        imageView=[UIImageView new]; imageView.contentMode=UIViewContentModeScaleAspectFill; imageView.clipsToBounds=YES;
        if ([viewController isKindOfClass:UITableViewController.class]) ((UITableViewController *)viewController).tableView.backgroundView=imageView;
        else ((UICollectionViewController *)viewController).collectionView.backgroundView=imageView;
    }
    if (imageView) {
        imageView.image=image; imageView.alpha=[TSThemeDefaults() objectForKey:@"TSThemeBackgroundOpacity"] ? [TSThemeDefaults() doubleForKey:@"TSThemeBackgroundOpacity"] : 0.22;
        UIVisualEffectView *blur=objc_getAssociatedObject(imageView, @selector(applyToViewController:));
        if (!blur) { blur=[[UIVisualEffectView alloc] initWithEffect:nil]; blur.frame=imageView.bounds; blur.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight; blur.userInteractionEnabled=NO; [imageView addSubview:blur]; objc_setAssociatedObject(imageView,@selector(applyToViewController:),blur,OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
        CGFloat amount=[TSThemeDefaults() doubleForKey:@"TSThemeBackgroundBlur"];
        blur.effect=amount>0 ? [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemMaterial] : nil; blur.alpha=MIN(1,MAX(0,amount/30.0));
    }
}
@end
