#import "TSThemeManager.h"
#import <TSUtil.h>
#import <objc/runtime.h>

static const void *TSThemeBackgroundKey = &TSThemeBackgroundKey;
static NSUserDefaults *TSThemeDefaults(void) { return trollStoreUserDefaults() ?: NSUserDefaults.standardUserDefaults; }
static UIColor *TSColorForName(NSString *name) {
    NSDictionary *colors=@{@"Blue":UIColor.systemBlueColor,@"Purple":UIColor.systemPurpleColor,@"Teal":UIColor.systemTealColor,@"Orange":UIColor.systemOrangeColor,@"Pink":UIColor.systemPinkColor,@"Green":UIColor.systemGreenColor};
    return colors[name] ?: UIColor.systemBlueColor;
}
@implementation TSThemeManager
+ (UIColor *)accentColor { return TSColorForName([TSThemeDefaults() stringForKey:@"TSThemeAccent"] ?: @"Blue"); }
+ (CGFloat)floatingBarHeight { CGFloat n=[TSThemeDefaults() doubleForKey:@"TSFloatingBarHeight"]; return n > 0 ? MAX(48,MIN(82,n)) : 64; }
+ (CGFloat)floatingBarSpacing { CGFloat n=[TSThemeDefaults() doubleForKey:@"TSFloatingBarSpacing"]; return n > 0 ? MAX(4,MIN(30,n)) : 12; }
+ (CGFloat)floatingBarHorizontalMargin { CGFloat n=[TSThemeDefaults() doubleForKey:@"TSFloatingBarMargin"]; return n > 0 ? MAX(6,MIN(40,n)) : 18; }
+ (CGFloat)floatingBarBottomOffset { id value=[TSThemeDefaults() objectForKey:@"TSFloatingBarBottomOffset"]; if(!value) return 8; CGFloat n=[value doubleValue]; return MAX(0,MIN(28,n)); }
+ (BOOL)floatingBarHidden { return [TSThemeDefaults() boolForKey:@"TSHideFloatingTabBar"]; }
+ (BOOL)floatingBarEnabled { id value=[TSThemeDefaults() objectForKey:@"TSFloatingTabBarEnabled"]; return value ? [value boolValue] : YES; }
+ (void)applyAppearance {
    NSInteger mode=[TSThemeDefaults() integerForKey:@"TSThemeMode"];
    UIUserInterfaceStyle style=mode==1?UIUserInterfaceStyleLight:(mode==2?UIUserInterfaceStyleDark:UIUserInterfaceStyleUnspecified);
    UIColor *tint=[self accentColor];
    for (UIScene *scene in UIApplication.sharedApplication.connectedScenes) {
        if (![scene isKindOfClass:UIWindowScene.class]) continue;
        for (UIWindow *window in ((UIWindowScene *)scene).windows) { window.overrideUserInterfaceStyle=style; window.tintColor=tint; }
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:@"TSAppearanceChanged" object:nil];
}
+ (void)applyToViewController:(UIViewController *)viewController {
    if (!viewController.isViewLoaded) return;
    viewController.view.tintColor=self.accentColor;
    NSString *path=[TSThemeDefaults() stringForKey:@"TSThemeBackgroundPath"];
    UIImage *image=path.length ? [UIImage imageWithContentsOfFile:path] : nil;
    UIImageView *imageView=nil;
    if ([viewController isKindOfClass:UITableViewController.class]) {
        UITableView *table=((UITableViewController *)viewController).tableView;
        imageView=[table.backgroundView isKindOfClass:UIImageView.class] ? (UIImageView *)table.backgroundView : nil;
        table.backgroundColor=UIColor.clearColor; table.backgroundView=imageView;
        table.separatorColor=[UIColor.separatorColor colorWithAlphaComponent:0.6];
    } else if ([viewController isKindOfClass:UICollectionViewController.class]) {
        UICollectionView *collection=((UICollectionViewController *)viewController).collectionView;
        imageView=[collection.backgroundView isKindOfClass:UIImageView.class] ? (UIImageView *)collection.backgroundView : nil;
        collection.backgroundColor=UIColor.clearColor; collection.backgroundView=imageView;
    } else {
        imageView=objc_getAssociatedObject(viewController,TSThemeBackgroundKey);
        if (!imageView) { imageView=[[UIImageView alloc] initWithFrame:viewController.view.bounds]; imageView.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight; imageView.contentMode=UIViewContentModeScaleAspectFill; [viewController.view insertSubview:imageView atIndex:0]; objc_setAssociatedObject(viewController,TSThemeBackgroundKey,imageView,OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
    }
    if (!imageView && ([viewController isKindOfClass:UITableViewController.class] || [viewController isKindOfClass:UICollectionViewController.class])) {
        imageView=[UIImageView new]; imageView.contentMode=UIViewContentModeScaleAspectFill; imageView.clipsToBounds=YES;
        if ([viewController isKindOfClass:UITableViewController.class]) ((UITableViewController *)viewController).tableView.backgroundView=imageView;
        else ((UICollectionViewController *)viewController).collectionView.backgroundView=imageView;
    }
    if (imageView) {
        imageView.image=image; imageView.alpha=[TSThemeDefaults() objectForKey:@"TSThemeBackgroundOpacity"] ? [TSThemeDefaults() doubleForKey:@"TSThemeBackgroundOpacity"] : 0.22;
        UIVisualEffectView *blur=objc_getAssociatedObject(imageView, @selector(applyToViewController:));
        if (!blur) { blur=[[UIVisualEffectView alloc] initWithEffect:nil]; blur.frame=imageView.bounds; blur.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight; blur.userInteractionEnabled=NO; [imageView addSubview:blur]; objc_setAssociatedObject(imageView,@selector(applyToViewController:),blur,OBJC_ASSOCIATION_RETAIN_NONATOMIC); }
        CGFloat amount=[TSThemeDefaults() doubleForKey:@"TSThemeBackgroundBlur"];
        blur.effect=amount>0 ? [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemMaterial] : nil; blur.alpha=MIN(1,MAX(0,amount/30.0));
    }
}
@end
