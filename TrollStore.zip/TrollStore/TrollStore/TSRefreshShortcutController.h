#import <UIKit/UIKit.h>

@interface TSRefreshShortcutController : UIViewController
@end
