#import "TSAppTableViewController.h"

#import "TSApplicationsManager.h"
#import <TSPresentationDelegate.h>
#import "TSInstallationController.h"
#import "TSUtil.h"
#import "TSAppCollectionViewController.h"
#import "TSAppDecryptor.h"
#import "TSTweakInjector.h"
#import "TSIPAPackageStore.h"
#import "TSAppRepackager.h"
#import "TSAppUpdateManager.h"
#import "TSThemeManager.h"
@import UniformTypeIdentifiers;

#define ICON_FORMAT_IPAD 8
#define ICON_FORMAT_IPHONE 10

NSInteger iconFormatToUse(void)
{
	if(UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad)
	{
		return ICON_FORMAT_IPAD;
	}
	else
	{
		return ICON_FORMAT_IPHONE;
	}
}

UIImage* imageWithSize(UIImage* image, CGSize size)
{
	if(CGSizeEqualToSize(image.size, size)) return image;
	UIGraphicsBeginImageContextWithOptions(size, NO, UIScreen.mainScreen.scale);
	CGRect imageRect = CGRectMake(0.0, 0.0, size.width, size.height);
	[image drawInRect:imageRect];
	UIImage* outImage = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	return outImage;
}

@interface UIImage ()
+ (UIImage *)_applicationIconImageForBundleIdentifier:(NSString *)id format:(NSInteger)format scale:(double)scale;
@end

@interface TSAppTableViewController ()
@property(nonatomic, copy) NSSet<NSString *> *blockedUpdateBundleIdentifiers;
@property(nonatomic, strong) NSOperationQueue *iconLoadQueue;
@property(nonatomic, strong) NSOperationQueue *searchQueue;
@property(nonatomic, strong) NSMutableSet<NSString *> *pendingIconIdentifiers;
@property(nonatomic, strong) NSCache<NSString *, NSNumber *> *managedContainerCache;
@end

static NSInteger TSLoadAppSourceCategoryPreference(void)
{
    NSUserDefaults *defaults = trollStoreUserDefaults();
    if (![defaults boolForKey:@"TSAppSourceCategoryV2"]) {
        id oldValue = [defaults objectForKey:@"TSAppSourceCategory"];
        if (oldValue) {
            NSInteger oldCategory = [oldValue integerValue];
            NSInteger migrated = oldCategory == 0 ? 2 : (oldCategory == 1 ? 1 : (oldCategory == 2 ? 3 : 0));
            [defaults setInteger:migrated forKey:@"TSAppSourceCategory"];
        } else {
            [defaults setInteger:0 forKey:@"TSAppSourceCategory"];
        }
        [defaults setBool:YES forKey:@"TSAppSourceCategoryV2"];
    }
    return MAX(0, MIN(3, [defaults integerForKey:@"TSAppSourceCategory"]));
}

static BOOL TSIsUserAppContainerPath(NSString *path)
{
    NSString *normalized = path.stringByStandardizingPath;
    return [normalized hasPrefix:@"/private/var/containers/Bundle/Application/"] || [normalized hasPrefix:@"/var/containers/Bundle/Application/"];
}

@implementation TSAppTableViewController

- (BOOL)isManagedByTrollStoreAtBundlePath:(NSString*)bundlePath
{
	if (!bundlePath.length) return NO;
	NSString* containerPath = bundlePath.stringByDeletingLastPathComponent;
	NSNumber *cached = [self.managedContainerCache objectForKey:containerPath];
	if (cached) return cached.boolValue;
	NSString* trollStoreMarker = [containerPath stringByAppendingPathComponent:TS_MARKER];
	NSString* trollStoreLiteMarker = [containerPath stringByAppendingPathComponent:TS_LITE_MARKER];
	NSFileManager* fileManager = [NSFileManager defaultManager];
	BOOL managed = [fileManager fileExistsAtPath:trollStoreMarker] || [fileManager fileExistsAtPath:trollStoreLiteMarker];
	[self.managedContainerCache setObject:@(managed) forKey:containerPath];
	return managed;
}

- (NSArray<NSString*>*)bundlePathsForWorkspaceType:(NSUInteger)type
{
    NSMutableOrderedSet<NSString*>* paths = [NSMutableOrderedSet new];
    NSFileManager* fm = [NSFileManager defaultManager];
    void (^appendAppProxy)(LSApplicationProxy*) = ^(LSApplicationProxy* proxy) {
        if(!proxy.installed || !proxy.bundleIdentifier.length || !proxy.bundleURL.path.length) return;
        NSString* bundlePath = proxy.bundleURL.path;
        if([self isManagedByTrollStoreAtBundlePath:bundlePath]) return;
        if([bundlePath.lastPathComponent isEqualToString:@"TrollStorePersistenceHelper.app"]) return;
        if([fm fileExistsAtPath:bundlePath]) [paths addObject:bundlePath];
    };
    [[LSApplicationWorkspace defaultWorkspace] enumerateApplicationsOfType:type block:appendAppProxy];
    return paths.array;
}

- (NSArray<TSAppInfo*>*)buildAppInfosForSourceCategory:(NSInteger)category
{
    NSMutableOrderedSet<NSString *> *paths = [NSMutableOrderedSet orderedSet];
    if (category == 0 || category == 2) [paths addObjectsFromArray:[[TSApplicationsManager sharedInstance] installedAppPaths] ?: @[]];
    if (category == 0 || category == 1) [paths addObjectsFromArray:[self bundlePathsForWorkspaceType:0]];
    if (category == 0 || category == 3) [paths addObjectsFromArray:[self bundlePathsForWorkspaceType:1]];
    NSMutableArray<TSAppInfo*>* appInfos = [NSMutableArray new];
    for(NSString* appPath in paths) { @autoreleasepool { TSAppInfo* info = [[TSAppInfo alloc] initWithAppBundlePath:appPath]; if([info sync_loadBasicInfo] == nil) [appInfos addObject:info]; } }
    [appInfos sortUsingComparator:^(TSAppInfo* a, TSAppInfo* b) { return [[a displayName] localizedStandardCompare:[b displayName]]; }];
    return appInfos.copy;
}

- (NSArray<TSAppInfo*>*)filteredAppInfosFromCatalog:(NSArray<TSAppInfo*>*)catalog searchKey:(NSString*)searchKey
{
	if(searchKey.length == 0) return catalog ?: @[];
	NSMutableArray<TSAppInfo*>* filtered = [NSMutableArray new];
	for(TSAppInfo* appInfo in catalog)
	{
		NSString* appName = [appInfo displayName] ?: @"";
		NSString* appId = [appInfo bundleIdentifier] ?: @"";
		BOOL nameMatch = [appName rangeOfString:searchKey options:NSCaseInsensitiveSearch].location != NSNotFound;
		BOOL identifierMatch = [appId rangeOfString:searchKey options:NSCaseInsensitiveSearch].location != NSNotFound;
		if(nameMatch || identifierMatch) [filtered addObject:appInfo];
	}
	return filtered.copy;
}

- (instancetype)init
{
	self = [super init];
	if(self)
	{
		_sourceCategory = TSLoadAppSourceCategoryPreference();
		_showAppStoreApps = (_sourceCategory == 0 || _sourceCategory == 1);
		_cachedAppInfos = @[];
		_reloadGeneration = 0;
		_placeholderIcon = [UIImage _applicationIconImageForBundleIdentifier:@"com.apple.WebSheet" format:iconFormatToUse() scale:[UIScreen mainScreen].scale];
		_cachedIcons = [NSCache new];
		_cachedIcons.countLimit = 300;
		_cachedIcons.totalCostLimit = 24 * 1024 * 1024;
        _managedContainerCache = [NSCache new];
        _managedContainerCache.countLimit = 1024;
        _iconLoadQueue = [NSOperationQueue new];
        _iconLoadQueue.name = @"com.opa334.TrollStore.app-list-icon-loader";
        _iconLoadQueue.maxConcurrentOperationCount = 2;
        _iconLoadQueue.qualityOfService = NSQualityOfServiceUtility;
        _searchQueue = [NSOperationQueue new];
        _searchQueue.name = @"com.opa334.TrollStore.app-list-search";
        _searchQueue.maxConcurrentOperationCount = 1;
        _searchQueue.qualityOfService = NSQualityOfServiceUtility;
        _pendingIconIdentifiers = [NSMutableSet set];
		[[LSApplicationWorkspace defaultWorkspace] addObserver:self];
		[self reloadTable];
	}
	return self;
}

- (void)dealloc
{
	[_iconLoadQueue cancelAllOperations];
    [_searchQueue cancelAllOperations];
	[[LSApplicationWorkspace defaultWorkspace] removeObserver:self];
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)themeChanged
{
	[TSThemeManager applyToViewController:self];
	[self.tableView reloadData];
}

- (void)applySearchToCatalog:(NSArray<TSAppInfo *> *)catalog
{
    NSUInteger generation = ++_searchGeneration;
    NSInteger category = _sourceCategory;
    NSString *searchKey = [_searchKey copy] ?: @"";
    NSArray<TSAppInfo *> *snapshot = catalog ?: @[];
    [self.searchQueue cancelAllOperations];
    [self.searchQueue addOperationWithBlock:^{
        NSArray<TSAppInfo *> *filtered = [self filteredAppInfosFromCatalog:snapshot searchKey:searchKey];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (generation != self->_searchGeneration || category != self->_sourceCategory) return;
            self->_cachedAppInfos = filtered;
            [self.tableView reloadData];
        });
    }];
}

- (void)reloadTable
{
    dispatch_async(dispatch_get_main_queue(), ^{
        NSUInteger generation = ++self->_reloadGeneration;
        self->_searchGeneration++;
        [self.searchQueue cancelAllOperations];
        NSInteger category = self->_sourceCategory;
        NSArray<TSAppInfo*> *cached = category == 0 ? self->_cachedAllAppCatalog : (category == 1 ? self->_cachedAppStoreAppCatalog : (category == 2 ? self->_cachedTrollStoreAppCatalog : self->_cachedSystemAppCatalog));
        if (cached) { [self applySearchToCatalog:cached]; return; }
        self->_cachedAppInfos=@[]; [self.tableView reloadData];
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY,0), ^{
            NSArray<TSAppInfo*> *catalog=[self buildAppInfosForSourceCategory:category];
            dispatch_async(dispatch_get_main_queue(), ^{
                if(generation!=self->_reloadGeneration || category!=self->_sourceCategory) return;
                if(category==0) self->_cachedAllAppCatalog=catalog;
                else if(category==1) self->_cachedAppStoreAppCatalog=catalog;
                else if(category==2) self->_cachedTrollStoreAppCatalog=catalog;
                else self->_cachedSystemAppCatalog=catalog;
                [self applySearchToCatalog:catalog];
            });
        });
    });
}

- (void)applicationsChangedNotification:(NSNotification*)notification
{
	dispatch_async(dispatch_get_main_queue(), ^{
		self->_cachedAllAppCatalog = nil;
		self->_cachedTrollStoreAppCatalog = nil;
		self->_cachedAppStoreAppCatalog = nil;
		self->_cachedSystemAppCatalog = nil;
        [self.managedContainerCache removeAllObjects];
		[self reloadTable];
	});
}

- (void)loadView
{
	[super loadView];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationsChangedNotification:) name:@"ApplicationsChanged" object:nil];
	if ([trollStoreUserDefaults() integerForKey:@"TSAppListLayout"] == 1 && [self.navigationController.viewControllers.firstObject isKindOfClass:TSAppTableViewController.class]) {
		// The root controller chooses the collection view on cold launch; this branch is only a migration safety net.
	}
}

- (void)viewDidLoad
{
	[super viewDidLoad];
	
	self.tableView.allowsMultipleSelectionDuringEditing = NO;
	self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];

	self.navigationItem.largeTitleDisplayMode=UINavigationItemLargeTitleDisplayModeAlways;
	[self _setUpNavigationBar];
	[self _setUpSearchBar];
	[self _setUpAppCategoryControl];
    self.blockedUpdateBundleIdentifiers = [NSSet set];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(themeChanged) name:@"TSAppearanceChanged" object:nil];
	[TSThemeManager applyToViewController:self];
}

- (void)_setUpAppCategoryControl
{
    _appCategoryControl = [[UISegmentedControl alloc] initWithItems:@[
        NSLocalizedString(@"All", nil),
        NSLocalizedString(@"User", nil),
        NSLocalizedString(@"Troll", nil),
        NSLocalizedString(@"System", nil)
    ]];
    _appCategoryControl.selectedSegmentIndex = _sourceCategory;
    [_appCategoryControl addTarget:self action:@selector(appCategoryChanged:) forControlEvents:UIControlEventValueChanged];
    UIView* header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableView.bounds.size.width, 52)];
    _appCategoryControl.frame = CGRectMake(16, 8, MAX(0, header.bounds.size.width - 32), 34);
    [header addSubview:_appCategoryControl];
    self.tableView.tableHeaderView = header;
}

- (void)viewDidLayoutSubviews
{
	[super viewDidLayoutSubviews];
	UIView* header = self.tableView.tableHeaderView;
	if(header && _appCategoryControl)
	{
		CGFloat width = self.tableView.bounds.size.width;
		BOOL headerSizeChanged = header.frame.size.width != width || header.frame.size.height != 52.0;
		if(headerSizeChanged)
		{
			header.frame = CGRectMake(0, 0, width, 52);
			self.tableView.tableHeaderView = header;
		}
		_appCategoryControl.frame = CGRectMake(16, 8, MAX(0, width - 32), 34);
	}
}

- (void)appCategoryChanged:(UISegmentedControl*)sender
{
	_sourceCategory = MAX(0, MIN(3, sender.selectedSegmentIndex));
	_showAppStoreApps = (_sourceCategory == 0 || _sourceCategory == 1);
	[trollStoreUserDefaults() setInteger:_sourceCategory forKey:@"TSAppSourceCategory"];
	[self reloadTable];
}

- (void)_setUpNavigationBar
{
	UIAction* installFromFileAction = [UIAction actionWithTitle:NSLocalizedString(@"Install IPA File", nil) image:[UIImage systemImageNamed:@"doc.badge.plus"] identifier:@"InstallIPAFile" handler:^(__kindof UIAction *action)
	{
		dispatch_async(dispatch_get_main_queue(), ^
		{
			UTType *dataType = [UTType typeWithIdentifier:@"public.data"];
			if (!dataType) return;
			UTType *ipaType = [UTType typeWithFilenameExtension:@"ipa" conformingToType:dataType] ?: dataType;
			UTType *tipaType = [UTType typeWithFilenameExtension:@"tipa" conformingToType:dataType] ?: dataType;

			UIDocumentPickerViewController* documentPickerVC = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:@[ipaType, tipaType]];
			documentPickerVC.allowsMultipleSelection = NO;
			documentPickerVC.delegate = self;

			[TSPresentationDelegate presentViewController:documentPickerVC animated:YES completion:nil];
		});
	}];

	UIAction* installFromURLAction = [UIAction actionWithTitle:NSLocalizedString(@"Install from URL", nil) image:[UIImage systemImageNamed:@"link.badge.plus"] identifier:@"InstallFromURL" handler:^(__kindof UIAction *action)
	{
		dispatch_async(dispatch_get_main_queue(), ^
		{
			UIAlertController* installURLController = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Install from URL", nil) message:@"" preferredStyle:UIAlertControllerStyleAlert];

			[installURLController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
				textField.placeholder = NSLocalizedString(@"IPA URL", nil);
			}];

			UIAlertAction* installAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Install", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
			{
				NSString* URLString = installURLController.textFields.firstObject.text;
				NSURL* remoteURL = [NSURL URLWithString:URLString];

				[TSInstallationController handleAppInstallFromRemoteURL:remoteURL completion:nil];
			}];
			[installURLController addAction:installAction];

			UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil];
			[installURLController addAction:cancelAction];

			[TSPresentationDelegate presentViewController:installURLController animated:YES completion:nil];
		});
	}];

	__weak typeof(self) weakSelf = self;
	UIAction *switchToGridAction = [UIAction actionWithTitle:NSLocalizedString(@"Switch to Grid Layout", nil) image:[UIImage systemImageNamed:@"square.grid.2x2"] identifier:@"SwitchToGridLayout" handler:^(__kindof UIAction *action) {
		[weakSelf switchToGridLayout];
	}];
	UIMenu* installMenu = [UIMenu menuWithChildren:@[installFromFileAction, installFromURLAction, switchToGridAction]];

	UIBarButtonItem* installBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"plus"] menu:installMenu];
	self.navigationItem.rightBarButtonItem = installBarButtonItem;
}

- (void)switchToGridLayout
{
	TSAppCollectionViewController *grid = [TSAppCollectionViewController new];
	grid.sourceCategory = _sourceCategory;
	grid.initialSearchText = _searchKey ?: @"";
	[trollStoreUserDefaults() setInteger:1 forKey:@"TSAppListLayout"];
	[self.navigationController setViewControllers:@[grid] animated:YES];
}

- (void)_setUpSearchBar
{
	_searchController = [[UISearchController alloc] initWithSearchResultsController:nil];
	_searchController.searchResultsUpdater = self;
	_searchController.obscuresBackgroundDuringPresentation = NO;
	self.navigationItem.searchController = _searchController;
	self.navigationItem.hidesSearchBarWhenScrolling = NO;
}

- (void)updateSearchResultsForSearchController:(UISearchController *)searchController
{
    NSString *searchKey = [searchController.searchBar.text copy] ?: @"";
    void (^update)(void) = ^{
        self->_searchKey = searchKey;
        NSArray<TSAppInfo *> *catalog = self->_sourceCategory == 0 ? self->_cachedAllAppCatalog : (self->_sourceCategory == 1 ? self->_cachedAppStoreAppCatalog : (self->_sourceCategory == 2 ? self->_cachedTrollStoreAppCatalog : self->_cachedSystemAppCatalog));
        if (catalog) [self applySearchToCatalog:catalog];
        // If catalog loading is in progress, reloadTable's completion will use
        // the latest search key and no intermediate main-thread filtering occurs.
    };
    if (NSThread.isMainThread) update();
    else dispatch_async(dispatch_get_main_queue(), update);
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls
{
	NSString* pathToIPA = urls.firstObject.path;
	[TSInstallationController presentInstallationAlertIfEnabledForFile:pathToIPA isRemoteInstall:NO completion:nil];
}

- (void)openAppPressedForRowAtIndexPath:(NSIndexPath*)indexPath enableJIT:(BOOL)enableJIT
{
	TSApplicationsManager* appsManager = [TSApplicationsManager sharedInstance];

	TSAppInfo* appInfo = _cachedAppInfos[indexPath.row];
	NSString* appId = [appInfo bundleIdentifier];
	BOOL didOpen = [appsManager openApplicationWithBundleID:appId];

	// if we failed to open the app, show an alert
	if(!didOpen)
	{
		NSString* failMessage = @"";
		if([[appInfo registrationState] isEqualToString:@"User"])
		{
			failMessage = NSLocalizedString(@"This app was not able to launch because it has a \"User\" registration state, register it as \"System\" and try again.", nil);
		}

		NSString* failTitle = [NSString stringWithFormat:NSLocalizedString(@"Failed to open %@", nil), appId];
		UIAlertController* didFailController = [UIAlertController alertControllerWithTitle:failTitle message:failMessage preferredStyle:UIAlertControllerStyleAlert];
		UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil];

		[didFailController addAction:cancelAction];
		[TSPresentationDelegate presentViewController:didFailController animated:YES completion:nil];
	}
	else if (enableJIT)
	{
		int ret = [appsManager enableJITForBundleID:appId];
		if (ret != 0)
		{
			UIAlertController* errorAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Error enabling JIT: trollstorehelper returned %d", nil), ret] preferredStyle:UIAlertControllerStyleAlert];
			UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];
			[errorAlert addAction:closeAction];
			[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:nil];
		}
	}
}

- (void)showDetailsPressedForRowAtIndexPath:(NSIndexPath*)indexPath
{
	TSAppInfo* appInfo = _cachedAppInfos[indexPath.row];

	[appInfo loadInfoWithCompletion:^(NSError* error)
	{
		dispatch_async(dispatch_get_main_queue(), ^
		{
			if(!error)
			{
				UIAlertController* detailsAlert = [UIAlertController alertControllerWithTitle:@"" message:@"" preferredStyle:UIAlertControllerStyleAlert];
				detailsAlert.attributedTitle = [appInfo detailedInfoTitle];
				detailsAlert.attributedMessage = [appInfo detailedInfoDescription];

				UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];
				[detailsAlert addAction:closeAction];

				[TSPresentationDelegate presentViewController:detailsAlert animated:YES completion:nil];
			}
			else
			{
				UIAlertController* errorAlert = [UIAlertController alertControllerWithTitle:[NSString stringWithFormat:NSLocalizedString(@"Parse Error %ld", nil), error.code] message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
				UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];
				[errorAlert addAction:closeAction];

				[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:nil];
			}
		});
	}];
}

- (void)changeAppRegistrationForRowAtIndexPath:(NSIndexPath*)indexPath toState:(NSString*)newState
{
	TSAppInfo* appInfo = _cachedAppInfos[indexPath.row];

	if([newState isEqualToString:@"User"])
	{
		NSString* title = [NSString stringWithFormat:NSLocalizedString(@"Switching '%@' to \"User\" Registration", nil), [appInfo displayName]];
		UIAlertController* confirmationAlert = [UIAlertController alertControllerWithTitle:title message:NSLocalizedString(@"Switching this app to a \"User\" registration will make it unlaunchable after the next respring because the bugs exploited in TrollStore only affect apps registered as \"System\".\nThe purpose of this option is to make the app temporarily show up in settings, so you can adjust the settings and then switch it back to a \"System\" registration (TrollStore installed apps do not show up in settings otherwise). Additionally, the \"User\" registration state is also useful to temporarily fix iTunes file sharing, which also doesn't work for TrollStore installed apps otherwise.\nWhen you're done making the changes you need and want the app to become launchable again, you will need to switch it back to \"System\" state in TrollStore.", nil) preferredStyle:UIAlertControllerStyleAlert];

		UIAlertAction* switchToUserAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Switch to \"User\"", nil) style:UIAlertActionStyleDestructive handler:^(UIAlertAction* action)
		{
			[[TSApplicationsManager sharedInstance] changeAppRegistration:[appInfo bundlePath] toState:newState];
			[appInfo sync_loadBasicInfo];
		}];

		[confirmationAlert addAction:switchToUserAction];

		UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil];

		[confirmationAlert addAction:cancelAction];

		[TSPresentationDelegate presentViewController:confirmationAlert animated:YES completion:nil];
	}
	else
	{
		[[TSApplicationsManager sharedInstance] changeAppRegistration:[appInfo bundlePath] toState:newState];
		[appInfo sync_loadBasicInfo];

		NSString* title = [NSString stringWithFormat:NSLocalizedString(@"Switched '%@' to \"System\" Registration", nil), [appInfo displayName]];

		UIAlertController* infoAlert = [UIAlertController alertControllerWithTitle:title message:NSLocalizedString(@"The app has been switched to the \"System\" registration state and will become launchable again after a respring.", nil) preferredStyle:UIAlertControllerStyleAlert];

		UIAlertAction* respringAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Respring", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
		{
			respring();
		}];

		[infoAlert addAction:respringAction];

		UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];

		[infoAlert addAction:closeAction];

		[TSPresentationDelegate presentViewController:infoAlert animated:YES completion:nil];
	}
}

- (void)uninstallPressedForRowAtIndexPath:(NSIndexPath*)indexPath
{
	TSApplicationsManager* appsManager = [TSApplicationsManager sharedInstance];

	TSAppInfo* appInfo = _cachedAppInfos[indexPath.row];

	NSString* appPath = [appInfo bundlePath];
	NSString* appId = [appInfo bundleIdentifier];
	NSString* appName = [appInfo displayName];

	UIAlertController* confirmAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Confirm Uninstallation", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Uninstalling the app '%@' will delete the app and all data associated to it.", nil), appName] preferredStyle:UIAlertControllerStyleAlert];

	UIAlertAction* uninstallAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Uninstall", nil) style:UIAlertActionStyleDestructive handler:^(UIAlertAction* action)
	{
		if(appId)
		{
			[appsManager uninstallApp:appId];
		}
		else
		{
			[appsManager uninstallAppByPath:appPath];
		}
	}];
	[confirmAlert addAction:uninstallAction];

	UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil];
	[confirmAlert addAction:cancelAction];

	[TSPresentationDelegate presentViewController:confirmAlert animated:YES completion:nil];
}

- (void)deselectRow
{
	[self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:YES];
}

- (void)exportManagedAppInfo:(TSAppInfo *)appInfo forRepackaging:(BOOL)repackage {
    [TSPresentationDelegate startActivity:repackage ? NSLocalizedString(@"Modify / Duplicate", nil) : NSLocalizedString(@"Export IPA", nil)];
    dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
        NSError *error = nil;
        NSURL *url = [TSIPAPackageStore exportInstalledAppAtPath:appInfo.bundlePath error:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            [TSPresentationDelegate stopActivityWithCompletion:^{
                if (!url) {
                    [self showMaintenanceResult:error.localizedDescription ?: NSLocalizedString(@"Export failed.", nil) title:NSLocalizedString(@"Export Failed", nil)];
                    return;
                }
                if (repackage) {
                    [TSAppRepackager presentFromViewController:self sourceIPA:url.path completion:^(NSString *outputPath, NSError *repackError) {
                        if (outputPath) [TSInstallationController presentInstallationAlertIfEnabledForFile:outputPath isRemoteInstall:NO completion:nil];
                        else if (repackError) [self showMaintenanceResult:repackError.localizedDescription title:NSLocalizedString(@"Repackage Failed", nil)];
                    }];
                } else {
                    UIActivityViewController *share = [[UIActivityViewController alloc] initWithActivityItems:@[url] applicationActivities:nil];
                    share.popoverPresentationController.sourceView = self.view;
                    share.popoverPresentationController.sourceRect = CGRectMake(CGRectGetMidX(self.view.bounds), CGRectGetMidY(self.view.bounds), 1, 1);
                    [TSPresentationDelegate presentViewController:share animated:YES completion:nil];
                }
            }];
        });
    });
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [TSAppUpdateManager copyBlockedBundleIdentifiersWithCompletion:^(NSSet<NSString *> *identifiers, NSError *error) {
        if (!error) {
            NSSet<NSString *> *updated = identifiers ?: [NSSet set];
            if (![self.blockedUpdateBundleIdentifiers isEqualToSet:updated]) {
                self.blockedUpdateBundleIdentifiers = updated;
                [self.tableView reloadData];
            }
        }
    }];
}

- (void)toggleUpdateLockForApp:(TSAppInfo *)appInfo
{
    NSString *bundleID = appInfo.bundleIdentifier;
    BOOL shouldBlock = ![self.blockedUpdateBundleIdentifiers containsObject:bundleID];
    NSString *title = shouldBlock ? NSLocalizedString(@"Block App Updates?", nil) : NSLocalizedString(@"Allow App Updates?", nil);
    NSString *message = shouldBlock ? NSLocalizedString(@"This hides the App Store metadata file for this app and refreshes LaunchServices. You can restore updates at any time from Settings. Keep the device unlocked while the App Store refreshes. This affects App Store app updates only; iOS system updates are not affected.", nil) : NSLocalizedString(@"Restore the original App Store metadata file and allow this app to update again?", nil);
    UIAlertController *confirm = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    [confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
    [confirm addAction:[UIAlertAction actionWithTitle:shouldBlock ? NSLocalizedString(@"Block Updates", nil) : NSLocalizedString(@"Allow Updates", nil) style:shouldBlock ? UIAlertActionStyleDestructive : UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
        [TSPresentationDelegate startActivity:NSLocalizedString(@"Refreshing App Store Metadata", nil)];
        [TSAppUpdateManager setUpdatesBlocked:shouldBlock forBundleIdentifier:bundleID completion:^(BOOL success, NSString *result) {
            [TSPresentationDelegate stopActivityWithCompletion:^{
                if (success) { NSMutableSet *updated = [self.blockedUpdateBundleIdentifiers mutableCopy] ?: [NSMutableSet set]; if (shouldBlock) [updated addObject:bundleID]; else [updated removeObject:bundleID]; self.blockedUpdateBundleIdentifiers = updated.copy; [self.tableView reloadData]; }
                UIAlertController *done = [UIAlertController alertControllerWithTitle:success ? NSLocalizedString(@"Completed", nil) : NSLocalizedString(@"Operation Failed", nil) message:result preferredStyle:UIAlertControllerStyleAlert];
                [done addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
                [TSPresentationDelegate presentViewController:done animated:YES completion:nil];
            }];
        }];
    }]];
    [TSPresentationDelegate presentViewController:confirm animated:YES completion:nil];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return _cachedAppInfos.count;
}

- (void)traitCollectionDidChange:(UITraitCollection *)previousTraitCollection
{
	[super traitCollectionDidChange:previousTraitCollection];
	BOOL appearanceChanged = previousTraitCollection && [self.traitCollection hasDifferentColorAppearanceComparedToTraitCollection:previousTraitCollection];
	BOOL contentSizeChanged = previousTraitCollection && ![self.traitCollection.preferredContentSizeCategory isEqualToString:previousTraitCollection.preferredContentSizeCategory];
	if (appearanceChanged || contentSizeChanged) [self.tableView reloadData];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ApplicationCell"];
	if(!cell) {
		cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"ApplicationCell"];
	}

	if(!indexPath || indexPath.row >= _cachedAppInfos.count) return cell;

	TSAppInfo* appInfo = _cachedAppInfos[indexPath.row];
	NSString* appId = [appInfo bundleIdentifier];
	NSString* appVersion = [appInfo versionString];

	// Configure the cell...
	cell.textLabel.text = [appInfo displayName];
    BOOL trollManaged = [self isManagedByTrollStoreAtBundlePath:appInfo.bundlePath];
    BOOL userContainer = TSIsUserAppContainerPath(appInfo.bundlePath) && !trollManaged;
    NSString *appCategory = trollManaged ? NSLocalizedString(@"Troll", nil) : (userContainer ? NSLocalizedString(@"User", nil) : NSLocalizedString(@"System App", nil));
    if (_sourceCategory == 1) appCategory = NSLocalizedString(@"User", nil);
    else if (_sourceCategory == 2) appCategory = NSLocalizedString(@"Troll", nil);
    else if (_sourceCategory == 3) appCategory = NSLocalizedString(@"System App", nil);
    BOOL updateBlocked = [self.blockedUpdateBundleIdentifiers containsObject:appId];
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ • %@ • %@%@", appCategory, appVersion, appId, updateBlocked ? [@" • " stringByAppendingString:NSLocalizedString(@"Updates Blocked", nil)] : @""];
    cell.detailTextLabel.textColor = trollManaged ? UIColor.systemGreenColor : (userContainer ? UIColor.systemBlueColor : UIColor.systemGrayColor);
	cell.backgroundColor = UIColor.clearColor;
	cell.contentView.backgroundColor = [UIColor.secondarySystemBackgroundColor colorWithAlphaComponent:0.74];
	cell.contentView.layer.cornerRadius = 10;
	cell.imageView.layer.borderWidth = 1;
	cell.imageView.layer.borderColor = [UIColor.labelColor colorWithAlphaComponent:0.1].CGColor;
	cell.imageView.layer.cornerRadius = 13.5;
	cell.imageView.layer.masksToBounds = YES;
	cell.imageView.layer.cornerCurve = kCACornerCurveContinuous;

	if(appId)
	{
		UIImage* cachedIcon = [_cachedIcons objectForKey:appId];
		if(cachedIcon)
		{
			cell.imageView.image = cachedIcon;
		}
		else
		{
			cell.imageView.image = _placeholderIcon;
            if (appId.length && ![self.pendingIconIdentifiers containsObject:appId]) {
                [self.pendingIconIdentifiers addObject:appId];
                __weak typeof(self) weakSelf = self;
                NSCache<NSString *, UIImage *> *iconCache = _cachedIcons;
                CGSize iconSize = _placeholderIcon.size;
                CGFloat screenScale = UIScreen.mainScreen.scale;
                [self.iconLoadQueue addOperationWithBlock:^{
                    @autoreleasepool {
                        UIImage *rawIcon = [UIImage _applicationIconImageForBundleIdentifier:appId format:iconFormatToUse() scale:screenScale];
                        UIImage *iconImage = rawIcon ? imageWithSize(rawIcon, iconSize) : nil;
                        if (iconImage) {
                            NSUInteger cost = (NSUInteger)(iconImage.size.width * iconImage.size.height * iconImage.scale * iconImage.scale * 4.0);
                            [iconCache setObject:iconImage forKey:appId cost:cost];
                        }
                        dispatch_async(dispatch_get_main_queue(), ^{
                            TSAppTableViewController *strongSelf = weakSelf;
                            if (!strongSelf) return;
                            [strongSelf.pendingIconIdentifiers removeObject:appId];
                            if (!iconImage) return;
                            NSUInteger currentRow = [strongSelf->_cachedAppInfos indexOfObject:appInfo];
                            if (currentRow == NSNotFound) return;
                            NSIndexPath *curIndexPath = [NSIndexPath indexPathForRow:currentRow inSection:0];
                            UITableViewCell *curCell = [tableView cellForRowAtIndexPath:curIndexPath];
                            TSAppInfo *currentInfo = strongSelf->_cachedAppInfos[currentRow];
                            if (curCell && [currentInfo.bundleIdentifier isEqualToString:appId]) {
                                curCell.imageView.image = iconImage;
                                [curCell setNeedsLayout];
                            }
                        });
                    }
                }];
            }
		}
	}
	else
	{
		cell.imageView.image = _placeholderIcon;
	}

	cell.preservesSuperviewLayoutMargins = NO;
	cell.separatorInset = UIEdgeInsetsZero;
	cell.layoutMargins = UIEdgeInsetsZero;

	return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 80.0f;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row >= _cachedAppInfos.count) return NO;
    return [self isManagedByTrollStoreAtBundlePath:_cachedAppInfos[indexPath.row].bundlePath];
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(indexPath.row >= _cachedAppInfos.count || ![self isManagedByTrollStoreAtBundlePath:_cachedAppInfos[indexPath.row].bundlePath]) return;
	if(editingStyle == UITableViewCellEditingStyleDelete)
	{
		[self uninstallPressedForRowAtIndexPath:indexPath];
	}
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	TSAppInfo* appInfo = _cachedAppInfos[indexPath.row];

	NSString* appId = [appInfo bundleIdentifier];
	NSString* appName = [appInfo displayName];

	UIAlertController* appSelectAlert = [UIAlertController alertControllerWithTitle:appName?:@"" message:appId?:@"" preferredStyle:UIAlertControllerStyleActionSheet];

	UIAlertAction* openAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Open", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
	{
		[self openAppPressedForRowAtIndexPath:indexPath enableJIT:NO];
		[self deselectRow];
	}];
	[appSelectAlert addAction:openAction];

	if ([appInfo isDebuggable])
	{
		UIAlertAction* openWithJITAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Open with JIT", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
		{
			[self openAppPressedForRowAtIndexPath:indexPath enableJIT:YES];
			[self deselectRow];
		}];
		[appSelectAlert addAction:openWithJITAction];
	}

	UIAlertAction* showDetailsAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Show Details", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
	{
		[self showDetailsPressedForRowAtIndexPath:indexPath];
		[self deselectRow];
	}];
	[appSelectAlert addAction:showDetailsAction];

    BOOL trollManagedApp = [self isManagedByTrollStoreAtBundlePath:appInfo.bundlePath];
    BOOL userManagedApp = TSIsUserAppContainerPath(appInfo.bundlePath) && !trollManagedApp;
    BOOL systemApp = !trollManagedApp && !userManagedApp;
    if (!systemApp) {
        [appSelectAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Clear Cache", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            [self confirmMaintenanceCommand:@"clear-cache" appInfo:appInfo]; [self deselectRow];
        }]];
        [appSelectAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Clear App Data", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
            [self confirmMaintenanceCommand:@"clear-data" appInfo:appInfo]; [self deselectRow];
        }]];
        [appSelectAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Decrypt & Export IPA", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            [TSAppDecryptor presentForBundleIdentifier:appId displayName:appName fromViewController:self]; [self deselectRow];
        }]];
    }
    if (userManagedApp) {
        BOOL isBlocked = [self.blockedUpdateBundleIdentifiers containsObject:appId];
        [appSelectAlert addAction:[UIAlertAction actionWithTitle:isBlocked ? NSLocalizedString(@"Allow App Updates", nil) : NSLocalizedString(@"Block App Updates", nil) style:isBlocked ? UIAlertActionStyleDefault : UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) { [self toggleUpdateLockForApp:appInfo]; [self deselectRow]; }]];
        [appSelectAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Inject Tweak", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) { [TSTweakInjector presentForBundleIdentifier:appId displayName:appName fromViewController:self]; [self deselectRow]; }]];
    }
    if (trollManagedApp) {
        [appSelectAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Export IPA", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            [self exportManagedAppInfo:appInfo forRepackaging:NO];
            [self deselectRow];
        }]];
        [appSelectAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Modify / Duplicate", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            [self exportManagedAppInfo:appInfo forRepackaging:YES];
            [self deselectRow];
        }]];
        [appSelectAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Inject Tweak", nil) style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) { [TSTweakInjector presentForBundleIdentifier:appId displayName:appName fromViewController:self]; [self deselectRow]; }]];
        NSString *switchState = [[appInfo registrationState] isEqualToString:@"System"] ? @"User" : @"System";
        UIAlertActionStyle switchStyle = [switchState isEqualToString:@"User"] ? UIAlertActionStyleDestructive : UIAlertActionStyleDefault;
        [appSelectAlert addAction:[UIAlertAction actionWithTitle:[NSString stringWithFormat:NSLocalizedString(@"Switch to \"%@\" Registration", nil), switchState] style:switchStyle handler:^(__unused UIAlertAction *action) { [self changeAppRegistrationForRowAtIndexPath:indexPath toState:switchState]; [self deselectRow]; }]];
        [appSelectAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Uninstall App", nil) style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) { [self uninstallPressedForRowAtIndexPath:indexPath]; [self deselectRow]; }]];
    }
    [appSelectAlert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:^(__unused UIAlertAction *action) { [self deselectRow]; }]];
    appSelectAlert.popoverPresentationController.sourceView = tableView;
    appSelectAlert.popoverPresentationController.sourceRect = [tableView rectForRowAtIndexPath:indexPath];
    [TSPresentationDelegate presentViewController:appSelectAlert animated:YES completion:nil];
}

- (void)confirmMaintenanceCommand:(NSString *)command appInfo:(TSAppInfo *)appInfo
{
	BOOL destructive = [command isEqualToString:@"clear-data"];
	UIAlertController *confirm = [UIAlertController alertControllerWithTitle:destructive ? NSLocalizedString(@"Clear App Data", nil) : NSLocalizedString(@"Clear Cache", nil) message:destructive ? NSLocalizedString(@"This deletes the application's entire data container, including documents, preferences, databases and caches. Quit the app first; iOS will be asked to create an empty container. This cannot be undone.", nil) : NSLocalizedString(@"This removes Library/Caches contents only. Other application data is preserved.", nil) preferredStyle:UIAlertControllerStyleAlert];
	[confirm addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil]];
	[confirm addAction:[UIAlertAction actionWithTitle:destructive ? NSLocalizedString(@"Delete Data", nil) : NSLocalizedString(@"Clear Cache", nil) style:destructive ? UIAlertActionStyleDestructive : UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
		[TSPresentationDelegate startActivity:destructive ? NSLocalizedString(@"Clearing App Data", nil) : NSLocalizedString(@"Clearing Cache", nil)];
		dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{ NSString *log = nil; int result = spawnRoot(rootHelperPath(), @[command, appInfo.bundleIdentifier ?: @""], nil, &log); dispatch_async(dispatch_get_main_queue(), ^{ [TSPresentationDelegate stopActivityWithCompletion:^{ [self showMaintenanceResult:log.length ? log : [NSString stringWithFormat:NSLocalizedString(@"Operation failed with code %d.", nil), result] title:result == 0 ? NSLocalizedString(@"Completed", nil) : NSLocalizedString(@"Operation Failed", nil)]; }]; }); });
	}]];
	[TSPresentationDelegate presentViewController:confirm animated:YES completion:nil];
}

- (void)showMaintenanceResult:(NSString *)message title:(NSString *)title
{
	UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
	[alert addAction:[UIAlertAction actionWithTitle:NSLocalizedString(@"OK", nil) style:UIAlertActionStyleCancel handler:nil]];
	[TSPresentationDelegate presentViewController:alert animated:YES completion:nil];
}

- (void)purgeCachedIconsForApps:(NSArray <LSApplicationProxy *>*)apps
{
	for (LSApplicationProxy *appProxy in apps) {
		NSString *appId = appProxy.bundleIdentifier;
		if (appId.length > 0) [_cachedIcons removeObjectForKey:appId];
	}
}

- (void)applicationsDidInstall:(NSArray <LSApplicationProxy *>*)apps
{
	[self purgeCachedIconsForApps:apps];
	dispatch_async(dispatch_get_main_queue(), ^{
		self->_cachedAllAppCatalog = nil;
		self->_cachedTrollStoreAppCatalog = nil;
		self->_cachedAppStoreAppCatalog = nil;
		self->_cachedSystemAppCatalog = nil;
        [self.managedContainerCache removeAllObjects];
		[self reloadTable];
	});
}

- (void)applicationsDidUninstall:(NSArray <LSApplicationProxy *>*)apps
{
	[self purgeCachedIconsForApps:apps];
	dispatch_async(dispatch_get_main_queue(), ^{
		self->_cachedAllAppCatalog = nil;
		self->_cachedTrollStoreAppCatalog = nil;
		self->_cachedAppStoreAppCatalog = nil;
		self->_cachedSystemAppCatalog = nil;
        [self.managedContainerCache removeAllObjects];
		[self reloadTable];
	});
}

@end
