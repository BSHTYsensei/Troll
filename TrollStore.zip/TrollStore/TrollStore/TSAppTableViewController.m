#import "TSAppTableViewController.h"

#import "TSApplicationsManager.h"
#import <TSPresentationDelegate.h>
#import "TSInstallationController.h"
#import "TSUtil.h"
@import UniformTypeIdentifiers;

#define ICON_FORMAT_IPAD 8
#define ICON_FORMAT_IPHONE 10

NSInteger iconFormatToUse(void)
{
	if(UIDevice.currentDevice.userInterfaceIdiom == UIUserInterfaceIdiomPad)
	{
		return ICON_FORMAT_IPAD;
	}
	else
	{
		return ICON_FORMAT_IPHONE;
	}
}

UIImage* imageWithSize(UIImage* image, CGSize size)
{
	if(CGSizeEqualToSize(image.size, size)) return image;
	UIGraphicsBeginImageContextWithOptions(size, NO, UIScreen.mainScreen.scale);
	CGRect imageRect = CGRectMake(0.0, 0.0, size.width, size.height);
	[image drawInRect:imageRect];
	UIImage* outImage = UIGraphicsGetImageFromCurrentImageContext();
	UIGraphicsEndImageContext();
	return outImage;
}

@interface UIImage ()
+ (UIImage *)_applicationIconImageForBundleIdentifier:(NSString *)id format:(NSInteger)format scale:(double)scale;
@end

@implementation TSAppTableViewController

- (BOOL)isManagedByTrollStoreAtBundlePath:(NSString*)bundlePath
{
	NSString* containerPath = bundlePath.stringByDeletingLastPathComponent;
	NSString* trollStoreMarker = [containerPath stringByAppendingPathComponent:TS_MARKER];
	NSString* trollStoreLiteMarker = [containerPath stringByAppendingPathComponent:TS_LITE_MARKER];
	NSFileManager* fileManager = [NSFileManager defaultManager];
	return [fileManager fileExistsAtPath:trollStoreMarker] || [fileManager fileExistsAtPath:trollStoreLiteMarker];
}

- (NSArray<NSString*>*)appStoreAppBundlePaths
{
	NSMutableOrderedSet<NSString*>* paths = [NSMutableOrderedSet new];
	NSFileManager* fileManager = [NSFileManager defaultManager];
	LSApplicationWorkspace* workspace = [LSApplicationWorkspace defaultWorkspace];

	// LSApplicationWorkspace type 0 enumerates user apps and type 1 system apps.
	// Merge both so AppStoreApp contains normal App Store apps plus stock system apps.
	// This category is intentionally read-only.
	void (^appendAppProxy)(LSApplicationProxy*) = ^(LSApplicationProxy* appProxy)
	{
		if(!appProxy.installed || !appProxy.bundleIdentifier.length || !appProxy.bundleURL.path.length)
		{
			return;
		}

		NSString* bundlePath = appProxy.bundleURL.path;
		if([self isManagedByTrollStoreAtBundlePath:bundlePath]) return;
		if([bundlePath.lastPathComponent isEqualToString:@"TrollStorePersistenceHelper.app"]) return;

		// Do not restrict this category to a hard-coded list of paths: Apple has moved
		// system apps between /Applications, /System/Applications and CoreServices.
		// The workspace's two enumeration types determine membership; the marker
		// check above prevents TrollStore-installed apps from appearing in both lists.
		if([fileManager fileExistsAtPath:bundlePath])
		{
			[paths addObject:bundlePath];
		}
	};
	[workspace enumerateApplicationsOfType:0 block:appendAppProxy];
	[workspace enumerateApplicationsOfType:1 block:appendAppProxy];

	return paths.array;
}

- (NSArray<TSAppInfo*>*)buildAppInfosShowingAppStoreApps:(BOOL)showAppStoreApps
{
	NSArray* appPaths = showAppStoreApps ? [self appStoreAppBundlePaths] : [[TSApplicationsManager sharedInstance] installedAppPaths];
	NSMutableArray<TSAppInfo*>* appInfos = [NSMutableArray new];
	for(NSString* appPath in appPaths)
	{
		@autoreleasepool
		{
			TSAppInfo* appInfo = [[TSAppInfo alloc] initWithAppBundlePath:appPath];
			if([appInfo sync_loadBasicInfo] == nil)
			{
				[appInfos addObject:appInfo];
			}
		}
	}

	[appInfos sortUsingComparator:^(TSAppInfo* appInfoA, TSAppInfo* appInfoB)
	{
		return [[appInfoA displayName] localizedStandardCompare:[appInfoB displayName]];
	}];
	return appInfos.copy;
}

- (NSArray<TSAppInfo*>*)filteredAppInfosFromCatalog:(NSArray<TSAppInfo*>*)catalog searchKey:(NSString*)searchKey
{
	if(searchKey.length == 0) return catalog ?: @[];
	NSMutableArray<TSAppInfo*>* filtered = [NSMutableArray new];
	for(TSAppInfo* appInfo in catalog)
	{
		NSString* appName = [appInfo displayName] ?: @"";
		NSString* appId = [appInfo bundleIdentifier] ?: @"";
		BOOL nameMatch = [appName rangeOfString:searchKey options:NSCaseInsensitiveSearch].location != NSNotFound;
		BOOL identifierMatch = [appId rangeOfString:searchKey options:NSCaseInsensitiveSearch].location != NSNotFound;
		if(nameMatch || identifierMatch) [filtered addObject:appInfo];
	}
	return filtered.copy;
}

- (instancetype)init
{
	self = [super init];
	if(self)
	{
		_showAppStoreApps = NO;
		_cachedAppInfos = @[];
		_reloadGeneration = 0;
		_placeholderIcon = [UIImage _applicationIconImageForBundleIdentifier:@"com.apple.WebSheet" format:iconFormatToUse() scale:[UIScreen mainScreen].scale];
		_cachedIcons = [NSCache new];
		_cachedIcons.countLimit = 300;
		[[LSApplicationWorkspace defaultWorkspace] addObserver:self];
		[self reloadTable];
	}
	return self;
}

- (void)dealloc
{
	[[LSApplicationWorkspace defaultWorkspace] removeObserver:self];
}

- (void)reloadTable
{
	dispatch_async(dispatch_get_main_queue(), ^
	{
		NSUInteger generation = ++self->_reloadGeneration;
		BOOL showAppStoreApps = self->_showAppStoreApps;
		NSArray<TSAppInfo*>* cachedCatalog = showAppStoreApps ? self->_cachedAppStoreAppCatalog : self->_cachedTrollStoreAppCatalog;
		if(cachedCatalog)
		{
			self->_cachedAppInfos = [self filteredAppInfosFromCatalog:cachedCatalog searchKey:self->_searchKey ?: @""];
			[self.tableView reloadData];
			return;
		}

		// Do not leave the previous category visible while a cold catalog is loading.
		self->_cachedAppInfos = @[];
		[self.tableView reloadData];

		dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^
		{
			NSArray<TSAppInfo*>* catalog = [self buildAppInfosShowingAppStoreApps:showAppStoreApps];
			dispatch_async(dispatch_get_main_queue(), ^
			{
				// Discard stale scans when the user switches categories or the catalog is refreshed.
				if(generation != self->_reloadGeneration) return;
				if(showAppStoreApps) self->_cachedAppStoreAppCatalog = catalog;
				else self->_cachedTrollStoreAppCatalog = catalog;
				self->_cachedAppInfos = [self filteredAppInfosFromCatalog:catalog searchKey:self->_searchKey ?: @""];
				[self.tableView reloadData];
			});
		});
	});
}

- (void)applicationsChangedNotification:(NSNotification*)notification
{
	dispatch_async(dispatch_get_main_queue(), ^{
		self->_cachedTrollStoreAppCatalog = nil;
		self->_cachedAppStoreAppCatalog = nil;
		[self reloadTable];
	});
}

- (void)loadView
{
	[super loadView];
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(applicationsChangedNotification:) name:@"ApplicationsChanged" object:nil];
}

- (void)viewDidLoad
{
	[super viewDidLoad];
	
	self.tableView.allowsMultipleSelectionDuringEditing = NO;
	self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];

	[self _setUpNavigationBar];
	[self _setUpSearchBar];
	[self _setUpAppCategoryControl];
}

- (void)_setUpAppCategoryControl
{
	_appCategoryControl = [[UISegmentedControl alloc] initWithItems:@[
		NSLocalizedString(@"TrollStore Apps", nil),
		NSLocalizedString(@"AppStoreApp", nil)
	]];
	_appCategoryControl.selectedSegmentIndex = 0;
	[_appCategoryControl addTarget:self action:@selector(appCategoryChanged:) forControlEvents:UIControlEventValueChanged];

	UIView* header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.tableView.bounds.size.width, 52)];
	_appCategoryControl.frame = CGRectMake(16, 8, MAX(0, header.bounds.size.width - 32), 34);
	[header addSubview:_appCategoryControl];
	self.tableView.tableHeaderView = header;
}

- (void)viewDidLayoutSubviews
{
	[super viewDidLayoutSubviews];
	UIView* header = self.tableView.tableHeaderView;
	if(header && _appCategoryControl)
	{
		CGFloat width = self.tableView.bounds.size.width;
		BOOL headerSizeChanged = header.frame.size.width != width || header.frame.size.height != 52.0;
		if(headerSizeChanged)
		{
			header.frame = CGRectMake(0, 0, width, 52);
			self.tableView.tableHeaderView = header;
		}
		_appCategoryControl.frame = CGRectMake(16, 8, MAX(0, width - 32), 34);
	}
}

- (void)appCategoryChanged:(UISegmentedControl*)sender
{
	_showAppStoreApps = sender.selectedSegmentIndex == 1;
	[self reloadTable];
}

- (void)_setUpNavigationBar
{
	UIAction* installFromFileAction = [UIAction actionWithTitle:NSLocalizedString(@"Install IPA File", nil) image:[UIImage systemImageNamed:@"doc.badge.plus"] identifier:@"InstallIPAFile" handler:^(__kindof UIAction *action)
	{
		dispatch_async(dispatch_get_main_queue(), ^
		{
			UTType* ipaType = [UTType typeWithFilenameExtension:@"ipa" conformingToType:UTTypeData];
			UTType* tipaType = [UTType typeWithFilenameExtension:@"tipa" conformingToType:UTTypeData];

			UIDocumentPickerViewController* documentPickerVC = [[UIDocumentPickerViewController alloc] initForOpeningContentTypes:@[ipaType, tipaType]];
			documentPickerVC.allowsMultipleSelection = NO;
			documentPickerVC.delegate = self;

			[TSPresentationDelegate presentViewController:documentPickerVC animated:YES completion:nil];
		});
	}];

	UIAction* installFromURLAction = [UIAction actionWithTitle:NSLocalizedString(@"Install from URL", nil) image:[UIImage systemImageNamed:@"link.badge.plus"] identifier:@"InstallFromURL" handler:^(__kindof UIAction *action)
	{
		dispatch_async(dispatch_get_main_queue(), ^
		{
			UIAlertController* installURLController = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Install from URL", nil) message:@"" preferredStyle:UIAlertControllerStyleAlert];

			[installURLController addTextFieldWithConfigurationHandler:^(UITextField *textField) {
				textField.placeholder = NSLocalizedString(@"IPA URL", nil);
			}];

			UIAlertAction* installAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Install", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
			{
				NSString* URLString = installURLController.textFields.firstObject.text;
				NSURL* remoteURL = [NSURL URLWithString:URLString];

				[TSInstallationController handleAppInstallFromRemoteURL:remoteURL completion:nil];
			}];
			[installURLController addAction:installAction];

			UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil];
			[installURLController addAction:cancelAction];

			[TSPresentationDelegate presentViewController:installURLController animated:YES completion:nil];
		});
	}];

	UIMenu* installMenu = [UIMenu menuWithChildren:@[installFromFileAction, installFromURLAction]];

	UIBarButtonItem* installBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage systemImageNamed:@"plus"] menu:installMenu];
	
	self.navigationItem.rightBarButtonItems = @[installBarButtonItem];
}

- (void)_setUpSearchBar
{
	_searchController = [[UISearchController alloc] initWithSearchResultsController:nil];
	_searchController.searchResultsUpdater = self;
	_searchController.obscuresBackgroundDuringPresentation = NO;
	self.navigationItem.searchController = _searchController;
	self.navigationItem.hidesSearchBarWhenScrolling = YES;
}

- (void)updateSearchResultsForSearchController:(UISearchController *)searchController
{
	NSString* searchKey = [searchController.searchBar.text copy] ?: @"";
	dispatch_async(dispatch_get_main_queue(), ^{
		self->_searchKey = searchKey;
		NSArray<TSAppInfo*>* catalog = self->_showAppStoreApps ? self->_cachedAppStoreAppCatalog : self->_cachedTrollStoreAppCatalog;
		if(!catalog) return; // The initial/background scan will apply the latest query when it completes.
		self->_cachedAppInfos = [self filteredAppInfosFromCatalog:catalog searchKey:searchKey];
		[self.tableView reloadData];
	});
}

- (void)documentPicker:(UIDocumentPickerViewController *)controller didPickDocumentsAtURLs:(NSArray<NSURL *> *)urls
{
	NSString* pathToIPA = urls.firstObject.path;
	[TSInstallationController presentInstallationAlertIfEnabledForFile:pathToIPA isRemoteInstall:NO completion:nil];
}

- (void)openAppPressedForRowAtIndexPath:(NSIndexPath*)indexPath enableJIT:(BOOL)enableJIT
{
	TSApplicationsManager* appsManager = [TSApplicationsManager sharedInstance];

	TSAppInfo* appInfo = _cachedAppInfos[indexPath.row];
	NSString* appId = [appInfo bundleIdentifier];
	BOOL didOpen = [appsManager openApplicationWithBundleID:appId];

	// if we failed to open the app, show an alert
	if(!didOpen)
	{
		NSString* failMessage = @"";
		if([[appInfo registrationState] isEqualToString:@"User"])
		{
			failMessage = NSLocalizedString(@"This app was not able to launch because it has a \"User\" registration state, register it as \"System\" and try again.", nil);
		}

		NSString* failTitle = [NSString stringWithFormat:NSLocalizedString(@"Failed to open %@", nil), appId];
		UIAlertController* didFailController = [UIAlertController alertControllerWithTitle:failTitle message:failMessage preferredStyle:UIAlertControllerStyleAlert];
		UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil];

		[didFailController addAction:cancelAction];
		[TSPresentationDelegate presentViewController:didFailController animated:YES completion:nil];
	}
	else if (enableJIT)
	{
		int ret = [appsManager enableJITForBundleID:appId];
		if (ret != 0)
		{
			UIAlertController* errorAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Error", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Error enabling JIT: trollstorehelper returned %d", nil), ret] preferredStyle:UIAlertControllerStyleAlert];
			UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];
			[errorAlert addAction:closeAction];
			[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:nil];
		}
	}
}

- (void)showDetailsPressedForRowAtIndexPath:(NSIndexPath*)indexPath
{
	TSAppInfo* appInfo = _cachedAppInfos[indexPath.row];

	[appInfo loadInfoWithCompletion:^(NSError* error)
	{
		dispatch_async(dispatch_get_main_queue(), ^
		{
			if(!error)
			{
				UIAlertController* detailsAlert = [UIAlertController alertControllerWithTitle:@"" message:@"" preferredStyle:UIAlertControllerStyleAlert];
				detailsAlert.attributedTitle = [appInfo detailedInfoTitle];
				detailsAlert.attributedMessage = [appInfo detailedInfoDescription];

				UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];
				[detailsAlert addAction:closeAction];

				[TSPresentationDelegate presentViewController:detailsAlert animated:YES completion:nil];
			}
			else
			{
				UIAlertController* errorAlert = [UIAlertController alertControllerWithTitle:[NSString stringWithFormat:NSLocalizedString(@"Parse Error %ld", nil), error.code] message:error.localizedDescription preferredStyle:UIAlertControllerStyleAlert];
				UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];
				[errorAlert addAction:closeAction];

				[TSPresentationDelegate presentViewController:errorAlert animated:YES completion:nil];
			}
		});
	}];
}

- (void)changeAppRegistrationForRowAtIndexPath:(NSIndexPath*)indexPath toState:(NSString*)newState
{
	TSAppInfo* appInfo = _cachedAppInfos[indexPath.row];

	if([newState isEqualToString:@"User"])
	{
		NSString* title = [NSString stringWithFormat:NSLocalizedString(@"Switching '%@' to \"User\" Registration", nil), [appInfo displayName]];
		UIAlertController* confirmationAlert = [UIAlertController alertControllerWithTitle:title message:NSLocalizedString(@"Switching this app to a \"User\" registration will make it unlaunchable after the next respring because the bugs exploited in TrollStore only affect apps registered as \"System\".\nThe purpose of this option is to make the app temporarily show up in settings, so you can adjust the settings and then switch it back to a \"System\" registration (TrollStore installed apps do not show up in settings otherwise). Additionally, the \"User\" registration state is also useful to temporarily fix iTunes file sharing, which also doesn't work for TrollStore installed apps otherwise.\nWhen you're done making the changes you need and want the app to become launchable again, you will need to switch it back to \"System\" state in TrollStore.", nil) preferredStyle:UIAlertControllerStyleAlert];

		UIAlertAction* switchToUserAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Switch to \"User\"", nil) style:UIAlertActionStyleDestructive handler:^(UIAlertAction* action)
		{
			[[TSApplicationsManager sharedInstance] changeAppRegistration:[appInfo bundlePath] toState:newState];
			[appInfo sync_loadBasicInfo];
		}];

		[confirmationAlert addAction:switchToUserAction];

		UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil];

		[confirmationAlert addAction:cancelAction];

		[TSPresentationDelegate presentViewController:confirmationAlert animated:YES completion:nil];
	}
	else
	{
		[[TSApplicationsManager sharedInstance] changeAppRegistration:[appInfo bundlePath] toState:newState];
		[appInfo sync_loadBasicInfo];

		NSString* title = [NSString stringWithFormat:NSLocalizedString(@"Switched '%@' to \"System\" Registration", nil), [appInfo displayName]];

		UIAlertController* infoAlert = [UIAlertController alertControllerWithTitle:title message:NSLocalizedString(@"The app has been switched to the \"System\" registration state and will become launchable again after a respring.", nil) preferredStyle:UIAlertControllerStyleAlert];

		UIAlertAction* respringAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Respring", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
		{
			respring();
		}];

		[infoAlert addAction:respringAction];

		UIAlertAction* closeAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Close", nil) style:UIAlertActionStyleDefault handler:nil];

		[infoAlert addAction:closeAction];

		[TSPresentationDelegate presentViewController:infoAlert animated:YES completion:nil];
	}
}

- (void)uninstallPressedForRowAtIndexPath:(NSIndexPath*)indexPath
{
	TSApplicationsManager* appsManager = [TSApplicationsManager sharedInstance];

	TSAppInfo* appInfo = _cachedAppInfos[indexPath.row];

	NSString* appPath = [appInfo bundlePath];
	NSString* appId = [appInfo bundleIdentifier];
	NSString* appName = [appInfo displayName];

	UIAlertController* confirmAlert = [UIAlertController alertControllerWithTitle:NSLocalizedString(@"Confirm Uninstallation", nil) message:[NSString stringWithFormat:NSLocalizedString(@"Uninstalling the app '%@' will delete the app and all data associated to it.", nil), appName] preferredStyle:UIAlertControllerStyleAlert];

	UIAlertAction* uninstallAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Uninstall", nil) style:UIAlertActionStyleDestructive handler:^(UIAlertAction* action)
	{
		if(appId)
		{
			[appsManager uninstallApp:appId];
		}
		else
		{
			[appsManager uninstallAppByPath:appPath];
		}
	}];
	[confirmAlert addAction:uninstallAction];

	UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:nil];
	[confirmAlert addAction:cancelAction];

	[TSPresentationDelegate presentViewController:confirmAlert animated:YES completion:nil];
}

- (void)deselectRow
{
	[self.tableView deselectRowAtIndexPath:[self.tableView indexPathForSelectedRow] animated:YES];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
	return _cachedAppInfos.count;
}

- (void)traitCollectionDidChange:(UITraitCollection *)previousTraitCollection
{
	[super traitCollectionDidChange:previousTraitCollection];
	[self.tableView reloadData];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ApplicationCell"];
	if(!cell) {
		cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"ApplicationCell"];
	}

	if(!indexPath || indexPath.row >= _cachedAppInfos.count) return cell;

	TSAppInfo* appInfo = _cachedAppInfos[indexPath.row];
	NSString* appId = [appInfo bundleIdentifier];
	NSString* appVersion = [appInfo versionString];

	// Configure the cell...
	cell.textLabel.text = [appInfo displayName];
	NSString* appCategory = _showAppStoreApps ? NSLocalizedString(@"AppStoreApp", nil) : NSLocalizedString(@"TrollStore App", nil);
	cell.detailTextLabel.text = [NSString stringWithFormat:@"%@ • %@ • %@", appCategory, appVersion, appId];
	cell.imageView.layer.borderWidth = 1;
	cell.imageView.layer.borderColor = [UIColor.labelColor colorWithAlphaComponent:0.1].CGColor;
	cell.imageView.layer.cornerRadius = 13.5;
	cell.imageView.layer.masksToBounds = YES;
	cell.imageView.layer.cornerCurve = kCACornerCurveContinuous;

	if(appId)
	{
		UIImage* cachedIcon = [_cachedIcons objectForKey:appId];
		if(cachedIcon)
		{
			cell.imageView.image = cachedIcon;
		}
		else
		{
			cell.imageView.image = _placeholderIcon;
			dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^
			{
				UIImage* iconImage = imageWithSize([UIImage _applicationIconImageForBundleIdentifier:appId format:iconFormatToUse() scale:[UIScreen mainScreen].scale], _placeholderIcon.size);
				if(iconImage) [_cachedIcons setObject:iconImage forKey:appId];
				dispatch_async(dispatch_get_main_queue(), ^{
					NSUInteger currentRow = [_cachedAppInfos indexOfObject:appInfo];
					if(currentRow == NSNotFound || !iconImage) return;
					NSIndexPath *curIndexPath = [NSIndexPath indexPathForRow:currentRow inSection:0];
					UITableViewCell *curCell = [tableView cellForRowAtIndexPath:curIndexPath];
					if(curCell)
					{
						curCell.imageView.image = iconImage;
						[curCell setNeedsLayout];
					}
				});
			});
		}
	}
	else
	{
		cell.imageView.image = _placeholderIcon;
	}

	cell.preservesSuperviewLayoutMargins = NO;
	cell.separatorInset = UIEdgeInsetsZero;
	cell.layoutMargins = UIEdgeInsetsZero;

	return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	return 80.0f;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
	return !_showAppStoreApps;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(_showAppStoreApps) return;
	if(editingStyle == UITableViewCellEditingStyleDelete)
	{
		[self uninstallPressedForRowAtIndexPath:indexPath];
	}
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
	TSAppInfo* appInfo = _cachedAppInfos[indexPath.row];

	NSString* appId = [appInfo bundleIdentifier];
	NSString* appName = [appInfo displayName];

	UIAlertController* appSelectAlert = [UIAlertController alertControllerWithTitle:appName?:@"" message:appId?:@"" preferredStyle:UIAlertControllerStyleActionSheet];

	UIAlertAction* openAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Open", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
	{
		[self openAppPressedForRowAtIndexPath:indexPath enableJIT:NO];
		[self deselectRow];
	}];
	[appSelectAlert addAction:openAction];

	if ([appInfo isDebuggable])
	{
		UIAlertAction* openWithJITAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Open with JIT", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
		{
			[self openAppPressedForRowAtIndexPath:indexPath enableJIT:YES];
			[self deselectRow];
		}];
		[appSelectAlert addAction:openWithJITAction];
	}

	UIAlertAction* showDetailsAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Show Details", nil) style:UIAlertActionStyleDefault handler:^(UIAlertAction* action)
	{
		[self showDetailsPressedForRowAtIndexPath:indexPath];
		[self deselectRow];
	}];
	[appSelectAlert addAction:showDetailsAction];

	if(_showAppStoreApps)
	{
		UIAlertAction* cancelSystemAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:^(UIAlertAction* action)
		{
			[self deselectRow];
		}];
		[appSelectAlert addAction:cancelSystemAction];
		appSelectAlert.popoverPresentationController.sourceView = tableView;
		appSelectAlert.popoverPresentationController.sourceRect = [tableView rectForRowAtIndexPath:indexPath];
		[TSPresentationDelegate presentViewController:appSelectAlert animated:YES completion:nil];
		return;
	}

	NSString* switchState;
	NSString* registrationState = [appInfo registrationState];
	UIAlertActionStyle switchActionStyle = 0;
	if([registrationState isEqualToString:@"System"])
	{
		switchState = @"User";
		switchActionStyle = UIAlertActionStyleDestructive;
	}
	else if([registrationState isEqualToString:@"User"])
	{
		switchState = @"System";
		switchActionStyle = UIAlertActionStyleDefault;
	}

	UIAlertAction* switchRegistrationAction = [UIAlertAction actionWithTitle:[NSString stringWithFormat:NSLocalizedString(@"Switch to \"%@\" Registration", nil), switchState] style:switchActionStyle handler:^(UIAlertAction* action)
	{
		[self changeAppRegistrationForRowAtIndexPath:indexPath toState:switchState];
		[self deselectRow];
	}];
	[appSelectAlert addAction:switchRegistrationAction];

	UIAlertAction* uninstallAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Uninstall App", nil) style:UIAlertActionStyleDestructive handler:^(UIAlertAction* action)
	{
		[self uninstallPressedForRowAtIndexPath:indexPath];
		[self deselectRow];
	}];
	[appSelectAlert addAction:uninstallAction];

	UIAlertAction* cancelAction = [UIAlertAction actionWithTitle:NSLocalizedString(@"Cancel", nil) style:UIAlertActionStyleCancel handler:^(UIAlertAction* action)
	{
		[self deselectRow];
	}];
	[appSelectAlert addAction:cancelAction];

	appSelectAlert.popoverPresentationController.sourceView = tableView;
	appSelectAlert.popoverPresentationController.sourceRect = [tableView rectForRowAtIndexPath:indexPath];

	[TSPresentationDelegate presentViewController:appSelectAlert animated:YES completion:nil];
}

- (void)purgeCachedIconsForApps:(NSArray <LSApplicationProxy *>*)apps
{
	for (LSApplicationProxy *appProxy in apps) {
		NSString *appId = appProxy.bundleIdentifier;
		if (appId.length > 0) [_cachedIcons removeObjectForKey:appId];
	}
}

- (void)applicationsDidInstall:(NSArray <LSApplicationProxy *>*)apps
{
	[self purgeCachedIconsForApps:apps];
	dispatch_async(dispatch_get_main_queue(), ^{
		self->_cachedTrollStoreAppCatalog = nil;
		self->_cachedAppStoreAppCatalog = nil;
		[self reloadTable];
	});
}

- (void)applicationsDidUninstall:(NSArray <LSApplicationProxy *>*)apps
{
	[self purgeCachedIconsForApps:apps];
	dispatch_async(dispatch_get_main_queue(), ^{
		self->_cachedTrollStoreAppCatalog = nil;
		self->_cachedAppStoreAppCatalog = nil;
		[self reloadTable];
	});
}

@end
