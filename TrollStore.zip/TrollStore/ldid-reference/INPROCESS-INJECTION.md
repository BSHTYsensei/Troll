# ldid in-process injection

## What changed

The previous `iosinject::patch_load()` implementation spawned `insert_dylib` through `fork`/`exec`. It has been replaced by a C++ Mach-O load-command editor inside `ldid.cpp`.

The injection path no longer starts `insert_dylib`, another `ldid`, or `clang` processes. Signing is performed by calling `ldid::Signer::sign_bundle()` in-process; verification calls `ldid::Verifier::verify()` in-process. Static `.a` archives are rejected with an explicit diagnostic because they are not dyld-loadable runtime images and converting them into a dylib would require a linker.

## Mach-O implementation

- Adds `LC_LOAD_DYLIB` or `LC_LOAD_WEAK_DYLIB` with the required name string, `cmdsize` alignment, and updates `ncmds` and `sizeofcmds`.
- Handles thin and universal/fat Mach-O files, including each architecture slice.
- Avoids adding the same command twice. If the requested path already exists but its weak/strong mode differs, it changes the existing command instead of duplicating it.
- Keeps the idempotent fast path before stripping signatures, so an already-injected and signed binary is left untouched.
- For a real modification, strips the old embedded signature with ldid's own parser, edits a complete in-memory image, then atomically replaces the file while preserving its mode bits.
- Requires enough zero-filled header padding before the first file-backed section. If the header does not have room, the operation fails without modifying the file rather than shifting Mach-O file offsets without a complete relocation pass.

## Invocation

```sh
ldid --iosinject --sign --verify MyApp.app tweak.dylib
```

`--output` currently denotes an output app-bundle directory; this subcommand does not create an `.ipa` by merely giving the output directory an `.ipa` suffix. Direct `.dylib` and `.framework` payloads are the main supported/tested paths. The existing `.xcframework` and `.deb` compatibility branches require additional real-package testing; `.a` inputs are deliberately refused.

Useful options include `--inplace`, `--output PATH`, `--overwrite`, `--weak`, `--entitlements PATH`, `--preserve-metadata`, `--deep`, `--super-deep`, `--sign`, `--verify`, `--dry-run`, and `--verbose`. There is no `--ldid` option because signing is now in-process.

## Validation performed here

- `clang++ -std=c++20 -fsyntax-only -Wall -Wextra -Wpedantic` passed with no diagnostics using temporary libplist API declarations. The local environment does not contain the target libplist development header, so this is not a substitute for a full iOS build.
- Synthetic 64-bit thin Mach-O injection passed.
- Synthetic two-slice fat Mach-O injection passed for both strong and weak dylib commands.
- Repeated injection was idempotent.
- Switching an existing path from weak to strong updated the command in place without a duplicate.
- Static scan found no process-spawn invocation (`fork`, `execv`, `execvp`, `system`, or `popen`) in the injected build path.

A full macOS/Xcode static link and iPhone app launch/signature acceptance test have not been run in this workspace.

## Project references

- TrollFools: https://github.com/Lessica/TrollFools
- insert_dylib: https://github.com/tyilo/insert_dylib
- ChOma: https://github.com/opa334/ChOma

These projects inform behavior and design only; their helper executables are not invoked at runtime, and this build does not link ChOma itself.
