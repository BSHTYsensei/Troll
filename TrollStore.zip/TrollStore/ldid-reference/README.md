# Supplied ldid reference (2026-10-30)

- Runtime executable: `../bin/ldid` — the exact prebuilt arm64 iOS binary supplied in stored files on 2026-10-30.
- SHA-256: `d23eb53e6c5b07f5cae72f0e93ab1b87214aa68ed4a59bc32286f8b15cb8b769`.
- Matching source package: `ldid-custom-signature-cli-2026-10-30.zip`.
- Extracted source: `../ldid.cpp` and `../ldid.hpp`.
- CLI reference: `CUSTOM-SIGNATURE-CLI-2026-10-30.md`.
- Dependency/build reference: `build_libs-2026-10-30.yml`.

The precompiled binary is the runtime authority. The source archive is included for audit and to document its CLI/API capabilities; it is not recompiled to replace the binary during the TrollStore build. It includes certificate-backed CMS signing (`.p12` or certificate/private-key PEM), configurable signing profiles, `--jobs`, deep entitlement merging, signature validation, certificate-chain validation (off by default), and in-process `--iosinject`.

The `classification.requested` value in ldid's custom-signature template is a descriptive hint only. It cannot create Apple trust, an Apple-issued certificate, a provisioning profile, an App Store receipt, or an Apple review/distribution authorization. The selected certificate and matching provisioning profile are what provide real identity and authorization evidence.

The supplied Mach-O is arm64, minimum iOS 16.0.0, SDK 16.4.0. The project does not claim that the binary runs on earlier iOS releases.


## Apple Internal profile policy (2026-11-09)

The bundled `bin/ldid` was updated from the matching 2026-11-09 uploaded Apple Internal policy build. Its companion implementation is in the root `ldid.cpp` and `ldid.hpp`; the strict provisioning-profile policy and template are documented in `APPLE-INTERNAL-PROFILE-SIGNING-2026-11-09.md` and bundled for the app at `TrollStore/Resources/SigningTemplates/apple-internal-profile-template.json`. The preset requires an authentic CMS-signed Apple Internal profile with `AppleInternalProfile=true`; it is not a profile-free mode or a way to convert public profiles.
