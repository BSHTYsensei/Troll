# Apple Internal Profile 签名策略模板

## 重要说明

这个模板**不是免 `.mobileprovision` 签名模板**。目前可核验的 Apple 内部配置证据是：Provisioning Profile 载荷中的 `AppleInternalProfile = true`。它仍然是 Apple CMS 签名的 provisioning profile，而不是可由 ldid 自行生成的替代文件。

模板只接受真实 Apple 签发、CMS 数学签名有效、包含 `AppleInternalProfile=true`、未过期且含 `DeveloperCertificates` 的 profile；签名完成后，还会检查 profile 与 App 的 Bundle ID / Team ID、CMS 叶证书指纹以及 entitlement 白名单是否一致。它不会创建 Apple 证书、Apple 私钥、Apple CMS 签名、平台信任缓存或系统平台权限。

## 生成模板

```sh
ldid --apple-internal-template apple-internal-profile.json
```

`appleInternalProfile.profilePath` 可以填写真实 `.mobileprovision` 路径。相对路径以 JSON 模板所在目录为基准。`embed: true` 时，工具会把它复制到主 `.app/embedded.mobileprovision`。如果留空，则输入 `.app` 必须已经包含该文件。

每个 `.appex` 是独立 bundle；如有 App Extension，必须预先放入它自己的内部 profile，且该 profile 也必须通过同样的 CMS、AppleInternalProfile、有效期与签名身份检查。主 App 的 profile 不会被错误复制到扩展中。

## 校验与签名

```sh
ldid --signature-template-check apple-internal-profile.json
ldid --signature-apply apple-internal-profile.json Payload/Example.app --p12 AppleInternalIdentity.p12 --password 'P12_PASSWORD'
```

也可以使用 `--cert certificate.pem --key private-key.pem` 代替 `--p12`。该策略会拒绝 ad-hoc 签名、没有 CMS 签名者的输出、签名证书不在 profile `DeveloperCertificates` 中的输出，以及关闭根证书链验证的配置。

模板默认启用证书链校验并要求信任根。请确认运行机器的 OpenSSL 信任库包含正确的 Apple 根/中间 CA；必要时在 `validation.caFile` 或 `validation.caPath` 配置可信 CA。这里的“可信”取决于你配置的信任锚，不能把任意自建 CA 文件当作 Apple 根证书。

`requireDEREncodedProfile` 默认是 `false`，因为旧 profile 未必包含该载荷字段；需要严格要求时可设为 `true`。

## 可验证范围

成功表示离线工具验证了文件结构、profile CMS、配置的证书链、签名者/profile 证书关系、Bundle ID / Team ID 和 entitlement 子集。它不代表 Apple 服务器签发了你没有的凭据，也不等于设备端 AMFI、MDM、Apple 内部网络或平台 trust cache 会接受安装/执行。

## 代码结构与性能调整

- 将 OpenSSL、libplist、libarchive 等实现依赖从公共头文件移到 `ldid.cpp`，减少头文件耦合与下游编译负担。
- bundle / framework 归属判断改用路径索引（`unordered_set`）和祖先路径查找，避免在每个 Mach-O / 资源文件上反复扫描完整嵌套 bundle 列表。
- `CodeResources` 的相对路径计算改为词法相对路径，避免对大量资源文件重复进行文件系统规范化操作。
- entitlement 的执行段标记解析复用一次 plist 解析结果，避免同一 XML plist 被重复解析多次。
- Apple Internal 策略现在在签名前检查输入类型和签名凭据；签名后逐一检查主 App 与 `.appex` 的 profile、证书链、Bundle ID / Team ID、CMS signer 与 `DeveloperCertificates` 的匹配。

当前环境缺少真实 libplist 开发包，因此这里只完成了使用临时声明桩的 C++ 语法检查与优化目标文件编译；尚未完成链接和真机/运行时验证。请在你的 Theos/Xcode 工程中使用项目实际依赖重新完整构建。
