# TrollStore — Original UI, built-in Simplified Chinese, and Custom Entitlements

This archive is based on the supplied `TrollStore-main.zip`. It preserves the original TrollStore app, Settings UI, installed-app list, app details/actions, URL scheme handling, installation confirmation/errors, advanced options, update flow, and persistence-helper UI/logic. The original Objective-C controllers are intentionally kept rather than replaced by a simplified Swift interface.

## Changes in this build

- Built-in Simplified Chinese (`zh-Hans.lproj`) for the main TrollStore app and persistence helper. `zh-Hans` is explicitly the development/default localization, so UI strings default to Chinese even when the device language is English.
- Removed the donation controller and its Settings entry.
- Added **Settings → Signing → Custom Entitlements**. The editor validates and saves an XML plist dictionary. When enabled, its keys override matching entitlements only for the main app executable during the normal TrollStore signing flow; unspecified keys are preserved, and plug-ins/extensions continue using TrollStore's original per-binary entitlement handling.
- Bundled the supplied precompiled iOS arm64 `ldid` at `bin/ldid`, also copied as the app resource `TrollStore/Resources/ldid`. The build does not compile `ldid.cpp`.
- Pins ChOma to `964023ddac2286ef8e843f90df64d44ac6a673df`, because the fastPathSign source depends on the matching `FAT.h`, four-argument load-command API, and CodeDirectory updater.

## Build

Run on macOS with Xcode, Theos, the required Theos SDK, Homebrew dependencies, and network access for downloading the pinned ChOma archive:

```sh
make assemble_trollstore THEOS="$HOME/theos" LDID_BIN="$PWD/bin/ldid"
```

The output is `_build/TrollStore.tar`. `make bootstrap-deps` validates the supplied ldid binary and downloads/validates the pinned ChOma dependency. `bootstrap-swift-support` builds Theos Swift helper tools before target parallelization, preventing the `generate-output-file-map` initialization race.

The intended GitHub Actions workflow is managed separately from this archive. If using a workflow that expects a root `TrollStore.zip`, upload this ZIP to the repository root as `TrollStore.zip`; the workflow should extract it to its project directory before invoking the Makefile.

## Validation notes

The source tree includes the original app/helper resources and source files; only the original donation controller files are removed. Static checks validate plist and localization syntax, require Chinese as the default localization, verify translated Chinese values and source-key coverage, check presence of original UI controllers and custom-entitlement wiring, pin ChOma, and verify the embedded `ldid` matches `bin/ldid`.

A complete iOS link and device installation test must run on the macOS/Theos toolchain. Static syntax and resource checks cannot validate all private-framework/runtime behavior on every iOS version.
