# TrollStore — Original UI, Simplified Chinese, pre-install Entitlements

This archive is based on the supplied `TrollStore-main.zip`. It preserves the original TrollStore app, Settings UI, installed-app list, app details/actions, URL scheme handling, installation confirmation/errors, advanced options, update flow, and persistence-helper UI/logic. The original Objective-C controllers are intentionally preserved, and the pre-install Entitlements editor is also implemented in Objective-C. The project contains no Swift source files.

## Changes in this build

- Built-in Simplified Chinese (`zh-Hans.lproj`) for the main TrollStore app and persistence helper. `zh-Hans` is explicitly the development/default localization, so UI strings default to Chinese even when the device language is English.
- Removed the donation controller and its Settings entry.
- Added **Edit Entitlements Before Install** to the IPA installation confirmation. The editor validates an XML plist dictionary before starting installation; its enabled overrides apply to that installation only, only to the main app executable, preserving unspecified keys and leaving extensions on TrollStore's original per-binary entitlement handling.
- Uses your supplied precompiled iOS arm64 `ldid` from `bin/ldid`. The build copies the exact binary to `TrollStore.app/ldid-bootstrap/ldid`, not to the active `TrollStore.app/ldid` path. The app never checks upstream ldid versions or downloads another ldid. Settings exposes **Auto-initialize bundled ldid** (default off) and an explicit **Initialize bundled ldid** action; either copies the bundled binary into the active path locally.
- Pins ChOma to `964023ddac2286ef8e843f90df64d44ac6a673df`, because the fastPathSign source depends on the matching `FAT.h`, four-argument load-command API, and CodeDirectory updater.

## Build

Run on macOS with Xcode, Theos, the required Theos SDK, Homebrew dependencies, and network access for downloading the pinned ChOma archive:

```sh
make assemble_trollstore THEOS="$HOME/theos" LDID_BIN="$PWD/bin/ldid"
```

The output is `_build/TrollStore.tar`. `make bootstrap-deps` validates the supplied ldid binary and downloads/validates the pinned ChOma dependency. The app, root helper, and persistence helper are built from Objective-C/C sources; no Swift toolchain or Swift bootstrap is needed.

The intended GitHub Actions workflow is managed separately from this archive. If using a workflow that expects a root `TrollStore.zip`, upload this ZIP to the repository root as `TrollStore.zip`; the workflow should extract it to its project directory before invoking the Makefile.

## Validation notes

The source tree includes the original app/helper resources and source files; only the original donation controller files are removed. Static checks validate plist and localization syntax, require Chinese as the default localization, verify translated Chinese values and source-key coverage, check presence of original UI controllers and pre-install custom-entitlement wiring, the default-off ldid initialization setting, no remote ldid update/download references, dormant packaging of `bin/ldid`, the app-category split, the ChOma pin, and the self-update association.

A complete iOS link and device installation test must run on the macOS/Theos toolchain. Static syntax and resource checks cannot validate all private-framework/runtime behavior on every iOS version.

## Install/sign performance pass

This build applies conservative I/O optimizations while keeping the bundled `bin/ldid` as the signing executable and retaining the existing signing order and install fallback: 

- Fixes bundle ownership/modes in one traversal instead of walking the entire app twice.
- Snapshots file paths once during signing and reuses them for the post-sign Mach-O pass; directories are excluded from Mach-O parsing.
- Uses same-directory temporary Mach-O files and atomic `rename()` replacement, avoiding an additional cross-directory copy and never deleting the original before replacement succeeds.
- Uses a same-volume move for the extracted `.app` bundle when possible, with copy fallback for unsupported/cross-volume moves.
- Increases libarchive's input block from 10 KiB to 256 KiB for large IPA/tar extraction.
- Drains stdout/stderr concurrently while child processes run, so one full pipe cannot stall signing; captured diagnostics are capped at 4 MiB per stream.

No throughput percentage is claimed: a real benchmark requires building with Theos on macOS and timing representative IPAs on target iOS hardware.


## Performance and stealth-install additions

- Theos production targets use `-O3` for Objective-C/C code; all targets use Objective-C/C optimization flags favoring runtime speed; these flags may increase binary size/build time compared with Theos' default `-Os`.
- App-list scanning, sorting, and info loading run off the main thread; category catalogs are cached across searches, stale scans are discarded, and icons use a thread-safe bounded `NSCache`.
- The app list is split into `TrollStore Apps` and `AppStoreApp`. The latter contains ordinary installed apps and stock/system apps and is read-only in TrollStore.
- The Settings toggle `Enable stealth install for new IPAs` is off by default. When enabled, future IPA installs get a randomized bundle identifier and lose `CFBundleURLTypes`; this can break deep links, OAuth/payment callbacks, or app-to-app URL handling. It reduces some fixed-ID fingerprints only and is not a global jailbreak hide or a guarantee against every detector. Existing installed apps are not modified in place.
