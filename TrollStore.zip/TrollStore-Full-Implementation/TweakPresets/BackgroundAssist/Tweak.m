#import <UIKit/UIKit.h>

// This preset asks iOS for its documented finite background execution allowance.
// It deliberately does not spoof audio/location use or attempt an infinite keepalive.
static UIBackgroundTaskIdentifier TSBackgroundTask = UIBackgroundTaskInvalid;
static void TSEndBackgroundTask(void) {
    if (TSBackgroundTask != UIBackgroundTaskInvalid) {
        [[UIApplication sharedApplication] endBackgroundTask:TSBackgroundTask];
        TSBackgroundTask = UIBackgroundTaskInvalid;
    }
}
static void TSRequestBackgroundAllowance(void) {
    UIApplication *app = UIApplication.sharedApplication;
    if (app.applicationState != UIApplicationStateBackground || TSBackgroundTask != UIBackgroundTaskInvalid) return;
    TSBackgroundTask = [app beginBackgroundTaskWithName:@"TSBackgroundAssist" expirationHandler:^{ dispatch_async(dispatch_get_main_queue(), ^{ TSEndBackgroundTask(); }); }];
    if (TSBackgroundTask == UIBackgroundTaskInvalid) return;
}
__attribute__((constructor)) static void TSBackgroundAssistInitialize(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        NSNotificationCenter *center = NSNotificationCenter.defaultCenter;
        [center addObserverForName:UIApplicationDidEnterBackgroundNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *note) { TSRequestBackgroundAllowance(); }];
        [center addObserverForName:UIApplicationWillEnterForegroundNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *note) { TSEndBackgroundTask(); }];
        [center addObserverForName:UIApplicationWillTerminateNotification object:nil queue:NSOperationQueue.mainQueue usingBlock:^(__unused NSNotification *note) { TSEndBackgroundTask(); }];
    });
}
