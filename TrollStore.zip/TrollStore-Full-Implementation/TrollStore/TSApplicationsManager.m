#import "TSApplicationsManager.h"
#import <TSUtil.h>
#import "TSSigningManager.h"
extern NSUserDefaults* trollStoreUserDefaults();

@implementation TSApplicationsManager

+ (instancetype)sharedInstance
{
    static TSApplicationsManager *sharedInstance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[TSApplicationsManager alloc] init];
    });
    return sharedInstance;
}

- (NSArray*)installedAppPaths
{
    return trollStoreInstalledAppBundlePaths();
}

- (NSError*)errorForCode:(int)code
{
    NSString* errorDescription = NSLocalizedString(@"Unknown Error", nil);
    switch(code)
    {
        // IPA install errors
        case 166:
        errorDescription = NSLocalizedString(@"The IPA file does not exist or is not accessible.", nil);
        break;
        case 167:
        errorDescription = NSLocalizedString(@"The IPA file does not appear to contain an app.", nil);
        break;
        case 168:
        errorDescription = NSLocalizedString(@"Failed to extract IPA file.", nil);
        break;
        case 169:
        errorDescription = NSLocalizedString(@"Failed to extract update tar file.", nil);
        break;
        // App install errors
        case 170:
        errorDescription = NSLocalizedString(@"Failed to create container for app bundle.", nil);
        break;
        case 171:
        errorDescription = [NSString stringWithFormat:NSLocalizedString(@"A non %@ or a %@ app with the same identifier is already installed. If you are absolutely sure it is not, you can force install it.", nil), APP_NAME, OTHER_APP_NAME];
        break;
        case 172:
        errorDescription = NSLocalizedString(@"The app does not contain an Info.plist file.", nil);
        break;
        case 173:
        errorDescription = NSLocalizedString(@"The bundled ldid is unavailable or not initialized. Enable Auto-initialize bundled ldid or choose Initialize bundled ldid in Settings, then try again.", nil);
        break;
        case 174:
        errorDescription = NSLocalizedString(@"The app's main executable does not exist.", nil);
        break;
        case 175: {
            //if (@available(iOS 16, *)) {
            //    errorDescription = @"Failed to sign the app.";
            //}
            //else {
                errorDescription = NSLocalizedString(@"Failed to sign the app. ldid returned a non zero status code.", nil);
            //}
        }
        break;
        case 176:
        errorDescription = NSLocalizedString(@"The app's Info.plist is missing required values.", nil);
        break;
        case 177:
        errorDescription = NSLocalizedString(@"Failed to mark app as TrollStore app.", nil);
        break;
        case 178:
        errorDescription = NSLocalizedString(@"Failed to copy app bundle.", nil);
        break;
        case 179:
        errorDescription = NSLocalizedString(@"The app you tried to install has the same identifier as a system app already installed on the device. The installation has been prevented to protect you from possible bootloops or other issues.", nil);
        break;
        case 180:
        errorDescription = NSLocalizedString(@"The app you tried to install has an encrypted main binary, which cannot have the CoreTrust bypass applied to it. Please ensure you install decrypted apps.", nil);
        break;
        case 181:
        errorDescription = NSLocalizedString(@"Failed to add app to icon cache.", nil);
        break;
        case 182:
        errorDescription = NSLocalizedString(@"The app was installed successfully, but requires developer mode to be enabled to run. After rebooting, select \"Turn On\" to enable developer mode.", nil);
        break;
        case 183:
        errorDescription = NSLocalizedString(@"Failed to enable developer mode.", nil);
        break;
        case 184:
        errorDescription = NSLocalizedString(@"The app was installed successfully, but has additional binaries that are encrypted (e.g. extensions, plugins). The app itself should work, but you may experience broken functionality as a result.", nil);
        break;
        case 185:
        errorDescription = NSLocalizedString(@"Failed to sign the app. The CoreTrust bypass returned a non zero status code.", nil);
        break;
        case 186:
        errorDescription = NSLocalizedString(@"Custom Entitlements are invalid. Choose Edit Entitlements Before Install and save a valid plist.", nil);
        break;
        case 187:
        errorDescription = NSLocalizedString(@"Stealth and normal installs cannot be mixed for the same app. Uninstall the existing copy first, then install again with the desired mode.", nil);
        break;
        case 188:
        errorDescription = NSLocalizedString(@"Failed to update the app's Info.plist while preparing installation.", nil);
        break;
        case 189:
        errorDescription = NSLocalizedString(@"The installd placeholder install failed. You can retry with the Custom installation method.", nil);
        break;
        case 190:
        errorDescription = NSLocalizedString(@"Real signing requires a valid imported P12 identity or a matching PEM certificate/private-key pair. Add one in Settings → Signing Method & Certificates.", nil);
        break;
        case 193:
        errorDescription = NSLocalizedString(@"The app was signed and installed, but no provisioning profile was attached. A valid CMS signature alone does not grant this app permission to install or launch on this device.", nil);
        break;
        case 195:
        errorDescription = NSLocalizedString(@"The supplied ldid binary requires iOS 16.0 or later. On iOS 15, TrollStore signing can use the native signer when available; true signing and legacy iOS 14 signing require a compatible ldid build.", nil);
        break;
    }

    NSError* error = [NSError errorWithDomain:TrollStoreErrorDomain code:code userInfo:@{NSLocalizedDescriptionKey : errorDescription}];
    return error;
}

- (int)installIpa:(NSString*)pathToIpa force:(BOOL)force log:(NSString**)logOut
{
    NSUserDefaults *defaults = trollStoreUserDefaults();
    NSNumber *methodNumber = [defaults objectForKey:@"installationMethod"];
    int method = methodNumber ? methodNumber.intValue : 1;
    if (method != 0 && method != 1) method = 1;
    BOOL preserveOverride = [defaults boolForKey:@"TSCustomEntitlementsOverrideEnabled"];
    NSString *applicationSupport = [NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES) firstObject];
    NSString *entitlementsPath = [applicationSupport stringByAppendingPathComponent:@"TSCustomEntitlements.plist"];
    BOOL stealth = [defaults boolForKey:@"TSStealthInstallEnabled"];
    return [self installIpa:pathToIpa
                      force:force
         installationMethod:method
preserveEntitlementsOverride:preserveOverride
     customEntitlementsPath:entitlementsPath
             stealthInstall:stealth
                       log:logOut];
}

- (int)installIpa:(NSString*)pathToIpa
            force:(BOOL)force
 installationMethod:(int)method
preserveEntitlementsOverride:(BOOL)preserve
              log:(NSString**)logOut
{
    NSUserDefaults *defaults = trollStoreUserDefaults();
    NSString *applicationSupport = [NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES) firstObject];
    NSString *entitlementsPath = [applicationSupport stringByAppendingPathComponent:@"TSCustomEntitlements.plist"];
    return [self installIpa:pathToIpa
                      force:force
         installationMethod:method
preserveEntitlementsOverride:preserve
     customEntitlementsPath:entitlementsPath
             stealthInstall:[defaults boolForKey:@"TSStealthInstallEnabled"]
                       log:logOut];
}

- (int)installIpa:(NSString*)pathToIpa
            force:(BOOL)force
 installationMethod:(int)method
preserveEntitlementsOverride:(BOOL)preserve
customEntitlementsPath:(NSString * _Nullable)entitlementsPath
      stealthInstall:(BOOL)stealthInstall
              log:(NSString**)logOut
{
    NSMutableArray *args = [NSMutableArray new];
    [args addObject:@"install"];
    if (force) [args addObject:@"force"];

    // Never re-read installationMethod during a retry. The controller owns the
    // attempt snapshot and explicitly passes 0 (installd) or 1 (custom).
    if (method == 0) [args addObject:@"installd"];
    else [args addObject:@"custom"];

    // The override is intentionally not consumed here. A retry must reuse the
    // same plist until the controller records success or the user cancels.
    if (preserve) {
        NSString *path = entitlementsPath;
        if (!path.length) {
            NSString *applicationSupport = [NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES) firstObject];
            path = [applicationSupport stringByAppendingPathComponent:@"TSCustomEntitlements.plist"];
        }
        [args addObject:@"--entitlements"];
        [args addObject:path]; // Let RootHelper return 186 if missing/invalid; don't silently skip it.
    }
    if (stealthInstall) [args addObject:@"stealth"];

    NSError *signingConfigurationError = nil;
    NSString *signingConfigurationPath = [TSSigningManager prepareRootHelperSigningConfiguration:&signingConfigurationError];
    if (!signingConfigurationPath) {
        if (logOut) *logOut = signingConfigurationError.localizedDescription ?: NSLocalizedString(@"Unable to prepare signing configuration.", nil);
        return (int)(signingConfigurationError.code ?: 190);
    }
    [args addObject:@"--signing-config"];
    [args addObject:signingConfigurationPath];
    [args addObject:pathToIpa];

    int ret = spawnRoot(rootHelperPath(), args, nil, logOut);
    [TSSigningManager cleanupRootHelperSigningConfiguration:signingConfigurationPath];
    // One-shot Entitlements cleanup is owned by TSInstallationController so
    // every retry retains the original state and arguments.
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ApplicationsChanged" object:nil];
    return ret;
}

- (int)installIpa:(NSString*)pathToIpa
{
    return [self installIpa:pathToIpa force:NO log:nil];
}

- (int)uninstallApp:(NSString*)appId
{
    if(!appId) return -200;

    NSMutableArray* args = [NSMutableArray new];
    [args addObject:@"uninstall"];

    NSNumber* uninstallationMethodToUseNum = [trollStoreUserDefaults() objectForKey:@"uninstallationMethod"];
    int uninstallationMethodToUse = uninstallationMethodToUseNum ? uninstallationMethodToUseNum.intValue : 0;
    if(uninstallationMethodToUse == 1)
    {
        [args addObject:@"custom"];
    }
    else
    {
        [args addObject:@"installd"];
    }

    [args addObject:appId];

    int ret = spawnRoot(rootHelperPath(), args, nil, nil);
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ApplicationsChanged" object:nil];
    return ret;
}

- (int)uninstallAppByPath:(NSString*)path
{
    if(!path) return -200;

    NSMutableArray* args = [NSMutableArray new];
    [args addObject:@"uninstall-path"];

    NSNumber* uninstallationMethodToUseNum = [trollStoreUserDefaults() objectForKey:@"uninstallationMethod"];
    int uninstallationMethodToUse = uninstallationMethodToUseNum ? uninstallationMethodToUseNum.intValue : 0;
    if(uninstallationMethodToUse == 1)
    {
        [args addObject:@"custom"];
    }
    else
    {
        [args addObject:@"installd"];
    }

    [args addObject:path];

    int ret = spawnRoot(rootHelperPath(), args, nil, nil);
    [[NSNotificationCenter defaultCenter] postNotificationName:@"ApplicationsChanged" object:nil];
    return ret;
}

- (BOOL)openApplicationWithBundleID:(NSString *)appId
{
    return [[LSApplicationWorkspace defaultWorkspace] openApplicationWithBundleID:appId];
}

- (int)enableJITForBundleID:(NSString *)appId
{
    return spawnRoot(rootHelperPath(), @[@"enable-jit", appId], nil, nil);
}

- (int)changeAppRegistration:(NSString*)appPath toState:(NSString*)newState
{
    if(!appPath || !newState) return -200;
    int ret = spawnRoot(rootHelperPath(), @[@"modify-registration", appPath, newState], nil, nil);
    if(ret == 0) [[NSNotificationCenter defaultCenter] postNotificationName:@"ApplicationsChanged" object:nil];
    return ret;
}

@end