# TrollStore 本轮功能完整实现报告（简体中文）

## 交付状态

本包把上一轮明确列为“尚未纳入”的大部分功能实际加入 Objective-C/C 源码、RootHelper 命令和 UI，并更新了 `ldid` 为用户 2026-10-27 上传的预编译二进制。它是**已完成源码集成与静态校验的交付候选版本**，不是已在 Xcode/Theos 上成功构建并通过真机测试的发布版。

## 本轮新增及完成的功能

### 1. 应用管理与列表 UI

- 支持双列网格与列表布局切换，并持久化所选布局。
- 常驻搜索栏、TrollStore / App Store / 系统应用三类筛选、不同颜色的来源标识及异步目录加载/缓存。
- 可配置浮动底栏的高度、边距、间距、底部偏移和显示/隐藏；切换带有淡入/轻微缩放、点击动效和触感反馈。
- 新增外观管理：系统/浅色/深色模式、主题色、可选背景图与透明度/模糊设置。
- 系统应用保持只读，不开放危险的清理、注入或卸载操作。

### 2. 脱壳并导出 IPA

- 应用列表提供“解密并导出 IPA”入口。
- RootHelper 在目标应用运行时枚举进程和 dyld 镜像，使用 `task_for_pid` / `mach_vm_read_overwrite` 读取运行时内存。
- 按 Mach-O segment 的 VM/file 映射定位加密区域；处理 arm64 fat/universal Mach-O 的字节序和 slice 边界，并仅在确认写回解密数据后清除相应 `cryptid`。
- 成功解密后才生成 IPA；扩展/插件仍加密时给出警告（184），权限被系统拒绝或没有解密到任何区域时返回明确失败，不输出伪造 IPA。

**平台限制：** `task_for_pid` 权限取决于系统版本、运行环境及目标进程状态。实现不能绕过系统未授予的任务端口权限；用户需先启动目标应用并保持运行。

### 3. 重打包与多开

- 修改 `CFBundleDisplayName` / `CFBundleName`、主 Bundle ID 和版本字段。
- 更新主应用、嵌套扩展及子 bundle 中与原 Bundle ID 同前缀的标识。
- 可选择移除 URL Schemes、Widget 扩展、嵌套 Watch App、`Payload` 下独立 Watch App 和 WatchKit 支持目录。
- 移除旧 provisioning profile / 代码签名资源后重新创建标准 IPA，并回流至现有安装确认与签名流程。
- 重打包输出为新文件，不覆盖源 IPA。
- 按用户明确要求，本轮不做图标替换。

### 4. 包管理、导入下载与解压

- 本地包管理支持 IPA、TIPA、TAR、ZIP、DEB；支持导入、分享、删除、导出已安装应用、直接 HTTPS 文件 URL 下载。
- ZIP 如果通过归档安全检查，并同时存在合法 `Payload/*.app/Info.plist` 和其声明的主可执行文件，会提供直接安装、修改后安装和分享 IPA 的动作；其他 ZIP 仍可以安全解压和扫描动态库。
- DEB 解包先解析外层 `ar`，再提取 `data.tar*`；ZIP/TAR 解压使用 libarchive 路径安全约束。IPA 打包保留符号链接，以兼容常见 Framework 结构。
- 本轮按要求不加入软件源/仓库订阅功能。

### 5. RootHelper 应用维护

新增 `clear-cache`、`clear-cache-all`、`clear-data` 和 `inject-dylib` 命令：

- 缓存清理只清除 `Library/Caches` 内容。
- 数据清理会在执行前检查主可执行文件 Entitlements 和容器标识。声明不使用标准容器的应用会被拒绝；普通应用则删除旧数据容器并通过 MobileContainerManager 请求创建空容器。
- 多应用缓存清理跳过 TrollStore 自身和受保护/系统应用。
- 对目标 Bundle ID、容器根路径、解析后的符号链接路径和注入 payload 的所有者路径做校验。注入目标限制在用户应用目录，payload 仅能来自 TrollStore 的 `Documents/Packages` 或已打包的 `TweakPresets`，拒绝系统应用。

### 6. Tweak 注入和内置预设

- 利用本轮新版 ldid 的 `--iosinject` 内置 Mach-O load-command 修改器；不再要求外部运行 `insert_dylib` 进程。
- 支持 `.dylib`、`.framework`，并可通过安全解压 `.zip` / `.deb` 后选择动态库。
- 注入完成后运行 ldid 内部校验及 TrollStore 签名/CoreTrust 处理。注入会修改已安装应用，应保留原始 IPA 以便恢复。
- 提供 AppLock 源码预设：应用内认证覆盖层，支持设备密码/生物识别。
- 提供 BackgroundAssist 源码预设：申请 iOS 授予的有限后台任务时长，并按过期/回前台结束。
- **没有虚构“禁止卸载”或“无限真后台” dylib。** 应用内 dylib 无法阻止 SpringBoard 卸载该应用；这需要 SpringBoard 进程中的越狱 tweak 或受监管设备策略。应用内的标准后台任务 API 也不能承诺无限执行。`TweakPresets/PreventUninstall/README.md` 记录了这一技术边界。
- Theos 在 macOS 上构建预设后，根 Makefile 会把编译出的 dylib 复制至应用 `Resources/TweakPresets`；当前交付环境没有 Theos/iOS SDK，因此只包含可构建源码，不包含伪造的预编译预设 dylib。

### 7. 安装与签名链路

- 保留用户默认安装方式，未添加智能/自动安装模式。
- 安装会话保存 IPA 路径、Force、installd/Custom、一次性 Entitlements 文件和开关、stealth 状态及累计日志。
- 普通失败提供 Retry、切换另一种安装方式、Copy Debug Log 和 Cancel；切换方式前请求 RootHelper 做受限的安装残留清理；对同一错误设置重试次数限制。
- 171 保留 Force 流程；182 / 184 走非致命提示；173 提供设置入口；installd 失败以 189 返回，由用户确认是否尝试 Custom，不静默切换。
- `TSBundlePreSigned=YES` 可跳过常规 ad-hoc 重签，但有自定义 Entitlements 覆盖时不会跳过；RootHelper 仍执行后续 CoreTrust 处理。
- Entitlements 编辑器提供原始只读层、视觉/XML 覆盖层、常用预设、合并预览和安装前的新增/覆盖摘要。RootHelper 合并覆盖层与原始字典，未指定键保留。

## 新版 ldid

- 包内 `bin/ldid` 为用户于 **2026-10-27** 提供的预编译 arm64 iOS 设备二进制，未重编译、未改写 Mach-O 元数据。
- SHA-256：`42b56d62bc5e2371144cff41aebd722e6172c19d4d9987b09e4b030901d903dc`
- `LC_BUILD_VERSION`：平台 iOS，最低版本 **16.0.0**，SDK **16.4.0**。
- `ldid.cpp`、`ldid.hpp` 和 `ldid-reference/ldid-inprocess-selfcontained.zip` 是查看接口/实现的参考副本；构建使用提供的完整二进制。
- 不能通过只修改 `minos` 字段来假装兼容 iOS 14/15。当前二进制的最低版本标记为 16.0，因此依赖此二进制的签名/注入操作在 iOS 14/15 **未经验证且不能保证工作**。要支持这些系统，需要提供或实际构建一个对旧系统兼容的 ldid 二进制，并在目标系统上验证。

## 验证结果

在当前可用环境执行：

- `python3 Scripts/validate_project.py`：通过；72 项必需文件存在，6 个 plist、4 个 strings 资源通过校验，419 个简体中文键匹配，其中 414 个值包含中文字符。
- `python3 Scripts/validate_macho.py bin/ldid`：通过，确认是 arm64 iOS 设备可执行文件。
- `sha256sum -c bin/ldid.sha256`：通过，二进制哈希一致。
- `bash -n Scripts/bootstrap_choma.sh`：通过。
- `python3 -m py_compile Scripts/*.py`：通过。
- 归档验证将在最终 ZIP 写出后再次执行。

## 尚未能宣称完成的验证

当前环境没有 `xcodebuild`、iPhoneOS SDK 或 Theos，无法做真正的 Objective-C/Objective-C++ 编译、签名验证、安装和真机测试。需要在 macOS 按 README 中的 Makefile 执行构建，并用真实 iOS 设备/版本对安装方式重试、Entitlements、解密、重打包、注入、图标缓存和容器恢复做端到端测试。

此外，本轮没有提供实时 GitHub 仓库地址或分支，因此源码基础是本会话可用的完整本地 TrollStore 快照（2026-10-25），再合入用户更新的 ldid 二进制和参考源码。它不是声称已从未指定的线上仓库克隆的最新 commit。

## 参考实现与公开资料

- TrollStore: https://github.com/opa334/TrollStore
- TrollFools（ChOma、Mach-O 注入，公开 README 中列出了支持范围和限制）: https://github.com/Lessica/TrollFools
- TrollDecryptor（目标应用需运行，导出解密后的 IPA）: https://github.com/wh1te4ever/trolldecryptor
- iOSDumpzzz 公开的改版发布/使用信息仅用于功能和 UI 方向参考；此包没有把未公开/无法核验的私有源码冒充为上游实现。
