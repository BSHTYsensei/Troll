#!/usr/bin/env python3
"""Install a freshly rebuilt TrollStore tar and refresh its pinned payload hashes."""
from __future__ import annotations

import argparse
import hashlib
import plistlib
import re
import shutil
import tarfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent.parent
VALIDATOR = ROOT / "Scripts" / "validate_custom_payload.py"
SWIFT_VALIDATOR = ROOT / "TrollInstallerX" / "Installer" / "Extract.swift"
RESOURCE = ROOT / "TrollInstallerX" / "Resources" / "TrollStore.tar"
MANIFEST = ROOT / "PAYLOAD-SHA256.txt"
REQUIRED = (
    "TrollStore.app/Info.plist",
    "TrollStore.app/TrollStore",
    "TrollStore.app/PersistenceHelper",
    "TrollStore.app/trollstorehelper",
    "TrollStore.app/ldid-bootstrap/ldid",
)
EXECUTABLES = REQUIRED[1:]
EXPECTED_BUNDLE_ID = "com.opa334.TrollStore"
EXPECTED_VERSION = "2.1.1"


def fail(message: str) -> None:
    raise SystemExit(f"[FAIL] {message}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path, help="fresh TrollStore.tar created by make assemble_trollstore")
    parser.add_argument("--no-copy", action="store_true", help="update pins only; do not replace the installer resource")
    args = parser.parse_args()
    source = args.archive.resolve()
    if not source.is_file():
        fail(f"archive not found: {source}")

    hashes: dict[str, str] = {}
    try:
        with tarfile.open(source, "r:gz") as tf:
            members = tf.getmembers()
            names = [m.name.rstrip("/") for m in members]
            if len(names) != len(set(names)):
                fail("archive contains duplicate member paths")
            by_name = {m.name.rstrip("/"): m for m in members}
            for member in members:
                p = PurePosixPath(member.name)
                if p.is_absolute() or ".." in p.parts or not (member.isdir() or member.isfile()):
                    fail(f"unsafe or unsupported archive member: {member.name}")
                if member.name != "TrollStore.app" and not member.name.startswith("TrollStore.app/"):
                    fail(f"unexpected archive root: {member.name}")
            missing = [name for name in REQUIRED if name not in by_name]
            if missing:
                fail("missing required members: " + ", ".join(missing))
            info_stream = tf.extractfile(by_name[REQUIRED[0]])
            if info_stream is None:
                fail("cannot read TrollStore Info.plist")
            info = plistlib.load(info_stream)
            if info.get("CFBundleIdentifier") != EXPECTED_BUNDLE_ID or info.get("CFBundleVersion") != EXPECTED_VERSION:
                fail(f"expected {EXPECTED_BUNDLE_ID} version {EXPECTED_VERSION}, got {info.get('CFBundleIdentifier')} {info.get('CFBundleVersion')}")
            for name in EXECUTABLES:
                member = by_name[name]
                if not member.isfile() or member.mode & 0o111 == 0:
                    fail(f"not an executable regular file: {name}")
                stream = tf.extractfile(member)
                if stream is None:
                    fail(f"cannot read executable: {name}")
                data = stream.read()
                if len(data) < 8 or data[:4] != bytes.fromhex("cffaedfe") or int.from_bytes(data[4:8], "little", signed=True) != 0x0100000C:
                    fail(f"expected thin arm64 Mach-O executable: {name}")
                hashes[name] = hashlib.sha256(data).hexdigest()
    except (OSError, tarfile.TarError, plistlib.InvalidFileException) as exc:
        fail(f"invalid TrollStore gzip tar: {exc}")

    if not args.no_copy:
        if source != RESOURCE.resolve():
            shutil.copy2(source, RESOURCE)

    validator_text = VALIDATOR.read_text()
    for name, digest in hashes.items():
        escaped = re.escape(name)
        pattern = rf'("{escaped}"\s*:\s*")[0-9a-f]{{64}}(")'
        validator_text, count = re.subn(pattern, rf'\g<1>{digest}\g<2>', validator_text)
        if count != 1:
            fail(f"could not update exactly one pinned hash for {name}")
    VALIDATOR.write_text(validator_text)

    swift_text = SWIFT_VALIDATOR.read_text()
    swift_names = {
        "TrollStore.app/TrollStore": "TrollStore",
        "TrollStore.app/PersistenceHelper": "PersistenceHelper",
        "TrollStore.app/trollstorehelper": "trollstorehelper",
        "TrollStore.app/ldid-bootstrap/ldid": "ldid-bootstrap/ldid",
    }
    for archive_name, swift_name in swift_names.items():
        escaped = re.escape(swift_name)
        pattern = rf'("{escaped}"\s*:\s*")[0-9a-f]{{64}}(")'
        swift_text, count = re.subn(pattern, rf'\g<1>{hashes[archive_name]}\g<2>', swift_text)
        if count != 1:
            fail(f"could not update exactly one runtime SHA-256 pin for {swift_name}")
    SWIFT_VALIDATOR.write_text(swift_text)

    tar_digest = hashlib.sha256(RESOURCE.read_bytes() if not args.no_copy else source.read_bytes()).hexdigest()
    lines = [f"TrollStore.tar SHA-256  {tar_digest}", "", "Embedded executable payload SHA-256:"]
    for name in EXECUTABLES:
        lines.append(f"{hashes[name]}  {name}")
    MANIFEST.write_text("\n".join(lines) + "\n")
    print("[OK] updated custom TrollStore archive and SHA-256 pins")
    for name in EXECUTABLES:
        print(f"  {hashes[name]}  {name}")


if __name__ == "__main__":
    main()
