#!/usr/bin/env python3
"""Validate the custom TrollStore payload embedded in the installer."""
from __future__ import annotations

import hashlib
import plistlib
import sys
import tarfile
from pathlib import Path, PurePosixPath

EXPECTED_BUNDLE_ID = "com.opa334.TrollStore"
EXPECTED_VERSION = "2.1.1"
EXPECTED_SHA256 = {
    "TrollStore.app/TrollStore": "49adf6d03a9a831aeec0cf2b67aadf1e743976b4b948c7a990447e2387f09188",
    "TrollStore.app/PersistenceHelper": "d52e706d60af59d8f1bfeb297d9cdb16ede0673034da243bb97b6a760715c5b0",
    "TrollStore.app/trollstorehelper": "82c83ce9d71b32a1f443d0c6faf1d4334889280f2be5c9f8a686f25e8179dee3",
    "TrollStore.app/ldid-bootstrap/ldid": "79af6331b7cd4c6ebf3f89284ce049450104e4a56dc5285017e83fc060901868",
}
REQUIRED = (
    "TrollStore.app/Info.plist",
    "TrollStore.app/TrollStore",
    "TrollStore.app/PersistenceHelper",
    "TrollStore.app/trollstorehelper",
    "TrollStore.app/ldid-bootstrap/ldid",
)
EXECUTABLES = (
    "TrollStore.app/TrollStore",
    "TrollStore.app/PersistenceHelper",
    "TrollStore.app/trollstorehelper",
    "TrollStore.app/ldid-bootstrap/ldid",
)


def fail(message: str) -> None:
    raise SystemExit(f"[FAIL] {message}")


def main() -> None:
    archive = Path(sys.argv[1] if len(sys.argv) > 1 else "Resources/TrollStore.tar")
    if not archive.is_file():
        fail(f"payload not found: {archive}")

    try:
        with tarfile.open(archive, mode="r:gz") as tf:
            members = tf.getmembers()
            normalized_names = [m.name.rstrip("/") for m in members]
            names = set(normalized_names)
            if len(names) != len(normalized_names):
                fail("archive contains duplicate member paths")
            for member in members:
                p = PurePosixPath(member.name)
                if p.is_absolute() or ".." in p.parts:
                    fail(f"unsafe archive path: {member.name}")
                if not (member.name == "TrollStore.app" or member.name.startswith("TrollStore.app/")):
                    fail(f"unexpected archive root: {member.name}")
                if not (member.isdir() or member.isfile()):
                    fail(f"unsupported link or special archive entry: {member.name}")
            missing = [name for name in REQUIRED if name not in names]
            if missing:
                fail("missing required payload entries: " + ", ".join(missing))

            info_member = tf.getmember("TrollStore.app/Info.plist")
            info_stream = tf.extractfile(info_member)
            if info_stream is None:
                fail("cannot read Info.plist")
            info = plistlib.load(info_stream)
            if info.get("CFBundleIdentifier") != EXPECTED_BUNDLE_ID:
                fail(f"unexpected TrollStore bundle ID: {info.get('CFBundleIdentifier')!r}")
            if info.get("CFBundleExecutable") != "TrollStore":
                fail(f"unexpected TrollStore executable: {info.get('CFBundleExecutable')!r}")
            if info.get("CFBundleVersion") != EXPECTED_VERSION:
                fail(f"expected version {EXPECTED_VERSION}, got {info.get('CFBundleVersion')!r}")

            by_name = {m.name: m for m in members}
            for name in EXECUTABLES:
                mode = by_name[name].mode
                if mode & 0o111 == 0:
                    fail(f"missing executable permission in tar: {name}")
                stream = tf.extractfile(by_name[name])
                if stream is None:
                    fail(f"cannot read executable: {name}")
                header = stream.read(8)
                if header[:4] != bytes.fromhex("cffaedfe"):
                    fail(f"not a 64-bit Mach-O executable: {name}")
                cpu_type = int.from_bytes(header[4:8], "little", signed=True)
                if cpu_type != 0x0100000C:
                    fail(f"expected arm64 Mach-O, got cputype=0x{cpu_type & 0xffffffff:08x}: {name}")

            for name, expected_digest in EXPECTED_SHA256.items():
                member = tf.extractfile(name)
                if member is None:
                    fail(f"cannot read bundled component: {name}")
                digest = hashlib.sha256(member.read()).hexdigest()
                if digest != expected_digest:
                    fail(f"custom component hash mismatch for {name}: {digest}")
    except (tarfile.TarError, OSError, plistlib.InvalidFileException) as exc:
        fail(f"invalid gzip tar payload: {exc}")

    project_root = archive.resolve().parent.parent
    entitlements_path = project_root / "Resources" / "ents.plist"
    if entitlements_path.is_file():
        with entitlements_path.open("rb") as stream:
            entitlements = plistlib.load(stream)
        app_identifier = entitlements.get("application-identifier", "")
        if not app_identifier.endswith(".com.trollstore.custominstaller"):
            fail(f"installer application-identifier does not match custom bundle ID: {app_identifier!r}")

    print(f"[OK] {archive}: TrollStore {EXPECTED_VERSION}, arm64 app/helper binaries, all four custom component SHA-256 hashes verified")


if __name__ == "__main__":
    main()
