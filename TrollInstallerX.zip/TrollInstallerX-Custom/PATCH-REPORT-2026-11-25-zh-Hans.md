# 巨魔安装器 / TrollStore 修复报告

日期：2026-11-25

## TrollStore / RootHelper

1. 修正 `safeExecutablePathForBundle` 的根目录判断：顶层 App Bundle 与 `appRoot` 相同是合法情形，不再因严格的“子路径”判断被拒绝；嵌套 Bundle 仍须位于待签名 App 根目录内。
2. 允许嵌套 Bundle 的可执行文件符号链接指向同一个暂存 App 根目录内的普通文件；普通非链接可执行文件必须留在自己的 Bundle 内。越界路径、非法 `CFBundleExecutable`、非普通文件仍拒绝。
3. 持久化助手安装从宿主 App 自己的 `Info.plist` 解析 `CFBundleExecutable`，不再完全依赖 LaunchServices 的 `canonicalExecutablePath`。
4. 对系统宿主的原可执行文件目录项（包括原始符号链接）实施备份、替换和失败恢复；卸载流程也使用相同目录项解析，避免恢复符号链接时把实际目标路径误认为 Bundle 外路径。
5. PersistenceHelper 以 `33:33`、`0755` 安装；`trollstorehelper` 以 `0:0`、`0755` 安装。增加对应的源代码回归检查。

## 证书导入与签名

1. P12 导入对空文件、错误密码、损坏/非 PKCS#12 文件和缺少有效 identity 分别给出错误。
2. PEM 文本输入处理 UTF-8 BOM、CRLF/CR；支持 `PRIVATE KEY`、`ENCRYPTED PRIVATE KEY`、`RSA PRIVATE KEY`、`EC PRIVATE KEY` 和 `DSA PRIVATE KEY` 区块，并兼容传统加密 PEM 的 `Proc-Type` / `DEK-Info` 头。
3. 证书导入同时接受 X.509 PEM 和 DER，并把 DER 证书规范化写成 PEM 供 ldid 使用。
4. 文件选择器加入 `public.item`、`public.content`、`public.data`、文本和扩展名 UTType；读取时使用 security-scoped URL 与 `NSFileCoordinator`，对不支持协调读取的 File Provider 仅做有大小限制的本地直接读取回退。此项针对截图及反馈中的“无法知道文件内容”/无法识别内容类型的问题。
5. 文件不可读时提示将文件下载到“我的 iPhone”；PEM 私钥读取失败会清空待导入证书状态，避免下一次选择沿用旧证书。
6. PEM 证书和私钥是否匹配由 ldid 在实际签名时通过 `X509_check_private_key` 检查；导入器不会把“私钥区块格式正确”误报为“证书与私钥已匹配”。
7. 错误码现在分开表达：`196` 为可执行文件路径缺失/越界，`197` 为证书与私钥不匹配，`198` 为加密私钥或 PKCS#12 身份解密失败；原 `176` 继续表示 Bundle ID / Info.plist 元数据问题，避免把签名路径错误显示成 Info.plist 错误。
8. ldid 的证书与私钥匹配检查位于实际签名阶段；P12 密码错误与损坏/非 PKCS#12 输入在导入阶段分别给出诊断。若 ldid 输出无法可靠分类，仍保留通用签名失败，不伪造更具体原因。

## UI

1. 软件包列表替换默认 Subtitle Cell，使用图标、两行文件名、文件类型/大小及固定布局约束，缓解截图中标题只显示成 `D...` 的裁切问题。
2. 持久化助手列表使用卡片布局，显示宿主 Bundle ID、选择说明和可选跳过入口。
3. 保留之前修复的设置存储回退、空日志保护、主线程日志更新及安装状态防重入。

## 汇编评估

没有新增汇编。当前问题的主要瓶颈和故障来自路径校验、LaunchServices、文件提供器、Security.framework、Keychain 和文件系统操作，不是可通过手写汇编优化的计算热点。没有可复现的 CPU 热点或基准数据证明汇编会带来收益；引入它反而会增加架构和维护风险。

## 已执行的验证

- `Scripts/validate_project.py`
- `Scripts/test_custom_install_signing_regressions.py`
- `Scripts/validate_custom_payload.py`
- `Scripts/test_ui_crash_guards.py`
- `Scripts/test_custom_installer_regressions.py`
- 全部 TrollInstallerX Swift 文件通过 `swiftc -frontend -parse`
- Python 脚本 `py_compile`、构建脚本 `bash -n`
- 内置 TrollStore.tar 目录结构、arm64 Mach-O、可执行权限和四个核心组件 SHA-256
- 重建归档的更新脚本会同步刷新 Python 构建期校验、Swift `Extract.swift` 运行时哈希锁定及 `PAYLOAD-SHA256.txt`

## 仍需 macOS / iPhone 验证的事项

当前工作环境没有 Xcode、iOS SDK 或可用于执行漏洞利用的 iPhone，因此没有声称已完成 iOS 编译或真机安装验证。尤其要注意：**TrollStore 源码中的 RootHelper 修复必须通过 Theos 重新构建并打入新的 `TrollStore.tar`，再由安装器打包。** 安装器 ZIP 内当前随附归档是原始自定义组件，不能代表已编译的新 RootHelper。

建议先在 TrollStore 源码仓库执行 `make assemble_trollstore`，得到 `_build/TrollStore.tar`；然后在安装器源码目录执行：

```bash
TROLLSTORE_ARCHIVE="/绝对路径/TrollStore/_build/TrollStore.tar" ./build.sh
```

该流程会复制新归档、更新四个核心组件的哈希锁定和 `PAYLOAD-SHA256.txt`，运行归档校验、UI 回归测试，再调用 Xcode 构建 IPA。

另外，用户提供的内置 iOS `ldid` Mach-O 声明最低系统版本为 iOS 16.0。不能仅修改 Mach-O load command 把它伪装成 iOS 14/15 兼容；若要支持 iOS 14/15 的证书 CMS 签名，需要使用对应 SDK 重新构建 ldid 并执行 API/真机验证。
