<div align="center">
    <h1>巨魔安装器（自定义构建）</h1>
    <img src="Resources/Icon.png" width="125" height="125" />
    <p>基于 TrollInstallerX · 内置用户提供的 TrollStore 2.1.1 组件</p>
</div>

## 定制内容

本项目是基于 TrollInstallerX 源码制作的定制分支。保留原项目的设备检测、kfd / dmaFail 安装路径和利用代码，并将安装资源替换为本项目提供的 `TrollStore.tar` 组件。

- **TrollStore 资源**：使用用户提供的 `TrollStore.tar` 内容，并重新打包为标准 gzip tar。归档路径为 `TrollStore.app/...`，与安装器及 `trollstorehelper` 的实际查找路径一致。
- **自定义 ldid**：完整保留 `TrollStore.app/ldid-bootstrap/ldid`。其 SHA-256 为 `79af6331b7cd4c6ebf3f89284ce049450104e4a56dc5285017e83fc060901868`，与用户保存的 `TrollStore/bin/ldid` 相同。安装器不会下载或覆盖成上游 ldid。
- **自定义持久化助手**：`PersistenceHelper` 和 `trollstorehelper` 均来自用户提供的归档。安装时使用同一归档中的 helper 与 PersistenceHelper，并通过 `install-persistence-helper` 命令传入组件路径。
- **去除上游覆盖逻辑**：移除 TrollHelperOTA 页面及自动拉取上游 TrollStore 发布包的逻辑，避免升级流程静默替换为普通版本。
- **临时文件隔离**：直接安装只操作 `/private/preboot/tmp/TrollInstallerCustom`；间接安装只操作应用 Documents 下的 `TrollInstallerCustom` 子目录。不会删除整个 `/private/preboot/tmp`，也不会清理 Documents 根目录中的同名用户文件。
- **安装状态**：安装失败会返回失败，不再将 helper 安装失败或 TrollStore 安装失败误报为成功。持久化助手选择使用 Swift async continuation，不再主线程忙等。
- **子进程输出**：`run_binary` 在等待进程退出前持续读取 stderr，避免子进程写满管道后双方互相等待。

## 支持范围与限制

设备支持判断和漏洞利用范围沿用原 TrollInstallerX 的实现，没有新增利用或扩大支持范围。基础支持范围为 iOS 14.0–16.6.1；源码还保留了极少数 iOS 17.0 Beta build 的白名单。具体安装方式仍受 SoC、arm64 / arm64e、系统小版本和设备限制影响；A8、A15、A16、M2 的限制仍然有效。

部分系统版本需要取得对应 kernelcache。此定制分支移除了 TrollStore 本体更新和 TrollHelperOTA 网络路径，但**没有移除 kernelcache 获取逻辑**；未内置缓存且设备无法通过本地路径取得时，安装过程仍可能需要网络。

## 打包布局

`Resources/TrollStore.tar` 必须为 gzip tar，并且归档根目录必须是 `TrollStore.app/`。其中至少包含：

```text
TrollStore.app/
├── Info.plist
├── TrollStore
├── PersistenceHelper
├── trollstorehelper
└── ldid-bootstrap/
    └── ldid
```

构建前会运行 `Scripts/validate_custom_payload.py`，检查归档路径、Bundle ID、版本号、arm64 Mach-O 类型、可执行权限，以及 TrollStore、PersistenceHelper、trollstorehelper、ldid 四个组件各自的 SHA-256。

## 构建

在 macOS 上使用包含 iOS SDK 的 Xcode，并准备宿主机可执行的 `ldid`：

```bash
./build.sh
```

构建脚本最后使用宿主 macOS 上的 `ldid` 为安装器写入 entitlements；这与包内供 TrollStore 使用的 iOS `ldid-bootstrap/ldid` 是两份不同用途的程序。也可以通过 `LDID_BIN=/绝对路径/ldid` 指定宿主机签名工具。成功后会生成 `TrollInstallerX.ipa`。

本源码包在 Linux 环境中完成归档、哈希、Swift 语法和 plist 静态检查；当前环境没有 Xcode / iOS SDK，因此未执行 Xcode 编译、真实设备漏洞利用或安装测试。

## 上游致谢与许可

本项目基于 [Alfie CG 的 TrollInstallerX](https://github.com/alfiecg24/TrollInstallerX) 修改。保留原项目 `LICENSE.md` 与 `CreditsView` 中的上游鸣谢；kfd、dmaFail、kernel patchfinder、MacDirtyCow 和其他组件仍归各自作者所有。请在再分发时一并保留许可证和相应署名。


## 运行时崩溃修复（2026-11-24）

- 修复安装页面日志列表为空时 `last!` 强制解包导致的首次布局崩溃。
- 设置页不再在 `@AppStorage` 初始化阶段创建自定义 Defaults suite；统一使用安全的 `UserDefaults.standard`，并尝试迁移旧设置。
- 日志模型的 UI 更新统一派发到主队列，删除后台线程触发 UIKit 触觉反馈的路径。
- 安装状态监听只在进入安装状态时启动任务，不会在状态退出时重复执行安装。
- 日志页面不再对 stdout 进行生命周期不稳定的 `dup2` 重定向；详细模式改为紧凑显示结构化安装日志。
- 新增 `Scripts/test_ui_crash_guards.py`，并接入 `build.sh` 与 GitHub Actions 的验证阶段。

本次在 Linux 环境完成 Swift 源码语法解析及静态回归检查；实际 iOS 设备运行和 Xcode 构建仍需在 macOS / iPhone 环境验证。
