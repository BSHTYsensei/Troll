//
//  SettingsView.swift
//  TrollInstallerX
//

import SwiftUI

struct SettingsView: View {
    let device: Device

    @State private var exploitFlavour = "landa"
    @State private var verbose = false
    @State private var preferencesLoaded = false

    private var availableExploitFlavours: [String] {
        var values = ["landa"]
        if smith.supports(device) { values.append("smith") }
        if physpuppet.supports(device) { values.append("physpuppet") }
        return values
    }

    var body: some View {
        VStack(spacing: 10) {
            Button(action: {
                let docsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                let cacheURL = docsURL.appendingPathComponent("kernelcache", isDirectory: false)
                do {
                    if FileManager.default.fileExists(atPath: cacheURL.path) {
                        try FileManager.default.removeItem(at: cacheURL)
                    }
                } catch {
                    Logger.log("清理内核缓存失败：\(error.localizedDescription)", type: .error)
                }
            }, label: {
                ZStack {
                    RoundedRectangle(cornerRadius: 10)
                        .frame(maxWidth: 225)
                        .frame(maxHeight: 40)
                        .foregroundColor(.white.opacity(0.2))
                        .shadow(radius: 10)
                    Text("清理内核缓存")
                        .font(.system(size: 17, weight: .semibold, design: .rounded))
                        .foregroundColor(.white)
                        .padding()
                }
            })
            .padding()

            if availableExploitFlavours.count > 1 {
                Picker("内核漏洞利用方式", selection: $exploitFlavour) {
                    ForEach(availableExploitFlavours, id: \.self) { flavour in
                        Text(flavour).tag(flavour)
                    }
                }
                .pickerStyle(.segmented)
                .colorMultiply(.white)
                .padding()
            }

            Toggle(isOn: $verbose) {
                Text("详细日志")
                    .font(.system(size: 17, weight: .regular, design: .rounded))
                    .foregroundColor(.white)
            }
            .padding()
        }
        .onAppear {
            let defaults = TIXDefaults()
            let savedFlavour = defaults.string(forKey: "exploitFlavour") ?? ""
            exploitFlavour = availableExploitFlavours.contains(savedFlavour)
                ? savedFlavour
                : (physpuppet.supports(device) ? "physpuppet" : "landa")
            verbose = defaults.bool(forKey: "verbose")
            preferencesLoaded = true
        }
        .onChange(of: exploitFlavour) { newValue in
            guard preferencesLoaded else { return }
            TIXDefaults().set(newValue, forKey: "exploitFlavour")
        }
        .onChange(of: verbose) { newValue in
            guard preferencesLoaded else { return }
            TIXDefaults().set(newValue, forKey: "verbose")
        }
    }
}
