import SwiftUI

struct LogView: View {
    @StateObject private var logger = Logger.shared
    @Binding var installationFinished: Bool
    @State private var verbose = false

    var body: some View {
        GeometryReader { geometry in
            ScrollViewReader { proxy in
                ScrollView {
                    VStack(alignment: .leading, spacing: 4) {
                        ForEach(logger.logItems) { log in
                            HStack(alignment: .top, spacing: 6) {
                                Image(systemName: log.image)
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 12, height: 12)
                                    .padding(.top, 2)
                                Text(log.message)
                                    .font(.system(
                                        size: verbose ? 10 : 13,
                                        weight: .regular,
                                        design: verbose ? .monospaced : .rounded
                                    ))
                                    .multilineTextAlignment(.leading)
                                Spacer(minLength: 0)
                            }
                            .foregroundColor(log.colour)
                            .padding(.vertical, 3)
                            .id(log.id)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        }

                        if installationFinished {
                            Text("安装流程已结束")
                                .font(.system(size: 12, weight: .semibold, design: .rounded))
                                .foregroundColor(.white.opacity(0.7))
                                .padding(.top, 6)
                                .id("installation-finished")
                        }
                    }
                    .frame(minHeight: geometry.size.height, alignment: .bottomLeading)
                    .padding(.vertical, 4)
                }
                .onAppear {
                    verbose = TIXDefaults().bool(forKey: "verbose")
                    scrollToLatest(using: proxy)
                }
                .onChange(of: logger.logItems.count) { _ in
                    scrollToLatest(using: proxy)
                }
                .onChange(of: installationFinished) { finished in
                    if finished {
                        DispatchQueue.main.async {
                            withAnimation { proxy.scrollTo("installation-finished", anchor: .bottom) }
                        }
                    }
                }
                .contextMenu {
                    Button {
                        UIPasteboard.general.string = logger.logString
                    } label: {
                        Label("复制日志", systemImage: "doc.on.doc")
                    }
                }
            }
        }
    }

    private func scrollToLatest(using proxy: ScrollViewProxy) {
        // SwiftUI may report the first geometry change before the first log is
        // appended. Never force-unwrap last on an empty collection.
        guard let lastID = logger.logItems.last?.id else { return }
        DispatchQueue.main.async {
            withAnimation { proxy.scrollTo(lastID, anchor: .bottom) }
        }
    }
}
