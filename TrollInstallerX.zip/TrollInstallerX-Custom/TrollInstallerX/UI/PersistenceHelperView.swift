//
//  PersistenceHelperView.swift
//  TrollInstallerX
//

import SwiftUI

@MainActor
struct PersistenceHelperView: View {
    @Binding var isShowingHelperAlert: Bool
    let allowNoPersistenceHelper: Bool

    var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                VStack(spacing: 8) {
                    Image(systemName: "checkmark.shield.fill")
                        .font(.system(size: 34, weight: .medium))
                        .foregroundColor(.accentColor)
                        .accessibilityHidden(true)
                    Text("选择持久化助手")
                        .font(.system(size: 23, weight: .semibold, design: .rounded))
                        .foregroundColor(.primary)
                    Text(allowNoPersistenceHelper
                         ? "选择一个系统应用作为持久化助手宿主。该应用的原有功能会被替换，请选择不常用的应用。Apple“快捷指令”不会列入候选；也可以选择跳过。"
                         : "选择一个系统应用作为持久化助手宿主。该应用的原有功能会被替换，请选择不常用的应用。Apple“快捷指令”不会列入候选。")
                        .font(.system(size: 14, weight: .regular, design: .rounded))
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .fixedSize(horizontal: false, vertical: true)
                }
                .padding(.horizontal, 18)
                .padding(.top, 12)

                LazyVStack(spacing: 10) {
                    ForEach(persistenceHelperCandidates, id: \.self) { candidate in
                        Button {
                            TIXDefaults().setValue(candidate.bundleIdentifier, forKey: "persistenceHelper")
                            HelperAlert.shared.finishSelection(candidate.bundleIdentifier)
                            withAnimation(.easeOut(duration: 0.18)) { isShowingHelperAlert = false }
                        } label: {
                            HStack(spacing: 14) {
                                Group {
                                    if let image = candidate.icon {
                                        Image(uiImage: image).resizable().scaledToFit()
                                    } else {
                                        Image(systemName: "app.fill")
                                            .resizable().scaledToFit().padding(9)
                                            .foregroundColor(.accentColor)
                                    }
                                }
                                .frame(width: 42, height: 42)
                                .background(Color.primary.opacity(0.06))
                                .clipShape(RoundedRectangle(cornerRadius: 11, style: .continuous))

                                VStack(alignment: .leading, spacing: 3) {
                                    Text(candidate.displayName)
                                        .font(.system(size: 16, weight: .semibold, design: .rounded))
                                        .foregroundColor(.primary)
                                    Text(candidate.bundleIdentifier)
                                        .font(.system(size: 11, weight: .regular, design: .monospaced))
                                        .foregroundColor(.secondary)
                                        .lineLimit(1)
                                        .truncationMode(.middle)
                                }
                                Spacer(minLength: 4)
                                Image(systemName: "chevron.right")
                                    .font(.system(size: 12, weight: .semibold))
                                    .foregroundColor(.secondary.opacity(0.7))
                            }
                            .padding(.horizontal, 14)
                            .padding(.vertical, 11)
                            .background(Color(.secondarySystemBackground))
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                            .contentShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        }
                        .buttonStyle(.plain)
                    }

                    if allowNoPersistenceHelper {
                        Button {
                            TIXDefaults().setValue("", forKey: "persistenceHelper")
                            HelperAlert.shared.finishSelection("")
                            withAnimation(.easeOut(duration: 0.18)) { isShowingHelperAlert = false }
                        } label: {
                            Label("不安装持久化助手", systemImage: "xmark.circle")
                                .font(.system(size: 15, weight: .semibold, design: .rounded))
                                .foregroundColor(.red)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(15)
                                .background(Color(.secondarySystemBackground))
                                .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 20)
        }
        .background(Color(.systemBackground))
    }
}
