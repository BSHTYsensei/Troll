//
//  PersistenceHelperView.swift
//  TrollInstallerX
//
//  Created by Alfie on 30/03/2024.
//

import SwiftUI

@MainActor
struct PersistenceHelperView: View {
    @Binding var isShowingHelperAlert: Bool
    let allowNoPersistenceHelper: Bool
    var body: some View {
        ScrollView {
            VStack {
                Text("选择持久化助手")
                    .font(.system(size: 23, weight: .semibold, design: .rounded))
                    .foregroundColor(.white)
                Text(allowNoPersistenceHelper
                     ? "选择一个系统应用作为持久化助手宿主。该应用的原有功能会被替换，建议选择不常用的应用；Apple“快捷指令”不会列入候选。若不需要安装，可选择底部的跳过选项。"
                     : "当前设备需要通过持久化助手完成后续安装，因此必须选择一个系统应用。该应用的原有功能会被替换；Apple“快捷指令”不会列入候选。")
                    .font(.system(size: 16, weight: .regular, design: .rounded))
                    .foregroundColor(.white)
                    .multilineTextAlignment(.center)
            }
            .padding()
            VStack(spacing: 20) {
                ForEach(persistenceHelperCandidates, id: \.self) { candidate in
                    Button(action: {
                        TIXDefaults().setValue(candidate.bundleIdentifier, forKey: "persistenceHelper")
                        HelperAlert.shared.finishSelection(candidate.bundleIdentifier)
                        withAnimation { isShowingHelperAlert = false }
                    }, label: {
                        HStack {
                            if let image = candidate.icon {
                                Image(uiImage: image)
                                    .resizable()
                                    .frame(width: 44, height: 44)
                                    .cornerRadius(10)
                            } else {
//                                Image(systemName: "gear")
//                                    .resizable()
//                                    .frame(width: 44, height: 44)
//                                    .cornerRadius(10)
                            }
                            Text(candidate.displayName)
                                .font(.system(size: 20, weight: .regular, design: .rounded))
                                .foregroundColor(.white)
                                .padding(.leading)
                            Spacer()
                        }
                    })
                }
                if allowNoPersistenceHelper {
                    Divider()
                    Button(action: {
                        TIXDefaults().setValue("", forKey: "persistenceHelper")
                        HelperAlert.shared.finishSelection("")
                        withAnimation { isShowingHelperAlert = false }
                    }, label: {
                        HStack {
                            Image(systemName: "xmark.circle")
                                .resizable()
                                .frame(width: 44, height: 44)
                                .cornerRadius(10)
                                .foregroundColor(.red)
                            Text("不安装持久化助手")
                                .font(.system(size: 20, weight: .regular, design: .rounded))
                                .foregroundColor(.white)
                                .padding(.leading)
                            Spacer()
                        }
                    })
                    .padding(.bottom)
                }
            }
        }
    }
}
