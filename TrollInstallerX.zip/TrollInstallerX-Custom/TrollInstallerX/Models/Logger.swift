//
//  Logger.swift
//  TrollInstallerX
//

import SwiftUI

enum LogType {
    case success
    case warning
    case error
    case info
}

struct LogItem: Identifiable, Equatable {
    let message: String
    let type: LogType
    let date: Date = Date()
    var id = UUID()

    var image: String {
        switch type {
        case .success: return "checkmark"
        case .warning: return "exclamationmark.triangle"
        case .error: return "xmark"
        case .info: return "info"
        }
    }

    var colour: Color {
        switch type {
        case .success: return .init(hex: 0x08d604)
        case .warning: return .yellow
        case .error: return .red
        case .info: return .white
        }
    }
}

final class Logger: ObservableObject {
    @Published var logString: String = ""
    @Published var logItems: [LogItem] = []

    static let shared = Logger()

    static func log(_ logMessage: String, type: LogType? = .info) {
        let newItem = LogItem(message: logMessage, type: type ?? .info)
        print(logMessage)

        // Logger.log is also called by the non-UI installation path. Publish
        // ObservableObject changes only on the main queue; do not invoke UIKit
        // feedback generators from a worker thread.
        DispatchQueue.main.async {
            shared.logItems.append(newItem)
            shared.logString.append(logMessage + "\n")
        }
    }
}
