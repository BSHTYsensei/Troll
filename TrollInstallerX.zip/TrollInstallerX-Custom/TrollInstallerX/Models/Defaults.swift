//
//  Defaults.swift
//  TrollInstallerX
//
//  Preferences storage shared by SettingsView, LogView and the installer.
//

import Foundation

private enum TIXPreferenceStore {
    static let shared: UserDefaults = {
        let defaults = UserDefaults.standard

        // Migrate values from the previous custom suite when present. The old
        // implementation force-unwrapped UserDefaults(suiteName:), which can
        // return nil on a device where that suite is unavailable.
        let bundleIdentifier = Bundle.main.bundleIdentifier ?? "com.trollstore.custominstaller"
        let legacyPreferencesPath = FileManager.default
            .urls(for: .libraryDirectory, in: .userDomainMask)
            .first.map { $0.appendingPathComponent("Preferences/com.Alfie.TrollInstallerX.plist").path }

        var legacyStores = [UserDefaults]()
        if let store = UserDefaults(suiteName: bundleIdentifier) {
            legacyStores.append(store)
        }
        if let path = legacyPreferencesPath,
           let store = UserDefaults(suiteName: path) {
            legacyStores.append(store)
        }

        let keys = ["exploitFlavour", "verbose", "persistenceHelper"]
        for legacy in legacyStores {
            for key in keys where defaults.object(forKey: key) == nil {
                if let value = legacy.object(forKey: key) {
                    defaults.set(value, forKey: key)
                }
            }
        }

        defaults.register(defaults: ["verbose": false])
        return defaults
    }()
}

public func TIXDefaults() -> UserDefaults {
    TIXPreferenceStore.shared
}
