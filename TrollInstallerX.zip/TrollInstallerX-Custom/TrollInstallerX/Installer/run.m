#import <Foundation/Foundation.h>
#import <spawn.h>
#import <sys/stat.h>
#import <sys/wait.h>
#import <fcntl.h>
#import <unistd.h>
#import <errno.h>
#include <stdlib.h>
#include <string.h>

NSString* get_NSString_from_file(int fd)
{
    NSMutableData *data = [NSMutableData data];
    char buffer[4096];
    ssize_t count;
    if (fcntl(fd, F_GETFD) == -1 && errno == EBADF) return @"";
    while ((count = read(fd, buffer, sizeof(buffer))) > 0) {
        [data appendBytes:buffer length:(NSUInteger)count];
        if (data.length > 1024 * 1024) break;
    }
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] ?: @"";
}

// Runs a bundled helper as the current effective user. Drain stderr before waitpid
// so a verbose child cannot block forever on a full pipe.
int run_binary(NSString* path, NSArray* args, NSString** output)
{
    if (output) *output = @"";
    if (path.length == 0 || ![[NSFileManager defaultManager] fileExistsAtPath:path]) return ENOENT;

    NSMutableArray *arguments = [args mutableCopy] ?: [NSMutableArray array];
    [arguments insertObject:path.lastPathComponent atIndex:0];
    NSUInteger argumentCount = arguments.count;
    char **argv = calloc(argumentCount + 1, sizeof(char *));
    if (!argv) return ENOMEM;
    for (NSUInteger i = 0; i < argumentCount; i++) {
        const char *value = [[arguments objectAtIndex:i] UTF8String];
        argv[i] = strdup(value ?: "");
        if (!argv[i]) {
            for (NSUInteger j = 0; j < i; j++) free(argv[j]);
            free(argv);
            return ENOMEM;
        }
    }
    argv[argumentCount] = NULL;

    int pipeFD[2] = {-1, -1};
    if (pipe(pipeFD) != 0) {
        int error = errno;
        for (NSUInteger i = 0; i < argumentCount; i++) free(argv[i]);
        free(argv);
        return error;
    }

    posix_spawn_file_actions_t actions;
    int actionError = posix_spawn_file_actions_init(&actions);
    if (actionError != 0) {
        close(pipeFD[0]); close(pipeFD[1]);
        for (NSUInteger i = 0; i < argumentCount; i++) free(argv[i]);
        free(argv);
        return actionError;
    }
    actionError = posix_spawn_file_actions_adddup2(&actions, pipeFD[1], STDERR_FILENO);
    if (actionError == 0) actionError = posix_spawn_file_actions_addclose(&actions, pipeFD[0]);
    if (actionError == 0) actionError = posix_spawn_file_actions_addclose(&actions, pipeFD[1]);

    pid_t child = -1;
    int spawnError = actionError;
    if (spawnError == 0) spawnError = posix_spawn(&child, path.fileSystemRepresentation, &actions, NULL, argv, NULL);
    posix_spawn_file_actions_destroy(&actions);
    for (NSUInteger i = 0; i < argumentCount; i++) free(argv[i]);
    free(argv);
    close(pipeFD[1]);

    if (spawnError != 0) {
        close(pipeFD[0]);
        return spawnError;
    }

    NSMutableData *captured = [NSMutableData data];
    char buffer[8192];
    ssize_t bytesRead;
    for (;;) {
        bytesRead = read(pipeFD[0], buffer, sizeof(buffer));
        if (bytesRead > 0) {
            // Keep captured diagnostics bounded, but continue draining the pipe.
            NSUInteger remaining = captured.length < 1024 * 1024 ? (1024 * 1024 - captured.length) : 0;
            NSUInteger appendLength = MIN((NSUInteger)bytesRead, remaining);
            if (appendLength > 0) [captured appendBytes:buffer length:appendLength];
            continue;
        }
        if (bytesRead < 0 && errno == EINTR) continue;
        break;
    }
    int readError = (bytesRead < 0) ? errno : 0;
    close(pipeFD[0]);

    int status = 0;
    pid_t waited;
    do { waited = waitpid(child, &status, 0); } while (waited == -1 && errno == EINTR);
    if (waited == -1) return errno;
    if (output) *output = [[NSString alloc] initWithData:captured encoding:NSUTF8StringEncoding] ?: @"";
    if (readError != 0) NSLog(@"Failed reading helper diagnostics: %d", readError);
    if (WIFEXITED(status)) return WEXITSTATUS(status);
    if (WIFSIGNALED(status)) return 128 + WTERMSIG(status);
    return ECHILD;
}
