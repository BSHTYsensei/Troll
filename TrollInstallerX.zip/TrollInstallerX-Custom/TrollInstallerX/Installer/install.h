//
//  install.h
//  TrollInstallerX
//
//  Created by Alfie on 22/03/2024.
//

#ifndef install_h
#define install_h

#import <Foundation/Foundation.h>

NSString *find_path_for_app(NSString *appName, NSString *bundleIdentifier);
NSString *installer_last_error(void);
bool install_trollstore(NSString *tar);
bool install_persistence_helper(NSString *app);

#endif /* install_h */
