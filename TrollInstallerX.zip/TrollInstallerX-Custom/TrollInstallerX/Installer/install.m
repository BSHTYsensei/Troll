// Custom installer bridge to the bundled TrollStore helper.
#import <Foundation/Foundation.h>
#import <spawn.h>
#import <sys/stat.h>
#import <errno.h>
#import "run.h"

static NSString * const kInstallerHelperPath = @"/private/preboot/tmp/TrollInstallerCustom/trollstorehelper";
static NSString * const kInstallerPersistenceHelperPath = @"/private/preboot/tmp/TrollInstallerCustom/payload/TrollStore.app/PersistenceHelper";

static BOOL prepareRootHelper(void) {
    const char *path = kInstallerHelperPath.UTF8String;
    if (chmod(path, 0755) != 0) {
        NSLog(@"chmod trollstorehelper failed: %d", errno);
        return NO;
    }
    if (chown(path, 0, 0) != 0) {
        NSLog(@"chown trollstorehelper failed: %d", errno);
        return NO;
    }
    return YES;
}

bool install_trollstore(NSString *tar) {
    if (tar.length == 0 || ![[NSFileManager defaultManager] fileExistsAtPath:tar]) return false;
    if (!prepareRootHelper()) return false;
    NSString *output = nil;
    int ret = run_binary(kInstallerHelperPath, @[@"install-trollstore", tar], &output);
    printf("trollstorehelper output: %s\n", output.UTF8String ?: "");
    return ret == 0;
}

NSString *find_path_for_app(NSString *appName) {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSString *bundlePath = @"/var/containers/Bundle/Application";
    NSArray *bundleContents = [fileManager contentsOfDirectoryAtPath:bundlePath error:nil];
    for (NSString *bundle in bundleContents) {
        NSString *appPath = [[[bundlePath stringByAppendingPathComponent:bundle]
                              stringByAppendingPathComponent:appName] stringByAppendingString:@".app"];
        if ([fileManager fileExistsAtPath:appPath]) return appPath;
    }
    return nil;
}

bool install_persistence_helper(NSString *app) {
    if (app.length == 0 || ![[NSFileManager defaultManager] fileExistsAtPath:app] ||
        ![[NSFileManager defaultManager] fileExistsAtPath:kInstallerPersistenceHelperPath]) return false;
    if (!prepareRootHelper()) return false;
    NSString *output = nil;
    int ret = run_binary(kInstallerHelperPath,
                         @[@"install-persistence-helper", app, kInstallerPersistenceHelperPath, kInstallerHelperPath],
                         &output);
    printf("persistence helper returned %d\n", ret);
    printf("trollstorehelper output: %s\n", output.UTF8String ?: "");
    return ret == 0;
}
