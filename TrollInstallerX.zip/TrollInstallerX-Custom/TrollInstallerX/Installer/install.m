// Custom installer bridge to the bundled TrollStore helper.
#import <Foundation/Foundation.h>
#import <spawn.h>
#import <sys/stat.h>
#import <errno.h>
#import <limits.h>
#import <stdlib.h>
#import <string.h>
#import <unistd.h>
#import "run.h"

static NSString * const kInstallerHelperPath = @"/private/preboot/tmp/TrollInstallerCustom/trollstorehelper";
static NSString * const kInstallerPersistenceHelperPath = @"/private/preboot/tmp/TrollInstallerCustom/payload/TrollStore.app/PersistenceHelper";
static NSString *gInstallerLastError = nil;

NSString *installer_last_error(void) {
    return gInstallerLastError ?: @"No additional error information was returned.";
}

static void setInstallerError(NSString *message) {
    gInstallerLastError = [message copy] ?: @"Unknown installer error.";
}

static BOOL prepareRootHelper(void) {
    const char *path = kInstallerHelperPath.fileSystemRepresentation;
    if (chmod(path, 0755) != 0) {
        int saved = errno;
        setInstallerError([NSString stringWithFormat:@"chmod trollstorehelper failed: %@", [NSString stringWithUTF8String:strerror(saved)]]);
        return NO;
    }
    if (chown(path, 0, 0) != 0) {
        int saved = errno;
        setInstallerError([NSString stringWithFormat:@"chown trollstorehelper failed: %@", [NSString stringWithUTF8String:strerror(saved)]]);
        return NO;
    }
    return YES;
}

static BOOL isSafeAppBundleAtPath(NSString *path, NSString *expectedBundleIdentifier) {
    if (!path.length || !expectedBundleIdentifier.length) return NO;
    struct stat bundleStat;
    if (lstat(path.fileSystemRepresentation, &bundleStat) != 0 || !S_ISDIR(bundleStat.st_mode) || S_ISLNK(bundleStat.st_mode)) return NO;
    char resolvedBundle[PATH_MAX] = {0};
    if (!realpath(path.fileSystemRepresentation, resolvedBundle)) return NO;
    NSString *canonicalBundle = [NSString stringWithUTF8String:resolvedBundle];
    NSDictionary *info = [NSDictionary dictionaryWithContentsOfFile:[canonicalBundle stringByAppendingPathComponent:@"Info.plist"]];
    if (![info[@"CFBundleIdentifier"] isKindOfClass:NSString.class] || ![info[@"CFBundleIdentifier"] isEqualToString:expectedBundleIdentifier]) return NO;
    NSString *executable = [info[@"CFBundleExecutable"] isKindOfClass:NSString.class] ? info[@"CFBundleExecutable"] : nil;
    if (!executable.length || [executable containsString:@"/"] || [executable containsString:@"\\"] ||
        [executable isEqualToString:@"."] || [executable isEqualToString:@".."] || [executable hasPrefix:@"~"]) return NO;
    NSString *executablePath = [canonicalBundle stringByAppendingPathComponent:executable];
    struct stat executableEntry;
    if (lstat(executablePath.fileSystemRepresentation, &executableEntry) != 0 ||
        (!S_ISREG(executableEntry.st_mode) && !S_ISLNK(executableEntry.st_mode))) return NO;
    char resolvedExecutable[PATH_MAX] = {0};
    if (!realpath(executablePath.fileSystemRepresentation, resolvedExecutable)) return NO;
    if (S_ISLNK(executableEntry.st_mode)) {
        // A system app may intentionally point CFBundleExecutable at a shared
        // system binary outside the bundle. The RootHelper swaps the symlink
        // directory entry itself and preserves it as the rollback backup.
        char linkTarget[PATH_MAX + 1] = {0};
        ssize_t linkLength = readlink(executablePath.fileSystemRepresentation, linkTarget, PATH_MAX);
        struct stat targetStat;
        return linkLength > 0 && linkLength <= PATH_MAX &&
            stat(resolvedExecutable, &targetStat) == 0 && S_ISREG(targetStat.st_mode);
    }
    NSString *canonicalExecutable = [NSString stringWithUTF8String:resolvedExecutable];
    if (![canonicalExecutable hasPrefix:[canonicalBundle stringByAppendingString:@"/"]]) return NO;
    struct stat targetStat;
    return stat(canonicalExecutable.fileSystemRepresentation, &targetStat) == 0 && S_ISREG(targetStat.st_mode);
}

NSString *find_path_for_app(NSString *appName, NSString *bundleIdentifier) {
    if (!appName.length || !bundleIdentifier.length || [appName containsString:@"/"] || [appName containsString:@"\\"]) return nil;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSMutableArray<NSString *> *roots = [NSMutableArray arrayWithArray:@[
        @"/Applications", @"/System/Applications", @"/System/Library/CoreServices"
    ]];
    NSString *expectedName = [appName stringByAppendingPathExtension:@"app"];
    for (NSString *root in roots) {
        BOOL isDirectory = NO;
        if (![fileManager fileExistsAtPath:root isDirectory:&isDirectory] || !isDirectory) continue;
        NSString *directCandidate = [root stringByAppendingPathComponent:expectedName];
        if (isSafeAppBundleAtPath(directCandidate, bundleIdentifier)) return directCandidate;

        // System apps can live one level below a grouping directory (for example
        // /System/Applications/Utilities). Search only one level; do not recurse
        // through arbitrary bundle trees or follow symlinked directories.
        NSArray<NSString *> *children = [fileManager contentsOfDirectoryAtPath:root error:nil] ?: @[];
        for (NSString *child in children) {
            NSString *childPath = [root stringByAppendingPathComponent:child];
            struct stat childStat;
            if (lstat(childPath.fileSystemRepresentation, &childStat) != 0 ||
                !S_ISDIR(childStat.st_mode) || S_ISLNK(childStat.st_mode)) continue;
            NSString *nestedCandidate = [childPath stringByAppendingPathComponent:expectedName];
            if (isSafeAppBundleAtPath(nestedCandidate, bundleIdentifier)) return nestedCandidate;
        }
    }
    return nil;
}

bool install_trollstore(NSString *tar) {
    gInstallerLastError = nil;
    if (tar.length == 0 || ![[NSFileManager defaultManager] fileExistsAtPath:tar]) {
        setInstallerError(@"The bundled TrollStore archive is missing.");
        return false;
    }
    if (!prepareRootHelper()) return false;
    NSString *output = nil;
    int ret = run_binary(kInstallerHelperPath, @[@"install-trollstore", tar], &output);
    if (ret != 0) setInstallerError([NSString stringWithFormat:@"trollstorehelper returned %d: %@", ret, output ?: @"(no output)"]);
    printf("trollstorehelper output: %s\n", output.UTF8String ?: "");
    return ret == 0;
}

bool install_persistence_helper(NSString *app) {
    gInstallerLastError = nil;
    if (app.length == 0) {
        setInstallerError(@"No persistence-helper host bundle identifier was selected.");
        return false;
    }
    if (![[NSFileManager defaultManager] isExecutableFileAtPath:kInstallerHelperPath]) {
        setInstallerError(@"The staged trollstorehelper binary is missing or not executable.");
        return false;
    }
    if (![[NSFileManager defaultManager] isExecutableFileAtPath:kInstallerPersistenceHelperPath]) {
        setInstallerError(@"The staged PersistenceHelper binary is missing or not executable.");
        return false;
    }
    if (!prepareRootHelper()) return false;
    NSString *output = nil;
    int ret = run_binary(kInstallerHelperPath,
                         @[@"install-persistence-helper", app, kInstallerPersistenceHelperPath, kInstallerHelperPath],
                         &output);
    if (ret != 0) setInstallerError([NSString stringWithFormat:@"RootHelper returned %d: %@", ret, output.length ? output : @"(no diagnostic output)"]);
    printf("persistence helper returned %d\n", ret);
    printf("trollstorehelper output: %s\n", output.UTF8String ?: "");
    return ret == 0;
}
