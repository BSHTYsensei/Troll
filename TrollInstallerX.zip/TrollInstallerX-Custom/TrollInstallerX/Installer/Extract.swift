// Custom TrollStore payload extraction. The archive is bundled with this installer;
// no user-supplied or remotely downloaded TrollStore archive is accepted.
import Foundation
import CryptoKit

let installerWorkspace = "/private/preboot/tmp/TrollInstallerCustom"
let installerPayloadPath = installerWorkspace + "/payload"
let installerRootHelperPath = installerWorkspace + "/trollstorehelper"
private let expectedPayloadSHA256: [String: String] = [
    "TrollStore": "49adf6d03a9a831aeec0cf2b67aadf1e743976b4b948c7a990447e2387f09188",
    "PersistenceHelper": "d52e706d60af59d8f1bfeb297d9cdb16ede0673034da243bb97b6a760715c5b0",
    "trollstorehelper": "82c83ce9d71b32a1f443d0c6faf1d4334889280f2be5c9f8a686f25e8179dee3",
    "ldid-bootstrap/ldid": "79af6331b7cd4c6ebf3f89284ce049450104e4a56dc5285017e83fc060901868"
]

private func makeExecutable(_ path: String) -> Bool {
    let fm = FileManager.default
    guard fm.fileExists(atPath: path) else { return false }
    do {
        try fm.setAttributes([.posixPermissions: NSNumber(value: 0o755)], ofItemAtPath: path)
        return true
    } catch {
        Logger.log("无法设置可执行权限：\(path)（\(error.localizedDescription)）", type: .error)
        return false
    }
}

private func validateExtractedPayload(at path: String) -> Bool {
    let fm = FileManager.default
    let app = path + "/TrollStore.app"
    let required = [
        app + "/Info.plist",
        app + "/TrollStore",
        app + "/PersistenceHelper",
        app + "/trollstorehelper",
        app + "/ldid-bootstrap/ldid"
    ]
    guard required.allSatisfy({ fm.fileExists(atPath: $0) }) else {
        Logger.log("自定义 TrollStore 归档缺少必要文件", type: .error)
        return false
    }
    guard let info = NSDictionary(contentsOfFile: app + "/Info.plist"),
          (info["CFBundleIdentifier"] as? String) == "com.opa334.TrollStore",
          (info["CFBundleExecutable"] as? String) == "TrollStore",
          (info["CFBundleVersion"] as? String) == "2.1.1" else {
        Logger.log("自定义 TrollStore 的 Info.plist 校验失败", type: .error)
        return false
    }
    for (relativePath, expectedHash) in expectedPayloadSHA256 {
        let binaryPath = app + "/" + relativePath
        guard let binaryData = try? Data(contentsOf: URL(fileURLWithPath: binaryPath)) else {
            Logger.log("无法读取内置组件：\(relativePath)", type: .error)
            return false
        }
        let actualHash = SHA256.hash(data: binaryData).map { String(format: "%02x", $0) }.joined()
        guard actualHash == expectedHash else {
            Logger.log("内置组件校验失败：\(relativePath)，拒绝安装不匹配的资源包", type: .error)
            return false
        }
    }

    return makeExecutable(app + "/TrollStore") &&
           makeExecutable(app + "/PersistenceHelper") &&
           makeExecutable(app + "/trollstorehelper") &&
           makeExecutable(app + "/ldid-bootstrap/ldid")
}

func extractTrollStore() -> Bool {
    let fm = FileManager.default
    guard let archive = Bundle.main.url(forResource: "TrollStore", withExtension: "tar")?.path else {
        Logger.log("安装器未包含 TrollStore.tar", type: .error)
        return false
    }

    do {
        try fm.createDirectory(atPath: installerWorkspace, withIntermediateDirectories: true)
        if fm.fileExists(atPath: installerPayloadPath) {
            try fm.removeItem(atPath: installerPayloadPath)
        }
    } catch {
        Logger.log("无法准备安装临时目录：\(error.localizedDescription)", type: .error)
        return false
    }

    guard libarchive_unarchive(archive, installerPayloadPath) == 0 else {
        Logger.log("解压内置 TrollStore.tar 失败", type: .error)
        return false
    }
    guard validateExtractedPayload(at: installerPayloadPath) else { return false }

    do {
        if fm.fileExists(atPath: installerRootHelperPath) {
            try fm.removeItem(atPath: installerRootHelperPath)
        }
        try fm.copyItem(atPath: installerPayloadPath + "/TrollStore.app/trollstorehelper", toPath: installerRootHelperPath)
    } catch {
        Logger.log("复制 trollstorehelper 失败：\(error.localizedDescription)", type: .error)
        return false
    }
    return makeExecutable(installerRootHelperPath)
}

func extractTrollStoreIndirect() -> Bool {
    let fm = FileManager.default
    guard let bundled = Bundle.main.url(forResource: "TrollStore", withExtension: "tar") else {
        Logger.log("安装器未包含 TrollStore.tar", type: .error)
        return false
    }
    let docs = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
    let workspace = docs.appendingPathComponent("TrollInstallerCustom")
    let archiveCopy = workspace.appendingPathComponent("TrollStore-Custom.tar")
    let extractPath = workspace.appendingPathComponent("payload")
    let rootHelperCopy = workspace.appendingPathComponent("trollstorehelper")
    let persistenceHelperCopy = workspace.appendingPathComponent("PersistenceHelper")

    cleanupIndirectInstall()
    do {
        try fm.createDirectory(at: workspace, withIntermediateDirectories: true)
        try fm.copyItem(at: bundled, to: archiveCopy)
    } catch {
        Logger.log("复制内置安装归档失败：\(error.localizedDescription)", type: .error)
        cleanupIndirectInstall()
        return false
    }

    guard libarchive_unarchive(archiveCopy.path, extractPath.path) == 0 else {
        Logger.log("解压自定义 TrollStore 归档失败", type: .error)
        cleanupIndirectInstall()
        return false
    }
    guard validateExtractedPayload(at: extractPath.path) else {
        cleanupIndirectInstall()
        return false
    }

    let appPath = extractPath.appendingPathComponent("TrollStore.app")
    do {
        try fm.copyItem(at: appPath.appendingPathComponent("trollstorehelper"), to: rootHelperCopy)
        try fm.copyItem(at: appPath.appendingPathComponent("PersistenceHelper"), to: persistenceHelperCopy)
    } catch {
        Logger.log("复制安装组件失败：\(error.localizedDescription)", type: .error)
        cleanupIndirectInstall()
        return false
    }

    let executablesReady = makeExecutable(rootHelperCopy.path) && makeExecutable(persistenceHelperCopy.path)
    if !executablesReady {
        cleanupIndirectInstall()
        return false
    }
    return true
}

func cleanupIndirectInstall() {
    let fm = FileManager.default
    let docs = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
    try? fm.removeItem(at: docs.appendingPathComponent("TrollInstallerCustom"))
}
