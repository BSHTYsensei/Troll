//
//  LaunchView.swift
//  TrollInstallerX
//
//  Created by Alfie on 22/03/2024.
//

import SwiftUI
import UniformTypeIdentifiers

@MainActor
struct MainView: View {
    
    @State private var isInstalling = false
    
    @State private var device: Device = Device()
    
    @State private var isShowingMDCAlert = false
    @State private var isShowingHelperAlert = false
    
    @State private var isShowingSettings = false
    @State private var isShowingCredits = false
    
    @State private var installedSuccessfully = false
    @State private var installationFinished = false
    @State private var selectedArchivePath: String? = InstallerArchiveStore.existingArchiveURL()?.path
    @State private var isImportingArchive = false
    @State private var showArchiveImportError = false
    @State private var archiveImportError = ""
    
    // Best way to show the alert midway through doInstall()
    @ObservedObject var helperView = HelperAlert.shared
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                ZStack {
                    LinearGradient(colors: [Color(hex: 0x0482d1), Color(hex: 0x0566ed)], startPoint: .topLeading, endPoint: .bottomTrailing)
                        .ignoresSafeArea()
                    VStack {
                        VStack {
                            Image("Icon")
                                .resizable()
                                .cornerRadius(22)
                                .frame(maxWidth: 100, maxHeight: 100)
                                .shadow(radius: 10)
                            Text("巨魔安装器")
                                .font(.system(size: 30, weight: .semibold, design: .rounded))
                                .foregroundColor(.white)
                            Text("自定义构建 · TrollStore 2.1.1")
                                .font(.system(size: 17, weight: .semibold, design: .rounded))
                                .foregroundColor(.white.opacity(0.5))
                            Text("iOS 14.0–16.6.1 · 特定 17.0 Beta")
                                .font(.system(size: 14, weight: .semibold, design: .rounded))
                                .foregroundColor(.white.opacity(0.5))
                        }
                        .padding(.vertical)

                        if !isInstalling {
                            HStack(spacing: 12) {
                                Image(systemName: selectedArchivePath == nil ? "doc.badge.plus" : "doc.zipper")
                                    .font(.system(size: 22, weight: .medium))
                                    .foregroundColor(.white)
                                VStack(alignment: .leading, spacing: 3) {
                                    Text("TrollStore 安装资源")
                                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                                        .foregroundColor(.white)
                                    Text(selectedArchivePath.map { URL(fileURLWithPath: $0).lastPathComponent } ?? "请从“文件”导入 TrollStore.tar / .tar.gz")
                                        .font(.system(size: 11, weight: .regular, design: .rounded))
                                        .foregroundColor(.white.opacity(0.7))
                                        .lineLimit(1)
                                        .truncationMode(.middle)
                                }
                                Spacer(minLength: 4)
                                Button {
                                    isImportingArchive = true
                                } label: {
                                    Text(selectedArchivePath == nil ? "导入" : "更换")
                                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                                        .foregroundColor(.white)
                                        .padding(.horizontal, 14)
                                        .padding(.vertical, 8)
                                        .background(Color.white.opacity(0.18))
                                        .clipShape(Capsule())
                                }
                                .buttonStyle(.plain)
                            }
                            .padding(.horizontal, 14)
                            .padding(.vertical, 11)
                            .frame(maxWidth: geometry.size.width / 1.2)
                            .background(Color.white.opacity(0.12))
                            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
                            .padding(.horizontal)
                        }
                        
                        if !isInstalling {
                            MenuView(isShowingSettings: $isShowingSettings, isShowingCredits: $isShowingCredits, isShowingMDCAlert: $isShowingMDCAlert, device: device)
                                .frame(maxWidth: geometry.size.width / 1.2, maxHeight: geometry.size.height / 4)
                                .transition(.scale)
                                .padding()
                                .shadow(radius: 10)
                                .disabled(!device.isSupported)
                        }
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 10)
                                .foregroundColor(.white.opacity(0.15))
                                .frame(maxWidth: geometry.size.width / 1.2)
                                .frame(maxHeight: isInstalling ? geometry.size.height / 1.75 : 60)
                                .transition(.scale)
                                .shadow(radius: 10)
                            if isInstalling {
                                LogView(
                                    installationFinished: $installationFinished,
                                    isInstalling: $isInstalling,
                                    installationSucceeded: installedSuccessfully
                                )
                                    .padding()
                                    .frame(maxWidth: geometry.size.width / 1.2)
                                    .frame(maxHeight: geometry.size.height / 1.75)
                            }
                            else {
                                Button(action: {
                                    guard !isShowingCredits && !isShowingSettings && !isShowingMDCAlert else { return }
                                    guard let archivePath = selectedArchivePath,
                                          FileManager.default.fileExists(atPath: archivePath) else {
                                        isImportingArchive = true
                                        return
                                    }
                                    Logger.clear()
                                    installationFinished = false
                                    installedSuccessfully = false
                                    withAnimation { isInstalling = true }
                                }, label: {
                                    Text(device.isSupported ? (selectedArchivePath == nil ? "先导入资源包" : "安装巨魔") : "当前系统不受支持")
                                            .font(.system(size: 20, weight: .semibold, design: .rounded))
                                            .foregroundColor(device.isSupported ? .white : .secondary)
                                            .padding()
                                            .frame(maxWidth: geometry.size.width / 1.2)
                                            .frame(maxHeight: 60)
                                })
                                .frame(maxWidth: geometry.size.width / 1.2)
                                .frame(maxHeight: 60)
                            }
                        }
                        .padding()
                        .disabled(!device.isSupported)
                        
                        
                        }
                        .blur(radius: (isShowingMDCAlert || isShowingSettings || isShowingCredits || helperView.showAlert) ? 10 : 0)
                    }
                }
                if isShowingMDCAlert {
                    PopupView(isShowingAlert: $isShowingMDCAlert, shouldAllowDismiss: false, content: {
                        UnsandboxView(isShowingMDCAlert: $isShowingMDCAlert)
                    })
                }
                if isShowingSettings {
                    PopupView(isShowingAlert: $isShowingSettings, content: {
                        SettingsView(device: device)
                    })
                }
                
                if isShowingCredits {
                    PopupView(isShowingAlert: $isShowingCredits, content: {
                        CreditsView()
                    })
                }
            
            if helperView.showAlert {
                PopupView(isShowingAlert: $isShowingHelperAlert, shouldAllowDismiss: false, content: {
                    PersistenceHelperView(isShowingHelperAlert: $isShowingHelperAlert, allowNoPersistenceHelper: device.supportsDirectInstall)
                    })
                }
            }
            // Hacky, but it works (can't pass helperView.showAlert as a binding variable)
            .onChange(of: helperView.showAlert) { new in
                if new {
                    withAnimation {
                        isShowingHelperAlert = true
                    }
                }
            }
            .onChange(of: isShowingHelperAlert) { new in
                if !new {
                    helperView.showAlert = false
                }
            }
            .onChange(of: isInstalling) { installing in
                // Only start once, when the user enters the installation screen.
                // The old handler also ran on a future transition back to false.
                guard installing, device.isSupported,
                      let archivePath = selectedArchivePath,
                      FileManager.default.fileExists(atPath: archivePath) else { return }
                Task {
                    let success: Bool
                    if device.supportsDirectInstall {
                        success = await doDirectInstall(device, archivePath: archivePath)
                    } else {
                        success = await doIndirectInstall(device, archivePath: archivePath)
                    }
                    installedSuccessfully = success
                    installationFinished = true
                }
            }
            .onAppear {
                if device.isSupported && !checkForMDCUnsandbox() && MacDirtyCow.supports(device) {
                    withAnimation { isShowingMDCAlert = true }
                }
            }
            .fileImporter(
                isPresented: $isImportingArchive,
                allowedContentTypes: [.data],
                allowsMultipleSelection: false
            ) { result in
                switch result {
                case .success(let urls):
                    guard let sourceURL = urls.first else { return }
                    do {
                        let importedURL = try InstallerArchiveStore.importArchive(from: sourceURL)
                        selectedArchivePath = importedURL.path
                        Logger.log("TrollStore 安装资源包已导入并通过校验：\(importedURL.lastPathComponent)", type: .success)
                    } catch {
                        archiveImportError = error.localizedDescription
                        showArchiveImportError = true
                    }
                case .failure(let error):
                    let cocoaError = error as NSError
                    guard cocoaError.code != NSUserCancelledError else { return }
                    archiveImportError = error.localizedDescription
                    showArchiveImportError = true
                }
            }
            .alert(isPresented: $showArchiveImportError) {
                Alert(
                    title: Text("导入安装资源失败"),
                    message: Text(archiveImportError),
                    dismissButton: .default(Text("确定"))
                )
            }

        }
    }


#Preview {
    MainView()
}
