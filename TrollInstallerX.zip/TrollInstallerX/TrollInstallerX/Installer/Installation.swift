//
//  Installation.swift
//  TrollInstallerX
//
//  Created by Alfie on 22/03/2024.
//

import SwiftUI

let fileManager = FileManager.default
let docsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0]
let docsDir = fileManager.urls(for: .documentDirectory, in: .userDomainMask)[0].path
let kernelPath = docsDir + "/kernelcache"


func checkForMDCUnsandbox() -> Bool {
    return fileManager.fileExists(atPath: docsDir + "/full_disk_access_sandbox_token.txt")
}

func getKernel(_ device: Device) -> Bool {
    if !fileManager.fileExists(atPath: kernelPath) {
        if fileManager.fileExists(atPath: Bundle.main.path(forResource: "kernelcache", ofType: "") ?? "") {
            try? fileManager.copyItem(atPath: Bundle.main.path(forResource: "kernelcache", ofType: "")!, toPath: kernelPath)
            if fileManager.fileExists(atPath: kernelPath) { return true }
        }
        if MacDirtyCow.supports(device) && checkForMDCUnsandbox() {
            let fd = open(docsDir + "/full_disk_access_sandbox_token.txt", O_RDONLY)
            if fd >= 0 {
                defer { close(fd) }
                let tokenData = get_NSString_from_file(fd)
                sandbox_extension_consume(tokenData)
                Logger.log("Copying kernelcache")
                if let path = get_kernelcache_path() {
                    do {
                        try fileManager.copyItem(atPath: path, toPath: kernelPath)
                        return true
                    } catch {
                        Logger.log("Failed to copy kernelcache", type: .error)
                        NSLog("Failed to copy kernelcache - \(error)")
                    }
                }
            }
        }
        Logger.log("Downloading kernel")
        if !grab_kernelcache(kernelPath) {
            Logger.log("Failed to download kernel", type: .error)
            return false
        }
    }
    
    return true
}


func cleanupPrivatePreboot() -> Bool {
    // Only remove this installer's private workspace; never touch the shared preboot tmp directory.
    let fileManager = FileManager.default
    guard fileManager.fileExists(atPath: installerWorkspace) else { return true }
    do {
        try fileManager.removeItem(atPath: installerWorkspace)
        return true
    } catch {
        Logger.log("清理安装临时目录失败：\(error.localizedDescription)", type: .error)
        return false
    }
}

func selectExploit(_ device: Device) -> KernelExploit {
    let flavour = (TIXDefaults().string(forKey: "exploitFlavour") ?? (physpuppet.supports(device) ? "physpuppet" : "landa"))
    if flavour == "landa" { return landa }
    if flavour == "physpuppet" { return physpuppet }
    if flavour == "smith" { return smith }
    return landa
}

func getCandidates() -> [InstalledApp] {
    return refreshPersistenceHelperCandidates()
}

@discardableResult
func doDirectInstall(_ device: Device, archivePath: String) async -> Bool {
    
    guard validateTrollStoreArchive(at: archivePath) else {
        Logger.log("TrollStore 安装资源包无效；未启动漏洞利用", type: .error)
        return false
    }

    let exploit = selectExploit(device)
    
    let iOS14 = device.version < Version("15.0")
    let supportsFullPhysRW = !(device.cpuFamily == .A8 && device.version > Version("15.1.1")) && ((device.isArm64e && device.version >= Version(major: 15, minor: 2)) || (!device.isArm64e && device.version >= Version("15.0")))
    
    Logger.log("Running on an \(device.modelIdentifier) on iOS \(device.version.readableString)")
    
    if !iOS14 {
        if !(getKernel(device)) {
            Logger.log("Failed to get kernel", type: .error)
            return false
        }
    }
    
    Logger.log("Gathering kernel information")
    if !initialise_kernel_info(kernelPath, iOS14) {
        Logger.log("Failed to patchfind kernel", type: .error)
        return false
    }
    
    Logger.log("Exploiting kernel (\(exploit.name))")
    if !exploit.initialise() {
        Logger.log("Failed to exploit the kernel", type: .error)
        return false
    }
    Logger.log("Successfully exploited the kernel", type: .success)
    post_kernel_exploit(iOS14)
    
    if supportsFullPhysRW {
        if device.isArm64e {
            Logger.log("Bypassing PPL (\(dmaFail.name))")
            if !dmaFail.initialise() {
                Logger.log("Failed to bypass PPL", type: .error)
                return false
            }
            Logger.log("Successfully bypassed PPL", type: .success)
        }
        
        if #available(iOS 16, *) {
            libjailbreak_kalloc_pt_init()
        }
        
        if !build_physrw_primitive() {
            Logger.log("Failed to build physical R/W primitive", type: .error)
            return false
        }
        
        if device.isArm64e {
            if !dmaFail.deinitialise() {
                Logger.log("Failed to deinitialise \(dmaFail.name)", type: .error)
                return false
            }
        }
        
        if !exploit.deinitialise() {
            Logger.log("Failed to deinitialise \(exploit.name)", type: .error)
            return false
        }
        
        Logger.log("Unsandboxing")
        if !unsandbox() {
            Logger.log("Failed to unsandbox", type: .error)
            return false
        }
        
        Logger.log("Escalating privileges")
        if !get_root_pplrw() {
            Logger.log("Failed to escalate privileges", type: .error)
            return false
        }
        if !platformise() {
            Logger.log("Failed to platformise", type: .error)
            return false
        }
    } else {
        
        Logger.log("Unsandboxing and escalating privileges")
        if !get_root_krw(iOS14) {
            Logger.log("Failed to unsandbox and escalate privileges", type: .error)
            return false
        }
    }
    
    remount_private_preboot()
    guard extractTrollStore(archivePath: archivePath) else {
        Logger.log("解压自定义 TrollStore 失败", type: .error)
        _ = cleanupPrivatePreboot()
        if !supportsFullPhysRW {
            _ = drop_root_krw(iOS14)
            _ = exploit.deinitialise()
        }
        return false
    }
    defer {
        if !cleanupPrivatePreboot() {
            Logger.log("清理安装临时目录失败", type: .error)
        }
    }

    let newCandidates = getCandidates()
    persistenceHelperCandidates = newCandidates
    var persistenceHelperSucceeded = true

    if !newCandidates.isEmpty {
        // Empty string is the explicit "skip Persistence Helper" choice shown
        // by PersistenceHelperView on direct-install devices. Only nil means the
        // selection flow was cancelled; skipping must not abort TrollStore itself.
        guard let persistenceID = await HelperAlert.shared.requestSelection() else {
            Logger.log("持久化助手选择流程已取消，终止安装", type: .warning)
            if !supportsFullPhysRW {
                _ = drop_root_krw(iOS14)
                _ = exploit.deinitialise()
            }
            return false
        }
        if persistenceID.isEmpty {
            Logger.log("用户选择跳过持久化助手；继续安装 TrollStore", type: .warning)
        } else if install_persistence_helper(persistenceID) {
            Logger.log("持久化助手安装成功", type: .success)
        } else {
            let detail = installer_last_error() ?? "RootHelper 没有返回详细错误。"
            Logger.log("持久化助手安装失败：\(detail)", type: .error)
            persistenceHelperSucceeded = false
        }
    } else {
        Logger.log("没有可用的持久化助手候选应用，跳过该步骤", type: .warning)
    }

    Logger.log("正在安装自定义 TrollStore")
    let trollStoreSucceeded = install_trollstore(archivePath)
    if trollStoreSucceeded {
        Logger.log("TrollStore 安装成功", type: .success)
    } else {
        let detail = installer_last_error() ?? "trollstorehelper 没有返回详细错误。"
        Logger.log("TrollStore 安装失败：\(detail)", type: .error)
    }

    if !supportsFullPhysRW {
        if !drop_root_krw(iOS14) {
            Logger.log("Failed to drop root privileges", type: .error)
            return false
        }
        if !exploit.deinitialise() {
            Logger.log("Failed to deinitialise \(exploit.name)", type: .error)
            return false
        }
    }
    
    return trollStoreSucceeded && persistenceHelperSucceeded
}

func doIndirectInstall(_ device: Device, archivePath: String) async -> Bool {
    guard fileManager.fileExists(atPath: archivePath) else {
        Logger.log("请先导入 TrollStore 安装资源包", type: .error)
        return false
    }

    let exploit = selectExploit(device)
    
    Logger.log("Running on an \(device.modelIdentifier) on iOS \(device.version.readableString)")
    
    if !extractTrollStoreIndirect(archivePath: archivePath) {
        return false
    }
    defer {
        cleanupIndirectInstall()
    }
    
    if !(getKernel(device)) {
        Logger.log("Failed to get kernel", type: .error)
        return false
    }
    
    Logger.log("Gathering kernel information")
    if !initialise_kernel_info(kernelPath, false) {
        Logger.log("Failed to patchfind kernel", type: .error)
        return false
    }
    
    Logger.log("Exploiting kernel (\(exploit.name))")
    if !exploit.initialise() {
        Logger.log("Failed to exploit the kernel", type: .error)
        return false
    }
    defer {
        if !exploit.deinitialise() {
            Logger.log("Failed to deinitialise \(exploit.name)", type: .error)
        }
    }
    Logger.log("Successfully exploited the kernel", type: .success)
    post_kernel_exploit(false)
    
    var path: UnsafePointer<CChar>? = nil
    let pathPointer = withUnsafeMutablePointer(to: &path) { ptr in
        UnsafeMutablePointer<UnsafePointer<CChar>?>.init(ptr)
    }
    if is_persistence_helper_installed(pathPointer) {
        let installedPath = path.map { String(cString: $0) } ?? "unknown"
        Logger.log("系统持久化助手已经安装：\(installedPath)", type: .success)
        Logger.log("无需重复替换系统应用。请打开对应宿主应用，在 TrollStore Helper 页面继续安装或修复 TrollStore。", type: .warning)
        return true
    }
    
    let apps = get_installed_apps() as? [String]
    var candidates = [InstalledApp]()
    for app in apps ?? [String]() {
        print(app)
        let appName = URL(fileURLWithPath: app).lastPathComponent.replacingOccurrences(of: ".app", with: "")
        for candidate in persistenceHelperCandidateDefinitions where appName == candidate.bundleName {
            var installedCandidate = candidate
            installedCandidate.isInstalled = true
            installedCandidate.bundlePath = "/var/containers/Bundle/Application/" + app
            candidates.append(installedCandidate)
        }
    }
    
    persistenceHelperCandidates = candidates
    guard !candidates.isEmpty else {
        Logger.log("没有找到可用的持久化助手宿主应用", type: .error)
        return false
    }
    guard let persistenceID = await HelperAlert.shared.requestSelection(), !persistenceID.isEmpty else {
        Logger.log("未选择持久化助手", type: .warning)
        return false
    }

    guard let selectedCandidate = persistenceHelperCandidates.first(where: { $0.bundleIdentifier == persistenceID }),
          let pathToInstall = selectedCandidate.bundlePath, !pathToInstall.isEmpty else {
        Logger.log("所选持久化助手应用路径无效", type: .error)
        return false
    }
    var success = false
    if !install_persistence_helper_via_vnode(pathToInstall, persistenceID) {
        Logger.log("Failed to install persistence helper", type: .error)
    } else {
        Logger.log("Successfully installed persistence helper!", type: .success)
        success = true
    }
    
    if success {
        let verbose = TIXDefaults().bool(forKey: "verbose")
        Logger.log("Respringing in \(verbose ? "15" : "5") seconds")
        DispatchQueue.global().async {
            sleep(verbose ? 15 : 5)
            restartBackboard()
        }
    }
    
    return success
}
