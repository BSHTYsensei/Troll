// Runtime TrollStore payload import and extraction.
import Foundation
import CryptoKit

let installerWorkspace = "/private/preboot/tmp/TrollInstallerCustom"
let installerPayloadPath = installerWorkspace + "/payload"
let installerRootHelperPath = installerWorkspace + "/trollstorehelper"

/// Keeps the selected payload in a private app container directory. It is
/// deliberately separate from TrollInstallerCustom, which is removed during
/// indirect-install cleanup.
enum InstallerArchiveStore {
    enum ImportError: LocalizedError {
        case unsupportedFileType
        case notRegularFile
        case invalidSize
        case invalidPayload

        var errorDescription: String? {
            switch self {
            case .unsupportedFileType:
                return "请选择 .tar、.tar.gz 或 .tgz 格式的 TrollStore 安装资源包。"
            case .notRegularFile:
                return "所选项目不是普通文件。"
            case .invalidSize:
                return "安装资源包为空或超过 128 MB。"
            case .invalidPayload:
                return "安装资源包结构、版本或核心组件 SHA-256 校验失败。请导入与当前源码匹配的 TrollStore.tar。"
            }
        }
    }

    private static var directoryURL: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("TrollInstallerXPayload", isDirectory: true)
    }

    static var archiveURL: URL {
        directoryURL.appendingPathComponent("TrollStore.tar", isDirectory: false)
    }

    static func existingArchiveURL() -> URL? {
        let path = archiveURL.path
        guard FileManager.default.fileExists(atPath: path),
              let attributes = try? FileManager.default.attributesOfItem(atPath: path),
              (attributes[.type] as? FileAttributeType) == .typeRegular else {
            return nil
        }
        let size = (attributes[.size] as? NSNumber)?.intValue ?? 0
        return size > 0 ? archiveURL : nil
    }

    @discardableResult
    static func importArchive(from source: URL) throws -> URL {
        let didStartAccessing = source.startAccessingSecurityScopedResource()
        defer {
            if didStartAccessing {
                source.stopAccessingSecurityScopedResource()
            }
        }

        let ext = source.pathExtension.lowercased()
        guard ["tar", "gz", "tgz"].contains(ext) else {
            throw ImportError.unsupportedFileType
        }

        let fm = FileManager.default
        try fm.createDirectory(at: directoryURL, withIntermediateDirectories: true)
        let temporaryURL = directoryURL.appendingPathComponent("TrollStore.tar.importing")
        if fm.fileExists(atPath: temporaryURL.path) {
            try fm.removeItem(at: temporaryURL)
        }
        do {
            // File Provider / iCloud URLs must be read under file coordination.
            // Keep security-scoped access active for the entire coordinated copy.
            let coordinator = NSFileCoordinator(filePresenter: nil)
            var coordinationError: NSError?
            var importError: Error?
            coordinator.coordinate(readingItemAt: source, options: [], error: &coordinationError) { readableURL in
                do {
                    let values = try readableURL.resourceValues(forKeys: [.isRegularFileKey, .isSymbolicLinkKey, .fileSizeKey])
                    guard values.isRegularFile == true, values.isSymbolicLink != true else {
                        throw ImportError.notRegularFile
                    }
                    guard let size = values.fileSize, size > 0, size <= 128 * 1024 * 1024 else {
                        throw ImportError.invalidSize
                    }
                    try fm.copyItem(at: readableURL, to: temporaryURL)
                    let copiedAttributes = try fm.attributesOfItem(atPath: temporaryURL.path)
                    guard (copiedAttributes[.type] as? FileAttributeType) == .typeRegular,
                          (copiedAttributes[.size] as? NSNumber)?.intValue == size else {
                        throw ImportError.invalidSize
                    }
                } catch {
                    importError = error
                }
            }
            if let coordinationError { throw coordinationError }
            if let importError { throw importError }
            guard validateTrollStoreArchive(at: temporaryURL.path) else {
                throw ImportError.invalidPayload
            }
            if fm.fileExists(atPath: archiveURL.path) {
                try fm.removeItem(at: archiveURL)
            }
            try fm.moveItem(at: temporaryURL, to: archiveURL)
        } catch {
            try? fm.removeItem(at: temporaryURL)
            throw error
        }
        return archiveURL
    }
}

private let expectedPayloadSHA256: [String: String] = [
    "TrollStore": "49adf6d03a9a831aeec0cf2b67aadf1e743976b4b948c7a990447e2387f09188",
    "PersistenceHelper": "d52e706d60af59d8f1bfeb297d9cdb16ede0673034da243bb97b6a760715c5b0",
    "trollstorehelper": "82c83ce9d71b32a1f443d0c6faf1d4334889280f2be5c9f8a686f25e8179dee3",
    "ldid-bootstrap/ldid": "79af6331b7cd4c6ebf3f89284ce049450104e4a56dc5285017e83fc060901868"
]

private func makeExecutable(_ path: String) -> Bool {
    let fm = FileManager.default
    guard fm.fileExists(atPath: path) else { return false }
    do {
        try fm.setAttributes([.posixPermissions: NSNumber(value: 0o755)], ofItemAtPath: path)
        return true
    } catch {
        Logger.log("无法设置可执行权限：\(path)（\(error.localizedDescription)）", type: .error)
        return false
    }
}

private func isRegularFile(_ path: String) -> Bool {
    guard let attributes = try? FileManager.default.attributesOfItem(atPath: path) else { return false }
    return (attributes[.type] as? FileAttributeType) == .typeRegular
}

private func validateExtractedPayload(at path: String) -> Bool {
    let app = path + "/TrollStore.app"
    let required = [
        app + "/Info.plist",
        app + "/TrollStore",
        app + "/PersistenceHelper",
        app + "/trollstorehelper",
        app + "/ldid-bootstrap/ldid"
    ]
    guard required.allSatisfy({ isRegularFile($0) }) else {
        Logger.log("自定义 TrollStore 归档缺少必要的普通文件", type: .error)
        return false
    }
    guard let info = NSDictionary(contentsOfFile: app + "/Info.plist"),
          (info["CFBundleIdentifier"] as? String) == "com.opa334.TrollStore",
          (info["CFBundleExecutable"] as? String) == "TrollStore",
          (info["CFBundleVersion"] as? String) == "2.1.1" else {
        Logger.log("自定义 TrollStore 的 Info.plist 校验失败", type: .error)
        return false
    }
    for (relativePath, expectedHash) in expectedPayloadSHA256 {
        let binaryPath = app + "/" + relativePath
        guard let binaryData = try? Data(contentsOf: URL(fileURLWithPath: binaryPath)) else {
            Logger.log("无法读取内置组件：\(relativePath)", type: .error)
            return false
        }
        let actualHash = SHA256.hash(data: binaryData).map { String(format: "%02x", $0) }.joined()
        guard actualHash == expectedHash else {
            Logger.log("内置组件校验失败：\(relativePath)，拒绝安装不匹配的资源包", type: .error)
            return false
        }
    }

    return makeExecutable(app + "/TrollStore") &&
           makeExecutable(app + "/PersistenceHelper") &&
           makeExecutable(app + "/trollstorehelper") &&
           makeExecutable(app + "/ldid-bootstrap/ldid")
}

private func archiveExists(_ path: String) -> Bool {
    guard isRegularFile(path),
          let attributes = try? FileManager.default.attributesOfItem(atPath: path) else { return false }
    return ((attributes[.size] as? NSNumber)?.intValue ?? 0) > 0
}

/// Perform the full archive and component validation before any exploit is run.
/// Extraction is confined to a temporary Documents subdirectory and always removed.
func validateTrollStoreArchive(at archivePath: String) -> Bool {
    guard archiveExists(archivePath) else { return false }
    let fm = FileManager.default
    let validationPath = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
        .appendingPathComponent("TrollInstallerXValidation", isDirectory: true)
    do {
        if fm.fileExists(atPath: validationPath.path) {
            try fm.removeItem(at: validationPath)
        }
        try fm.createDirectory(at: validationPath, withIntermediateDirectories: true)
    } catch {
        Logger.log("无法准备安装资源校验目录：\(error.localizedDescription)", type: .error)
        return false
    }
    defer { try? fm.removeItem(at: validationPath) }

    guard libarchive_unarchive(archivePath, validationPath.path) == 0 else {
        Logger.log("安装资源包无法安全解压，已拒绝该文件", type: .error)
        return false
    }
    return validateExtractedPayload(at: validationPath.path)
}

func extractTrollStore(archivePath: String) -> Bool {
    let fm = FileManager.default
    guard archiveExists(archivePath) else {
        Logger.log("尚未导入有效的 TrollStore.tar 安装资源包", type: .error)
        return false
    }

    do {
        try fm.createDirectory(atPath: installerWorkspace, withIntermediateDirectories: true)
        if fm.fileExists(atPath: installerPayloadPath) {
            try fm.removeItem(atPath: installerPayloadPath)
        }
        try fm.createDirectory(atPath: installerPayloadPath, withIntermediateDirectories: true)
    } catch {
        Logger.log("无法准备安装临时目录：\(error.localizedDescription)", type: .error)
        return false
    }

    guard libarchive_unarchive(archivePath, installerPayloadPath) == 0 else {
        Logger.log("解压 TrollStore 安装资源包失败（归档损坏或包含不安全路径）", type: .error)
        return false
    }
    guard validateExtractedPayload(at: installerPayloadPath) else { return false }

    do {
        if fm.fileExists(atPath: installerRootHelperPath) {
            try fm.removeItem(atPath: installerRootHelperPath)
        }
        try fm.copyItem(atPath: installerPayloadPath + "/TrollStore.app/trollstorehelper", toPath: installerRootHelperPath)
    } catch {
        Logger.log("复制 trollstorehelper 失败：\(error.localizedDescription)", type: .error)
        return false
    }
    return makeExecutable(installerRootHelperPath)
}

func extractTrollStoreIndirect(archivePath: String) -> Bool {
    let fm = FileManager.default
    guard !vnode_redirection_is_active() else {
        Logger.log("检测到上一次 vnode 映射尚未确认恢复。为保护系统宿主应用，已保留临时目录；请重启设备后重试。", type: .error)
        return false
    }
    guard archiveExists(archivePath) else {
        Logger.log("尚未导入有效的 TrollStore.tar 安装资源包", type: .error)
        return false
    }

    let docs = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
    let workspace = docs.appendingPathComponent("TrollInstallerCustom", isDirectory: true)
    let archiveCopy = workspace.appendingPathComponent("TrollStore-Custom.tar")
    let extractPath = workspace.appendingPathComponent("payload", isDirectory: true)
    let rootHelperCopy = workspace.appendingPathComponent("trollstorehelper")
    let persistenceHelperCopy = workspace.appendingPathComponent("PersistenceHelper")

    cleanupIndirectInstall()
    do {
        try fm.createDirectory(at: workspace, withIntermediateDirectories: true)
        try fm.copyItem(atPath: archivePath, toPath: archiveCopy.path)
        try fm.createDirectory(at: extractPath, withIntermediateDirectories: true)
    } catch {
        Logger.log("复制安装归档失败：\(error.localizedDescription)", type: .error)
        cleanupIndirectInstall()
        return false
    }

    guard libarchive_unarchive(archiveCopy.path, extractPath.path) == 0 else {
        Logger.log("解压 TrollStore 安装资源包失败（归档损坏或包含不安全路径）", type: .error)
        cleanupIndirectInstall()
        return false
    }
    guard validateExtractedPayload(at: extractPath.path) else {
        cleanupIndirectInstall()
        return false
    }

    let appPath = extractPath.appendingPathComponent("TrollStore.app")
    do {
        try fm.copyItem(at: appPath.appendingPathComponent("trollstorehelper"), to: rootHelperCopy)
        try fm.copyItem(at: appPath.appendingPathComponent("PersistenceHelper"), to: persistenceHelperCopy)
    } catch {
        Logger.log("复制安装组件失败：\(error.localizedDescription)", type: .error)
        cleanupIndirectInstall()
        return false
    }

    let executablesReady = makeExecutable(rootHelperCopy.path) && makeExecutable(persistenceHelperCopy.path)
    if !executablesReady {
        cleanupIndirectInstall()
        return false
    }
    return true
}

func cleanupIndirectInstall() {
    guard !vnode_redirection_is_active() else {
        Logger.log("vnode 映射恢复状态不确定，已阻止删除 TrollInstallerCustom 临时目录，以免误删系统应用。请重启设备后再清理或重试。", type: .error)
        return
    }
    let fm = FileManager.default
    let docs = fm.urls(for: .documentDirectory, in: .userDomainMask)[0]
    try? fm.removeItem(at: docs.appendingPathComponent("TrollInstallerCustom"))
}
