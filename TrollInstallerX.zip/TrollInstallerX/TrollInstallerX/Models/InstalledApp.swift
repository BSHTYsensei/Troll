//
//  InstalledApp.swift
//  TrollInstallerX
//
//  Created by Alfie on 29/03/2024.
//

import SwiftUI

struct InstalledApp: Hashable {
    let displayName: String
    let bundleName: String
    let bundleIdentifier: String
    var bundlePath: String?
    
    var isInstalled: Bool
    
    var icon: UIImage?
    
    init(displayName: String, bundleName: String, bundleIdentifier: String) {
        self.displayName = displayName
        self.bundleName = bundleName
        self.bundleIdentifier = bundleIdentifier
        
        self.bundlePath = find_path_for_app(bundleName, bundleIdentifier)
        self.isInstalled = !(bundlePath == nil)
        if let bundlePath {
            self.icon = Self.loadIcon(at: bundlePath)
        }
    }

    private static func loadIcon(at bundlePath: String) -> UIImage? {
        let infoPath = (bundlePath as NSString).appendingPathComponent("Info.plist")
        let info = NSDictionary(contentsOfFile: infoPath) as? [String: Any] ?? [:]
        let primaryIcon = (info["CFBundleIcons"] as? [String: Any])?["CFBundlePrimaryIcon"] as? [String: Any]
        let iconNames = (primaryIcon?["CFBundleIconFiles"] as? [String] ?? []) +
            (info["CFBundleIconFiles"] as? [String] ?? [])
        let appBundle = Bundle(path: bundlePath)

        for name in iconNames.reversed() {
            if let appBundle, let image = UIImage(named: name, in: appBundle, compatibleWith: nil) {
                return image
            }
            let directPath = (bundlePath as NSString).appendingPathComponent(name)
            if let image = UIImage(contentsOfFile: directPath) { return image }
            for suffix in ["@3x", "@2x", ""] {
                let candidate = (bundlePath as NSString).appendingPathComponent(name + suffix + ".png")
                if let image = UIImage(contentsOfFile: candidate) { return image }
            }
        }

        // Fallbacks used by older system bundles and non-asset-catalog icons.
        for filename in ["AppIcon60x60@3x.png", "AppIcon60x60@2x.png", "AppIcon@2x.png", "iOSAppIcon60x60@2x.png"] {
            let candidate = (bundlePath as NSString).appendingPathComponent(filename)
            if let image = UIImage(contentsOfFile: candidate) { return image }
        }
        return nil
    }
}

let persistenceHelperCandidateDefinitions: [InstalledApp] = [
    InstalledApp(displayName: "提示", bundleName: "Tips", bundleIdentifier: "com.apple.tips"),
    InstalledApp(displayName: "测距仪", bundleName: "Measure", bundleIdentifier: "com.apple.measure"),
    InstalledApp(displayName: "指南针", bundleName: "Compass", bundleIdentifier: "com.apple.compass"),
    InstalledApp(displayName: "图书", bundleName: "Books", bundleIdentifier: "com.apple.iBooks"),
    InstalledApp(displayName: "iTunes Store", bundleName: "MobileStore", bundleIdentifier: "com.apple.MobileStore"),
    InstalledApp(displayName: "翻译", bundleName: "SequoiaTranslator", bundleIdentifier: "com.apple.Translate"),
    InstalledApp(displayName: "播客", bundleName: "Podcasts", bundleIdentifier: "com.apple.podcasts"),
    InstalledApp(displayName: "计算器", bundleName: "Calculator", bundleIdentifier: "com.apple.calculator"),
    InstalledApp(displayName: "钱包", bundleName: "Passbook", bundleIdentifier: "com.apple.Passbook"),
    InstalledApp(displayName: "Apple TV", bundleName: "AppleTV", bundleIdentifier: "com.apple.tv"),
    InstalledApp(displayName: "无边记", bundleName: "Freeform", bundleIdentifier: "com.apple.freeform"),
    InstalledApp(displayName: "股市", bundleName: "Stocks", bundleIdentifier: "com.apple.stocks")
]

// Direct installation runs after the exploit has removed the app sandbox. The
// process-global Swift array was initially constructed before that point, so
// its paths are stale; rebuild every candidate immediately before presenting it.
var persistenceHelperCandidates = persistenceHelperCandidateDefinitions

func refreshPersistenceHelperCandidates() -> [InstalledApp] {
    let refreshed = persistenceHelperCandidateDefinitions.map {
        InstalledApp(displayName: $0.displayName, bundleName: $0.bundleName, bundleIdentifier: $0.bundleIdentifier)
    }
    persistenceHelperCandidates = refreshed
    return refreshed.filter { $0.isInstalled }
}

@MainActor
final class HelperAlert: ObservableObject {
    static let shared = HelperAlert()
    @Published var showAlert: Bool = false
    private var continuation: CheckedContinuation<String?, Never>?

    func requestSelection() async -> String? {
        guard continuation == nil else { return nil }
        return await withCheckedContinuation { continuation in
            self.continuation = continuation
            self.showAlert = true
        }
    }

    func finishSelection(_ identifier: String?) {
        guard let continuation else { return }
        self.continuation = nil
        showAlert = false
        continuation.resume(returning: identifier)
    }
}
