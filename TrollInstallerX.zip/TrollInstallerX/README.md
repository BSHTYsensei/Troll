<div align="center">
    <h1>巨魔安装器（自定义构建）</h1>
    <img src="Resources/Icon.png" width="125" height="125" />
    <p>基于 TrollInstallerX · 运行时导入 TrollStore 2.1.1 安装资源</p>
</div>

## 定制内容

本项目是基于 TrollInstallerX 源码制作的定制分支。保留原项目的设备检测、kfd / dmaFail 安装路径和利用代码。安装器本身不再把 `TrollStore.tar` 作为 Xcode 必需资源；首次运行时从 iOS“文件”导入资源包。

- **运行时导入**：从 Files 导入 `.tar`、`.tar.gz` 或 `.tgz`，复制到安装器私有 Documents 目录。直接安装与间接安装流程均使用同一份导入文件。
- **自定义 ldid**：完整保留 `TrollStore.app/ldid-bootstrap/ldid`。其 SHA-256 为 `79af6331b7cd4c6ebf3f89284ce049450104e4a56dc5285017e83fc060901868`，与用户保存的 `TrollStore/bin/ldid` 相同。安装器不会下载或覆盖成上游 ldid。
- **自定义持久化助手**：`PersistenceHelper` 和 `trollstorehelper` 均来自用户提供的归档。安装时使用同一归档中的 helper 与 PersistenceHelper，并通过 `install-persistence-helper` 命令传入组件路径。
- **去除上游覆盖逻辑**：移除 TrollHelperOTA 页面及自动拉取上游 TrollStore 发布包的逻辑，避免升级流程静默替换为普通版本。
- **临时文件隔离**：直接安装只操作 `/private/preboot/tmp/TrollInstallerCustom`；间接安装只操作应用 Documents 下的 `TrollInstallerCustom` 子目录。不会删除整个 `/private/preboot/tmp`，也不会清理 Documents 根目录中的同名用户文件。
- **安装状态**：安装失败会返回失败，不再将 helper 安装失败或 TrollStore 安装失败误报为成功。持久化助手选择使用 Swift async continuation，不再主线程忙等。
- **子进程输出**：`run_binary` 在等待进程退出前持续读取 stderr，避免子进程写满管道后双方互相等待。

## 支持范围与限制

设备支持判断和漏洞利用范围沿用原 TrollInstallerX 的实现，没有新增利用或扩大支持范围。基础支持范围为 iOS 14.0–16.6.1；源码还保留了极少数 iOS 17.0 Beta build 的白名单。具体安装方式仍受 SoC、arm64 / arm64e、系统小版本和设备限制影响；A8、A15、A16、M2 的限制仍然有效。

部分系统版本需要取得对应 kernelcache。此定制分支移除了 TrollStore 本体更新和 TrollHelperOTA 网络路径，但**没有移除 kernelcache 获取逻辑**；未内置缓存且设备无法通过本地路径取得时，安装过程仍可能需要网络。

## 运行时安装资源

安装器编译阶段不会检查或引用 `TrollStore.tar`。首次安装前，用户需要在主界面选择由匹配版本 TrollStore 源码构建得到的归档。归档内容必须以 `TrollStore.app/` 为根，并至少包含：

```text
TrollStore.app/
├── Info.plist
├── TrollStore
├── PersistenceHelper
├── trollstorehelper
└── ldid-bootstrap/
    └── ldid
```

导入后，安装器会在设备上解压前限制归档根路径、拒绝绝对路径、`..`、符号链接/硬链接和特殊文件，并限制展开大小与文件数量；解压后再校验 Bundle ID、版本号及四个关键可执行文件的 SHA-256。`Scripts/validate_custom_payload.py` 可在开发机上手动检查归档，但不属于安装器构建流程。

## 构建

在 macOS 上使用包含 iOS SDK 的 Xcode，并准备宿主机可执行的 `ldid`：

```bash
./build.sh
```

构建脚本最后使用宿主 macOS 上的 `ldid` 为安装器写入 entitlements；这与 TrollStore 归档中的设备版 `ldid-bootstrap/ldid` 是两份不同用途的程序。也可以通过 `LDID_BIN=/绝对路径/ldid` 指定宿主机签名工具。成功后会生成 `TrollInstallerX.ipa`。本工程不要求 `TrollStore.tar` 存在，因此没有归档时也能编译安装器；但设备上实际安装 TrollStore 之前必须在应用界面导入有效归档。


### GitHub Actions / CI 根目录检查

如果 CI 报告 `Expected exactly one custom TrollInstallerX source root ... and embedded payload. Found: 0`，说明工作流仍在要求源码包内含有 `Resources/TrollStore.tar`。本分支采用运行时 Files 导入，普通编译不需要该文件。请删除旧的 payload-mandatory root finder，改用 `CI-ROOT-DISCOVERY-RUNTIME-PAYLOAD-FIX.md` 中的替换命令；该命令会调用 `Scripts/validate_custom_installer_root.py --print-root` 并验证恰好一个源码根目录。此工作流文件若位于上传 ZIP 之外，必须在仓库 CI YAML 中同步修改。

本源码包在 Linux 环境中完成归档、哈希、Swift 语法和 plist 静态检查；当前环境没有 Xcode / iOS SDK，因此未执行 Xcode 编译、真实设备漏洞利用或安装测试。

## 上游致谢与许可

本项目基于 [Alfie CG 的 TrollInstallerX](https://github.com/alfiecg24/TrollInstallerX) 修改。保留原项目 `LICENSE.md` 与 `CreditsView` 中的上游鸣谢；kfd、dmaFail、kernel patchfinder、MacDirtyCow 和其他组件仍归各自作者所有。请在再分发时一并保留许可证和相应署名。


## 运行时崩溃修复（2026-11-24）

- 修复安装页面日志列表为空时 `last!` 强制解包导致的首次布局崩溃。
- 设置页不再在 `@AppStorage` 初始化阶段创建自定义 Defaults suite；统一使用安全的 `UserDefaults.standard`，并尝试迁移旧设置。
- 日志模型的 UI 更新统一派发到主队列，删除后台线程触发 UIKit 触觉反馈的路径。
- 安装状态监听只在进入安装状态时启动任务，不会在状态退出时重复执行安装。
- 日志页面不再对 stdout 进行生命周期不稳定的 `dup2` 重定向；详细模式改为紧凑显示结构化安装日志。
- 新增 `Scripts/test_ui_crash_guards.py`，并接入 `build.sh` 与 GitHub Actions 的验证阶段。

本次在 Linux 环境完成 Swift 源码语法解析及静态回归检查；实际 iOS 设备运行和 Xcode 构建仍需在 macOS / iPhone 环境验证。

## 本轮安装 / 签名 / UI 修复（2026-11-25）

- 系统宿主应用候选会在提权完成后重新扫描；不再复用沙盒阶段初始化的旧路径。候选必须匹配系统应用 Bundle ID，并验证 `CFBundleExecutable`。
- 直接安装会把自定义 `PersistenceHelper` 与同一归档中的 `trollstorehelper` 路径明确传给 RootHelper；失败时输出 RootHelper 返回码和日志文本。
- 持久化助手界面显示 Bundle ID，采用卡片行布局，并可在允许的直接安装流程中选择跳过。
- 软件包列表换为自适应两行标题，避免长文件名被默认 Subtitle Cell 压缩为单字符省略号。
- 设置页、安装页之前的闪退保护继续保留。
- 新增 `Scripts/test_custom_installer_regressions.py` 与 `Scripts/update_custom_payload_hashes.py`。

### 与重新编译的 TrollStore 源码集成

`TrollStore/RootHelper/main.m` 的修复必须先在 TrollStore 源码工程中重新编译成新的二进制，再重新生成 `TrollStore.tar`。该 tar 不会自动嵌入安装器，用户在安装器中导入新归档即可。

在 TrollStore 源码根目录完成 Theos 构建：

```bash
make assemble_trollstore
```

重新编译 TrollStore 后，需在本源码目录手动运行以下命令更新运行时校验白名单；之后重新构建安装器源码，并在设备端导入该 tar：

```bash
python3 Scripts/update_custom_payload_hashes.py --no-copy /绝对路径/TrollStore/_build/TrollStore.tar
./build.sh
```

用户提供的设备版 ldid 的 Mach-O 最低系统版本为 iOS 16.0。TrollStore App 的最低部署目标与此 ldid 二进制的实际运行要求不同；iOS 14/15 设备需要重新构建兼容其系统版本的 ldid，不能只改最低版本字段。


## 文件提供商导入加固（2026-11-26）

运行时导入现通过 `NSFileCoordinator` 协调读取 Files / iCloud 文件，并在复制阶段验证普通文件属性、大小和符号链接状态。导入成功后仍须通过归档结构、版本和四个关键二进制 SHA-256 校验。

完整本轮修改与验证边界见 `PATCH-REPORT-2026-11-26-zh-Hans.md`。
