#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

# The installer no longer embeds TrollStore.tar. The payload is imported by
# the user at runtime, so a missing archive must not block building the IPA.
python3 Scripts/test_custom_installer_regressions.py
python3 -m py_compile Scripts/*.py
python3 Scripts/test_ui_crash_guards.py

if ! command -v xcodebuild >/dev/null 2>&1; then
  echo "error: xcodebuild is required; run this script on macOS with Xcode installed." >&2
  exit 1
fi

LDID_BIN="${LDID_BIN:-$(command -v ldid || true)}"
if [[ -z "$LDID_BIN" || ! -x "$LDID_BIN" ]]; then
  echo "error: ldid is required to sign the final installer. Install a host ldid or set LDID_BIN." >&2
  exit 1
fi

xcodebuild \
  -project TrollInstallerX.xcodeproj \
  -configuration Release \
  -derivedDataPath DerivedData/TrollInstallerX \
  -destination 'generic/platform=iOS' \
  -scheme TrollInstallerX \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY=""

PRODUCTS="$ROOT/DerivedData/TrollInstallerX/Build/Products/Release-iphoneos"
APP="$PRODUCTS/TrollInstallerX.app"
if [[ ! -d "$APP" ]]; then
  echo "error: Xcode did not produce TrollInstallerX.app at $APP" >&2
  exit 1
fi

cp "$ROOT/Resources/ents.plist" "$PRODUCTS/"
pushd "$PRODUCTS" >/dev/null
rm -rf Payload TrollInstallerX.ipa
mkdir -p Payload
cp -R TrollInstallerX.app Payload/
"$LDID_BIN" -Sents.plist Payload/TrollInstallerX.app
zip -qry TrollInstallerX.ipa Payload
rm -rf Payload
popd >/dev/null

cp "$PRODUCTS/TrollInstallerX.ipa" "$ROOT/TrollInstallerX.ipa"
echo "Built: $ROOT/TrollInstallerX.ipa"
