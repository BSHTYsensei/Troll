#!/usr/bin/env python3
"""Find and validate exactly one TrollInstallerX custom source root.

By default this accepts the documented runtime Files-import layout, which does
not contain Resources/TrollStore.tar. Pass --require-payload only for a release
that intentionally embeds a real, hash-validated TrollStore archive.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

REQUIRED = (
    Path("TrollInstallerX.xcodeproj/project.pbxproj"),
    Path("build.sh"),
    Path("Scripts/validate_custom_payload.py"),
    Path("Resources/ents.plist"),
    Path("PAYLOAD-SHA256.txt"),
)


def candidates(search_root: Path, require_payload: bool) -> list[Path]:
    matches: list[Path] = []
    for project_file in search_root.rglob("TrollInstallerX.xcodeproj/project.pbxproj"):
        root = project_file.parent.parent
        if not all((root / rel).is_file() for rel in REQUIRED):
            continue
        if require_payload and not (root / "Resources/TrollStore.tar").is_file():
            continue
        matches.append(root.resolve())
    # De-duplicate symlink aliases and nested traversal results.
    return sorted(set(matches))


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate the custom TrollInstallerX source root.")
    parser.add_argument("search_root", nargs="?", default=".", help="directory to search recursively")
    parser.add_argument("--require-payload", action="store_true", help="also require Resources/TrollStore.tar (release-only mode)")
    parser.add_argument("--print-root", action="store_true", help="print only the validated source-root path for CI command substitution")
    args = parser.parse_args()

    search_root = Path(args.search_root).expanduser().resolve()
    if not search_root.is_dir():
        print(f"[FAIL] search root is not a directory: {search_root}", file=sys.stderr)
        return 1

    found = candidates(search_root, args.require_payload)
    if len(found) != 1:
        mode = "with embedded payload" if args.require_payload else "with runtime Files import"
        print(f"[FAIL] expected exactly one custom TrollInstallerX source root {mode}; found {len(found)}", file=sys.stderr)
        for path in found:
            print(path, file=sys.stderr)
        return 1

    root = found[0]
    if args.print_root:
        print(root)
        return 0
    print(f"[OK] TrollInstallerX source root: {root}")
    if not args.require_payload:
        print("[OK] runtime Files-import mode: embedded TrollStore.tar is intentionally optional")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
