#!/usr/bin/env bash
set -euo pipefail

# Runtime-import installer CI entry point.
# The source package intentionally does not contain Resources/TrollStore.tar;
# the user selects a matching archive from Files when the installer runs.
SEARCH_ROOT="${1:-${GITHUB_WORKSPACE:-$(pwd)}}"

if [[ ! -d "$SEARCH_ROOT" ]]; then
    echo "[FAIL] CI search root is not a directory: $SEARCH_ROOT" >&2
    exit 1
fi

VALIDATOR="$(find "$SEARCH_ROOT" \
    -type d \( -name .git -o -name DerivedData -o -name .build \) -prune -o \
    -type f -path '*/Scripts/validate_custom_installer_root.py' -print -quit)"

if [[ -z "$VALIDATOR" ]]; then
    echo "[FAIL] TrollInstallerX source-root validator not found under: $SEARCH_ROOT" >&2
    exit 1
fi

SOURCE_ROOT="$(python3 "$VALIDATOR" "$SEARCH_ROOT" --print-root)"
cd "$SOURCE_ROOT"

# This accepts the runtime Files-import manifest and deliberately does not
# enable embedded-archive mode.
python3 Scripts/validate_custom_payload.py
python3 Scripts/test_custom_installer_regressions.py
python3 -m py_compile Scripts/*.py
python3 Scripts/test_ui_crash_guards.py

printf '[OK] CI validation completed for: %s\n' "$SOURCE_ROOT"
