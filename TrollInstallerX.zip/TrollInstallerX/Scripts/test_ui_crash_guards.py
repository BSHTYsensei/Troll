#!/usr/bin/env python3
"""Regression checks for the installer UI crash paths reported by users."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read(relative: str) -> str:
    path = ROOT / relative
    if not path.is_file():
        raise SystemExit(f"[FAIL] Missing source file: {relative}")
    return path.read_text(encoding="utf-8")


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(f"[FAIL] {message}")
    print(f"[OK] {message}")


def main() -> None:
    defaults = read("TrollInstallerX/Models/Defaults.swift")
    settings = read("TrollInstallerX/UI/SettingsView.swift")
    log_view = read("TrollInstallerX/UI/LogView.swift")
    logger = read("TrollInstallerX/Models/Logger.swift")
    log_view = read("TrollInstallerX/UI/LogView.swift")
    main_view = read("TrollInstallerX/UI/MainView.swift")

    require("tixUserDefaults!" not in defaults, "Preferences store has no forced optional unwrap")
    require("UserDefaults.standard" in defaults, "Preferences have a safe standard-store fallback")
    require("@AppStorage" not in settings, "Settings view does not initialize a custom AppStorage suite")
    require("logger.logItems.last!" not in log_view, "Log view never force-unwraps an empty log list")
    require("stdoutItems.last!" not in log_view, "Log view does not force-unwrap the verbose output list")
    require("readabilityHandler" not in log_view and "dup2(" not in log_view,
            "Log view does not redirect process stdout through a view lifecycle")
    require("DispatchQueue.main.async" in logger, "Log publishing is marshalled to the main queue")
    require("UIImpactFeedbackGenerator" not in logger and "UINotificationFeedbackGenerator" not in logger,
            "Logger does not call UIKit feedback APIs from worker threads")
    require("guard installing, device.isSupported" in main_view and
            "let archivePath = selectedArchivePath" in main_view,
            "Install task only starts on entry and requires an imported archive")
    require("static func clear()" in logger and "Logger.clear()" in main_view,
            "A new install starts with a clean log instead of stale previous output")
    require("返回主界面" in log_view and "installationSucceeded" in log_view,
            "The completion screen reports success/failure and can return to the main screen")


if __name__ == "__main__":
    main()
