#!/usr/bin/env python3
"""Static regression tests for the custom TrollInstallerX host-selection flow."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

def read(rel: str) -> str:
    path = ROOT / rel
    if not path.is_file():
        raise SystemExit(f"[FAIL] missing source: {rel}")
    return path.read_text(errors="replace")

def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(f"[FAIL] {message}")
    print(f"[OK] {message}")

install_m = read("TrollInstallerX/Installer/install.m")
install_h = read("TrollInstallerX/Installer/install.h")
installed_app = read("TrollInstallerX/Models/InstalledApp.swift")
installation = read("TrollInstallerX/Installer/Installation.swift")
helper_view = read("TrollInstallerX/UI/PersistenceHelperView.swift")

require('find_path_for_app(NSString *appName, NSString *bundleIdentifier)' in install_m and
        '"/Applications", @"/System/Applications", @"/System/Library/CoreServices"' in install_m and
        'CFBundleIdentifier' in install_m and
        'stat(resolvedExecutable, &targetStat) == 0 && S_ISREG(targetStat.st_mode)' in install_m,
        "helper host discovery verifies bundle IDs in system app locations")
require('refreshPersistenceHelperCandidates()' in installed_app and
        'return refreshed.filter { $0.isInstalled }' in installed_app and
        'let newCandidates = getCandidates()' in installation and
        installation.index('let newCandidates = getCandidates()') > installation.index('post_kernel_exploit(iOS14)'),
        "candidate paths are refreshed after privilege escalation and unsandboxing")
require('installer_last_error' in install_m and 'installer_last_error' in install_h and
        'RootHelper returned %d' in install_m,
        "helper installation returns detailed RootHelper diagnostics")
require('@[@"install-persistence-helper", app, kInstallerPersistenceHelperPath, kInstallerHelperPath]' in install_m,
        "direct install passes the custom persistence and root-helper binaries explicitly")
build_script = read("build.sh")
hash_updater = read("Scripts/update_custom_payload_hashes.py")
extract_swift = read("TrollInstallerX/Installer/Extract.swift")
require("SWIFT_VALIDATOR" in hash_updater and "Extract.swift" in hash_updater and
        "expectedPayloadSHA256" in extract_swift,
        "payload updater refreshes the manual validator and runtime component hash pins")
project = read("TrollInstallerX.xcodeproj/project.pbxproj")
require("Scripts/validate_custom_payload.py" not in build_script and "Scripts/update_custom_payload_hashes.py" not in build_script and
        "TrollStore.tar in Resources" not in project and "path = TrollStore.tar" not in project,
        "installer compiles without a bundled TrollStore.tar or build-time payload validation")
require("fileImporter(" in read("TrollInstallerX/UI/MainView.swift") and
        "InstallerArchiveStore.importArchive(from:" in read("TrollInstallerX/UI/MainView.swift") and
        "NSFileCoordinator(filePresenter: nil)" in extract_swift and
        "isSymbolicLink != true" in extract_swift and
        "func extractTrollStore(archivePath: String)" in extract_swift and
        "func extractTrollStoreIndirect(archivePath: String)" in extract_swift and
        "func validateTrollStoreArchive(at archivePath: String)" in extract_swift and
        "validateTrollStoreArchive(at: archivePath)" in installation and
        "Bundle.main.url(forResource: \"TrollStore\", withExtension: \"tar\")" not in extract_swift,
        "direct and indirect installer paths consume a user-imported payload from Files")
require("archive_path_is_safe" in read("TrollInstallerX/Exploitation/libjailbreak/util.c") and
        "ARCHIVE_EXTRACT_SECURE_NODOTDOT" in read("TrollInstallerX/Exploitation/libjailbreak/util.c") and
        "archive_entry_symlink(entry)" in read("TrollInstallerX/Exploitation/libjailbreak/util.c"),
        "archive extraction rejects path traversal, links, and unexpected archive roots")
require("CFBundlePrimaryIcon" in installed_app and "UIImage(named: name, in: appBundle" in installed_app,
        "persistence-helper host rows resolve icon assets through their app bundle metadata")
require('不安装持久化助手' in helper_view and 'bundleIdentifier' in helper_view and
        'RoundedRectangle(cornerRadius: 16' in helper_view,
        "helper picker clearly identifies system hosts and presents an optional skip action")
print("[PASS] custom TrollInstallerX regression checks completed")
