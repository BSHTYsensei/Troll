#!/usr/bin/env python3
"""Static regression tests for the custom TrollInstallerX host-selection flow."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

def read(rel: str) -> str:
    path = ROOT / rel
    if not path.is_file():
        raise SystemExit(f"[FAIL] missing source: {rel}")
    return path.read_text(errors="replace")

def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(f"[FAIL] {message}")
    print(f"[OK] {message}")

install_m = read("TrollInstallerX/Installer/install.m")
install_h = read("TrollInstallerX/Installer/install.h")
installed_app = read("TrollInstallerX/Models/InstalledApp.swift")
installation = read("TrollInstallerX/Installer/Installation.swift")
helper_view = read("TrollInstallerX/UI/PersistenceHelperView.swift")

require('find_path_for_app(NSString *appName, NSString *bundleIdentifier)' in install_m and
        '"/Applications", @"/System/Applications", @"/System/Library/CoreServices"' in install_m and
        'CFBundleIdentifier' in install_m and
        'stat(resolvedExecutable, &targetStat) == 0 && S_ISREG(targetStat.st_mode)' in install_m,
        "helper host discovery verifies bundle IDs in system app locations")
require('refreshPersistenceHelperCandidates()' in installed_app and
        'return refreshed.filter { $0.isInstalled }' in installed_app and
        'let newCandidates = getCandidates()' in installation and
        installation.index('let newCandidates = getCandidates()') > installation.index('post_kernel_exploit(iOS14)'),
        "candidate paths are refreshed after privilege escalation and unsandboxing")
require('installer_last_error' in install_m and 'installer_last_error' in install_h and
        'RootHelper returned %d' in install_m,
        "helper installation returns detailed RootHelper diagnostics")
require('@[@"install-persistence-helper", app, kInstallerPersistenceHelperPath, kInstallerHelperPath]' in install_m,
        "direct install passes the custom persistence and root-helper binaries explicitly")
build_script = read("build.sh")
hash_updater = read("Scripts/update_custom_payload_hashes.py")
extract_swift = read("TrollInstallerX/Installer/Extract.swift")
require("SWIFT_VALIDATOR" in hash_updater and "Extract.swift" in hash_updater and
        "expectedPayloadSHA256" in extract_swift,
        "payload updater refreshes the manual validator and runtime component hash pins")
project = read("TrollInstallerX.xcodeproj/project.pbxproj")
require("Scripts/validate_custom_payload.py" in build_script and
        "Scripts/validate_custom_installer_root.py" in build_script and
        "Scripts/update_custom_payload_hashes.py" not in build_script and
        "--require-payload" not in build_script and
        "TrollStore.tar in Resources" not in project and "path = TrollStore.tar" not in project,
        "installer compiles without a bundled TrollStore.tar or build-time payload validation")
require("def candidates(" in read("Scripts/validate_custom_installer_root.py") and
        "--require-payload" in read("Scripts/validate_custom_payload.py"),
        "runtime-import source-root validation is available separately from opt-in embedded-payload validation")
require("if persistenceID.isEmpty" in installation and
        "继续安装 TrollStore" in installation and
        "let persistenceID = await HelperAlert.shared.requestSelection()" in installation,
        "explicitly skipping the optional Persistence Helper does not abort direct TrollStore installation")
require("is_persistence_helper_installed(pathPointer)" in installation and
        "系统持久化助手已经安装" in installation and
        "请打开对应宿主应用" in installation,
        "indirect install recognizes an existing healthy Persistence Helper and reports the next user action")
vnode = read("TrollInstallerX/Exploitation/libjailbreak/vnode.m")
require("[bundleIdentifier isEqualToString:expectedIdentifier]" in vnode and
        "lstat(markerPath.fileSystemRepresentation" in vnode and
        "lstat(backupPath.fileSystemRepresentation" in vnode and
        "installedMarkerStat" in vnode and "persistenceExecutableIsArm64" in vnode and
        "S_ISREG(originalExecutableStat.st_mode)" in vnode and
        "S_ISREG(infoStat.st_mode)" in vnode and
        "knownHostBundleIDs" in vnode and
        vnode.index('dictionaryWithContentsOfFile:infoPath') < vnode.index('vnode_unredirect_folder(mountPath.UTF8String, origToVData)', vnode.index('dictionaryWithContentsOfFile:infoPath')),
        "indirect host validation checks the selected bundle ID and inspects marker/backup while the vnode redirect is active")
require("fileImporter(" in read("TrollInstallerX/UI/MainView.swift") and
        "InstallerArchiveStore.importArchive(from:" in read("TrollInstallerX/UI/MainView.swift") and
        "NSFileCoordinator(filePresenter: nil)" in extract_swift and
        "isSymbolicLink != true" in extract_swift and
        "func extractTrollStore(archivePath: String)" in extract_swift and
        "func extractTrollStoreIndirect(archivePath: String)" in extract_swift and
        "func validateTrollStoreArchive(at archivePath: String)" in extract_swift and
        "validateTrollStoreArchive(at: archivePath)" in installation and
        "Bundle.main.url(forResource: \"TrollStore\", withExtension: \"tar\")" not in extract_swift,
        "direct and indirect installer paths consume a user-imported payload from Files")
require("archive_path_is_safe" in read("TrollInstallerX/Exploitation/libjailbreak/util.c") and
        "ARCHIVE_EXTRACT_SECURE_NODOTDOT" in read("TrollInstallerX/Exploitation/libjailbreak/util.c") and
        "archive_entry_symlink(entry)" in read("TrollInstallerX/Exploitation/libjailbreak/util.c"),
        "archive extraction rejects path traversal, links, and unexpected archive roots")
require("CFBundlePrimaryIcon" in installed_app and "UIImage(named: name, in: appBundle" in installed_app,
        "persistence-helper host rows resolve icon assets through their app bundle metadata")
require('不安装持久化助手' in helper_view and 'bundleIdentifier' in helper_view and
        'RoundedRectangle(cornerRadius: 16' in helper_view,
        "helper picker clearly identifies system hosts and presents an optional skip action")
require("bool vnode_redirection_is_active(void)" in read("TrollInstallerX/Exploitation/libjailbreak/vnode.h") and
        "writeVnodeRedirectionGuard" in vnode and "kern.bootsessionuuid" in vnode and "kern.boottime" in vnode and
        "bootIdentifier" in vnode and "parseHexVnodePointer" in vnode and
        "currentVData != redirectedVData" in vnode and
        "could not restore original app-container ownership" in vnode and
        vnode.index("writeVnodeRedirectionGuard") < vnode.index("kwrite64(to_vnode + 0xE0, redirectedVData)") and
        vnode.index("kwrite32(currentVData + 0x80, originalUID)") < vnode.index("kwrite64(vnode + 0xE0, orig)") and
        "lstat(backupPath.fileSystemRepresentation" in vnode and "installedMarkerStat" in vnode and
        "refusing to inspect app containers while a previous vnode redirect may still be active" in vnode and
        "guard !vnode_redirection_is_active()" in extract_swift and
        "阻止删除 TrollInstallerCustom 临时目录" in extract_swift,
        "vnode redirects persist a boot-scoped recovery guard, restore original ownership, and block destructive cleanup until mapping recovery or reboot")
print("[PASS] custom TrollInstallerX regression checks completed")
