# CI root discovery for runtime-import installers

This source package intentionally **does not contain** `Resources/TrollStore.tar`.
The installer imports a matching archive from Files at runtime. Its Xcode build
must not require or scan for a bundled archive.

The source root is present and contains the Xcode project, `build.sh`, both
validators, entitlements, and `PAYLOAD-SHA256.txt`. The older CI root finder
reported `Found: 0` because it additionally required an embedded `TrollStore.tar`.
That requirement contradicts runtime-import mode. Do not add an empty or fake
archive: it would only hide the discovery error and produce a non-installable
installer.

## Replace the old CI discovery step

Remove the inline finder/validator that requires `Resources/TrollStore.tar` and
replace it with this shell step (it discovers the actual source root, validates
that exactly one exists, and does not require a payload):

```bash
set -euo pipefail
VALIDATOR="$(find "$GITHUB_WORKSPACE" -type f -path '*/Scripts/validate_custom_installer_root.py' -print -quit)"
test -n "$VALIDATOR" || { echo 'TrollInstallerX root validator not found' >&2; exit 1; }
SOURCE_ROOT="$(python3 "$VALIDATOR" "$GITHUB_WORKSPACE" --print-root)"
cd "$SOURCE_ROOT"
python3 Scripts/validate_custom_payload.py
python3 Scripts/test_custom_installer_regressions.py
./build.sh
```

The root validator still requires exactly one source root with these files:

- `TrollInstallerX.xcodeproj/project.pbxproj`
- `build.sh`
- `Scripts/validate_custom_payload.py`
- `Resources/ents.plist`
- `PAYLOAD-SHA256.txt`

It only requires `Resources/TrollStore.tar` when explicitly invoked with
`--require-payload`, which is reserved for a release pipeline that intentionally
embeds an archive. The ordinary build does not use that option.

If the workflow that emitted the old error is stored outside this source ZIP,
that workflow file must be updated in the repository: changing a source ZIP
cannot rewrite a separate GitHub Actions YAML or an inline script that was not
included in the upload.

## Optional embedded-release mode

For a separate release job that intentionally embeds a real matching archive,
use:

```bash
python3 Scripts/validate_custom_installer_root.py . --require-payload
python3 Scripts/validate_custom_payload.py Resources/TrollStore.tar --require-payload
```

Do not use the embedded-release mode for the runtime Files-import build.
