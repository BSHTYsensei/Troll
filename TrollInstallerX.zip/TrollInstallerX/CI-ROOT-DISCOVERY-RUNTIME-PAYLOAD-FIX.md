# CI root discovery for runtime-import TrollInstallerX

This branch intentionally does **not** embed `Resources/TrollStore.tar`. The
archive is selected by the user from Files at runtime. Normal source-root
discovery and compilation must not require an embedded payload.

Replace the old CI finder that tests for `Resources/TrollStore.tar` or prints
`and embedded payload` with:

```bash
set -euo pipefail
CI_ENTRY="$(find "$GITHUB_WORKSPACE" \
  -type d \( -name .git -o -name DerivedData -o -name .build \) -prune -o \
  -type f -path '*/Scripts/ci_validate_custom_installer.sh' -print -quit)"
test -n "$CI_ENTRY"
bash "$CI_ENTRY" "$GITHUB_WORKSPACE"
```

The CI entry point resolves the single source root using
`Scripts/validate_custom_installer_root.py --print-root`, then validates the
runtime-import manifest and installer regression suite. It intentionally does
not pass `--require-payload`.

A workflow script stored outside this source package must be updated in the
repository. A ZIP cannot alter an external workflow step that fails before it
runs any code from the ZIP.

For a separate release that deliberately embeds a real, matching tar, validate
it explicitly with:

```bash
python3 Scripts/validate_custom_installer_root.py . --require-payload
python3 Scripts/validate_custom_payload.py Resources/TrollStore.tar --require-payload
```

Do not create an empty or placeholder tar to satisfy root discovery.
