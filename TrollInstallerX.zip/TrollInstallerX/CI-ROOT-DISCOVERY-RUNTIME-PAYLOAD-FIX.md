# CI root discovery for runtime-import installers

This source package intentionally **does not contain** `Resources/TrollStore.tar`.
The installer imports a release-matched archive from Files at runtime, validates
its manifest/version and SHA-256 hashes, and only then extracts it. The Xcode
build therefore must not require a tar file.

The previous CI root finder reported `Found: 0` because it defined a valid
source root as one that also contained an embedded payload. That requirement
contradicts runtime-import mode. The root itself is present and contains:

- `TrollInstallerX.xcodeproj/project.pbxproj`
- `build.sh`
- `Scripts/validate_custom_payload.py`
- `Resources/ents.plist`
- `PAYLOAD-SHA256.txt` (documents runtime Files import)

Replace the old payload-mandatory root check with:

```bash
python3 Scripts/validate_custom_installer_root.py .
python3 Scripts/validate_custom_payload.py
```

`validate_custom_payload.py` validates the runtime-import contract when no tar
is present. On a release job that intentionally embeds an archive, use:

```bash
python3 Scripts/validate_custom_installer_root.py . --require-payload
python3 Scripts/validate_custom_payload.py Resources/TrollStore.tar --require-payload
```

Do not create an empty or placeholder `TrollStore.tar` to satisfy root discovery:
it is not installable and runtime validation must reject it. A real embedded
payload must be produced from the matching TrollStore build and hash manifest.

The workflow that emitted the old error is not included in this source archive,
so its external root-finder step must be changed to use the validator above.

## Persistence-helper redirect recovery

The indirect installer also writes a boot-session recovery marker beside the
`mount` directory before changing a vnode mapping. It restores the mapped
container's original UID/GID before restoring `v_data`, verifies both changes,
and removes the marker only after successful recovery. If recovery cannot be
verified, cleanup intentionally preserves `TrollInstallerCustom` and refuses
new vnode operations until a reboot changes the boot-session identifier. This
prevents a failed cleanup from deleting the system application's redirected
bundle through the temporary mount path.
