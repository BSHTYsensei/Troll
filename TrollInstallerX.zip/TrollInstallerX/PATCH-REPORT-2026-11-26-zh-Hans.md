# TrollInstallerX 源码修复报告（2026-11-26）

## 核心目标：构建阶段不依赖 TrollStore.tar

- 从 Xcode 工程资源引用中移除了 `TrollStore.tar`；工程可以在没有该文件时进入正常编译流程。
- `build.sh` 不再运行构建前的归档存在性/内容验证，也不再复制内置 tar。构建最终 IPA 仍需要 macOS Xcode 和宿主机 `ldid`。
- 安装器运行时提供 Files 文件选择器，导入 `.tar`、`.tar.gz`、`.tgz`，拷贝到安装器私有 Documents 并记住所选归档；直接安装与间接安装都使用同一个导入路径。
- 导入读取使用 security-scoped access 和 `NSFileCoordinator`，拒绝符号链接/非普通文件，限制归档大小 128 MiB，复制后再做完整校验。
- 安装前会在临时目录安全解压并验证归档根目录、Bundle ID、版本及四个关键组件 SHA-256；校验失败不会进入漏洞利用/安装步骤。

## 归档安全

`libarchive_unarchive` 只接受 `TrollStore.app/` 根目录下的普通目录和普通文件，拒绝绝对路径、路径穿越、符号链接、硬链接和特殊文件；使用安全解压标志，并将展开数据限制为 128 MiB、条目数量限制为 8192。安装后的必需文件再次检查为普通文件。

## 重要：修改后的 TrollStore 二进制需要更新哈希白名单

本安装器源码当前包含的是原基线 TrollStore 2.1.1 资源的 SHA-256 固定值。因为本次同时修改了 TrollStore 主应用源码，后续重新编译生成的新 `TrollStore.tar` 中二进制哈希会变化。**不能关闭哈希校验，也不能直接拿旧白名单安装新 tar。**

先在 TrollStore 主工程中生成新的 tar，然后在本安装器源码目录执行：

```bash
python3 Scripts/update_custom_payload_hashes.py --no-copy /绝对路径/TrollStore/_build/TrollStore.tar
```

该脚本会验证 tar 根目录、版本、四个 arm64 Mach-O 可执行文件，再更新开发机验证器、Swift 运行时校验哈希和 SHA-256 manifest。完成后再运行 `./build.sh` 构建新的安装器。`.zip` 源码包本身不包含 `TrollStore.tar`。

## 检查结果

以下检查通过：

- `Scripts/test_custom_installer_regressions.py`
- `Scripts/test_ui_crash_guards.py`
- 所有脚本的 Python 字节码编译检查
- `bash -n build.sh`
- 对所有 Swift 文件执行 `swiftc -frontend -parse`
- Xcode project 与 entitlements plist 的 `plutil -lint`
- 确认 Xcode 工程资源中不再引用 `TrollStore.tar`

## 未验证项目

当前环境没有 `xcodebuild`、Apple iOS SDK 和可用 iPhone，因此本包是源码包，不是已编译的 `TrollInstallerX.ipa`。没有完成 Xcode 真正编译、漏洞利用、安装成功率、系统版本兼容或真机 UI 测试。最终构建仍需在 macOS + Xcode 环境执行 `./build.sh`。

## 本次 CI 根目录扫描错误的进一步修复

CI 日志中的 `Found: 0` 并非 Xcode 工程丢失：本 ZIP 的根目录、Xcode 工程、`build.sh`、validator、entitlements 和运行时导入清单均存在。错误来自 ZIP 外的旧 CI 扫描器，它还要求源码根目录包含 `Resources/TrollStore.tar`，这与运行时 Files 导入设计矛盾。

- `Scripts/validate_custom_installer_root.py` 新增 `--print-root`，供 CI 安全地取得唯一通过验证的源码根目录。
- `CI-ROOT-DISCOVERY-RUNTIME-PAYLOAD-FIX.md` 增加可直接替换旧扫描步骤的命令：从 workspace 找 validator，执行不要求 tar 的根目录验证，再运行普通 payload 契约检查和 `build.sh`。
- 保留显式 `--require-payload`，但仅供确实要制作 embedded-payload release 的工作流使用。
- 没有创建空文件、伪造 tar 或放宽设备端安装资源的 SHA-256 校验。

**外部 CI 工作流仍需修改：** 原工作流 YAML / inline finder 不在用户上传的 `TrollInstallerX.zip` 中，无法从本源码 ZIP 内更改它。必须将其旧的“必须包含 embedded payload”的查找段替换为报告中的新命令。当前源码包内的根目录验证器和构建脚本本身已通过测试。

验证：`validate_custom_installer_root.py .`、`--print-root`、`validate_custom_payload.py`（无 tar 运行时模式）、安装器回归及 UI crash guard 测试均通过。
